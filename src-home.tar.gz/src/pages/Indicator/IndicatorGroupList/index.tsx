import React, { Component } from 'react';
import { Provider, inject } from 'mobx-react';
import { RouteComponentProps } from 'react-router-dom';

import ThemeTree from './containers/ThemeTree/ThemeTree';
import GroupContent from './containers/GroupContent';

import IndicatorGroupStore from './stores/indicatorGroup.store';

import styles from './index.less';

interface IProps extends RouteComponentProps {
  global?: any;
  managerStore?: any;
}
interface IState {}

@inject('global')
class IndicatorGroup extends Component<IProps, IState> {
  private readonly indicatorGroupStore: any;
  public constructor(props: IProps) {
    super(props);
    this.indicatorGroupStore = new IndicatorGroupStore(props.global, {
      history: props.history
    });
  }

  public render() {
    return (
      <Provider indicatorGroupStore={this.indicatorGroupStore}>
        <div className={styles.groupWrapper}>
          <ThemeTree />
          <GroupContent />
        </div>
      </Provider>
    );
  }
}

export default IndicatorGroup;
