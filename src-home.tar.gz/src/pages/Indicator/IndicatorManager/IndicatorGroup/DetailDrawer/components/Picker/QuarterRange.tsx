import React, { Component } from 'react';
import { Cascader } from 'sup-ui';
import moment from 'moment';

import { genYears } from '@utils/indicator';
import styles from './index.less';

interface IProps {
  onChange: any;
}
interface IState {
  options: any[];
  start: any[];
  defaultStart: any[];
  end: any[];
  defaultEnd: any[];
}
class QuarterRange extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      options: genYears(),
      start: [],
      defaultStart: [],
      end: [],
      defaultEnd: []
    };
  }

  public formatQuarter = () => {
    const { start, end } = this.state;
    let s = null,
      e = null;

    if (start.length) {
      const [sy, sq] = start;
      s = moment(`${sy}-01-01`).quarter(sq).hour(0);
    }

    if (end.length) {
      const [ey, eq] = end;
      e = moment(`${ey}-01-01`)
        .quarter(eq - 0 + 1)
        .hour(0)
        .subtract(1, 's');
    }

    this.props.onChange([s, e]);
  };

  public handleStartChange = (start: any) => {
    this.setState(
      {
        start
      },
      () => {
        this.formatQuarter();
      }
    );
  };

  public handleEndChange = (end: any) => {
    this.setState(
      {
        end
      },
      () => {
        this.formatQuarter();
      }
    );
  };

  public render() {
    const { options, start, defaultStart, end, defaultEnd } = this.state;

    return (
      <div className={styles.quarterRange}>
        <Cascader
          value={start.length !== 2 ? defaultStart : start}
          options={options}
          className={start.length !== 2 ? styles.cascaderLabel : ''}
          onPopupVisibleChange={value => {
            // 打开选择框定位到当前年
            if (value) {
              this.setState({
                defaultStart: [moment().year(), `${moment().quarter()}`]
              });
            } else if (start.length !== 2) {
              this.setState({ defaultStart: [] });
            }
          }}
          onChange={this.handleStartChange}
          placeholder="开始时间"
          allowClear={true}
        />
        <p>~</p>
        <Cascader
          value={end.length !== 2 ? defaultEnd : end}
          options={options}
          className={end.length !== 2 ? styles.cascaderLabel : ''}
          onPopupVisibleChange={value => {
            // 打开选择框定位到当前年
            if (value) {
              this.setState({
                defaultEnd: [moment().year(), `${moment().quarter()}`]
              });
            } else if (end.length !== 2) {
              this.setState({ defaultEnd: [] });
            }
          }}
          onChange={this.handleEndChange}
          placeholder="结束时间"
          allowClear={true}
        />
      </div>
    );
  }
}

export default QuarterRange;
