import React, { Component, Fragment } from 'react';
import { Spin, message, Input } from 'sup-ui';
import styles from '../index.less';

interface IProps {
  value?: string;
  onChange?: any;
  item: any;
  loadData: any;
  dataParams?: any;
}
interface IState {
  loading: boolean;
  list: any[];
  pageIndex: number;
  pageSize: number;

  disableFetch: boolean;
  selectMenu: boolean;
}

class Selector extends Component<IProps, IState> {
  private inputRef: any;
  private onSearch: any;
  public constructor(props: IProps) {
    super(props);
    this.state = {
      loading: false,
      list: [],
      pageIndex: 1,
      pageSize: 20,
      disableFetch: false,
      selectMenu: false
    };

    this.inputRef = React.createRef();
    this.onSearch = _.debounce(this.handleInputSearch, 500);
  }

  public async fetchData() {
    const { disableFetch, pageSize, pageIndex } = this.state;

    if (disableFetch) {
      return;
    }
    const { loadData, dataParams, value } = this.props;
    this.setState({
      loading: true
    });

    const params = {
      ...dataParams,
      keyword: value,
      pageIndex,
      pageSize
    };

    const res = await loadData(params);

    if (res.code !== 200) {
      message.error(res.message);
      this.setState({
        loading: false
      });

      return;
    }

    if (res.data.list.length < this.state.pageSize) {
      this.setState({
        disableFetch: true
      });
    }

    this.setState(prevState => ({
      loading: false,
      list: prevState.list.concat(res.data.list)
    }));
  }

  public handleInputChange = (e: any) => {
    const { value } = e.target;
    this.props.onChange(value);

    this.onSearch();
  };

  public handleInputSearch = () => {
    this.setState(
      {
        list: [],
        pageIndex: 1,
        disableFetch: false
      },
      () => {
        this.fetchData();
      }
    );
  };

  public handleFocus = () => {
    const { list } = this.state;

    this.setState({
      selectMenu: true
    });

    if (list.length === 0) {
      this.fetchData();
    }
  };

  public handleBlur = () => {
    this.setState({ selectMenu: false });
  };

  public handleScroll = (e: any) => {
    const { list, loading } = this.state;

    if (list.length === 0 || loading) {
      return;
    }

    const {
      target: { scrollTop, scrollHeight, offsetHeight }
    } = e;

    if (scrollTop + offsetHeight + 2 >= scrollHeight) {
      this.setState(
        prevState => ({
          pageIndex: prevState.pageIndex + 1
        }),
        () => {
          this.fetchData();
        }
      );
    }
  };

  public handleLiClick = (value: any) => {
    const { onChange } = this.props;
    this.inputRef.current.blur();
    onChange(value);
  };

  public render() {
    const { value } = this.props;
    const { list, loading, selectMenu } = this.state;

    return (
      <Fragment>
        <Input
          placeholder="-请选择-"
          onFocus={this.handleFocus}
          onChange={this.handleInputChange}
          onBlur={this.handleBlur}
          ref={this.inputRef}
          value={value}
        />

        {selectMenu ? (
          <ul className={styles.autoList} onScroll={this.handleScroll}>
            <Spin spinning={loading}>
              {_.map(list, (item: any) => (
                <li
                  key={item.id}
                  onMouseDown={(e: any) => e.preventDefault()}
                  onClick={() => {
                    this.handleLiClick(item.value);
                  }}
                  className={value === item.value ? styles.active : null}
                >
                  {item.value}
                </li>
              ))}
            </Spin>
          </ul>
        ) : null}
      </Fragment>
    );
  }
}

export default Selector;
