import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { DatePicker } from 'sup-ui';
import moment from 'moment';
import QuarterRange from './QuarterRange';
import WeekRange from './WeekRange';

const { RangePicker } = DatePicker;

const disabledDate = (current: any) => {
  return current && current > moment().endOf('day');
};

const typeMap: any = {
  1: 'year',
  3: 'month',
  5: 'date',
  6: 'hour',
  7: 'minute',
  9: 'second'
};
const modeMap: any = {
  1: ['year', 'year'],
  3: ['month', 'month']
};
const timeMap: any = {
  1: ['', 'YYYY'],
  3: ['', 'YYYY-MM'],
  5: ['', 'YYYY-MM-DD'],
  6: ['HH', 'YYYY-MM-DD HH时'],
  7: ['HH:mm', 'YYYY-MM-DD HH:mm'],
  9: ['HH:mm:ss', 'YYYY-MM-DD HH:mm:ss']
};

interface IProps {
  value?: any;
  onChange?: any;
  type: string; //类型 1year, 2quarter, 3month, 4week, 5date, 6hour, 7minute, 9second
  timeOffset: any;
}
interface IState {
  mode: string[];
  open: boolean;
  format: string;
  showTime: any;
  value: any;
}

@observer
class Picker extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    const { type } = props;
    const mode = modeMap[props.type] || ['date', 'date'];
    const [timeF, format = ''] = timeMap[type] || [];
    const showTime = _.includes(['6', '7', '9'], type) && { format: timeF };

    this.state = {
      open: false,
      mode,
      showTime,
      format,
      value: undefined
    };
  }

  public handleRangeChange = (value: any) => {
    this.setState({
      value
    });

    const v = this.formatMoment(value);
    this.props.onChange(v);
  };

  public handlePanelChange = (value: any) => {
    this.setState({
      open: false,
      value
    });

    const v = this.formatMoment(value);
    this.props.onChange(v);
  };

  public formatMoment = ([s, e]: any) => {
    //将RangePicker的值格式化为精准范围值
    const t = typeMap[this.props.type];
    const start = s ? moment(s).startOf(t) : null;
    const end = e ? moment(e).endOf(t) : null;

    return [start, end];
  };

  public render() {
    const { open, mode, showTime, format, value } = this.state;
    const { type, timeOffset, onChange } = this.props;

    switch (type) {
      case '2':
        return <QuarterRange onChange={onChange} />;
      case '4':
        return <WeekRange timeOffset={timeOffset} onChange={onChange} />;
      default:
        return (
          <RangePicker
            open={open}
            mode={mode}
            value={value}
            allowClear={true}
            format={format}
            showTime={showTime}
            disabledDate={disabledDate}
            placeholder={['开始时间', '结束时间']}
            onChange={this.handleRangeChange}
            onOpenChange={visible => this.setState({ open: visible })}
            onPanelChange={this.handlePanelChange}
          />
        );
    }
  }
}

export default Picker;
