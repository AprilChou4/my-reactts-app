import React, { Component, Fragment } from 'react';
import { observer } from 'mobx-react';
import { Popover, Button } from 'sup-ui';
import { RouteComponentProps } from 'react-router-dom';
import classnames from 'classnames';

import Header from '@components/Header';
import Icon from '@components/Icon';
import BloodSanKey from './BloodSanKey';
import IndicatorMode from './IndicatorMode';
import ObjectMode from './ObjectMode';
import ManagerStore from './stores/manager.store';
import styles from './index.less';

const tabs = [
  { key: 'indicator', name: '指标模式' }
  // { key: 'object', name: '对象模式' }
];

interface IProps extends RouteComponentProps {}

interface IState {
  themeBloodVisible: boolean;
}

@observer
class IndicatorManager extends Component<IProps, IState> {
  private readonly store: ManagerStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new ManagerStore(props.history);
    this.state = {
      themeBloodVisible: false
    };
  }

  private handleThemeBloodVisible = (cacheDataVisible: boolean) => {
    if (cacheDataVisible) {
      this.store.checkThemeBlood();
    }
    this.setState({
      themeBloodVisible: cacheDataVisible
    });
  };

  public render() {
    const {
      mode,
      title,
      switchMode,
      updateInfo,
      loadMap: { indicator, object },
      showJumpBtn,
      handlePageJump,
      themeBloodLoading,
      themeBloodData
    } = this.store;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <div className={styles.tabs}>
            {tabs.map(tab => (
              <p
                className={`${mode === tab.key ? styles.active : ''}`}
                key={tab.key}
                onClick={() => switchMode(tab.key)}
              >
                {tab.name}
              </p>
            ))}
          </div>
          <Header
            className={styles.head}
            left={title}
            right={
              showJumpBtn && (
                <Fragment>
                  <div
                    className={styles.headerBtn}
                    onClick={() => handlePageJump('theme')}
                  >
                    主题定义
                  </div>
                  <div
                    className={classnames(styles.headerBtn, styles.last)}
                    onClick={() => handlePageJump('definition')}
                  >
                    指标定义
                  </div>
                  <Popover
                    placement="bottom"
                    overlayClassName={styles.popoverWrapper}
                    content={
                      <BloodSanKey
                        loading={themeBloodLoading}
                        title={''}
                        data={themeBloodData}
                      />
                    }
                    trigger="click"
                    visible={this.state.themeBloodVisible}
                    onVisibleChange={this.handleThemeBloodVisible}
                  >
                    <Button ghost type="primary" className={styles.jumpBtn}>
                      <Icon type="blood" style={{ verticalAlign: '-2px' }} />
                    </Button>
                  </Popover>
                </Fragment>
              )
            }
          />
        </div>
        {indicator && (
          <div
            className={styles.content}
            style={{ display: mode === 'indicator' ? 'block' : 'none' }}
          >
            <IndicatorMode
              history={this.props.history}
              onChange={(info: any) => updateInfo('indicator', info)}
            />
          </div>
        )}
        {object && (
          <div
            className={styles.content}
            style={{ display: mode === 'object' ? 'block' : 'none' }}
          >
            <ObjectMode
              history={this.props.history}
              onChange={(info: any) => updateInfo('object', info)}
            />
          </div>
        )}
      </div>
    );
  }
}

export default IndicatorManager;
