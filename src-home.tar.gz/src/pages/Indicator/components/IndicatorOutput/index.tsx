import React, { Component, Fragment } from 'react';
import { Spin, Radio, Switch, Form, message } from 'sup-ui';

import TempOutput from './TempOutput';
import InstOutput from './InstOutput';

const FormItem = Form.Item;

interface IProps {
  getFieldDecorator: any;
  setFieldsValue: any;
  outType: string; // 输出的类型 模板|实例
  // 配置信息
  config: {
    service: any;
    template: any;
    instance: any;
    attribute: any;
  };
  // 输出的权限，由外层控制，当且仅当有数据权限的时候才会加载指标输出组件
  outputAuth: {
    model?: boolean;
    instance?: boolean;
    templateInfoList?: any[];
  };
  // 外部指标的配置信息，当是属性创建时，属性的名称和别名与指标的名称别名相同
  indicatorInfo: {
    name: string;
    otherName: string;
    dataType: string;
    decimalNumber: number;
  };
}

interface IState {
  isOutput: boolean;
  outType: string;
  isMounted: boolean;
  config: any;
}

class IndicatorOutput extends Component<IProps, IState> {
  private tempRef: any;
  private instRef: any;
  public constructor(props: IProps) {
    super(props);
    /**
     * @param {boolean} isOutput 是否打开输出开关量 默认false
     * 当有输出权限 并且已经配置过输出信息 显示true
     * 有输出权限但是没有配置，显示 false , 需要用户手动开启
     */
    this.state = {
      isOutput: false,
      outType: '',
      isMounted: false,
      config: {}
    };
  }

  /**
   * @description: 当获取输出权限之后，需要初始化页面配置
   * 已经配置过的信息 与 输出权限信息 可能存在不一致的情况，需要重置配置信息
   * ps: 该处仅重置显示
   */
  private init = () => {
    if (!this.state.isMounted) {
      const { outputAuth, config, outType } = this.props;
      let stateConfig: any = {};
      // 当已存在配置的信息，则判断已配置的信息是否与可输出的权限信息是否一致
      // 不一致，需要重置配置信息
      if (!_.isEmpty(config)) {
        // 当输出权限为输出到模板，则需要判断 输出到权限模板的信息 是否与 已配置输出到模板的信息一致
        // ps: 输出到模板 需要输出到同一个模板下
        if (outputAuth.model) {
          if (`${outType}` === '1') {
            if (
              _.some(
                outputAuth.templateInfoList,
                item => item.templateEnName === config.template.enName
              )
            ) {
              stateConfig = _.cloneDeep(config);
            }
          }
        } else if (outputAuth.instance) {
          // 输出到实例没有硬性要求，只要判断是否是输出到实例即可
          if (`${outType}` === '2') {
            stateConfig = _.cloneDeep(config);
          }
        } else {
          // 如果已经存在配置，但没有输出权限，则需要重置配置
          stateConfig = {};
        }

        if (_.isEmpty(stateConfig)) {
          message.warning('已配置输出信息与输出权限不一致，建议重新配置！');
        }
      }
      this.setState({
        isOutput:
          (!!outputAuth.model || !!outputAuth.instance) && !_.isEmpty(config), // 是否输出
        outType: outputAuth.model ? '1' : outputAuth.instance ? '2' : '',
        isMounted: true,
        config: stateConfig
      });
    }
  };

  public async getValue() {
    const { isOutput, outType } = this.state;
    const { outputAuth } = this.props;
    // 如果指标不输出，或者没有权限输出，或者没有选择输出类型
    if (!isOutput || (!outputAuth.model && !outputAuth.instance) || !outType) {
      return {
        outType: undefined,
        outputType: undefined,
        outputInfo: undefined,
        extraConfig: undefined
      };
    }
    if (outType === '1') {
      const params = await this.tempRef.getValue();
      if (params) {
        return { ...params, outType };
      } else {
        return false;
      }
    } else if (outType === '2') {
      const params = await this.instRef.getValue();
      if (params) {
        return { ...params, outType };
      } else {
        return false;
      }
    }
  }

  private handleSwitchOut = (check: boolean) => {
    this.setState({
      isOutput: check
    });
  };

  private handleChangeOutput = (e: any) => {
    this.setState({
      outType: e.target.value
    });
  };

  public render() {
    const { outputAuth, getFieldDecorator, setFieldsValue, indicatorInfo } =
      this.props;
    const { isOutput, outType, config } = this.state;
    const auth = outputAuth.model || outputAuth.instance;
    return (
      <div style={{ position: 'relative' }}>
        {_.isEmpty(outputAuth) ? (
          <Spin spinning={true} />
        ) : (
          <div
            ref={() => {
              this.init();
            }}
          >
            <FormItem label="指标输出">
              <Switch
                checked={auth ? isOutput : false}
                disabled={!outputAuth.model && !outputAuth.instance}
                onChange={this.handleSwitchOut}
              />
            </FormItem>
            {auth && isOutput && (
              <Fragment>
                <FormItem label="指标输出类型">
                  {getFieldDecorator('outType', {
                    initialValue: outType
                  })(
                    <Radio.Group onChange={this.handleChangeOutput}>
                      <Radio value="1" disabled={!outputAuth.model}>
                        对象模板
                      </Radio>
                      <Radio value="2" disabled={!outputAuth.instance}>
                        对象实例
                      </Radio>
                    </Radio.Group>
                  )}
                </FormItem>
                {outType === '1' && (
                  <TempOutput
                    ref={(ref: any) => {
                      this.tempRef = ref;
                    }}
                    getFieldDecorator={getFieldDecorator}
                    setFieldsValue={setFieldsValue}
                    templateList={outputAuth.templateInfoList || []}
                    config={config}
                    indicatorInfo={indicatorInfo}
                  />
                )}
                {outType === '2' && (
                  <InstOutput
                    ref={(ref: any) => {
                      this.instRef = ref;
                    }}
                    getFieldDecorator={getFieldDecorator}
                    setFieldsValue={setFieldsValue}
                    config={config}
                    indicatorInfo={indicatorInfo}
                  />
                )}
              </Fragment>
            )}
          </div>
        )}
      </div>
    );
  }
}

export default IndicatorOutput;
