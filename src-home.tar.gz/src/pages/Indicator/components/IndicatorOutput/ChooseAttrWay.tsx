import React, { FunctionComponent } from 'react';
import { Radio, Form } from 'sup-ui';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;

interface IProps {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}

const ChooseAttrWay: FunctionComponent<IProps> = (props: IProps) => {
  const { value, disabled = false, onChange } = props;
  return (
    <FormItem label="属性选择">
      <RadioGroup
        value={value}
        disabled={disabled}
        onChange={(e: any) => {
          onChange(e.target.value);
        }}
      >
        <Radio value="create">属性创建</Radio>
        <Radio value="choose">属性选择</Radio>
      </RadioGroup>
    </FormItem>
  );
};

export default ChooseAttrWay;
