import React, { FunctionComponent } from 'react';
import { Form, Select } from 'sup-ui';

const { Option } = Select;
const FormItem = Form.Item;

const attrTypes = ['DOUBLE', 'LONG', 'FLOAT', 'INTEGER'];

interface IProps {
  initValue: string;
  onChange: (value: string) => void;
  getFieldDecorator: any;
  disabled?: boolean;
}

const AttrType: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, initValue, disabled = false, onChange } = props;
  return (
    <FormItem label="属性类型" style={{ width: '245px' }}>
      {getFieldDecorator('attrType', {
        initialValue: initValue,
        rules: [{ required: true }]
      })(
        <Select disabled={disabled} onChange={onChange}>
          {_.map(attrTypes, item => (
            <Option value={item} key={item}>
              {item}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default AttrType;
