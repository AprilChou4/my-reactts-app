import React, { Component, Fragment } from 'react';
import { Form, Radio } from 'sup-ui';

import TimeOption from './TimeOption';
import CycleMinute from './CycleMinute';

import { hourList } from '../indicatorRuleConfig.helper';

import styles from './common.less';

interface IProps {
  form: any;
  ruleInfo: any;
  updateHourRule: (rule: boolean) => void;
}
interface IState {
  help: string;
  hourType: string;
  validateStatus: any;
}

const FormItem = Form.Item;

class CycleHour extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const { ruleInfo } = props;
    this.state = {
      hourType: _.get(ruleInfo, 'hourType', '1'),
      validateStatus: '',
      help: ''
    };
  }

  public updateHourRule = ({
    help,
    validateStatus,
    status
  }: {
    help: string;
    validateStatus: string;
    status: boolean;
  }) => {
    this.setState({
      validateStatus,
      help
    });
    this.props.updateHourRule(status);
  };

  public handleChange = (e: any) => {
    const {
      target: { value }
    } = e;

    this.setState(
      {
        hourType: value
      },
      () => {
        if (this.state.hourType === '1') {
          this.updateHourRule({ help: '', status: false, validateStatus: '' });
        } else {
          const { appointHour } = this.props.form.getFieldsValue();

          if (!appointHour.length) {
            this.updateHourRule({
              help: '请选择指定时间',
              status: true,
              validateStatus: 'error'
            });
          }
        }
      }
    );
  };

  public handleHourChange = (value: any) => {
    if (!value.length) {
      this.updateHourRule({
        help: '请选择指定时间',
        status: true,
        validateStatus: 'error'
      });
    } else {
      this.updateHourRule({
        help: '',
        status: false,
        validateStatus: ''
      });
    }
  };

  public render() {
    const { help, hourType, validateStatus } = this.state;
    const {
      form,
      ruleInfo,
      form: { getFieldDecorator }
    } = this.props;
    const optionDisabled = hourType === '1';
    return (
      <div className={styles.hour}>
        <FormItem>
          {getFieldDecorator('hourType', {
            initialValue: hourType
          })(
            <Radio.Group onChange={this.handleChange}>
              <Fragment>
                <Radio value={'1'} />
                <CycleMinute
                  form={form}
                  disabled={!optionDisabled}
                  ruleInfo={ruleInfo}
                />
              </Fragment>
              <Fragment>
                <Radio value={'2'} />
                <FormItem
                  label="指定时间"
                  className={`${styles.item} ${styles.appointHour}`}
                  help={help}
                  validateStatus={validateStatus}
                >
                  {getFieldDecorator('appointHour', {
                    initialValue: _.get(ruleInfo, 'appointHour', ['0'])
                  })(
                    <TimeOption
                      mode="tags"
                      list={hourList}
                      disabled={optionDisabled}
                      onChange={this.handleHourChange}
                    />
                  )}
                </FormItem>
              </Fragment>
            </Radio.Group>
          )}
        </FormItem>
      </div>
    );
  }
}

export default CycleHour;
