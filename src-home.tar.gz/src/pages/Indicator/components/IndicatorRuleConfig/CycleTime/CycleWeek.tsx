import React, { FunctionComponent, Fragment } from 'react';
import { Form } from 'sup-ui';

import { weekList, startMinute } from '../indicatorRuleConfig.helper';

import TimeOption from './TimeOption';

interface IProps {
  form: any;
  ruleInfo: any;
}

const FormItem = Form.Item;

const CycleWeek: FunctionComponent<IProps> = (props: IProps) => {
  const {
    ruleInfo,
    form: { getFieldDecorator }
  } = props;

  return (
    <Fragment>
      <FormItem label="指定时间">
        {getFieldDecorator('appointWeek', {
          rules: [
            {
              required: true,
              message: '请选择结束时间'
            }
          ],
          initialValue: _.get(ruleInfo, 'appointWeek', ['2'])
        })(<TimeOption mode="tags" list={weekList} />)}
      </FormItem>
      <FormItem label="具体时间">
        {getFieldDecorator('specTimeWeek', {
          rules: [
            {
              required: true,
              message: '请选择结束时间'
            }
          ],
          initialValue: _.get(ruleInfo, 'specTimeWeek', ['0'])
        })(<TimeOption mode="tags" list={startMinute} />)}
      </FormItem>
    </Fragment>
  );
};

export default CycleWeek;
