//固化规则配置
import { Form, message } from 'sup-ui';
import React, { Component } from 'react';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import moment from 'moment';

import CycleRuleConfig from './CycleRuleConfig';

import { getCron } from '@utils/indicator';

import DialogModal from '@components/Modal/Dialog';

interface IProps extends FormComponentProps {
  visible: boolean;
  ruleInfo: any;
  onOk: (params: any) => void;
  onCancel: (visible: any) => void;
}
interface IState {
  ruleType: string;
  hourRule: boolean;
}

class IndicatorRuleConfig extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const { ruleInfo } = props;
    this.state = {
      hourRule: false,
      ruleType: _.get(ruleInfo, 'ruleType', '0')
    };
  }

  public updateHourRule = (rule: boolean) => {
    this.setState({
      hourRule: rule
    });
  };

  public handleOk = () => {
    const { hourRule } = this.state;
    const {
      form: { validateFields }
    } = this.props;

    validateFields((error: any, values: any) => {
      if (error || hourRule) {
        return;
      }

      let cornExpr = '';
      const {
        effectDate: [start, end],
        timeCuring
      } = values;

      if (!timeCuring) {
        message.warning('请配置定时固化!');
        return;
      } else {
        cornExpr = getCron({ ...values });
      }

      const stopTime = moment(end.format('YYYY-MM-DD'))
        .add(23, 'hours')
        .add(59, 'minutes')
        .add(59, 'seconds');

      const startDate = start.format('YYYY-MM-DD');
      const endDate = end.format('YYYY-MM-DD');
      const startTime = start.unix() * 1000;
      const endTime = stopTime.unix() * 1000;
      const params = {
        endTime,
        cornExpr,
        startTime,
        cornLayout: JSON.stringify({
          ...values,
          effectDate: [startDate, endDate],
          ruleType: '0' //固化规则类型 0 周期固化, 1变化固化
        })
      };

      this.props.onOk(params);
    });
  };

  public handleCancel = () => {
    this.props.onCancel(false);
  };

  // public handleRuleType = (e: any) => {
  //   const {
  //     target: { value }
  //   } = e;

  //   this.setState({
  //     ruleType: value
  //   });
  // };

  public render() {
    // const { ruleType } = this.state;
    const {
      form,
      ruleInfo,
      // form: { getFieldDecorator },
      visible
    } = this.props;

    return (
      <DialogModal
        onOk={this.handleOk}
        onCancel={this.handleCancel}
        title="固化规则配置"
        visible={visible}
      >
        <Form>
          {/* <FormItem>
            {getFieldDecorator('ruleType', {
              initialValue: ruleType
            })(
              <Radio.Group onChange={this.handleRuleType}>
                <Radio.Button value="0">周期固化</Radio.Button>
                <Radio.Button value="1">变化固化</Radio.Button>
              </Radio.Group>
            )}
          </FormItem> */}
          <CycleRuleConfig
            form={form}
            ruleInfo={ruleInfo}
            updateHourRule={this.updateHourRule}
          />
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>()(IndicatorRuleConfig);
