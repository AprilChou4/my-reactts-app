import React, { Component } from 'react';

import { Select, Form } from 'sup-ui';

import styles from './time.common.less';

const FormItem = Form.Item;

interface IProps {
  list?: any;
  value?: any;
  disabled?: boolean;
  styling?: any;
  onChange?: (v: any) => void;
}
interface IState {}

const { Option } = Select;

class TimeSelect extends Component<IProps, IState> {
  public handleChange = (value: any) => {
    const { onChange } = this.props;
    if (onChange) {
      onChange(value);
    }
  };

  public render() {
    const {
      list = [],
      disabled = false,
      value = '',
      styling = {}
    } = this.props;

    return (
      <FormItem className={styles.select} style={styling}>
        <Select
          value={value}
          className={styles.timeSelect}
          onChange={this.handleChange}
          disabled={disabled}
        >
          {!list.length
            ? null
            : _.map(list, ({ key, name, disabled: forbid = false }) => (
                <Option key={key} value={key} disabled={forbid}>
                  {name}
                </Option>
              ))}
        </Select>
      </FormItem>
    );
  }
}

export default TimeSelect;
