import React, { Component } from 'react';
import { Table, message } from 'sup-ui';
import DialogModal from '@components/Modal/Dialog';
import { TableCellText } from '@components/Table';

const columns = [
  {
    title: '关系模板',
    dataIndex: 'relation',
    width: 150,
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '关系组',
    dataIndex: 'group',
    width: 150,
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '关联模板',
    dataIndex: 'templates',
    width: 'auto',
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  }
];

interface IProps {
  visible: boolean;
  dataSource: any;
  onVisibleChange: any;
  onOk: any;
}
interface IState {
  selectedRowKeys: any[];
}

class RelationModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    this.state = {
      selectedRowKeys: [props.dataSource[0]['id']]
    };
  }

  public handleOk = () => {
    const { onOk, dataSource } = this.props;
    const { selectedRowKeys } = this.state;
    const target = _.find(dataSource, ['id', selectedRowKeys[0]]);

    if (!target) {
      message.error('请选择一条关系!');
      return;
    }

    onOk(target);
  };

  public updateSelectedRowKeys = (selectedKeys: string[] | number[]) => {
    this.setState({
      selectedRowKeys: selectedKeys
    });
  };

  public handleRowClick = (key: any) => {
    this.setState({
      selectedRowKeys: [key]
    });
  };

  public render() {
    const { visible, onVisibleChange, dataSource } = this.props;
    const { selectedRowKeys } = this.state;
    const rowSelection = {
      columnWidth: 40,
      type: 'radio' as any,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true
    };

    return (
      <DialogModal
        width={600}
        title="选择关系"
        visible={visible}
        maskClosable={false}
        onOk={this.handleOk}
        onCancel={() => onVisibleChange(false)}
      >
        <div className="mp-table-gray">
          <Table
            rowSelection={rowSelection}
            columns={columns}
            dataSource={dataSource}
            rowKey="id"
            pagination={false}
            onRow={(record: any) => ({
              onClick: () => this.handleRowClick(record.id)
            })}
            scroll={{ y: 320 }}
          />
        </div>
      </DialogModal>
    );
  }
}

export default RelationModal;
