import React, { Component } from 'react';
import { Modal, Select, Table } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import { ColumnProps } from 'sup-ui/es/table';
import Icon from '@components/Icon';
import { dataTypeArray } from '../../consts/typeMap';
import styles from '../index.less';

const linkMap = [
  { title: '内联', cName: 'innerLink', type: 2, disable: false },
  { title: '左联', cName: 'leftLink', type: 1, disable: false },
  { title: '右联', cName: 'rightLink', type: 3, disable: false },
  { title: '全联', cName: 'allLink', type: 4, disable: false }
];

const { Option } = Select;

interface IProps {
  themeStore?: any;
  position: any;
}
interface IState {}

@inject('themeStore')
@observer
class DataTableModal extends Component<IProps, IState> {
  public handleAddItem = () => {
    const {
      addNewTableData,
      currentPipeInfo: { disabled }
    } = this.props.themeStore;

    if (disabled) {
      return;
    }

    addNewTableData();
  };

  public deleteListItems = (keys: any[]) => {
    const { deleteTableData } = this.props.themeStore;

    deleteTableData(keys);
  };

  public handleSelectChange = (index: number, key: string, value: string) => {
    this.props.themeStore.updatePipeConfig('dataTable', value, key, index);
  };

  public getColumns = (): ColumnProps<any>[] => {
    const {
      currentPipeInfo: { disabled },
      fieldSelectList: [mainFields, viceFields, mainTitle, viceTitle]
    } = this.props.themeStore;

    return [
      {
        title: () => (
          <div className={styles.columnTitle} title={mainTitle}>
            {mainTitle}
          </div>
        ),
        width: 150,
        dataIndex: 'left',
        render: (_value: any, record: any): any => {
          const viceDataType = record.vice ? record.vice.split('|:|')[1] : '';

          return (
            <Select
              allowClear
              disabled={disabled}
              value={record.main}
              placeholder="-请选择-"
              onChange={(value: string) =>
                this.handleSelectChange(record.key, 'main', value)
              }
            >
              {mainFields.map((option: any) => (
                <Option
                  value={option.uniKey}
                  key={option.uniKey}
                  disabled={
                    viceDataType &&
                    !_.includes(
                      dataTypeArray(viceDataType),
                      option.clientDataType
                    )
                  }
                >
                  <span title={`${option.fieldName} (字段:${option.name})`}>
                    {option.fieldName}
                  </span>
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '等于',
        width: 'auto',
        align: 'center',
        render: () => <span>=</span>
      },
      {
        title: () => (
          <div className={styles.columnTitle} title={viceTitle}>
            {viceTitle}
          </div>
        ),
        width: 150,
        dataIndex: 'right',
        render: (_value: any, record: any): any => {
          const mainDataType = record.main ? record.main.split('|:|')[1] : '';

          return (
            <Select
              allowClear
              disabled={disabled}
              value={record.vice}
              placeholder="-请选择-"
              onChange={(value: string) =>
                this.handleSelectChange(record.key, 'vice', value)
              }
            >
              {viceFields.map((option: any) => (
                <Option
                  value={option.uniKey}
                  key={option.uniKey}
                  disabled={
                    mainDataType &&
                    !_.includes(
                      dataTypeArray(mainDataType),
                      option.clientDataType
                    )
                  }
                >
                  <span title={`${option.fieldName} (字段:${option.name})`}>
                    {option.fieldName}
                  </span>
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '操作',
        width: 42,
        align: 'center',
        render: (_value: any, record: any) => (
          <Icon
            disabled={disabled}
            type="remove"
            onClick={this.deleteListItems.bind(this, [record.key])}
          />
        )
      }
    ];
  };

  public updateLinkType = (item: any) => {
    const {
      updatePipeConfig,
      currentPipeInfo: { disabled }
    } = this.props.themeStore;
    const { type, disable } = item;

    if (disabled || disable) return;

    updatePipeConfig('linkType', type);
  };

  public render() {
    const {
      position: { x, y },
      themeStore: {
        visible,
        changeModalVisible,
        currentDataTableList,
        currentPipeInfo: { linkType, disabled }
      }
    } = this.props;
    const columns = this.getColumns();

    return (
      <Modal
        title=""
        width="auto"
        wrapClassName="dataTableModal"
        style={{
          top: y + 28 + 'px',
          left: x - 224 + 'px' //modal宽度偏移
        }}
        closable={false}
        mask={false}
        visible={visible}
        footer={null}
        onCancel={() => changeModalVisible(false)}
      >
        <div className={styles.popover}>
          <ul className={styles.linkBox}>
            {linkMap.map((item: any) => (
              <li
                key={item.type}
                className={`${linkType === item.type ? styles.active : ''} ${
                  disabled || item.disable ? styles.disable : ''
                }`}
                onClick={() => this.updateLinkType(item)}
              >
                <p className={styles[item.cName]} />
                <h4>{item.title}</h4>
              </li>
            ))}
          </ul>
          <div className={styles.dataTable}>
            <div className={styles.title}>
              <h3>关联条件</h3>
              <div
                className={`${styles.btn} ${disabled ? styles.disable : ''}`}
                onClick={this.handleAddItem}
              >
                新增
              </div>
            </div>
            <Table
              size="small"
              rowKey="key"
              columns={columns}
              dataSource={currentDataTableList}
              scroll={{ y: 190 }}
              pagination={false}
            />
          </div>
        </div>
      </Modal>
    );
  }
}

export default DataTableModal;
