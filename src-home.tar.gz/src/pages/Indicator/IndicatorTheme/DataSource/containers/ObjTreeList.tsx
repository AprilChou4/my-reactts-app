import React, { Component, createRef } from 'react';
import { inject, observer } from 'mobx-react';
import { Spin } from 'sup-ui';
import TempTree from '../components/Tree';
import styles from '../index.less';

interface IProps {
  store?: any;
  sourceInfo: any; //数据源信息
  onDragInfo: any;
}
interface IState {}

@inject('store')
@observer
class ObjTreeList extends Component<IProps, IState> {
  private readonly nodeRef: any;
  private openedKeys: string[] = []; //已经加载过的tree节点
  public constructor(props: IProps) {
    super(props);
    this.nodeRef = createRef();
  }

  public handleSelectSearchItem = (item: any) => {
    const { getNodeParents } = this.props.store;

    getNodeParents(item, () => {
      setTimeout(() => {
        const parentNode = this.nodeRef.current.querySelector(
          '.sup-tree-child-tree'
        );
        this.handleEventListener(parentNode);
      }, 0);
    });
  };

  public handleTreeExpend = (
    expandedKeys: string[],
    { expanded, node }: any
  ) => {
    const isNew = _.difference(expandedKeys, this.openedKeys).length > 0;

    //第一次展开的时候走onLoad的绑定
    if (isNew) {
      return;
    }

    if (expanded) {
      setTimeout(() => {
        const parentNode = node.selectHandle.nextSibling;
        this.handleEventListener(parentNode);
      }, 0);
    }
  };

  public handleTreeLoaded = (expandedKeys: string[], { node }: any) => {
    const parentNode = node.selectHandle.nextSibling;

    this.openedKeys = _.union(this.openedKeys, expandedKeys);
    this.handleEventListener(parentNode);
  };

  public handleEventListener = (node: any) => {
    const children = node.querySelectorAll('.sup-tree-node-content-wrapper');

    _.forOwn(children, child => {
      child.setAttribute('draggable', true);

      child.addEventListener('dragstart', (e: any) => {
        const target = e.target.lastChild.querySelector('span');
        const id = target.dataset.id;

        e.dataTransfer.setData('text/plain', id);
        e.dataTransfer.effectAllowed = 'move';

        this.getTargetTempNode(id);
      });

      child.addEventListener('dragend', () => {
        this.props.onDragInfo({});
      });
    });
  };

  public getTargetTempNode = (id: any) => {
    const {
      store: { tempTreeData },
      onDragInfo,
      sourceInfo
    } = this.props;

    const recurse = (childs: any) => {
      _.forEach(childs, (temp: any): any => {
        if (temp.sourceFromId === id) {
          onDragInfo({
            ...temp,
            sourceInfo,
            tempType: temp.type, //ENTITY, RELATION, FORM
            type: 'template'
          });
          return false;
        }

        if (temp.children) {
          recurse(temp.children);
        }
      });
    };

    recurse(tempTreeData);
  };

  public render() {
    const {
      treeLoading,
      tempTreeData,
      fuzzySelectData,
      expandedKeys,
      getDefaultTreeNodes,
      getTreeChildren,
      fuzzySearch
    } = this.props.store;

    return (
      <div className={styles.tempList}>
        <Spin spinning={treeLoading}>
          <TempTree
            treeData={tempTreeData}
            getTreeData={getDefaultTreeNodes}
            getTreeChildren={getTreeChildren}
            getNodeParents={this.handleSelectSearchItem}
            fuzzySearch={fuzzySearch}
            fuzzySelectData={fuzzySelectData}
            fuzzyPlaceholder="请输入模板名搜索"
            expandedKeys={expandedKeys}
            onExpend={this.handleTreeExpend}
            onLoad={this.handleTreeLoaded}
            forwardRef={this.nodeRef}
          />
        </Spin>
      </div>
    );
  }
}

export default ObjTreeList;
