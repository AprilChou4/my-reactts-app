import React, { Component } from 'react';
import { inject, observer, Provider } from 'mobx-react';
import { Spin } from 'sup-ui';
import DataSourceStore from '../stores/datasource.store';
import Selector from './components/Selector';
import DataTableList from './containers/DataTableList';
import ObjTreeList from './containers/ObjTreeList';
import IndicatorList from './containers/IndicatorList';

import styles from './index.less';

const FormItem = ({ title, children }: any) => {
  return (
    <div className={styles.item}>
      <p className={styles.label}>{title}</p>
      <div className={styles.box}>{children}</div>
    </div>
  );
};

interface IProps {
  themeStore?: any;
}
interface IState {
  inputType: string;
  sourceType: any;
  sourceName: any;
}

@inject('themeStore')
@observer
class DataSource extends Component<IProps, IState> {
  private readonly store: DataSourceStore;
  public constructor(props: IProps) {
    super(props);
    this.store = new DataSourceStore();
  }

  public handleRefCallback(ref: any) {
    this.props.themeStore.getSourceListRef(ref);
  }

  public render() {
    const {
      sourceLoading,
      tableParams,
      indicatorParams,
      fetchTableList,
      fetchIndicatorList,
      formData: { inputType, sourceType, sourceName },
      sourceMap,
      sourceTypes,
      sourceNames,
      sourceInfo,
      handleInputTypeChange,
      handleSourceTypeChange,
      handleSourceNameChange
    } = this.store;
    const { changeCurrentDragInfo } = this.props.themeStore;
    const typeTitle = inputType === 'indicator' ? '主题域' : '数据源类型';
    const sourceTitle =
      inputType === 'supos'
        ? 'supOS实例'
        : inputType === 'indicator'
        ? '主题'
        : '数据源名称';

    return (
      <Provider store={this.store}>
        <div className={styles.container}>
          <Spin spinning={sourceLoading}>
            <div className={styles.form}>
              <FormItem title="数据来源">
                <Selector
                  value={inputType}
                  onChange={handleInputTypeChange}
                  source={sourceMap}
                  renderKey={['id', 'displayName']}
                />
              </FormItem>
              {inputType !== 'supos' && (
                <FormItem title={typeTitle}>
                  <Selector
                    value={sourceType}
                    onChange={handleSourceTypeChange}
                    source={sourceTypes}
                    renderKey={[
                      'id',
                      inputType === 'sql' ? 'showName' : 'name'
                    ]}
                  />
                </FormItem>
              )}
              <FormItem title={sourceTitle}>
                <Selector
                  value={sourceName}
                  onChange={handleSourceNameChange}
                  source={sourceNames}
                  renderKey={['id', 'showName']}
                />
              </FormItem>
            </div>
          </Spin>
          {sourceName && (
            <div className={styles.content}>
              {inputType === 'sql' ? (
                <DataTableList
                  ref={ref => {
                    this.handleRefCallback(ref);
                  }}
                  sourceName={sourceName}
                  sourceInfo={sourceInfo}
                  loadData={fetchTableList}
                  baseParams={tableParams}
                  onDragInfo={changeCurrentDragInfo}
                />
              ) : inputType === 'supos' ? (
                <ObjTreeList
                  sourceInfo={sourceInfo}
                  onDragInfo={changeCurrentDragInfo}
                />
              ) : inputType === 'indicator' ? (
                <IndicatorList
                  sourceInfo={sourceInfo}
                  loadData={fetchIndicatorList}
                  baseParams={indicatorParams}
                  onDragInfo={changeCurrentDragInfo}
                />
              ) : null}
            </div>
          )}
        </div>
      </Provider>
    );
  }
}

export default DataSource;
