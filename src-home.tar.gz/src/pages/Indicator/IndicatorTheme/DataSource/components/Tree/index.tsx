import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Tree, message, Empty } from 'sup-ui';
import FuzzySearch from '../FuzzySearch';
import styles from './index.less';

const { TreeNode, DirectoryTree } = Tree;

interface IProps {
  treeData: any; //节点树列表
  getTreeData: () => void; //获取所有节点
  getTreeChildren: (treeNodeProps: any) => Promise<any>; //获取节点下的子节点
  getNodeParents: (selectItem: any) => void; //获取节点的父节点
  fuzzySearch: (value: string) => void; //模糊搜索
  fuzzySelectData: any; //模糊搜索列表
  fuzzyPlaceholder?: string;
  expandedKeys: string[]; //展开的节点
  onExpend: any;
  onLoad: any;
  forwardRef: any;
}
interface IState {
  expandedKeys: any;
  treeData: any;
  prevTreeData: any[]; //缓存旧的treeData, 在getDerivedStateFromProps内判断使用
}

@observer
class TopicTree extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      expandedKeys: [],
      treeData: [],
      prevTreeData: []
    };
  }

  public static getDerivedStateFromProps(
    nextProps: Readonly<IProps>,
    state: IState
  ) {
    if (!_.isEqual(nextProps.treeData, state.prevTreeData)) {
      const { expandedKeys, treeData } = nextProps;
      return {
        expandedKeys,
        treeData,
        prevTreeData: treeData
      };
    }

    return null;
  }

  //展开/收缩treeNode
  public handleTreeExpand = (
    expandedKeys: string[],
    { expanded, node }: any
  ) => {
    this.props.onExpend(expandedKeys, { expanded, node });
    this.setState({ expandedKeys });
  };

  //搜索结果处理
  public handleSearchChange = (item: any) => {
    const { fuzzySelectData } = this.props;

    if (item) {
      const selectedItem = _.find(fuzzySelectData, ['sourceFromId', item.id]);

      if (!_.isNil(selectedItem)) {
        //有搜索结果
        this.props.getNodeParents(selectedItem);
        return;
      }

      this.setState({ treeData: [] });
    } else {
      this.props.getTreeData();
    }
  };

  public onLoadData = (treeNode: any): Promise<any> => {
    return new Promise(resolve => {
      this.props.getTreeChildren(treeNode.props).then((res: any) => {
        if (res.code !== 200) {
          message.error(res.message);
          return;
        }

        const { children, eventKey } = treeNode.props;

        if (children) {
          resolve();
          return;
        }

        const nodes = res.data.list || [];

        treeNode.props.dataRef.children = _.map(nodes, (node, i) => ({
          ...node,
          key: `${eventKey}-${i}`,
          isLeaf: !node.leaf,
          selectable: false
        }));

        this.setState({
          treeData: [...this.state.treeData]
        });

        resolve();
      });
    });
  };

  //自定义节点title
  public treeTitle = (item: any) => (
    <div className={styles.customerTitle}>
      <span data-id={item.sourceFromId} title={item.name}>
        {item.name}
      </span>
    </div>
  );

  //递归节点树结构
  public loopTreeNode = (data: any) => {
    return data.map((item: any) => {
      if (item.children) {
        return (
          <TreeNode
            key={item.key}
            dataRef={item}
            title={this.treeTitle(item)}
            selectable={item.selectable}
          >
            {this.loopTreeNode(item.children)}
          </TreeNode>
        );
      }

      return (
        <TreeNode
          key={item.key}
          isLeaf={item.isLeaf}
          selectable={item.selectable}
          title={this.treeTitle(item)}
          dataRef={item}
        />
      );
    });
  };

  public render() {
    const { treeData, expandedKeys } = this.state;
    const {
      fuzzySelectData,
      fuzzyPlaceholder,
      fuzzySearch,
      forwardRef,
      onLoad
    } = this.props;
    const searchSource = _.map(fuzzySelectData, item => ({
      id: item.sourceFromId,
      displayName: item.templateShowName
    }));

    return (
      <div className={styles.treeContainer}>
        <FuzzySearch
          placeholder={fuzzyPlaceholder}
          dataSource={searchSource}
          onSearch={fuzzySearch}
          onChange={this.handleSearchChange}
        />

        <div className={styles.directoryTree} ref={forwardRef}>
          {treeData.length > 0 ? (
            <DirectoryTree
              // expandAction={false}
              expandedKeys={expandedKeys}
              onExpand={this.handleTreeExpand}
              loadData={this.onLoadData}
              onLoad={onLoad}
            >
              {this.loopTreeNode(treeData)}
            </DirectoryTree>
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </div>
      </div>
    );
  }
}

export default TopicTree;
