import React, { Component, Fragment, createContext } from 'react';
import { inject, observer } from 'mobx-react';
import { Table, Input, Select, Form, message, Popover } from 'sup-ui';
import memoizeOne from 'memoize-one';
import { DelBtn } from '@components/Button';
import { popupContainer } from '@utils/propUtil';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import ColumnFilter from '@components/ColumnFilter';
import DuplicateModal from './containers/DuplicateModal';
import { attrNameReg, dateReg } from '../consts/typeMap';
import { dataStructColumns } from '../consts/columns';
import DataPreviewModal from '../DataPreview';
import styles from './index.less';

const { Option } = Select;

const reminder = (
  <div className={styles.tips}>
    <p>列表展示的是数据域所选字段。</p>
    <h4>默认值：</h4>
    <p>
      输入符合数据类别的值，当数据为空时，会将所输入的默认值填入到数据表中。
    </p>
    <h4>重名查询：</h4>
    <p>可将列表中重名字段进行筛选，统一修改。</p>
  </div>
);

const timeDimType = [
  'Year',
  'Date',
  'Time',
  'Datetime',
  'SmallDatetime',
  'Datetime_3',
  'Long'
]; //时间维度允许的数据类型

const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  markDirty: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex, markDirty } = this.props;

    if (this.form.isFieldsTouched()) {
      markDirty();
    }

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      //字段名称
      if (dataIndex === 'fieldName') {
        if (!values[dataIndex]) {
          message.error('字段名称不能为空!');
          return;
        }

        if (!attrNameReg.test(values[dataIndex])) {
          message.error(
            '字段名称只能由字母、数字、下划线、中文组成，且不能以数字开头!'
          );
          return;
        }
      }

      //默认值
      if (dataIndex === 'defaultValue' && values[dataIndex]) {
        if (values[dataIndex].length > 200) {
          message.error('默认值的长度不能超过200个字符！');
          return;
        }

        //根据clientDataType去校验
        const { clientDataType } = record;
        const [reg, format] = dateReg(clientDataType);

        if (!reg.test(values[dataIndex])) {
          message.error(
            `默认值需与数据类型${clientDataType}相匹配，格式：${format}！`
          );
          return;
        }
      }

      handleSave({ ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;
    const { dup, disabled } = record;
    const disableName = disabled && dataIndex === 'fieldName';

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={`${styles['editable-cell-value-wrap']} ${
          dup && dataIndex === 'fieldName' ? styles.dup : ''
        } ${disableName ? styles.disable : ''}`}
        onClick={() => {
          if (disableName) return;
          this.toggleEdit();
        }}
      >
        {record[dataIndex] ? (
          <TableCellText text={record[dataIndex]} />
        ) : (
          <span style={{ color: 'rgba(53, 64, 82, 0.5)' }}>请输入</span>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      markDirty,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  themeStore?: any;
}
interface IState {
  searchText: string;
  checkedColumns: any[];
  previewVisible: boolean;
}

@inject('themeStore')
@observer
class DataStruct extends Component<IProps, IState> {
  private readonly handleSearch: any;
  public constructor(props: IProps) {
    super(props);
    const checkedItems = _.map(
      _.filter(dataStructColumns, 'check'),
      'dataIndex'
    );

    this.state = {
      checkedColumns: checkedItems,
      searchText: '',
      previewVisible: false
    };
    this.handleSearch = _.debounce(this.handleListSearch.bind(this), 200);
  }

  //批量“删除”字段
  public handleBatchDeleteItems = () => {
    //将在keys内的数据checked置为false
    this.props.themeStore.updateFieldsCheckedStatus();
  };

  public updateRowData = (key: string, value: any, record: any) => {
    const { updateSourceFieldMap, markThemeAsDirty } = this.props.themeStore;

    updateSourceFieldMap({
      ...record,
      [key]: value
    });
    markThemeAsDirty();
  };

  public handleCellSave = (row: any) => {
    const { updateSourceFieldMap } = this.props.themeStore;

    updateSourceFieldMap(row);
  };

  public getColumns = () => {
    return [
      {
        title: '字段来源',
        dataIndex: 'tableName',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段',
        dataIndex: 'name',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段名称',
        width: 200,
        dataIndex: 'fieldName',
        editable: true
      },
      {
        title: '数据类型',
        dataIndex: 'clientDataType',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '数据类别',
        dataIndex: 'dimension',
        width: 200,
        render: (_text: string, record: any) => {
          const allowTime = _.includes(timeDimType, record.clientDataType);
          const allowNum = record.clientDataType !== 'String';

          return (
            <Select
              value={record.dimension}
              getPopupContainer={popupContainer}
              onChange={(value: string) =>
                this.updateRowData('dimension', value, record)
              }
            >
              <Option value="1">文本维度</Option>
              <Option value="2" disabled={!allowNum}>
                数值维度
              </Option>
              <Option value="3" disabled={!allowTime}>
                时间维度
              </Option>
            </Select>
          );
        }
      },
      {
        title: '默认值',
        width: 200,
        dataIndex: 'defaultValue',
        editable: true
      },
      // {
      //   title: '数据长度',
      //   dataIndex: 'dataSize',
      //   width: 200,
      //   className: 'ellipsis-hide',
      //   render: (text: string) => <TableCellText text={text} />
      // },
      {
        title: '操作',
        align: 'center',
        width: 120,
        render: (_value: any, record: any) => (
          <Fragment>
            <div className="operator">
              {!record.disabled && (
                <a onClick={() => this.updateRowData('checked', false, record)}>
                  删除
                </a>
              )}
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ];
  };

  public updateCheckedColumns = (checkedItems: any[]) => {
    this.setState({
      checkedColumns: checkedItems
    });
  };

  public getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 20;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  //搜索筛选
  public handleListSearch(keyword: string) {
    this.props.themeStore.updateDataStructSearchText(keyword);
  }

  public handleDupSearch = () => {
    const { dupDataStructList, handleDupModalVisible } = this.props.themeStore;

    if (dupDataStructList.length === 0) {
      message.warning('无重复的字段名称!');
      return;
    }

    handleDupModalVisible(true);
  };

  public handleSearchTextChange = (e: any) => {
    this.setState({
      searchText: e.target.value
    });

    this.handleSearch(e.target.value);
  };

  public changePreviewVisible = (visible: boolean) => {
    const { hasDirty, dataFieldsList } = this.props.themeStore;

    if (visible && (!dataFieldsList.length || hasDirty)) {
      message.warning('请先保存主题配置!');
      return;
    }

    this.setState({
      previewVisible: visible
    });
  };

  public render() {
    const {
      themeLoading,
      searchDataStructList,
      dupModalVisible,
      themeInfo: { id: themeId },
      selectedRowKeys,
      updateSelectedRowKeys,
      markThemeAsDirty
    } = this.props.themeStore;
    const { checkedColumns, searchText, previewVisible } = this.state;
    const rowSelection = {
      columnWidth: 60,
      selectedRowKeys,
      onChange: updateSelectedRowKeys,
      hideDefaultSelections: true,
      getCheckboxProps: (record: any): any => ({ disabled: record.disabled })
    };
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          markDirty: markThemeAsDirty,
          handleSave: this.handleCellSave
        })
      };
    });

    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <h3>
            字段列表
            <Popover placement="bottom" content={reminder}>
              <Icon type="circle-help" width={20} />
            </Popover>
          </h3>
          <div className={styles.operator}>
            <div
              className={styles.preview}
              onClick={() => this.changePreviewVisible(true)}
            >
              <Icon type="start" fill="#0f71e2" width={16} />
              数据预览
            </div>
            <div className={styles.dupSearch} onClick={this.handleDupSearch}>
              重名查询
            </div>
            <DelBtn
              onClick={this.handleBatchDeleteItems}
              disabled={!selectedRowKeys.length}
            />
            <div className={styles.divider} />
            <Input
              allowClear
              value={searchText}
              onChange={this.handleSearchTextChange}
              placeholder="输入字段搜索"
              prefix={<Icon type="search" />}
              style={{ width: '150px' }}
            />
            <ColumnFilter
              sourceColumns={dataStructColumns}
              onOk={this.updateCheckedColumns}
            />
          </div>
        </div>
        <div className={`${styles.content} mp-table-gray mp-table-grow`}>
          {!themeLoading && (
            <Table
              components={{
                body: {
                  row: EditableFormRow,
                  cell: EditableCell
                }
              }}
              rowClassName={() => styles['editable-row']}
              rowSelection={rowSelection}
              columns={filterColumns}
              dataSource={searchDataStructList}
              rowKey={(record: any) => `${record.key}|:|${record.name}`}
              pagination={{
                defaultPageSize: 20,
                showTotal: total => `共${total}条`,
                itemRender: CustomPaging,
                pageSizeOptions: ['20', '50', '100'],
                showSizeChanger: true,
                showQuickJumper: true
              }}
              scroll={{
                x: totalWidthX,
                y: 'calc(100% - 40px)'
              }}
            />
          )}
        </div>
        {dupModalVisible && <DuplicateModal />}
        {previewVisible && (
          <DataPreviewModal
            id={themeId}
            visible={previewVisible}
            onVisibleChange={this.changePreviewVisible}
          />
        )}
      </div>
    );
  }
}

export default DataStruct;
