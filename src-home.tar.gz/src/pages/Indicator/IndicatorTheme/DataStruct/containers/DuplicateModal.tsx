import React, { Component, createContext, Fragment } from 'react';
import { Form, Input, Table, message } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import DialogModal from '@components/Modal/Dialog';
import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import { DelBtn } from '@components/Button';
import { attrNameReg } from '../../consts/typeMap';
import styles from '../index.less';

const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      if (!values[dataIndex]) {
        message.error('字段名称不能为空!');
        return;
      }

      if (!attrNameReg.test(values[dataIndex])) {
        message.error(
          '字段名称只能由字母、数字、下划线、中文组成，且不能以数字开头!'
        );
        return;
      }

      handleSave({ ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;
    const { dup, disabled } = record;

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={`${styles['editable-cell-value-wrap']} ${
          dup ? styles.dup : ''
        } ${disabled ? styles.disable : ''}`}
        onClick={() => {
          if (disabled) return;
          this.toggleEdit();
        }}
      >
        <TableCellText text={record[dataIndex]} />
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  themeStore?: any;
}
interface IState {
  dataSource: any[];
  selectedRowKeys: any[];
  deleteKeys: any[]; //删除的数据
}

@inject('themeStore')
@observer
class DuplicateModal extends Component<IProps, IState> {
  private readonly columns: any;
  private readonly fieldsNameMap: any = {}; //修改的字段表
  public constructor(props: IProps) {
    super(props);
    const { dupDataStructList } = props.themeStore;

    this.state = {
      dataSource: _.cloneDeep(dupDataStructList),
      selectedRowKeys: [],
      deleteKeys: []
    };

    this.columns = [
      {
        title: '字段来源',
        dataIndex: 'tableName',
        width: 130,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段',
        dataIndex: 'name',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段名称',
        width: 180,
        dataIndex: 'fieldName',
        editable: true
      },
      {
        title: '数据类型',
        dataIndex: 'clientDataType',
        width: 'auto',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '操作',
        align: 'center',
        width: 100,
        render: (_value: any, record: any) => (
          <Fragment>
            <div className="operator">
              {!record.disabled && (
                <a
                  onClick={() =>
                    this.handleDelete([`${record.key}|:|${record.name}`])
                  }
                >
                  删除
                </a>
              )}
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ];
  }

  public updateSelectedRowKeys = (selectedKeys: string[] | number[]) => {
    this.setState({
      selectedRowKeys: selectedKeys
    });
  };

  public batchDelete = () => {
    const { selectedRowKeys } = this.state;

    if (selectedRowKeys.length === 0) {
      message.warning('请选择要删除的字段!');
      return;
    }

    this.handleDelete(selectedRowKeys);
  };

  public handleDelete = (keys: any[]) => {
    const { dataSource, deleteKeys, selectedRowKeys } = this.state;

    const remains = _.filter(
      dataSource,
      ({ key, name }) => !_.includes(keys, `${key}|:|${name}`)
    );
    const deletes = _.uniq(_.concat(deleteKeys, keys));
    const remainKeys = _.filter(selectedRowKeys, key => !_.includes(keys, key));

    this.calcDataStatus(remains);

    this.setState({
      dataSource: remains,
      deleteKeys: deletes,
      selectedRowKeys: remainKeys
    });
  };

  public handleCellSave = (row: any) => {
    const newData = [...this.state.dataSource];
    const idx = _.findIndex(
      newData,
      itm => itm.key === row.key && itm.name === row.name
    );
    const item = newData[idx];
    const uniqKey = `${row.key}|:|${row.name}`;

    newData.splice(idx, 1, {
      ...item,
      ...row
    });

    this.fieldsNameMap[uniqKey] = row.fieldName; //储存新的字段名
    this.calcDataStatus(newData);
    this.setState({ dataSource: newData });
  };

  public calcDataStatus = (list: any) => {
    const map: any = {};
    _.forEach(list, field => {
      const { fieldName } = field;
      const name = fieldName.toLowerCase();

      if (map[name]) {
        field.dup = true;
        map[name].dup = true;
      } else {
        map[name] = field;
        field.dup = !field.fieldName;
      }
    });
  };

  public handleOK = () => {
    const { deleteKeys, dataSource } = this.state;
    const { handleDupModalOk } = this.props.themeStore;

    //先判断这一波列表没有重复字段
    const hasDup = _.find(dataSource, 'dup');

    if (hasDup) {
      message.error(
        '数据结构中字段名称不能重复且只能由非数字开头的字母、数字、下划线、中文组成!'
      );
      return;
    }

    //删掉的字段不用更新字段名
    handleDupModalOk(deleteKeys, this.fieldsNameMap);
  };

  public render() {
    const { dupModalVisible, handleDupModalVisible } = this.props.themeStore;
    const { selectedRowKeys, dataSource } = this.state;
    const rowSelection = {
      columnWidth: 40,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true,
      getCheckboxProps: (record: any): any => ({ disabled: record.disabled })
    };
    const columns = this.columns.map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });

    return (
      <DialogModal
        width={820}
        title="重名查询"
        okText="保存"
        wrapClassName={styles.dupModalWrapper}
        visible={dupModalVisible}
        maskClosable={false}
        onOk={this.handleOK}
        onCancel={() => handleDupModalVisible(false)}
        bodyStyle={{ padding: '10px 20px 5px' }}
      >
        <div className={styles.header}>
          <DelBtn onClick={this.batchDelete} />
        </div>
        <div className="mp-table-gray">
          <Table
            components={{
              body: {
                row: EditableFormRow,
                cell: EditableCell
              }
            }}
            rowSelection={rowSelection}
            columns={columns}
            dataSource={dataSource}
            rowKey={(record: any) => `${record.key}|:|${record.name}`}
            scroll={{
              y: 400
            }}
            pagination={{
              pageSize: 10,
              showTotal: total => `共${total}条`
            }}
          />
        </div>
      </DialogModal>
    );
  }
}

export default DuplicateModal;
