import moment from 'moment';

export const dataTypeArray = (dataType: string) => {
  switch (dataType) {
    case 'Double':
    case 'Float':
      return ['Double', 'Float'];
    case 'Integer':
    case 'Long':
    case 'Boolean':
      return ['Integer', 'Long', 'Boolean'];
    case 'String':
    case 'Date':
    case 'Time':
    case 'Year':
    case 'Datetime':
    case 'SmallDatetime':
    case 'Datetime_3':
    default:
      return [dataType];
  }
};

//模板内置属性表, oodm无法直接判断属性是否为内置属性
export const innerAttrArray = [
  'id',
  'en_name',
  'display_name',
  'comment',
  'code',
  'app_name',
  'app_access_mode',
  'created_time',
  'last_modified_time',
  'creator_id',
  'last_modifier_id'
];

//字段名称格式：名称只能由字母、数字、下划线、中文组成，不能以数字开头
export const attrNameReg =
  /^[\u4e00-\u9fa5_a-zA-Z][\u4e00-\u9fa5_a-zA-Z0-9]{0,199}$/;

//默认值校验
export const dateReg = (dateType: string): any[] => {
  switch (dateType) {
    case 'String':
      return [/[^]+/, ''];
    case 'Boolean':
      return [/^(true|false)$/, 'true或false'];
    case 'Integer':
    case 'Long':
      return [/^[+-]?(\d+)$/, '整数'];
    case 'Float':
    case 'Double':
      return [/^[+-]?(\d+\.\d+|\d+|\.\d+)$/, '数字'];
    case 'Year':
      return [/^\d{4}$/, 'YYYY'];
    case 'Date':
      return [
        /^\d{4}(-)(0[1-9]|1[0-2])\1(0[1-9]|[12][0-9]|3[01])$/,
        'YYYY-MM-DD'
      ];
    case 'Time':
      return [/^([01][0-9]|[2][0-3]):[0-5][0-9]:[0-5][0-9]$/, 'HH:mm:ss'];
    case 'Datetime':
      return [
        /^\d{4}(-)(0[1-9]|1[0-2])\1(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|[2][0-3]):[0-5][0-9]:[0-5][0-9]$/,
        'YYYY-MM-DD HH:mm:ss'
      ];
    case 'SmallDatetime':
      return [
        /^\d{4}(-)(0[1-9]|1[0-2])\1(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|[2][0-3]):[0-5][0-9]$/,
        'YYYY-MM-DD HH:mm'
      ];
    case 'Datetime_3':
      return [
        /^\d{4}(-)(0[1-9]|1[0-2])\1(0[1-9]|[12][0-9]|3[01])\s([01][0-9]|[2][0-3]):[0-5][0-9]:[0-5][0-9]\.\d{3}$/,
        'YYYY-MM-DD HH:mm:ss.SSS'
      ];
    default:
      //未知类型输入
      return [/[^]+/, ''];
  }
};

//默认值转换
//将时间类型默认值转为毫秒数
export const transDateStringToTimestamp = (
  dateType: string,
  value: string
): any => {
  if (!value) {
    return null;
  }

  switch (dateType) {
    case 'Integer':
    case 'Long':
    case 'Float':
    case 'Double':
      return +value;
    case 'Year':
      return moment(`${value}-01-01`).startOf('day').valueOf();
    case 'Date':
      return moment(value).startOf('day').valueOf();
    case 'Time':
      //从1970-01-01开始
      return moment(`1970-01-01 ${value}`).valueOf();
    case 'Datetime':
      return moment(value).valueOf();
    case 'SmallDatetime':
      return moment(`${value}:00`).valueOf();
    case 'Datetime_3':
      return moment(value).valueOf();
    default:
      //其他类型
      return value;
  }
};
