import { action, computed, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';
import qs from 'qs';
import TipsDelete from '@components/Modal/TipsDelete';
import {
  getThemeGroup,
  getGroupBaseTheme,
  addThemeGroup,
  modifyThemeGroup,
  deleteThemeGroup,
  moveThemeGroup,
  addThemeBase,
  modifyThemeBase,
  deleteThemeBase,
  searchThemeBase,
  copyThemeBase,
  moveThemeBase
} from '../theme.service';

class SiderTreeStore {
  private readonly history: any;
  private readonly globalStore: any;
  private readonly parentStore: any;
  private searchParams: any = {}; //页面路由参数
  private directoryRef: any; //树结构dom
  @observable public editItem: any = {}; //当前编辑的节点
  @observable public selectedItem: any = null; //当前选定的项(主题域/主题)
  @observable public treeData: any = []; //树结构
  @observable public fuzzySelectData: any[] = []; //模糊搜索结果列表
  @observable public selectedKeys: any[] = []; //选中的key
  @observable public expandedKeys: any[] = []; //展开的key
  @observable public treeLoading = false; //主题树loading
  @observable public formData: any = {}; //主题信息
  @observable public visible = false; //弹窗visible
  @observable public loading = false; //弹窗loading
  @observable public copyFormData: any = {}; //复制主题信息
  @observable public copyModalVisible = false; //复制弹窗visible
  @observable public copyModalLoading = false; //复制弹窗loading

  public constructor(globalStore: any, parentStore: any, history: any) {
    this.globalStore = globalStore;
    this.parentStore = parentStore;
    this.history = history;

    this.searchParams = qs.parse(history.location.search, {
      ignoreQueryPrefix: true
    });
  }

  @action.bound
  public changeEditItem(item: any) {
    this.editItem = item;
  }

  @action.bound
  public updateExpandedKeys(keys: any) {
    this.expandedKeys = keys;
  }

  //移动主题/主题域
  @action.bound
  public async moveNode(info: any) {
    const { type, id: moveNodeId, from, to } = info;
    this.treeLoading = true;

    //同级拖拽: 1. 上拖下,先删再加,同时加的位置要减1; 2.下拖上,删完直接加
    if (type === 'group') {
      if (_.eq(from, to) || _.eq(from + 1, to)) {
        return;
      }

      const afterIdx = to - 1;
      const afterId = this.treeData[afterIdx] && this.treeData[afterIdx]['id'];
      const res = await moveThemeGroup({
        ...(afterIdx < 0 ? null : { afterId }),
        groupId: moveNodeId
      });

      runInAction(() => {
        this.treeLoading = false;
      });

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      runInAction(() => {
        const [moveNode] = this.treeData.splice(from, 1);
        const insertIdx = from < to ? to - 1 : to;
        this.treeData.splice(insertIdx, 0, moveNode);
      });
    }

    if (type === 'theme') {
      const operateCurrentNode =
        this.selectedItem && this.selectedItem.id === moveNodeId;
      const [gf, tf] = from;
      const [gt, tt] = to;

      if (_.eq(from, to) || (_.eq(gf, gt) && _.eq(tf + 1, tt))) {
        return;
      }

      const afterIdx = tt - 1;
      const { id: groupId, children } = this.treeData[gt];
      const targetTheme = children && children[afterIdx];
      const afterId = targetTheme && targetTheme['id'];
      const res = await moveThemeBase({
        ...(afterIdx < 0 ? null : { afterId }),
        groupId,
        themeId: moveNodeId
      });

      runInAction(() => {
        this.treeLoading = false;
      });

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      runInAction(() => {
        //注意更新主题信息
        const [moveNode] = this.treeData[gf]['children'].splice(tf, 1);
        const insertIdx = _.eq(gf, gt) && tf < tt ? tt - 1 : tt;

        if (!_.eq(gf, gt)) {
          const { key, id } = this.treeData[gt];
          moveNode.key = `${key}-${moveNode.id}`;
          moveNode.groupId = id;

          if (operateCurrentNode) {
            this.selectedItem = { ...moveNode };
            this.selectedKeys = [moveNode.key];
            this.updatePageRoute({ ...moveNode });
          }

          this.expandedKeys = _.uniq([...this.expandedKeys, key]); //展开目标组
        }

        if (_.eq(gf, gt) || this.treeData[gt]['children']) {
          this.treeData[gt]['children'].splice(insertIdx, 0, moveNode);
        }
      });
    }

    message.success('移动成功!');
  }

  //切换主题/主题域
  @action.bound
  public handleTreeNodeSelect(selectedKeys: string[], { selected, node }: any) {
    const { changeThemeInfo, hasDirty } = this.parentStore;

    if (this.selectedKeys[0] === selectedKeys[0]) {
      return;
    }

    const {
      props: { dataRef }
    } = node;

    if (hasDirty) {
      const config = {
        title: '确定切换主题?',
        content: '未保存的更改将会丢失!',
        onOk: () => {
          runInAction(() => {
            this.selectedKeys = selectedKeys;

            if (selected) {
              changeThemeInfo(dataRef);
              this.selectedItem = dataRef;
              this.updatePageRoute(dataRef);
            }
          });
        }
      };
      TipsDelete(config);
    } else {
      this.selectedKeys = selectedKeys;

      if (selected) {
        changeThemeInfo(dataRef);
        this.selectedItem = dataRef;
        this.updatePageRoute(dataRef);
      }
    }
  }

  //获取主题域列表
  @action.bound
  public async getDefaultTreeNodes() {
    this.treeLoading = true;
    const res = await getThemeGroup();

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    runInAction(() => {
      this.treeData = _.map(res.data.list || [], (item: any) => ({
        id: item.id,
        displayName: item.name,
        description: item.description,
        key: _.uniqueId(),
        isGroup: true,
        isLeaf: false,
        selectable: true,
        editable: true
      }));

      //展开search内指定的主题域
      if (!_.isEmpty(this.searchParams)) {
        const { changeThemeInfo, hasDirty } = this.parentStore;
        const { themeGroupId, themeId } = this.searchParams;
        const targetGroup = _.find(this.treeData, ['id', +themeGroupId]);

        if (!targetGroup) {
          this.updatePageRoute(null);

          if (this.treeData.length) {
            const firstKey = this.treeData[0]['key'];
            this.expandedKeys = [firstKey];
          }

          return;
        }

        if (_.isNil(themeId)) {
          this.selectedKeys = [targetGroup.key];
          this.selectedItem = { ...targetGroup };

          //滚动到相应位置
          this.scrollTreeToPosition(this.directoryRef);

          if (hasDirty) return;
          changeThemeInfo(targetGroup);
        }

        this.expandedKeys = [targetGroup.key];
      } else {
        if (this.treeData.length) {
          const firstKey = this.treeData[0]['key'];
          this.expandedKeys = [firstKey];
        }
      }

      this.treeLoading = false;
    });
  }

  //获取主题域下所有主题
  @action.bound
  public getTreeChildren(treeNode: any) {
    const { changeThemeInfo, hasDirty } = this.parentStore;

    return new Promise<void>(resolve => {
      const { children, eventKey, dataRef } = treeNode.props;
      getGroupBaseTheme(dataRef.id).then((res: any) => {
        if (res.code !== 200) {
          message.error(res.message);
          return;
        }

        if (children) {
          resolve();
          return;
        }

        const nodes = res.data.list || [];

        runInAction(() => {
          dataRef.children = _.map(nodes, node => ({
            ...node,
            displayName: node.showName,
            key: `${eventKey}-${node.id}`,
            isGroup: false,
            isLeaf: true,
            selectable: true,
            editable: true
          }));

          //定位到选中的节点
          if (!_.isEmpty(this.searchParams)) {
            const { themeGroupId, themeId } = this.searchParams;

            if (+themeGroupId === dataRef.id && !_.isNil(themeId)) {
              const targetTheme = _.find(dataRef.children, ['id', +themeId]);

              if (targetTheme) {
                this.selectedKeys = [targetTheme.key];
                this.selectedItem = { ...targetTheme };

                //滚动到相应位置
                const groupNode = treeNode.selectHandle.parentNode;
                this.scrollTreeToPosition(groupNode);

                if (hasDirty) return;
                changeThemeInfo(targetTheme);
              } else {
                this.updatePageRoute(null);
              }
            }
          }
        });

        resolve();
      });
    });
  }

  //新增或编辑主题/主题域
  @action.bound
  public async modifyTheme(values: any) {
    this.loading = true;
    let res: any;
    const { name, showName, description } = values;
    const { isGroup, id, groupId, key } = this.editItem;
    const groupParams = {
      name: showName,
      description
    };
    const { hasDirty } = this.parentStore;

    if (_.isEmpty(this.formData)) {
      //新增
      if (isGroup) {
        res = await addThemeGroup(groupParams);
      } else {
        const { id: sid } = this.selectedItem;
        res = await addThemeBase(sid, {
          name,
          showName,
          description
        });
      }
    } else {
      //编辑
      if (isGroup) {
        res = await modifyThemeGroup(id, groupParams);
      } else {
        res = await modifyThemeBase(id, {
          groupId,
          showName,
          description
        });
      }
    }

    if (res.code !== 200) {
      message.error(`${res.message}`);

      runInAction(() => {
        this.loading = false;
      });

      return;
    }

    if (!_.isEmpty(this.formData)) {
      //编辑后，手动修改名称
      const map = key.split('-');
      let arr: any = { children: this.treeData },
        i = 1;

      while (i <= map.length) {
        arr = _.find(
          arr.children,
          (node: any) => node.key === _.take(map, i).join('-')
        );
        i++;
      }

      runInAction(() => {
        arr.displayName = showName;
        arr.description = description;

        if (!arr.isGroup) {
          arr.showName = showName;
        }

        //更新选中项的信息
        if (this.selectedItem && this.selectedItem.id === this.editItem.id) {
          this.selectedItem = arr;
        }
      });

      message.success('修改成功!');
    } else {
      runInAction(() => {
        //新增主题域/主题后，定位到新增的节点
        if (!hasDirty) {
          this.updatePageRoute({
            ...res.data,
            isGroup,
            ...(!isGroup ? { groupId: this.selectedItem.id } : null)
          });
        }

        this.getDefaultTreeNodes();
      });

      message.success('新增成功!');
    }

    runInAction(() => {
      this.loading = false;
      this.visible = false;
      this.formData = {};
      this.editItem = {};
    });

    this.clearRelateCachePages();
  }

  //修改主题域/主题
  @action.bound
  public async editNode(info: any) {
    const { name, displayName, description } = info;

    this.formData = {
      name,
      showName: displayName,
      description
    };
    this.editItem = info;
    this.visible = true;
  }

  //删除主题/主题域
  @action.bound
  public async deleteNode(node: any) {
    const { id, isGroup, key } = node;
    let res: any;

    if (isGroup) {
      res = await deleteThemeGroup(id);
    } else {
      res = await deleteThemeBase(id);
    }

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    const map = key.split('-');
    let arr = { children: this.treeData },
      i = 1;

    while (i < map.length) {
      arr = _.find(
        arr.children,
        (n: any) => n.key === _.take(map, i).join('-')
      );
      i++;
    }

    const idx = _.findIndex(arr.children, (n: any) => n.key === key);

    runInAction(() => {
      arr.children.splice(idx, 1);

      if (this.selectedItem && this.selectedItem.id === node.id) {
        this.selectedItem = null;
        this.parentStore.changeThemeInfo({});
        this.updatePageRoute(null);
      }
    });

    message.success('删除成功!');

    this.clearRelateCachePages();
  }

  //模糊搜索
  @action.bound
  public async fuzzySearch(keyword: string) {
    const params = {
      showName: keyword
    };

    const res = await searchThemeBase(params);

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    runInAction(() => {
      this.fuzzySelectData = _.map(res.data.list || [], (item: any) => ({
        ...item,
        id: item.themeId,
        displayName: item.showName
      }));
    });
  }

  @action.bound
  public handleSearchChange(value: any) {
    //value 可能为item, {}, ''
    if (value) {
      if (!_.isEmpty(value)) {
        //有搜索结果
        const {
          themeId,
          name,
          showName,
          description,
          group: { groupId, groupName }
        } = value;
        const pKey = _.uniqueId();

        this.treeData = [
          {
            id: groupId,
            displayName: groupName,
            key: pKey,
            isGroup: true,
            isLeaf: false,
            selectable: true,
            editable: false,
            children: [
              {
                id: themeId,
                name,
                showName,
                groupId,
                displayName: showName,
                description,
                key: `${pKey}-${themeId}`,
                isGroup: false,
                isLeaf: true,
                selectable: true,
                editable: true
              }
            ]
          }
        ];
        this.expandedKeys = [pKey];

        if (this.selectedItem && this.selectedItem.id === themeId) {
          this.selectedKeys = [`${pKey}-${themeId}`];
        }
      } else {
        //无搜索结果
        this.treeData = [];
      }
    } else {
      this.getDefaultTreeNodes();
    }
  }

  //复制主题
  @action.bound
  public handleCopyTheme(info: any) {
    const { hasDirty } = this.parentStore;

    //不管是否复制的是当前主题，都需先保存后再复制（复制主题后自动定位到新主题）
    if (hasDirty) {
      message.error('请先保存当前主题，再进行复制操作!');
      return;
    }

    const { id, name, showName, description, groupId } = info;

    this.copyFormData = {
      copyId: id,
      groupId,
      name,
      showName,
      description
    };

    this.copyModalVisible = true;
  }

  //生成主题域列表
  @computed
  public get groupsList() {
    return _.map(this.treeData, group => ({
      id: group.id,
      displayName: group.displayName
    }));
  }

  @action.bound
  public async copyTheme(values: any) {
    const { copyId, name, showName, description, groupId } = values;
    const params = {
      name,
      showName,
      description,
      groupId,
      copyId
    };

    this.copyModalLoading = true;

    const res = await copyThemeBase(params);

    runInAction(() => {
      this.copyModalLoading = false;
    });

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    runInAction(() => {
      this.copyModalVisible = false;

      this.updatePageRoute({
        id: res.data.themeId,
        isGroup: false,
        groupId
      });

      this.getDefaultTreeNodes();
      this.clearRelateCachePages();
    });
  }

  @action.bound
  public changeModalVisible(visible: boolean) {
    this.visible = visible;

    if (!visible) {
      this.formData = {};
      this.editItem = {};
    }
  }

  @action.bound
  public changeCopyModalVisible(visible: boolean) {
    this.copyModalVisible = visible;
  }

  @action.bound
  public updatePageRoute(selectedItem: any) {
    if (!selectedItem) {
      this.searchParams = {};
      this.history.push('/indicator/theme');
      return;
    }

    const { id, groupId, isGroup } = selectedItem;
    const search = isGroup
      ? `themeGroupId=${id}`
      : `themeGroupId=${groupId}&themeId=${id}`;

    this.searchParams = {
      themeGroupId: isGroup ? id : groupId,
      ...(!isGroup ? { themeId: id } : null)
    };

    this.history.push(`/indicator/theme?${search}`);
  }

  //刷新指标定义、指标管理页面
  @action.bound
  public clearRelateCachePages() {
    const cachePages = ['/indicator/definition', '/indicator/manager'];
    this.globalStore.clearCachePages(cachePages);
  }

  @action.bound
  public bindTreeDirectoryRef(ref: any) {
    this.directoryRef = ref;
  }

  //滚动树
  @action.bound
  public scrollTreeToPosition(parentNode: any) {
    setTimeout(() => {
      const targetNode = parentNode.querySelector(
        '.sup-tree-treenode-selected'
      );
      const top = targetNode.offsetTop - 32 * 6; //少滚动6个元素占位

      this.directoryRef.scrollTo({
        top,
        behavior: 'smooth'
      });
    }, 0);
  }
}

export default SiderTreeStore;
