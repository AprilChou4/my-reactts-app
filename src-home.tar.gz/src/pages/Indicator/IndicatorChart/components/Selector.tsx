import React, { Component } from 'react';
import { Select, Spin, message } from 'sup-ui';
import { popupContainer } from '@utils/propUtil';

import styles from './Selector.less';

interface IProps {
  value?: any;
  onChange?: any;
  loadData: any;
  params?: any;
  formKey: any;
}
interface IState {
  fetching: boolean;
  loading: boolean;
  list: any[];
  pageIndex: number;
  pageSize: number;
  keyword: string;
  disableFetch: boolean;
}

const { Option } = Select;

class Selector extends Component<IProps, IState> {
  private readonly handleSearch: any;
  public constructor(props: IProps) {
    super(props);
    this.state = {
      fetching: false,
      loading: false,
      list: [],
      pageIndex: 1,
      pageSize: 20,
      keyword: '',
      disableFetch: false
    };

    this.handleSearch = _.debounce(this.handleSelectSearch.bind(this), 500);
  }

  public async fetchData() {
    if (this.state.disableFetch) return;

    this.setState({
      loading: true
    });

    const { pageIndex, pageSize, keyword } = this.state;
    const { loadData, params = {} } = this.props;

    const res = await loadData({ ...params, pageIndex, pageSize, keyword });

    if (res.code !== 200) {
      message.error(res.message);
      this.setState({
        loading: false,
        fetching: false
      });

      return;
    }

    if (res.data.list.length < this.state.pageSize) {
      this.setState({
        disableFetch: true
      });
    }

    this.setState(prevState => ({
      loading: false,
      fetching: false,
      list: prevState.list.concat(res.data.list)
    }));
  }

  public handleSelectSearch(keyword: string) {
    this.setState(
      {
        keyword,
        fetching: true,
        list: [],
        pageIndex: 1,
        disableFetch: false
      },
      () => {
        this.fetchData();
      }
    );
  }

  public handleFocus = () => {
    const { list, disableFetch } = this.state;

    if (list.length === 0 && !disableFetch) {
      this.setState({
        fetching: true
      });
      this.fetchData();
    }
  };

  public handleBlur = () => {
    //console.log('');
  };

  public handleChange = (values: any) => {
    const { onChange } = this.props;

    if (onChange) {
      onChange(values);
    }
  };

  public handleScroll = (e: any) => {
    if (this.state.list.length === 0) return;

    const {
      target: { scrollTop, scrollHeight, offsetHeight }
    } = e;

    if (scrollTop + offsetHeight + 3 >= scrollHeight) {
      this.setState(
        prevState => ({
          pageIndex: prevState.pageIndex + 1
        }),
        () => {
          this.fetchData();
        }
      );
    }
  };

  public render() {
    const { list, fetching, loading } = this.state;
    const { id, value, name } = this.props.formKey;

    return (
      <Select
        allowClear
        showSearch
        placeholder="—请选择—"
        filterOption={false}
        loading={loading}
        onBlur={this.handleBlur}
        onFocus={this.handleFocus}
        onChange={this.handleChange}
        onSearch={this.handleSearch}
        onPopupScroll={this.handleScroll}
        defaultActiveFirstOption={false}
        getPopupContainer={popupContainer}
        dropdownClassName={styles.selector}
        notFoundContent={fetching ? <Spin size="small" /> : '暂无搜索结果'}
      >
        {_.map(list, (item: any) => (
          <Option key={item[id]} value={item[value]}>
            {item[name]}
          </Option>
        ))}
      </Select>
    );
  }
}

export default Selector;
