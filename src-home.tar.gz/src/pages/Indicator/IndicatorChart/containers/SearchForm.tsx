import React, { Component, ReactNode } from 'react';
import { inject, observer } from 'mobx-react';
import { Form, Button, DatePicker, Col, message, Select } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import Selector from '../components/Selector';
import styles from '../index.less';

const { Option } = Select;
const FormItem = Form.Item;
const { RangePicker } = DatePicker;

interface IProps extends FormComponentProps {
  store?: any;
}
interface IState {}

@inject('store')
@observer
class SearchForm extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public handleSearch = () => {
    const {
      form: { validateFields },
      store: { getChartData }
    } = this.props;

    validateFields((errors, values) => {
      if (errors) {
        message.error('选择参数有异常, 请重新选择!');
        return;
      }

      const result: any[] = [];

      _.forOwn(values, (value, key) => {
        if (_.isNil(value) || _.isEmpty(value)) return;

        const temp: any = {};
        const [id, type] = key.split('_');

        if (type === '3') {
          const [start, end] = value;

          temp.timeValue = {
            endTime: start.unix() * 1000,
            startTime: end.unix() * 1000
          };
        } else {
          temp.numValue = type === '1' ? value : +value;
        }

        temp.dimensionId = id;
        temp.dimensionType = type;

        result.push(temp);
      });

      getChartData(result);
    });
  };

  public renderFormItem = (field: any): ReactNode => {
    const { dimensionId, dimensionType } = field;
    const {
      getFieldData,
      indicatorInfo: { themeId, groupId }
    } = this.props.store;

    switch (dimensionType) {
      case 1:
      case 2:
        return (
          <Selector
            params={{ themeId, groupId, dimensionId }}
            loadData={getFieldData}
            formKey={{ id: 'id', value: 'value', name: 'value' }}
          />
        );
      case 3:
        return <RangePicker />;
      default:
        return null;
    }
  };

  public render() {
    const { fieldList, handleChartTypeChange } = this.props.store;
    const { getFieldDecorator } = this.props.form;

    return (
      <div className={styles.searchBox}>
        <Form onSubmit={this.handleSearch}>
          {fieldList.map((field: any) => {
            const { dimensionShowName, dimensionId, dimensionType } = field;

            return (
              <Col xl={6} xxl={4} key={dimensionId}>
                <FormItem
                  label={dimensionShowName}
                  labelCol={{ span: 4 }}
                  wrapperCol={{ span: 18 }}
                >
                  {getFieldDecorator(`${dimensionId}_${dimensionType}`)(
                    this.renderFormItem(field)
                  )}
                </FormItem>
              </Col>
            );
          })}
          <Col xl={6} xxl={4}>
            <Select defaultValue="line" onChange={handleChartTypeChange}>
              <Option value="line">折线图</Option>
              <Option value="column">柱状图</Option>
              <Option value="pie">饼图</Option>
            </Select>
          </Col>
          <Col xl={6} xxl={4}>
            <Button type="primary" htmlType="submit">
              搜索
            </Button>
          </Col>
        </Form>
      </div>
    );
  }
}

export default Form.create<IProps>()(SearchForm);
