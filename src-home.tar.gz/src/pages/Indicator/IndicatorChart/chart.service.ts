import http from '@services/http';

//获取搜索字段列表
export const getFields = (data: any): Promise<any> => {
  return http.get(
    `/inter-api/dam-indicator/indicator/data/dimension/query/${data.groupId}`
  );
};

//获取字段数据
export const getFieldData = (data: any): Promise<any> => {
  const { groupId, themeId, dimensionId } = data;

  return http.get(
    `/inter-api/dam-indicator/indicator/data/dimension/value/${themeId}/${groupId}/${dimensionId}`,
    data
  );
};

//获取指标数据，图表用
export const getIndicatorData = (data: any): Promise<any> => {
  return http.post('/inter-api/dam-indicator/indicator/data', data);
};
