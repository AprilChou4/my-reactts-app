import { observable, action, runInAction, toJS } from 'mobx';
import qs from 'qs';
import { message } from 'sup-ui';

import { transJsonParse } from '@utils/common';
import {
  groupIndicatorCacheData,
  getTimeDimensionStatus
} from '@utils/indicator';
import {
  updateIndicatorGroupInfo,
  getGroupDetail,
  getTimeConfig,
  updateRuleTask,
  getGroupData,
  createIndicatorGroupDetail,
  updateIndicatorGroupDetail,
  getIndicatorOutputAuth,
  verifyIndicator,
  updateDataOutput
} from './groupDetail.service';

/**
 * @description:
 * 指标类型说明 indicator type：
 * 1： 基于宽表中的数值类型 进行表达式计算
 * 2： 基于宽表中的数值类型 进行基础求和求平均 计算
 * 3： 基于已经使用的指标 进行表达式计算
 * 4： 基于已经使用的指标 进行基础求和求平均计算
 * 字段类型说明 field propType:
 * 1： 文本类型  原始数据类型  string
 * 2： 数值型  原始数据类型 inter/float/double/boolean 等
 * 3： 时间类型  原始数据类型  year/time/date/timestamp
 * "customIndicator": 前端自定义类型  可基于宽表数值进行表达式计算
 * "reprocessIndicator": 前端自定义类型  可基于已经存在的指标进行表达式计算
 */
class GroupDetailStore {
  private readonly history: any;
  private readonly globalStore: any;
  private readonly pathname: string;
  private getGroupData: any;
  public getTimeConfig: any;
  private getIndicatorOutputAuth: any;
  private readonly maxDimensionNumber = 8;
  private readonly maxIndicatorNumber = 8;
  @observable public isCreateDetail = false; // 标识该指标组是否被创建过
  @observable public detailLoading = false;
  @observable public fields: any[] = [];
  @observable public customizeIndicator: any[] = []; //自定义指标（大于等于当前指标组的维度）
  @observable public exprIndicator: any[] = []; // 表达式使用的指标（小于等于当期指标组的维度）
  @observable public filters: any[] = [];
  @observable public filterStatus = true;
  @observable public dimensionList: any[] = []; //维度列表
  @observable public indicatorList: any[] = []; //数值列表
  @observable public dimensionTime: any = {};
  @observable public systemTimeConfig: any = {}; // 系统配置全局的时间偏移量
  @observable public queryDataTotal = 0;
  @observable public queryTableHTML = '';
  @observable public ruleInfo: any = {};
  @observable public dataOutput: any = {};
  @observable public dimensionActiveIndex = -1;
  @observable public indicatorActiveIndex = -1;
  @observable public indicatorVisible = false;
  @observable public timeVisible = false;
  @observable public customVisible = false;
  @observable public batchDimensionVisible = false;
  @observable public batchIndicatorVisible = false;
  @observable public outputAuth: {
    model?: boolean;
    instance?: boolean;
    templateInfoList?: any[];
  } = {};

  @observable public groupBaseInfo: any = {
    groupId: undefined,
    groupName: '',
    groupOtherName: '',
    themeId: undefined,
    themeOtherName: ''
  };

  public constructor(
    globalStore: any,
    {
      history,
      themeId,
      groupId,
      pathname
    }: {
      history: any;
      themeId: string;
      groupId: string;
      pathname: string;
    }
  ) {
    this.pathname = pathname;
    this.globalStore = globalStore;
    this.history = history;
    runInAction(() => {
      this.groupBaseInfo.themeId = themeId;
      this.groupBaseInfo.groupId = groupId;
    });
    this.getGroupDetail();
    this.getGroupData = _.debounce(this.getGroupDataApi, 600);
    this.getTimeConfig = _.debounce(this.getTimeConfigFn, 600);

    this.getIndicatorOutputAuth = _.debounce(
      this.getIndicatorOutputAuthApi,
      600
    );
    this.getParams = this.getParams.bind(this);
  }

  @action.bound
  public handleDimensionSelect = (index: number) => {
    const targetItem = this.dimensionList[index];
    if (targetItem.propType === 3) {
      this.dimensionActiveIndex = index;
      this.timeVisible = true;
    }
  };

  @action.bound
  public handleIndicatorSelect = (index: number) => {
    const targetItem = this.indicatorList[index];
    if (!this.dimensionList.length) {
      message.warning('对指标进行编辑，维度不能为空！');
      return;
    }
    if (
      targetItem.propType === 'customIndicator' ||
      targetItem.type === 1 ||
      targetItem.type === 3
    ) {
      this.customVisible = true;
    } else if (targetItem.type === 2 || targetItem.type === 4) {
      this.indicatorVisible = true;
    }
    this.indicatorActiveIndex = index;
  };

  @action.bound
  public closeIndicatorVisible = () => {
    this.indicatorVisible = false;
    this.indicatorActiveIndex = -1;
  };

  @action.bound
  public closeCustomVisible = () => {
    this.customVisible = false;
    this.indicatorActiveIndex = -1;
  };

  @action.bound
  public handleBatchAdd = (type: 'dimension' | 'indicator') => {
    if (type === 'dimension') {
      this.batchDimensionVisible = true;
    } else if (type === 'indicator') {
      this.batchIndicatorVisible = true;
    }
  };

  @action.bound
  public async getTimeConfigFn() {
    const res = await getTimeConfig();
    if (res.code !== 200) return;
    runInAction(() => {
      if (!_.isEmpty(res.data)) {
        this.systemTimeConfig = transJsonParse(res.data);
      }
    });
  }

  @action.bound
  public async getGroupDetail() {
    this.detailLoading = true;
    const params = _.pick(this.groupBaseInfo, ['themeId', 'groupId']);
    const res = await getGroupDetail(params);
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.error(res.message);
      runInAction(() => {
        this.detailLoading = false;
      });
      return;
    } else {
      const {
        fields = [],
        group = {},
        timeConfig = '{}'
      } = _.isNil(res.data) ? {} : res.data;

      const { statistics, dimension, time } = group;
      let indicatorList: any[] = [];
      let dimensionList: any[] = [];
      let dimensionTime: any = {};
      if (statistics) {
        indicatorList = _.map(transJsonParse(statistics, []), item => {
          return {
            ..._.find(fields, o => o.id === item.id),
            ...item,
            isCreated: true
          };
        });
      }

      if (time) {
        dimensionTime = transJsonParse(time);
        dimensionTime.timeJson = dimensionTime.timeJson
          ? transJsonParse(dimensionTime.timeJson)
          : '';
      }
      if (dimension) {
        let timeCount = 0; // 记录是否存在时间类型的维度次数
        // 先判断维度列表中是否存在时间类型的宽表字段
        // 存在解析时间配置参数  反之 为空 （
        // 注：原始配置维度中含有时间类型有可能因为主题定义数据类型改变，导致渲染有误，所以需要判断维度列表中是否含有时间类型）
        dimensionList = _.map(transJsonParse(dimension, []), item => {
          const targetField = _.find(fields, o => o.id === item) || {};
          if (targetField.propType === 3) {
            timeCount++;
          }
          return {
            ...targetField
          };
        });
        if (timeCount === 0) {
          dimensionTime = {};
        }
      }
      runInAction(() => {
        // 将字段按 3（时间）1（文本）2（数值）类型进行排序
        this.fields = _.sortBy(fields, i =>
          i.propType === 3 ? 1 : i.propType === 2 ? 2 : 3
        );
        if (group.filters) {
          this.filters = transJsonParse(group.filters, []);
        }
        if (group.cornLayout) {
          this.ruleInfo = transJsonParse(group.cornLayout);
        }
        this.indicatorList = indicatorList;
        this.dimensionList = dimensionList;
        this.dimensionTime = dimensionTime;
        this.groupBaseInfo = _.assign(
          this.groupBaseInfo,
          _.pick(group, ['groupName', 'groupOtherName', 'themeOtherName'])
        );
        this.dataOutput = _.get(group, 'output', {});
        this.isCreateDetail = group.createDetail;
        this.systemTimeConfig = transJsonParse(timeConfig);
        this.getFilterStatus();
        this.getIndicatorOutputAuth();
      });
    }
  }

  /**
   * @description: 检验时间维度
   * 当时间维度数量大于等于2 返回false
   * 当时间维度数量等于1  但是没有配置dimensionTime 返回false
   * @return {boolean}
   */

  private verifyDimensionTime = () => {
    const dimensionTime: any = toJS(this.dimensionTime);
    const dimTimeLen = _.filter(
      this.dimensionList,
      item => item.propType === 3
    ).length;
    if (dimTimeLen > 1) {
      return false;
    } else if (dimTimeLen === 1 && _.isEmpty(dimensionTime)) {
      return false;
    } else {
      return true;
    }
  };

  /**
   * @description: 获取保存和查询缓存数据参数
   * 当维度或者指标数量超过最大限值 或者 配置信息有误 维度还有多个时间类型
   * 返回 false 表示发送给后台数据有误，前端拦截请求
   * @return {boolean|object} 当为false 标识数据有误
   */
  private getParams = () => {
    if (
      !this.dimensionList.length ||
      this.dimensionList.length > this.maxDimensionNumber ||
      !this.indicatorList.length ||
      this.indicatorList.length > this.maxIndicatorNumber ||
      _.some(this.dimensionList, item => item.status) ||
      _.some(this.indicatorList, item => item.status) ||
      !this.filterStatus
    ) {
      return false;
    }

    const verifyTimeRes = this.verifyDimensionTime();
    if (!verifyTimeRes) return false;

    const formatIndicatorList = _.map(this.indicatorList, item => {
      if (item.type === 1 || item.type === 3) {
        const exprBase = item.expr.slice(0, item.expr.lastIndexOf(',[PROP('));
        const exprPostfix = _.map(
          this.dimensionList,
          itm => `PROP("1.${this.groupBaseInfo.themeId}.${itm.name}")`
        ).join(',');
        item.expr = `${exprBase},[${exprPostfix}])`;
      }
      item.rid = _.get(
        _.find(this.customizeIndicator, o => o.otherName === item.otherName),
        'id'
      );
      return item;
    });
    const dimensionTime: any = toJS(this.dimensionTime);
    const params = {
      dimensionTime: _.isEmpty(dimensionTime)
        ? ''
        : JSON.stringify(dimensionTime),
      dimension: _.map(this.dimensionList, i => i.id),
      filters: this.filters,
      statistics: JSON.stringify(formatIndicatorList)
    };

    if (_.isEmpty(dimensionTime)) {
      params.dimensionTime = '';
    } else {
      dimensionTime.timeJson = dimensionTime.systemType
        ? ''
        : JSON.stringify(dimensionTime.timeJson);
      params.dimensionTime = JSON.stringify(dimensionTime);
    }
    return params;
  };

  /**
   * @description: 最大数量提示
   * @param {string} type dimension indicator
   */
  private maxTips = (type: 'dimension' | 'indicator') => {
    if (type === 'dimension') {
      message.warning(`维度个数超过${this.maxDimensionNumber}个，请校验核查！`);
    } else if (type === 'indicator') {
      message.warning(`数值个数超过${this.maxIndicatorNumber}个，请校验核查！`);
    }
  };

  /**
   * @description: 保存操作
   * 当指标组没有创建，走创建（post）逻辑
   * 当指标已经创建，走修改（put）逻辑
   */
  @action.bound
  public async onSave(callback: (data: any[]) => void) {
    if (this.detailLoading) return;
    const params: any = this.getParams();
    if (params === false) {
      message.warning('指标组态信息有误，请核对！');
      return;
    } else if (this.dimensionList.length > this.maxDimensionNumber) {
      this.maxTips('dimension');
      return;
    } else if (this.indicatorList.length > this.maxIndicatorNumber) {
      this.maxTips('indicator');
      return;
    }
    this.detailLoading = true;
    params.id = Number(this.groupBaseInfo.groupId);

    if (this.isCreateDetail) {
      const res = await updateIndicatorGroupDetail(params);
      if (_.isNil(res)) return;
      if (res.code !== 200) {
        // 特殊业务逻辑状态码，返回指标错误依赖树
        if (res.code === 90101216) {
          callback(transJsonParse(res.message, []));
        } else {
          message.error(res.message);
        }
        runInAction(() => {
          this.detailLoading = false;
        });
        return;
      } else {
        message.success('更新成功');
        runInAction(() => {
          this.indicatorList = _.map(this.indicatorList, item => ({
            ...item,
            isCreated: true
          }));
          this.detailChange(false);
          this.getIndicatorOutputAuth();
        });
      }
    } else {
      const res = await createIndicatorGroupDetail(params);
      if (_.isNil(res)) return;
      if (res.code !== 200) {
        if (res.code === 90101216) {
          callback(transJsonParse(res.message, []));
        } else {
          message.error(res.message);
        }
        runInAction(() => {
          this.detailLoading = false;
        });
        return;
      } else {
        message.success('创建成功');
        runInAction(() => {
          this.isCreateDetail = true;
          this.indicatorList = _.map(this.indicatorList, item => ({
            ...item,
            isCreated: true
          }));
          this.detailChange(false);
          this.getIndicatorOutputAuth();
        });
      }
    }

    this.globalStore.clearCachePages([
      `/indicator/definition`,
      `/indicator/manager`
    ]);
  }

  /**
   * @description: 当指标组发生维度、指标、条件过滤信息变化时，获取缓存数据
   * 获取缓存后的数据根据维度进行聚合
   */
  @action.bound
  public async getGroupDataApi() {
    const params = this.getParams();
    if (params === false) {
      runInAction(() => {
        this.queryTableHTML = '';
        this.queryDataTotal = 0;
        this.detailLoading = false;
      });
      return;
    }
    this.detailLoading = true;
    const res = await getGroupData({
      ...params,
      groupId: Number(this.groupBaseInfo.groupId)
    });
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.error(res.message);
      runInAction(() => {
        this.detailLoading = false;
        this.queryTableHTML = '';
        this.queryDataTotal = 0;
      });
      return;
    } else {
      if (_.isNil(res.data)) return;
      const data = _.isNil(res.data.data) ? [] : res.data.data;
      const title = _.isNil(res.data.title) ? [] : res.data.title;
      runInAction(() => {
        let timeParams;
        if (!_.isEmpty(this.dimensionTime)) {
          const { name, clientDataType } =
            _.find(
              this.dimensionList,
              i => i.id === this.dimensionTime.propId
            ) || {};
          timeParams = {
            key: name,
            clientDataType,
            dimensionTime: this.dimensionTime,
            systemTimeConfig: this.systemTimeConfig
          };
        }

        // 获取缓存数据聚合之后的结果，（columns dataSource）
        const tableDom = groupIndicatorCacheData(
          title,
          data,
          title.length - this.indicatorList.length,
          timeParams ? timeParams : undefined
        );
        this.queryTableHTML = tableDom;
        this.queryDataTotal = data.length;
        this.detailLoading = false;
      });
    }
  }

  /**
   * @description: 校验条件过滤的状态信息
   * 当指标含有派生指标时，过滤条件只能选择当前指标组的维度字段
   * 反之所有字段都能够过滤
   * @return  {boolean} filterStatus
   */
  private getFilterStatus = () => {
    if (!this.filters.length) {
      this.filterStatus = true;
      return;
    }
    const hasDerive = _.some(
      this.indicatorList,
      i => i.type === 3 || i.type === 4
    );
    if (hasDerive) {
      const dimensionTimeId = _.get(this.dimensionTime, 'propId');

      this.filterStatus = _.every(this.filters, i => {
        const isInclude = _.some(this.dimensionList, dim => dim.id === i.id);
        if (!isInclude) return false;
        if (i.id === dimensionTimeId) {
          return getTimeDimensionStatus(
            i.content,
            this.dimensionTime,
            this.systemTimeConfig
          );
        } else {
          return true;
        }
      });
    } else {
      this.filterStatus = true;
    }
  };

  /**
   * @description: 当指标创建或发生变化之后，校验指标是否配置正确，仅作前端校验
   * 1.判断指标的名称别名配置与否，是否重复（别名需校验所有，包括宽表字段的别名）
   * 2.当作聚合计算的原子指标（type为2），需判断依赖的原始宽表属性是否存在
   * 3.当作聚合计算的派生指标（type为4），需判断依赖的已创建的指标是否有使用权限
   */
  private getIndicatorVerifyStatus = (
    targetIndicator: any,
    indicatorIndex: number
  ) => {
    const { type, id, otherName, name } = targetIndicator;
    /**
     * 所有指标必须先校验是否存在别名
     * 其次判断未创建的指标 是否与 宽表字段 / 正在组态的指标列表 / 可使用的指标 有别名重复
     * 如果别名存在且不重复，则校验各个类型的指标其依赖性
     */
    if (!otherName || !name) {
      return '指标别名/名称未配置！';
    } else if (
      !targetIndicator.isCreated &&
      (_.some(this.fields, i => i.otherName === otherName || i.name === name) ||
        _.some(
          this.indicatorList,
          (i, index: number) =>
            indicatorIndex !== index &&
            (i.otherName === otherName || i.name === name)
        ) ||
        _.some(
          _.concat(this.customizeIndicator, this.exprIndicator),
          i => i.otherName === otherName || i.name === name
        ))
    ) {
      return '指标别名/名称已存在';
    }

    //基于已经定义的指标进行基础计算,无论保存创建与否，都需要判断其是否在宽表字段中存在
    if (type === 2 && !_.some(this.fields, i => i.id === id)) {
      return '依赖的指标维度发生变化，当前指标不可用';
    }
    // 基于已经创建并使用的指标做派生计算，校验目标指标的数据源是否在自定义指标列表中存在
    if (
      type === 4 &&
      !_.some(
        this.customizeIndicator,
        i => i.otherName === _.get(targetIndicator, 'sourceName[0].otherName')
      )
    ) {
      return '依赖的指标维度发生变化，当前指标不可用';
    }

    // 当是表达式指标时，需要分析其依赖的原始字段或者指标 是否存在
    // 指标类型为4，其依赖指标可能为其他指标组的指标，不予校验
    if (type === 1 || type === 3) {
      if (_.isString(targetIndicator.expr)) {
        let verifyRes = true;
        const useableFields = _.filter(
          this.fields,
          field => !_.includes(['Boolean', 'Bytes'], field.clientDataType)
        );
        // 判断之前先把维度信息剔除，维度所支持的数据类型和指标所支持的不同，只判断主体表达式部分
        // 对表达式中含有派生指标的，需根据可使用的表达式指标（exprIndicator）进行是否存在判断
        targetIndicator.expr
          .slice(0, targetIndicator.expr.lastIndexOf(',[PROP('))
          .replace(
            /PROP\(\"1\.\d+\.([A-Za-z0-9_\u4E00-\u9FA5]+)\"\)/g,
            (_v1: string, v2: string) => {
              const target = _.find(useableFields, o => o.name === v2);
              if (_.isNil(target)) verifyRes = false;
            }
          )
          .replace(
            /PROP\(\"2\.\d+\.([a-zA-Z0-9_]+)\"\)/g,
            (_v1: string, v2: string) => {
              const target = _.find(
                this.exprIndicator,
                i => i.otherName === v2
              );
              if (_.isNil(target)) verifyRes = false;
            }
          );
        if (!verifyRes) {
          return '依赖的指标维度发生变化，当前指标不可用';
        }
      } else {
        return '指标表达式有误或未配置';
      }
    }

    return '';
  };

  private getSourceName = (item: any) => {
    if (item.type === 2) {
      const { name } = _.find(this.fields, i => i.id === item.id) || item;
      return name;
    } else {
      const { sourceName } =
        _.find(
          this.customizeIndicator,
          i => i.otherName === item.otherName && i.type === item.type
        ) || item;
      return sourceName;
    }
  };

  /**
   * @description: 当维度信息发生改变，重新获取指标输出权限
   * 当输出权限发生改变，则重置已经配置过输出信息的指标
   */
  @action.bound
  public async getIndicatorOutputAuthApi() {
    const verifyTimeRes = this.verifyDimensionTime();
    if (!verifyTimeRes) {
      this.detailLoading = false;
      return;
    }
    this.detailLoading = true;
    const res = await getIndicatorOutputAuth(
      this.groupBaseInfo.themeId,
      this.groupBaseInfo.groupId,
      {
        dimensionBOs: this.dimensionList,
        dimensionTimeVO: _.isEmpty(this.dimensionTime)
          ? null
          : JSON.stringify(this.dimensionTime)
      }
    );
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.error(res.message);
      runInAction(() => {
        this.detailLoading = false;
      });
      return;
    } else {
      this.getGroupData();
      runInAction(() => {
        const { outInfo = {}, forAggTags = [], forExprTags = [] } = res.data;
        const outputAuth = _.isNil(outInfo) ? {} : outInfo;
        this.outputAuth = outputAuth || {};
        this.customizeIndicator = forAggTags;
        this.exprIndicator = forExprTags;
        const indicatorList: any[] = toJS(this.indicatorList);
        const errorOutput: string[] = [];
        /**
         * 如果新的输出权限为输出到模板
         * 已经配置过输出信息为输出到非模板的需要置空
         */
        if (outputAuth.model) {
          this.indicatorList = _.map(indicatorList, (item, index: number) => {
            let newIndicator;
            item.sourceName = this.getSourceName(item);
            if (item.outType && `${item.outType}` !== '1') {
              newIndicator = {
                ...item,
                outType: undefined,
                outputType: undefined,
                outputInfo: undefined,
                extraConfig: undefined
              };
              errorOutput.push(item.name);
            } else {
              newIndicator = item;
            }
            newIndicator.status = this.getIndicatorVerifyStatus(
              newIndicator,
              index
            );
            return newIndicator;
          });
        } else if (outputAuth.instance) {
          /**
           * 如果新的输出权限为输出到实例
           * 已经配置过输出信息为输出到非实例的需要置空
           */
          this.indicatorList = _.map(indicatorList, (item, index: number) => {
            let newIndicator;
            item.sourceName = this.getSourceName(item);
            if (item.outType && `${item.outType}` !== '2') {
              newIndicator = {
                ...item,
                outType: undefined,
                outputType: undefined,
                outputInfo: undefined,
                extraConfig: undefined
              };
              errorOutput.push(item.name);
            } else {
              newIndicator = item;
            }
            newIndicator.status = this.getIndicatorVerifyStatus(
              newIndicator,
              index
            );
            return newIndicator;
          });
        } else {
          /**
           * 如果新的输出权限为空，则置空所有已经配置输出权限的指标
           */
          this.indicatorList = _.map(indicatorList, (item, index: number) => {
            let newIndicator;
            item.sourceName = this.getSourceName(item);
            if (item.outType) {
              errorOutput.push(item.name);
              newIndicator = {
                ...item,
                outType: undefined,
                outputType: undefined,
                outputInfo: undefined,
                extraConfig: undefined
              };
            } else {
              newIndicator = item;
            }
            newIndicator.status = this.getIndicatorVerifyStatus(
              newIndicator,
              index
            );
            return newIndicator;
          });
        }

        if (errorOutput.length) {
          message.warning(
            `指标${errorOutput.join(',')}输出权限改变，输出信息已重置！`
          );
        }
      });
    }
  }

  /*********** 维度相关 ***********/
  /**
   * @description: 添加维度信息，默认宽表中的所有字段都可以成为维度，维度数量默认最多8个，最多有一个时间维度
   * 当新增的维度是时间维度，则需要初始化时间维度信息 dimensionTime
   * 新增完成之后需要重新获取指标输出权限信息，重新查询缓存数据
   */
  @action.bound
  public addDimension = ({ target: dimension }: any) => {
    if (this.dimensionList.length >= this.maxDimensionNumber) {
      this.maxTips('dimension');
      return;
    }
    const targetId = dimension.id;
    let originField = _.find(this.fields, item => item.id === targetId) || {};
    if (originField.propType === 3) {
      if (_.isEmpty(this.dimensionTime)) {
        this.dimensionTime = {
          propId: targetId,
          systemType: true,
          type: originField.clientDataType === 'Time' ? 7 : 1,
          timeJson: {}
        };
        originField = { ...originField, ...this.dimensionTime };
      } else {
        message.warning('最多添加一个时间维度！');
        return;
      }
    } else if (
      _.some(
        this.dimensionList,
        i => i.id === originField.id && i.propType === originField.propType
      )
    ) {
      message.warning('该维度已经存在！');
      return;
    }
    this.dimensionList = _.concat(this.dimensionList, originField);
    this.getFilterStatus();
    this.detailChange(true);
    this.getIndicatorOutputAuth();
  };

  /**
   * @description: 批量添加维度
   * @param {array} text 宽表文本型的字段id
   * @param {array} number 宽表中数值型字段的id
   * @param {number|undefined} time 宽表中的时间类型的id 没有选择时间 为undefined
   */
  @action.bound
  public batchAddDimension = (params: any) => {
    const { text = [], number = [], time } = params;
    if (
      this.dimensionList.length + text.length + (_.isNil(time) ? 0 : 1) >
      this.maxDimensionNumber
    ) {
      this.maxTips('dimension');
      return;
    }
    const newDimension: any[] = [];
    const dimensionArr = _.concat(text, number);
    if (dimensionArr.length) {
      _.forEach(dimensionArr, i => {
        const originField = _.find(this.fields, item => item.id === i);
        if (originField) {
          newDimension.push(originField);
        }
      });
    }
    if (!_.isNil(time) && _.isEmpty(this.dimensionTime)) {
      let originField = _.find(this.fields, item => item.id === time);
      if (originField) {
        this.dimensionTime = {
          propId: originField.id,
          systemType: true,
          type: originField.clientDataType === 'Time' ? 7 : 1,
          timeJson: {}
        };
        originField = { ...originField, ...this.dimensionTime };
        newDimension.push(originField);
      }
    }
    if (!newDimension.length) {
      message.warning('所选维度依赖的宽表字段有误，请校验！');
      return;
    } else {
      this.dimensionList = _.concat(this.dimensionList, newDimension);
      this.getIndicatorOutputAuth();
    }
    this.closeBatchDimension();
    this.detailChange(true);
    this.getFilterStatus();
  };

  @action.bound
  public closeBatchDimension = () => {
    this.batchDimensionVisible = false;
  };

  /**
   * @description: 移除维度
   * 当移除的维度为时间维度，则需要重置时间维度信息
   * 删除维度之后需要重新获取维度输出
   */
  @action.bound
  public removeDimension = (index: number) => {
    const targetItem = this.dimensionList[index];
    if (_.isNil(targetItem)) return;
    if (
      targetItem.propType === 3 &&
      targetItem.id === this.dimensionTime.propId
    ) {
      this.dimensionTime = {};
    }
    const dimensionList = toJS(this.dimensionList);
    dimensionList.splice(index, 1);
    this.dimensionList = dimensionList;
    this.getIndicatorOutputAuth();
    this.detailChange(true);
    this.getFilterStatus();
  };

  /**
   * @description: 更新时间维度
   */
  @action.bound
  public updateDimensionTime = (params: any) => {
    const targetItem = this.dimensionList[this.dimensionActiveIndex];
    if (!targetItem) return;
    this.dimensionList[this.dimensionActiveIndex] = {
      ...targetItem,
      ...params
    };
    this.dimensionTime = { ...params, propId: targetItem.id };
    this.closeTimeVisible();
    this.getFilterStatus();
    this.getIndicatorOutputAuth();
    this.detailChange(true);
  };

  @action.bound
  public closeTimeVisible = () => {
    this.timeVisible = false;
    this.dimensionActiveIndex = -1;
  };

  /*********** 指标相关 ***********/
  /**
   * @description: 添加指标，根据不同的数据来源生成不同的类型的指标
   */
  @action.bound
  public addIndicator = ({ target: indicator }: any) => {
    if (this.indicatorList.length >= this.maxIndicatorNumber) {
      this.maxTips('indicator');
      return;
    }
    const { propType } = indicator;
    let indicatorItem;

    if (!_.isNil(propType)) {
      if (propType === 'customIndicator') {
        // 自定义表达式计算，需要根据表达式的类型 判断是原子表达式（type:1） 还是聚合表达式（type:3）
        indicatorItem = {
          ...indicator,
          statType: 1,
          sourceName: ''
        };
      } else {
        // 宽表属性 基础聚合计算 当宽表字段属性类型为文本类型（propType=1） 时默认聚合类型为计数
        indicatorItem = {
          ...indicator,
          type: 2,
          sourceName: indicator.name,
          statType: propType === 1 ? 3 : 1
        };
      }
    } else {
      // 表达式指标再次使用，指标变为聚合类指标 类型为4
      // 基于聚合计算的指标再次求聚合计算，指标类型变成4
      // 新生成的指标是基于已经创建的指标进行二次构建，所以数据源的名称为该指标的名称，数据源所在的维度信息为该指标的维度
      indicatorItem = {
        ...indicator,
        type: 4,
        statType: 1,
        sourceName: [
          {
            name: indicator.name,
            dimensions:
              indicator.dimensionModel &&
              _.isArray(indicator.dimensionModel.groupBy)
                ? indicator.dimensionModel.groupBy
                : []
          }
        ]
      };
    }

    if (!indicatorItem) return;
    indicatorItem.decimalNumber = 2;
    indicatorItem.status = this.getIndicatorVerifyStatus(
      indicatorItem,
      this.indicatorList.length
    );
    this.indicatorList = _.concat(this.indicatorList, indicatorItem);
    this.detailChange(true);
    this.getFilterStatus();
    this.getGroupData();
  };

  /**
   * @description: 批量添加指标
   * @param {array} number 宽表数值型的字段id
   * @param {array} indicator 已经存在的指标的id
   * @param {array} custom 前端自定义指标 customIndicator
   */
  @action.bound
  public batchAddIndicator = (params: any) => {
    const { text = [], number = [], indicator = [], custom = [] } = params;
    if (
      text.length +
        number.length +
        indicator.length +
        custom.length +
        this.indicatorList.length >
      this.maxIndicatorNumber
    ) {
      this.maxTips('indicator');
      return;
    }
    const newIndicator = [];
    if (text.length) {
      _.forEach(text, (i, index: number) => {
        const originField = _.find(this.fields, item => item.id === i);
        if (originField) {
          const indicatorItem = {
            ...originField,
            type: 2,
            statType: 3,
            decimalNumber: 2,
            sourceName: originField.name
          };
          indicatorItem.status = this.getIndicatorVerifyStatus(
            indicatorItem,
            index
          );
          newIndicator.push(indicatorItem);
        }
      });
    }
    if (number.length) {
      _.forEach(number, (i, index: number) => {
        const originField = _.find(this.fields, item => item.id === i);
        if (originField) {
          const indicatorItem = {
            ...originField,
            type: 2,
            statType: 1,
            decimalNumber: 2,
            sourceName: originField.name
          };
          indicatorItem.status = this.getIndicatorVerifyStatus(
            indicatorItem,
            index
          );
          newIndicator.push(indicatorItem);
        }
      });
    }
    if (indicator.length) {
      _.forEach(indicator, i => {
        const originIndicator = _.find(
          this.customizeIndicator,
          item => item.id === i
        );
        if (originIndicator) {
          const indicatorItem = {
            ...originIndicator,
            type: 4,
            decimalNumber: 2,
            sourceName: [
              {
                name: originIndicator.name,
                dimensions:
                  originIndicator.dimensionModel &&
                  _.isArray(originIndicator.dimensionModel.groupBy)
                    ? originIndicator.dimensionModel.groupBy
                    : []
              }
            ]
          };
          indicatorItem.status = this.getIndicatorVerifyStatus(
            indicatorItem,
            this.indicatorList.length
          );
          newIndicator.push(indicatorItem);
        }
      });
    }
    if (custom.length) {
      if (_.includes(custom, 'customIndicator')) {
        const indicatorItem: any = {
          name: '指标自定义',
          statType: 1,
          decimalNumber: 2,
          propType: 'customIndicator'
        };
        indicatorItem.status = this.getIndicatorVerifyStatus(
          indicatorItem,
          this.indicatorList.length
        );
        newIndicator.push(indicatorItem);
      }
    }
    if (!newIndicator.length) {
      return;
    } else {
      this.indicatorList = _.concat(this.indicatorList, newIndicator);
      this.detailChange(true);
      this.closeBatchIndicator();
      this.getFilterStatus();
      this.getGroupData();
    }
  };

  @action.bound
  private closeBatchIndicator = () => {
    this.batchIndicatorVisible = false;
  };

  @action.bound
  public removeIndicator = (index: number) => {
    const targetItem = this.indicatorList[index];
    if (_.isNil(targetItem)) return;
    const indicatorList = toJS(this.indicatorList);
    indicatorList.splice(index, 1);
    this.indicatorList = indicatorList;
    this.detailChange(true);
    this.getFilterStatus();
    this.getGroupData();
  };

  /**
   * @description: 每次编辑完指标保存之前都需要对指标进行校验
   * @param {array} types 不同类型的校验规则
   * 1： 校验别名 （当指标时新建的时候必选，已经创建的指标跳过）
   * 2： 表达式校验 （当指标的类型为 1，3 时必选）
   * 3： 指标输出校验 （当指标配置了输出信息校验）
   * 4： 小数位数校验 （必选）
   * 5： 统计方式校验 （当指标的类型为 2,4 时必选）
   */
  @action.bound
  public updateIndicator = (params: any) => {
    const targetIndicatorItem = {
      ...this.indicatorList[this.indicatorActiveIndex],
      ...params
    };
    //指标类型 1,3 为 表达式指标  2,4 为基础计算指标
    const { type: indicatorType, otherName } = targetIndicatorItem;

    const types = [4];
    if (!targetIndicatorItem.isCreated) {
      types.push(1);
    }

    if (indicatorType === 1 || indicatorType === 3) {
      types.push(2);
    } else if (indicatorType === 2 || indicatorType === 4) {
      types.push(5);
    }
    if (_.isNil(targetIndicatorItem.outType)) {
      types.push(3);
    }
    targetIndicatorItem.rid = _.get(
      _.find(this.customizeIndicator, o => o.otherName === otherName),
      'id'
    );
    const verifyParams = {
      types,
      statistics: targetIndicatorItem,
      groupId: this.groupBaseInfo.groupId,
      themeId: this.groupBaseInfo.themeId,
      dimensionTime: _.isEmpty(this.dimensionTime)
        ? ''
        : JSON.stringify(this.dimensionTime),
      dimension: _.map(this.dimensionList, i => i.id)
    };
    this.detailLoading = true;
    verifyIndicator(verifyParams).then(res => {
      if (res.code && res.data) {
        runInAction(() => {
          targetIndicatorItem.sourceName = transJsonParse(
            _.get(res.data, 'info', '')
          );
          targetIndicatorItem.status = this.getIndicatorVerifyStatus(
            targetIndicatorItem,
            this.indicatorActiveIndex
          );
          this.indicatorList[this.indicatorActiveIndex] = targetIndicatorItem;
          if (indicatorType === 1 || indicatorType === 3) {
            this.closeCustomVisible();
          } else if (indicatorType === 2 || indicatorType === 4) {
            this.closeIndicatorVisible();
          }
          this.detailChange(true);
          this.getFilterStatus();
          this.getGroupData();
        });
      } else {
        message.error(res.message);
        runInAction(() => {
          this.detailLoading = false;
        });
        return;
      }
    });
  };

  /**
   * @description: 维度/指标 拖拽调换编排顺序
   * 维度顺序发生改变需要重新获取指标输出权限信息
   * 指标顺序发生变化只需重新获取缓存数据
   */
  @action.bound
  public exchangeSite = (
    type: 'dimension' | 'indicator',
    originIndex: number,
    targetIndex: number
  ) => {
    let list = [];
    if (type === 'dimension') {
      list = toJS(this.dimensionList);
      [list[originIndex], list[targetIndex]] = [
        list[targetIndex],
        list[originIndex]
      ];
      this.dimensionList = list;
      if (!this.detailLoading) {
        this.getIndicatorOutputAuth();
        this.detailChange(true);
      }
    } else if (type === 'indicator') {
      list = toJS(this.indicatorList);
      [list[originIndex], list[targetIndex]] = [
        list[targetIndex],
        list[originIndex]
      ];
      this.indicatorList = list;
      if (!this.detailLoading) {
        this.getGroupData();
        this.detailChange(true);
      }
    }
  };

  @action.bound
  public async updateDataOutput(params: any, callback: () => void) {
    const res = await updateDataOutput({
      ...params,
      ..._.pick(this.groupBaseInfo, ['groupId', 'themeId'])
    });
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.error(res.message);
      return;
    } else {
      message.success('输出信息设置成功');
      runInAction(() => {
        this.dataOutput = params;
      });
      callback();
    }
  }

  /**
   * @description: 更新过滤条件 （只更新store 不涉及后台交互）
   * 内部编排逻辑由条件过滤组件内部进行处理，只需将最终的 dataSource 更新到 store
   */
  @action.bound
  public updateFilters = (dataSource: any[]) => {
    this.filters = dataSource;
    this.detailChange(true);
    this.getFilterStatus();
    this.getGroupData();
  };

  /**
   * @description: 更新固化规则  与后台有交互 保存成功即入库
   */
  @action.bound
  public async updateRuleTask(params: any, callback: () => void) {
    const res = await updateRuleTask({
      ...params,
      groupId: this.groupBaseInfo.groupId
    });
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.warning(res.message);
      return;
    } else {
      const { cornLayout } = params;
      message.success('固化更新成功');
      runInAction(() => {
        this.ruleInfo = transJsonParse(cornLayout);
      });
      callback();
    }
  }

  /**
   * @description: 更新基本信息 与后台有交互 保存成功即入库
   */
  @action.bound
  public async updateIndicatorGroupInfo(params: any, callback: () => void) {
    params.groupId = this.groupBaseInfo.groupId;
    const res = await updateIndicatorGroupInfo(params);
    if (_.isNil(res)) return;
    if (res.code !== 200) {
      message.error(res.message);
      return;
    } else {
      message.success('编辑成功！');
      runInAction(() => {
        this.groupBaseInfo.groupName = params.groupName;
        const [preFix, qsString] = window.location.hash.split('?');
        const qsForm = qs.parse(qsString);
        qsForm.tab = `${params.groupName}-指标组`;
        window.location.hash = `${preFix}?${qs.stringify(qsForm)}`;
        this.globalStore.clearCachePages([`/indicator/definition`]);
      });
      callback();
    }
  }

  @action.bound
  public pushRoute = (path: string) => {
    this.history.push(path);
  };

  @action.bound
  public detailChange = (bool: boolean) => {
    this.globalStore.changePromptMap(this.pathname, bool);
  };
}

export default GroupDetailStore;
