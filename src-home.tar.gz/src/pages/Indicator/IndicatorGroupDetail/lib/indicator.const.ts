export const statTypeList = [
  {
    key: 1,
    name: '求和',
    expr: 'STAT_SUM',
    disabledPropType: [1]
  },
  {
    key: 2,
    name: '平均',
    expr: 'STAT_AVG',
    disabledPropType: [1]
  },
  { key: 3, name: '计数', expr: 'STAT_COU', disabledDataType: [] },
  { key: 4, name: '去重计数', expr: 'STAT_DIS', disabledDataType: [] },
  {
    key: 5,
    name: '最大值',
    expr: 'STAT_MAX',
    disabledPropType: [1]
  },
  {
    key: 6,
    name: '最小值',
    expr: 'STAT_MIN',
    disabledPropType: [1]
  }
];

export const statTypeMapping: { [propName: number]: string } = {
  1: '求和',
  2: '平均',
  3: '计数',
  4: '去重计算',
  5: '最大值',
  6: '最小值'
};

export const statTypeEnum: { [propName: string]: string } = {
  STAT_SUM: '求和',
  STAT_AVG: '平均',
  STAT_MAX: '最大值',
  STAT_MIN: '最小值',
  STAT_COU: '计数',
  STAT_DIS: '去重计数'
};

export const decimalNumbers = [2, 3, 4, 5, 6, 7, 8];
