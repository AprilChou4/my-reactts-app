import React, { FunctionComponent, Fragment } from 'react';
import { Form, Input, Select } from 'sup-ui';
import { nameRule } from '@consts/rules';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  getFieldDecorator: any;
  serviceList: any[];
  loading: boolean;
  resourceId: undefined | string;
  formName: string;
  formAlias: string;
}

const OutputTemp: FunctionComponent<IProps> = (props: IProps) => {
  const {
    getFieldDecorator,
    resourceId,
    loading,
    formName,
    formAlias,
    serviceList
  } = props;
  return (
    <Fragment>
      <FormItem label="supOS实例">
        {getFieldDecorator('resourceId', {
          initialValue: resourceId,
          rules: [{ required: true, message: '请选择supOS实例!' }]
        })(
          <Select placeholder="—请选择—" loading={loading}>
            {_.map(serviceList, item => (
              <Option key={item.id} value={item.id}>
                {item.showName}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      <FormItem label="表单模板名称" colon={false}>
        {getFieldDecorator('formName', {
          initialValue: formName,
          rules: [
            { message: `请输入表单模板名称`, required: true },
            { max: 200, message: `指标组名称长度不能超过200!` }
          ]
        })(<Input />)}
      </FormItem>
      <FormItem label="别名" colon={false}>
        {getFieldDecorator('formAlias', {
          initialValue: formAlias,
          rules: [
            { message: `请输入表单模板别名`, required: true },
            { pattern: nameRule.pattern, message: nameRule.message }
          ]
        })(<Input />)}
      </FormItem>
    </Fragment>
  );
};

export default OutputTemp;
