import React, { FunctionComponent, Fragment } from 'react';
import { Form, Input } from 'sup-ui';
import { nameRule } from '@consts/rules';
import styles from './index.less';

const FormItem = Form.Item;

interface IProps {
  getFieldDecorator: any;
  name: string;
  otherName: string;
  usedNames: {
    otherNames: string[];
    names: string[];
  };
  onChange: (type: 'name' | 'otherName', value: string) => void;
  disabled?: boolean;
}

const IndicatorName: FunctionComponent<IProps> = (props: IProps) => {
  const {
    getFieldDecorator,
    name,
    otherName,
    usedNames,
    onChange,
    disabled = false
  } = props;
  const { otherNames = [], names = [] } = usedNames || {};
  return (
    <Fragment>
      <div className={styles.title}>指标定义</div>

      <FormItem label="指标名称" className={styles.formItem}>
        {getFieldDecorator('name', {
          initialValue: name,
          rules: [
            {
              required: true,
              pattern: /^[A-Za-z0-9_\u4E00-\u9FA5]+$/,
              message: '只允许输入字母、数字、中文及下划线'
            },
            { whitespace: true, message: '请输入字符' },
            {
              validator: (_rules: any, value: any, callback: any) => {
                if (disabled) {
                  callback();
                } else if (_.includes(names, _.toLower(value))) {
                  callback('该名称已经在创建的指标中使用！');
                } else {
                  callback();
                }
              }
            }
          ],
          validateTrigger: ['onChange', 'onBlur']
        })(
          <Input
            placeholder="请输入"
            size="large"
            onChange={(e: any) => {
              onChange('name', e.target.value);
            }}
          />
        )}
      </FormItem>
      <FormItem label="指标别名" className={styles.formItem}>
        {getFieldDecorator('otherName', {
          initialValue: otherName,
          rules: [
            {
              required: true,
              ...nameRule
            },
            { whitespace: true, message: '请输入字符' },
            {
              validator: (_rules: any, value: any, callback: any) => {
                if (disabled) {
                  callback();
                } else if (_.includes(otherNames, _.toLower(value))) {
                  callback('该别名已经在宽表字段或指标中使用！');
                } else {
                  callback();
                }
              }
            }
          ],
          validateTrigger: ['onChange', 'onBlur']
        })(
          <Input
            placeholder="请输入"
            size="large"
            disabled={disabled}
            onChange={(e: any) => {
              onChange('otherName', e.target.value);
            }}
          />
        )}
      </FormItem>
    </Fragment>
  );
};

export default IndicatorName;
