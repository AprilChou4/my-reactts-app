import React, { FunctionComponent, Fragment } from 'react';
import { useDrag, useDrop } from 'react-dnd';
import classnames from 'classnames';
import { Tooltip, Row, Col } from 'sup-ui';

import Icon from '@components/Icon';
import { getIndicatorSourceName } from '@utils/indicator';

import styles from './index.less';

interface IProps {
  item: any;
  type: string;
  index: number;
  active: boolean;
  onMove: (originIndex: number, targetIndex: number) => void;
  onSelect: (index: number) => void;
  onRemove: (index: number) => void;
}

const DropListItem: FunctionComponent<IProps> = ({
  item,
  type,
  index,
  active,
  onMove,
  onSelect,
  onRemove
}: IProps) => {
  const [, drop] = useDrop({
    accept: `${type}_field_drop`,
    drop: (props: any) => {
      onMove(index, props.index);
    }
  });
  const [, drag] = useDrag({
    item: { type: `${type}_field_drop`, index },
    collect: monitor => ({
      isDragging: monitor.isDragging()
    })
  });
  const sourceName = getIndicatorSourceName(item.sourceName);
  return (
    <li
      ref={node => drag(drop(node))}
      className={classnames(styles.listItem, active ? styles.active : '')}
    >
      {item.status ? (
        <Tooltip title={item.status}>
          <Icon type="tips-warning" />
          <span
            className={styles.name}
            onClick={() => {
              onSelect(index);
            }}
          >
            {item.name}
          </span>
        </Tooltip>
      ) : (
        <Tooltip
          overlayClassName={styles.tooltipWrapper}
          title={
            <Fragment>
              <Row>
                <Col span={7} className={styles.tooltipLabel}>
                  数据来源
                </Col>
                <Col span={17}>{sourceName}</Col>
              </Row>
              {(item.type === 3 || item.type === 4) && (
                <Fragment>
                  {_.map(item.sourceName, (sourceItem, i) =>
                    _.isArray(sourceItem.dimensions) &&
                    sourceItem.dimensions.length ? (
                      <Row key={`${sourceItem.name}_${i}`}>
                        <Col
                          span={7}
                          className={styles.tooltipLabel}
                          title={sourceItem.name}
                        >
                          {sourceItem.name}
                        </Col>
                        <Col span={17}>{sourceItem.dimensions.join(',')}</Col>
                      </Row>
                    ) : (
                      ''
                    )
                  )}
                </Fragment>
              )}
              <Row>
                <Col span={7} className={styles.tooltipLabel}>
                  字段
                </Col>
                <Col span={17}>{item.otherName}</Col>
              </Row>
              <Row>
                <Col span={7} className={styles.tooltipLabel}>
                  字段名称
                </Col>
                <Col span={17}>{item.name}</Col>
              </Row>
            </Fragment>
          }
        >
          <span
            className={styles.name}
            onClick={() => {
              onSelect(index);
            }}
          >
            {item.name}
          </span>
        </Tooltip>
      )}

      <Icon
        type="close"
        onClick={(e: any) => {
          e.stopPropagation();
          onRemove(index);
        }}
      />
    </li>
  );
};

export default DropListItem;
