import React, { FunctionComponent } from 'react';
import { Input } from 'sup-ui';

import styles from './index.less';

const { Search } = Input;

interface IProps {
  onSearch: (value: string) => void;
}

const FieldSearch: FunctionComponent<IProps> = (props: IProps) => {
  const { onSearch } = props;
  return (
    <dt className={styles.header}>
      <Search
        placeholder="输入关键字搜索"
        onChange={(e: any) => {
          onSearch(e.target.value);
        }}
      />
    </dt>
  );
};

export default FieldSearch;
