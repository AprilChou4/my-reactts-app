import React, { FunctionComponent } from 'react';
import Icon from '@components/Icon';

interface IProps {
  propType: number | string;
  type?: number;
}

const PropIcon: FunctionComponent<IProps> = ({ propType, type }: IProps) => {
  const getIconType = () => {
    if (propType === 1) {
      return 'text';
    } else if (propType === 2) {
      return 'number';
    } else if (propType === 3) {
      return 'time';
    } else if (
      propType === 'customIndicator' ||
      propType === 'reprocessIndicator'
    ) {
      return 'DIY';
    } else if (type === 1 || type === 2 || type === 3 || type === 4) {
      return 'number';
    } else {
      return '';
    }
  };
  return <Icon type={`indicator-${getIconType()}`} size="small" />;
};

export default PropIcon;
