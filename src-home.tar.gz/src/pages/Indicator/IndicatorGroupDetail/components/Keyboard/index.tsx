import React, { FunctionComponent, useState, Fragment } from 'react';
import { Tooltip } from 'sup-ui';

import Icon from '@components/Icon';
import { calculatorLeftMid, calculatorRightMid } from '../../lib/keyboard';

import classnames from 'classnames';

import styles from './index.less';

interface IDeclarationProps {
  title: string;
  description: string;
  example: string;
}
const Declaration: FunctionComponent<IDeclarationProps> = (
  item: IDeclarationProps
) => {
  return (
    <Fragment>
      <h4 className={styles.title}>{item.title}</h4>
      <p className={styles.description}>{item.description}</p>
    </Fragment>
  );
};

interface IFlexContentProps {
  data: any;
  onClick: (value: string, wrapRange?: number) => void;
}
const KeyboardFlexContent: FunctionComponent<IFlexContentProps> = (
  props: any
) => {
  const { data, onClick } = props;
  return (
    <ul className={styles.calculator}>
      {_.map(data, item => (
        <li
          key={item.key}
          onClick={() => {
            onClick(`${item.key}`);
          }}
          className={styles.keyBtn}
          style={item.width ? { width: `${item.width}px` } : {}}
        >
          {item.title ? (
            <Tooltip
              placement="top"
              title={<Declaration {...item} />}
              mouseEnterDelay={0.6}
            >
              {item.name}
            </Tooltip>
          ) : (
            item.name
          )}
        </li>
      ))}
    </ul>
  );
};

interface IProps {
  onChange: (value: string, wrapRange?: number) => void;
}

const Keyboard: FunctionComponent<IProps> = (props: IProps) => {
  const [visible, setVisible] = useState(true);

  return (
    <div className={styles.keyboard}>
      <div
        className={classnames(
          styles.keyboardContainer,
          visible && styles.visible
        )}
      >
        <div className={styles.leftKeyBoard}>
          <KeyboardFlexContent
            data={calculatorLeftMid}
            onClick={value => {
              props.onChange(value, 0);
            }}
          />
        </div>
        <div className={styles.rightKeyBoard}>
          <KeyboardFlexContent
            data={calculatorRightMid}
            onClick={(value: any) => {
              if (value === 'MIN' || value === 'MAX' || value === 'ATAN2') {
                props.onChange(`${value}(表达式,表达式)`, 5);
              } else if (value.startsWith('STAT_')) {
                props.onChange(`${value}(表达式,[维度1,维度2])`, 11);
              } else if (value === 'IF') {
                props.onChange(`${value}(条件?表达式:表达式)`, 9);
              } else {
                props.onChange(`${value}(表达式)`, 1);
              }
            }}
          />
        </div>
      </div>
      {visible ? (
        <Icon
          type="close"
          onClick={() => {
            setVisible(false);
          }}
        />
      ) : (
        <Icon
          type="keyboard"
          onClick={() => {
            setVisible(true);
          }}
        />
      )}
    </div>
  );
};

export default Keyboard;
