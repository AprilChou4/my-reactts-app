import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getTableCount, exportData } from '../statistics.service';

class StatisticsStore {
  @observable public tableCount: any = []; //表数量top10 [[x, y], ...]
  @observable public sizeCount: any = []; //存储量top10 [[x, y], ...]
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public exporting = false;
  @observable public searchParams: any = {
    dbType: [],
    dbName: '',
    order: {
      item: 'tableCount',
      orderType: 'DESC'
    },
    pageIndex: 1,
    pageSize: 20
  };

  public constructor() {
    this.getInitData();
  }

  @action.bound
  public async getInitData() {
    this.loading = true;

    const res = await getTableCount(this.searchParams);

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const {
        tcList = [],
        tsList = [],
        pagination: { total }
      } = res.data || {};

      this.tableCount = _.map(_.take(tcList, 10), ({ dsName, tableCount }) => [
        dsName,
        tableCount
      ]);

      this.sizeCount = _.map(
        _.take(tsList, 10),
        ({ dsName, storageCapacity }) => {
          const size = +((storageCapacity || 0) / 1024 / 1024 / 1024).toFixed(
            2
          );
          return [dsName, size];
        }
      );

      this.list = tcList;
      this.count = total;
    });
  }

  @action.bound
  public async getList() {
    this.loading = true;

    const res = await getTableCount(this.searchParams);

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const {
        pagination: { total },
        tcList
      } = res.data || {};

      this.list = tcList || [];
      this.count = total;
    });
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }

  @action.bound
  public async exportTable(callback: any) {
    if (this.exporting) {
      return;
    }

    this.exporting = true;

    const res = await exportData();

    runInAction(() => {
      this.exporting = false;

      if (!res) {
        message.error('文件下载错误，请稍后再试!');
        return;
      }

      callback && callback(res);
    });
  }
}

export default StatisticsStore;
