import React, { FunctionComponent, useState } from 'react';
import { Input } from 'sup-ui';

import Icon from '@components/Icon';
import styles from './index.less';

interface IProps {
  name: string;
  totalNum: number;
  onChange: (value: string) => void;
  onRemove: () => void;
  disabled?: boolean;
}

const TreeNode: FunctionComponent<IProps> = (props: IProps) => {
  const { name, totalNum, disabled, onChange, onRemove } = props;
  const [editing, setEdit] = useState(false);
  return (
    <div className={styles.customerTitle}>
      <div className={styles.edit}>
        {editing ? (
          <Input
            size="small"
            autoFocus
            defaultValue={name}
            maxLength={50}
            onBlur={(e: any) => {
              e.target.value !== name && onChange(e.target.value);
              setEdit(false);
            }}
            onPressEnter={(e: any) => {
              e.target.value !== name && onChange(e.target.value);
              setEdit(false);
            }}
          />
        ) : (
          <div className={styles.nameContent}>
            <span className={styles.name}>{name}</span>
            <span className={styles.totalNum}>{`(${totalNum})`}</span>
          </div>
        )}
      </div>
      <div className="operator">
        <Icon
          type="edit"
          fill="white"
          height={24}
          width={20}
          disabled={editing || disabled}
          onClick={(e: any) => {
            e.stopPropagation();
            setEdit(true);
          }}
        />
        <Icon
          type="remove"
          fill="white"
          height={24}
          width={20}
          disabled={editing || disabled}
          onClick={(e: any) => {
            e.stopPropagation();
            onRemove();
          }}
        />
      </div>
    </div>
  );
};

export default TreeNode;
