import React, { Component } from 'react';
import { Form, TreeSelect } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import DialogModal from '@components/Modal/Dialog';

const FormItem = Form.Item;
const { TreeNode } = TreeSelect;

interface IProps extends FormComponentProps {
  loading: boolean;
  folderId: string;
  catalog: any[];
  onOk: (targetFolderId: string) => void;
  onCancel: () => void;
}
interface IState {}

class MoveDataset extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  private handleSubmit = () => {
    const { form, folderId } = this.props;
    form.validateFields((errors, values) => {
      if (errors) {
        return;
      }
      if (values.folderId === folderId) {
        this.props.onCancel();
      } else {
        this.props.onOk(values.folderId);
      }
    });
  };

  private renderTreeNode = (catalogs: any[]) => {
    return _.map(catalogs, catalogItem => {
      return (
        <TreeNode
          value={catalogItem.id}
          title={catalogItem.name}
          key={catalogItem.id}
        >
          {catalogItem.folders
            ? this.renderTreeNode(catalogItem.folders)
            : null}
        </TreeNode>
      );
    });
  };

  public render() {
    const {
      form: { getFieldDecorator },
      loading,
      folderId,
      catalog = [],
      onCancel
    } = this.props;

    return (
      <DialogModal
        title="移动数据资产"
        visible={true}
        loading={loading}
        onOk={this.handleSubmit}
        onCancel={onCancel}
        width={460}
      >
        <Form colon={false}>
          <FormItem label="目标文件夹">
            {getFieldDecorator('folderId', {
              initialValue: folderId,
              rules: [
                {
                  required: true,
                  message: '-请选择-'
                }
              ],
              validateTrigger: ['onChange']
            })(
              <TreeSelect
                showSearch
                style={{ width: '100%' }}
                dropdownStyle={{
                  maxHeight: 400,
                  overflow: 'auto',
                  minHeight: 100
                }}
                placeholder="-请选择-"
                allowClear
                treeDefaultExpandedKeys={folderId ? [`${folderId}`] : ['root']}
                treeNodeFilterProp="title"
              >
                {this.renderTreeNode(catalog)}
              </TreeSelect>
            )}
          </FormItem>
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>({
  name: 'moveDataset'
})(MoveDataset);
