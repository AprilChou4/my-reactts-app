import React, { FunctionComponent } from 'react';
import classnames from 'classnames';

import styles from './index.less';

interface IProps {
  label: string;
  value: any;
  onClick: () => void;
  active?: boolean;
}

const ListItem: FunctionComponent<IProps> = (props: IProps) => {
  const { label, value, active, onClick } = props;
  return (
    <div
      className={classnames(styles.listWrapper, active && styles.listActive)}
      onClick={onClick}
    >
      <label className={styles.label}>{label}</label>
      <span className={styles.value}>{value}</span>
    </div>
  );
};

export default ListItem;
