import React, { Component, Fragment } from 'react';
import { Table, Form, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form';

import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import InputEditCell from '../../components/EditAsset/InputEditCell';
import CatalogEditCell from '../../components/EditAsset/CatalogEditCell';
import UserEditCell from '../../components/EditAsset/UserEditCell';

import styles from './index.less';

interface IProps extends FormComponentProps {
  loading: boolean;
  dataSource: any[];
  catalog: any[];
  update: (dataSource: any[]) => void;
}

interface IState {
  isFolderFirstChange: boolean;
  isChargerFirstChange: boolean;
}
class AssetInfo extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      isFolderFirstChange: true,
      isChargerFirstChange: true
    };
  }

  public verify = () => {
    let verifyRes = true;
    this.props.form.validateFieldsAndScroll(error => {
      if (error) {
        verifyRes = false;
        message.warning('请选择资产目录！');
      }
    });
    return verifyRes;
  };

  private updateDataSourceByKey = (newRecord: any) => {
    const { dataSource } = this.props;
    const { metaId } = newRecord;
    const newDataSource: any[] = _.map(dataSource, (item: any) =>
      item.metaId === metaId ? newRecord : item
    );
    this.props.update(newDataSource);
  };

  private updateValueByFolderId = (value: string, record: any) => {
    const { dataSource } = this.props;
    if (this.state.isFolderFirstChange) {
      this.setState({
        isFolderFirstChange: false
      });
      const { metaId } = record;
      const newDataSource = _.map(dataSource, item => {
        if (item.metaId === metaId) {
          return { ...item, folderId: value };
        } else return item.folderId ? item : { ...item, folderId: value };
      });
      this.props.update(newDataSource);
    } else {
      const newRecord = {
        ...record,
        folderId: value
      };
      this.updateDataSourceByKey(newRecord);
    }
  };

  private changeValueByType = (key: string, value: string, record: any) => {
    const newRecord = {
      ...record,
      [key]: value
    };
    this.updateDataSourceByKey(newRecord);
  };

  private changeChargerValue = (value: string, record: any) => {
    const { dataSource } = this.props;
    if (this.state.isChargerFirstChange) {
      this.setState({
        isChargerFirstChange: false
      });
      const { metaId } = record;
      const newDataSource = _.map(dataSource, item => {
        if (item.metaId === metaId) {
          return { ...item, chargeUser: value };
        } else return item.chargeUser ? item : { ...item, chargeUser: value };
      });
      this.props.update(newDataSource);
    } else {
      const newRecord = {
        ...record,
        chargeUser: value
      };
      this.updateDataSourceByKey(newRecord);
    }
  };

  private removeAssetInfoTable = (metaId: number) => {
    const newDataSource = _.filter(
      this.props.dataSource,
      (item: any) => item.metaId !== metaId
    );
    this.props.update(newDataSource);
  };

  private getColumns = (): any[] => {
    const {
      catalog,
      form: { getFieldDecorator }
    } = this.props;

    return [
      {
        title: '表名',
        dataIndex: 'tableName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '显示名称',
        dataIndex: 'tableCnName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '资产名称',
        dataIndex: 'name',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <InputEditCell
            value={text}
            onChange={(value: string) => {
              this.changeValueByType('name', value, record);
            }}
          />
        )
      },
      {
        title: '描述',
        dataIndex: 'description',
        width: 160,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <InputEditCell
            value={text}
            maxLen={255}
            onChange={(value: string) => {
              this.changeValueByType('description', value, record);
            }}
          />
        )
      },
      {
        title: '负责人',
        dataIndex: 'chargeUser',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <UserEditCell
            value={text}
            onChange={(value: string) => {
              this.changeChargerValue(value, record);
            }}
          />
        )
      },
      // {
      //   title: '业务板块',
      //   dataIndex: 'businessModelName',
      //   width: 120,
      //   className: 'ellipsis-hide',
      //   render: (text: string, record: any) => (
      //     <InputEditCell
      //       value={text}
      //       onChange={(value: string) => {
      //         this.changeValueByType('businessModelName', value, record);
      //       }}
      //     />
      //   )
      // },
      // {
      //   title: '主题域',
      //   dataIndex: 'themeModelName',
      //   width: 120,
      //   className: 'ellipsis-hide',
      //   render: (text: string, record: any) => (
      //     <InputEditCell
      //       value={text}
      //       onChange={(value: string) => {
      //         this.changeValueByType('themeModelName', value, record);
      //       }}
      //     />
      //   )
      // },
      // {
      //   title: '业务过程/维度',
      //   dataIndex: 'businessObjName',
      //   width: 120,
      //   className: 'ellipsis-hide',
      //   render: (text: string, record: any) => (
      //     <InputEditCell
      //       value={text}
      //       onChange={(value: string) => {
      //         this.changeValueByType('businessObjName', value, record);
      //       }}
      //     />
      //   )
      // },
      {
        title: '数据资产目录',
        dataIndex: 'folderId',
        width: 150,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <CatalogEditCell
            formKey={`folderId_${record.metaId}`}
            initialValue={text}
            getFieldDecorator={getFieldDecorator}
            catalog={catalog}
            onChange={(value: string) => {
              this.updateValueByFolderId(value, record);
            }}
          />
        )
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 120,
        render: (_text: any, record: any) => (
          <Fragment>
            <div className="operator">
              <a
                onClick={() => {
                  this.removeAssetInfoTable(record.metaId);
                }}
              >
                删除
              </a>
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ];
  };

  public render() {
    const { loading, dataSource } = this.props;
    return (
      <Table
        columns={this.getColumns()}
        className={`${styles.assetInfoTable} mp-table-gray-light mp-table-grow`}
        loading={loading}
        dataSource={dataSource}
        rowKey="metaId"
        pagination={false}
        scroll={{
          x: 1200,
          y: 'calc(100% - 40px)'
        }}
      />
    );
  }
}

export default Form.create<IProps>({
  name: 'assetInfo'
})(AssetInfo);
