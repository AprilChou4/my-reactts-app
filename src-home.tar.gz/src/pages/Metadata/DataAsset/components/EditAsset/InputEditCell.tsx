import React, { FunctionComponent } from 'react';
import { Input, message } from 'sup-ui';

interface InputProps {
  value: string;
  maxLen?: number;
  onChange: (value: string) => void;
}

const InputEditCell: FunctionComponent<InputProps> = (props: InputProps) => {
  const { value, maxLen = 50, onChange } = props;

  const save = (val: string) => {
    if (val.length > maxLen) {
      message.error(`字段长度不能超过${maxLen}！`);
      return;
    }
    onChange(val);
  };
  return (
    <Input
      defaultValue={value}
      size="small"
      onPressEnter={(e: any) => {
        save(e.target.value);
      }}
      onBlur={(e: any) => {
        save(e.target.value);
      }}
    />
  );
};

export default InputEditCell;
