import { action, observable, runInAction, toJS } from 'mobx';
import { message } from 'sup-ui';
import qs from 'qs';
import {
  getCatalogue,
  addCatalogue,
  editCatalogue,
  deleteCatalogue,
  moveCatalogue
} from '../services/assetCatalog.service';

class CatalogueStore {
  private readonly history: any;
  private readonly globalStore: any;
  private readonly onChange: any;
  private searchParams: any = {}; //页面路由参数
  private directoryRef: any; //树结构dom
  @observable public editItem: any = {}; //当前编辑的节点
  @observable public selectedItem: any = null; //当前选定的项
  @observable public treeData: any[] = []; //树结构
  @observable public fuzzySelectData: any[] = []; //模糊搜索结果列表
  @observable public selectedKeys: any[] = []; //选中的key
  @observable public expandedKeys: any[] = []; //展开的key
  @observable public treeLoading = false; //目录loading
  @observable public catalogVisible = false; //弹窗visible
  @observable public catalogData: any[] = []; // 目录管理时的树结构
  @observable public addingExpandedKeys: string[] = []; // 树展开key

  public constructor(globalStore: any, history: any, onChange: any) {
    this.globalStore = globalStore;
    this.onChange = onChange;
    this.history = history;

    this.searchParams = qs.parse(history.location.search, {
      ignoreQueryPrefix: true
    });
  }

  private addAllExpandKeys = () => {
    const expandKeys: any[] = [];
    const addExpandKeys = (catalogs: any[]) => {
      catalogs.forEach(item => {
        if (!_.isEmpty(item.folders)) {
          expandKeys.push(item.id);
          addExpandKeys(item.folders);
        }
      });
    };
    addExpandKeys(this.catalogData);
    return expandKeys;
  };
  /**
   * @description 在treedata中附加tableNum属性
   * @param trees
   * @param payload
   * @returns new trees
   */
  private getTreeData = (trees: any[], payload: any = { tableNum: 0 }) => {
    trees.forEach((item: any) => {
      item.tableNum = item.totalNum;
      if (item.folders instanceof Array) {
        this.getTreeData(item.folders, item);
      }
      payload.tableNum += item.tableNum;
    });
    return trees;
  };

  /**
   * @description 更新treedata tableNum
   * @param treeData
   * @param folderId
   * @param tableNum
   */
  @action.bound
  public updateTreeTableNum = (
    treeData: any[] = this.treeData,
    folderId: string,
    tableNum: number
  ) => {
    _.forEach(treeData, (item: any) => {
      if (item.id === folderId) {
        item.tableNum !== tableNum && (item.tableNum = tableNum);
        return;
      }
      if (item.folders instanceof Array) {
        this.updateTreeTableNum(item.folders, folderId, tableNum);
      }
    });
  };

  @action.bound
  public handelAddingExpandedKeys = (expandedKeys: string[]) => {
    this.addingExpandedKeys = expandedKeys;
  };

  @action.bound
  public updateExpandedKeys(keys: any) {
    this.expandedKeys = keys;
  }

  @action.bound
  public updateSelectedItem = (selectedItem: string) => {
    this.selectedItem = selectedItem;
    this.selectedKeys = [];
    this.updatePageRoute(selectedItem);
    this.onChange(selectedItem);
  };

  //切换目录
  @action.bound
  public handleTreeNodeSelect(selectedKeys: string[], selectedNode: any) {
    if (this.selectedKeys[0] === selectedKeys[0]) {
      return;
    }
    const { selected, node } = selectedNode;
    this.selectedKeys = selectedKeys;
    if (selected) {
      const { dataRef } = node.props;
      this.onChange(dataRef);
      this.selectedItem = dataRef;
      this.updatePageRoute(dataRef.id);
    }
  }

  @action.bound
  public toggleCatalogModal = (visible: boolean) => {
    if (visible) {
      this.catalogData = toJS(this.treeData);
    }
    this.catalogVisible = visible;
  };

  //获取目录列表
  @action.bound
  public async getDefaultTreeNodes(init = false) {
    this.treeLoading = true;
    const res = await getCatalogue();

    runInAction(() => {
      this.treeLoading = false;
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }
      //this.treeData = res.list || [];
      this.treeData = this.getTreeData(res.list || []);
      this.catalogData = this.treeData;
      this.addingExpandedKeys = this.addAllExpandKeys();
      if (init) {
        const targetFolderId = _.get(this.searchParams, 'folderId');
        let targetFolder: any;
        if (
          _.includes(
            ['all', 'favorite', 'charge', 'release'],
            targetFolderId
          ) ||
          _.isNil(targetFolderId)
        ) {
          this.selectedItem = targetFolderId || 'all';
          this.onChange(this.selectedItem);
        } else if (targetFolderId) {
          const firstKey = _.get(this.treeData, ['0', 'id']);
          const expandedKeys = firstKey ? [firstKey] : [];
          const findTargetItem = (treeData: any[], folderId: string): any => {
            if (!folderId || targetFolder) return;
            for (let i = 0; i < treeData.length; i++) {
              const item = treeData[i];
              if (item.id === folderId) {
                targetFolder = item;
                break;
              } else if (!_.isEmpty(item.folders) && !targetFolder) {
                findTargetItem(item.folders, folderId);
              }
            }
          };
          findTargetItem(this.treeData, targetFolderId);
          if (targetFolder) {
            const { parentId, id } = targetFolder;
            this.selectedItem = targetFolder;
            this.selectedKeys = [id];
            this.onChange(this.selectedItem);
            this.expandedKeys = parentId ? [parentId] : [];
            this.scrollTreeToPosition(this.directoryRef);
          } else {
            this.expandedKeys = expandedKeys;
          }
        }
      }
    });
  }

  @action.bound
  public updateCatalogData = (catalogData: any[], nodeInfo: any) => {
    this.catalogData = catalogData;
    this.editItem = nodeInfo;
  };

  @action.bound
  public changeEditItem = (nodeInfo: any = {}) => {
    this.editItem = nodeInfo;
  };

  @action.bound
  public async addCatalog(params: any) {
    this.treeLoading = true;
    const res = await addCatalogue(params);
    runInAction(() => {
      this.treeLoading = false;
      if (res.code === 200) {
        message.success('新建成功！');
        this.changeEditItem();
        this.getDefaultTreeNodes();
      } else {
        message.error(res.message);
      }
    });
  }

  //修改目录逻辑
  @action.bound
  public async editNode(params: any) {
    this.treeLoading = true;
    const res = await editCatalogue(params);
    runInAction(() => {
      this.treeLoading = false;
      if (res.code === 200) {
        message.success('编辑成功！');
        this.changeEditItem();
        this.getDefaultTreeNodes();
      } else {
        message.error(res.message);
      }
    });
  }

  @action.bound
  public async moveNode(params: any) {
    this.treeLoading = true;
    const res = await moveCatalogue(params);
    runInAction(() => {
      this.treeLoading = false;
      if (res.code === 200) {
        message.success('移动成功！');
        this.getDefaultTreeNodes();
      }
    });
  }

  @action.bound
  public async deleteNode(folderId: string) {
    this.treeLoading = true;
    const res = await deleteCatalogue(folderId);
    runInAction(() => {
      this.treeLoading = false;
      if (res.code === 200) {
        message.success('删除成功！');
        this.getDefaultTreeNodes();
      } else {
        message.error(res.message);
      }
    });
  }

  // 在目录编辑状态时 删除编辑状态的目录
  @action.bound
  public deleteEditingNode() {
    function findNode(catalogTree: any[]) {
      for (let i = 0; i < catalogTree.length; i++) {
        if (catalogTree[i].id === 'addNode') {
          catalogTree.splice(i, 1);
          return;
        } else if (!_.isEmpty(catalogTree[i].folders)) {
          findNode(catalogTree[i].folders);
        }
      }
    }
    findNode(this.catalogData);
    this.editItem = {};
  }

  @action.bound
  public updatePageRoute(id = '') {
    const path = `/metadata/data-asset${id ? `?folderId=${id}` : ''}`;
    this.history.replace(path);
  }

  @action.bound
  public bindTreeDirectoryRef(ref: any) {
    this.directoryRef = ref;
  }

  //滚动树
  @action.bound
  public scrollTreeToPosition(parentNode: any) {
    setTimeout(() => {
      const targetNode = parentNode.querySelector(
        '.sup-tree-treenode-selected'
      );
      const top = targetNode.offsetTop - 32 * 6; //少滚动6个元素占位

      this.directoryRef.scrollTo({
        top,
        behavior: 'smooth'
      });
    }, 0);
  }
}

export default CatalogueStore;
