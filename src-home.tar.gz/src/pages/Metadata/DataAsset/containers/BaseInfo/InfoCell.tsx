import React, { Component, Fragment } from 'react';
import { message, Input } from 'sup-ui';

import Icon from '@components/Icon';
import styles from './index.less';

interface ICellProps {
  label: string;
  value: string;
  onEdit?: (value: string, callback: () => void) => void;
  maxLength?: number;
}
interface ICellState {
  editing: boolean;
}

class InfoCell extends Component<ICellProps, ICellState> {
  private inputRef: any;
  public constructor(props: ICellProps) {
    super(props);
    this.state = {
      editing: false
    };
    this.inputRef = React.createRef();
  }

  private setEdit = () => {
    if (_.isFunction(this.props.onEdit)) {
      this.setState({ editing: true });
    }
  };

  private closeEdit = () => {
    this.setState({
      editing: false
    });
  };

  private save = () => {
    const { value: propValue, maxLength = 50, onEdit } = this.props;
    const value = _.get(this.inputRef.current, 'state.value', '');
    //短文本长度限制50，长文本限制255
    if (value.length > maxLength) {
      message.error(`字段长度不能超过${maxLength}！`);
      return;
    }
    //值不变不请求接口
    if (value === propValue || (propValue === null && value === '')) {
      this.closeEdit();
      return;
    }

    this.closeEdit();
    onEdit &&
      onEdit(value, () => {
        this.closeEdit();
      });
  };

  public render() {
    const { value, label, onEdit } = this.props;
    const { editing } = this.state;
    return (
      <div className={styles.infoItem}>
        <label htmlFor={label} className={styles.label}>
          {label}
        </label>
        {editing ? (
          <div className={styles.editWrapper}>
            <Input
              autoFocus
              ref={this.inputRef}
              defaultValue={value}
              onPressEnter={this.save}
            />
            <Icon
              type="success"
              width={12}
              className={styles.editIcon}
              onClick={this.save}
            />
            <Icon type="error" width={9} onClick={this.closeEdit} />
          </div>
        ) : (
          <div className={styles.editableCell}>
            {_.isNil(onEdit) ? (
              <span title={value}>{value || '--'}</span>
            ) : (
              <Fragment>
                <span
                  title={value}
                  className={!value ? styles.clickInput : ''}
                  onClick={this.setEdit}
                >
                  {value || '点击填写'}
                </span>
                {value && (
                  <Icon
                    type="edit"
                    className={styles.editIcon}
                    onClick={this.setEdit}
                  />
                )}
              </Fragment>
            )}
          </div>
        )}
      </div>
    );
  }
}

export default InfoCell;
