import React, { FC, useState } from 'react';
import { Select } from 'sup-ui';
import { dataLevelEnum } from '../consts/attrs';
import styles from './index.less';
const { Option } = Select;
interface IProps {
  value?: any;
  onChange?: (value: any) => void;
  disabled?: boolean;
  label?: string;
}
const DataLevelSelector: FC<IProps> = ({
  value,
  onChange,
  disabled = false,
  label
}) => {
  const handleChange = (value: number) => {
    onChange && onChange(value);
  };
  return (
    <div className={styles.dataLevel}>
      {label && <label className={styles.label}>{label}</label>}
      {disabled ? (
        <span className={styles.title}>
          {_.find(dataLevelEnum, v => v.key === +value)?.showName || '--'}
        </span>
      ) : (
        <Select
          placeholder={'-请选择-'}
          value={value || undefined}
          onChange={handleChange}
          style={{ width: '100%' }}
        >
          {_.map(dataLevelEnum, level => (
            <Option key={level.key} value={level.key} disabled={level.disable}>
              {level.showName}
            </Option>
          ))}
        </Select>
      )}
    </div>
  );
};

export default DataLevelSelector;
