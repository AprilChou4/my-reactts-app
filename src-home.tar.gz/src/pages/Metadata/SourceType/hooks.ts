import { useRef } from 'react';

export const useScrollTo = () => {
  const menuRef = useRef<any>(null);

  const scrollToPosition = () => {
    setTimeout(() => {
      const supMenu =
        menuRef.current && menuRef.current.querySelector('.sup-menu');

      const targetRef =
        menuRef.current &&
        menuRef.current.querySelector('.sup-menu-item-selected');

      if (targetRef) {
        const top = targetRef.offsetTop - 28 * 4; //少滚动4个元素占位
        supMenu.scrollTo({
          top,
          behavior: 'smooth'
        });
      }
    });
  };
  return [menuRef, scrollToPosition];
};
