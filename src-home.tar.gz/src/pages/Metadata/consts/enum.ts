interface ListItem {
  key: number | string;
  showName: string;
  disable?: boolean;
  isShow?: boolean;
}

//采集状态
export const collectStatusList: ListItem[] = [
  { key: 0, showName: '失败' },
  { key: 1, showName: '成功' }
];

//采集周期
export const collectCycleList: ListItem[] = [{ key: 'day', showName: '天' }];

//采集策略
export const collectStrategyList: ListItem[] = [
  { key: 'all', showName: '全量' }
];

//调度状态
export const scheduleStatusList: ListItem[] = [
  { key: 0, showName: '停用' },
  { key: 1, showName: '启用' }
];

// 数据源类型
export const sourceTypes: ListItem[] = [
  // dm_model/ dm_ods
  { key: 'dm', showName: '本地数仓', isShow: false },
  { key: 'mysql', showName: 'Mysql', isShow: true },
  { key: 'oracle', showName: 'Oracle', isShow: true },
  { key: 'sqlserver', showName: 'SQL Server', isShow: true },
  { key: 'supos', showName: 'supOS', isShow: true }
];

// 数据库类型
export const databaseTypes: ListItem[] = [
  { key: 'mysql', showName: 'Mysql' },
  { key: 'oracle', showName: 'Oracle' },
  { key: 'sqlserver', showName: 'SQL Server' },
  { key: 'model', showName: 'supOS' },
  { key: 'dm_ods', showName: '本地数仓' },
  { key: 'dm_model', showName: '本地数仓' }
];

// 数仓包含类型
export const DWTypes = ['dm_ods', 'dm_model'];
export const sourceTypeMap = () => {
  const result: any = {};

  _.forEach(sourceTypes, ({ key, showName }) => {
    if (key === 'dm') {
      result['dm_model'] = showName;
      result['dm_ods'] = showName;
    } else {
      result[key] = showName;
    }
  });

  return result;
};

//表类型
export const tableTypeList = (type: string): any[] => {
  const map: any = {
    sql: [
      { key: 'TABLE', showName: '物理表', disable: false },
      { key: 'VIEW', showName: '视图', disable: false }
    ],
    template: [
      { key: 'ENTITY', showName: '实体模板', disable: false },
      { key: 'FORM', showName: '表单模板', disable: false },
      { key: 'RELATION', showName: '关系模板', disable: false }
    ],
    dm: [
      { key: 'FACT_TABLE', showName: '事实表', disable: false },
      { key: 'DIM_TABLE', showName: '维度表', disable: false },
      { key: 'SUM_TABLE', showName: '汇总表', disable: false }
    ]
  };
  // 贴源层是对 数仓的物理表进行采集的 只有 物理表和视图表
  // 标准层是采集数仓的模型 有区分 维度表、事实表、汇总表

  switch (type) {
    case 'mysql':
    case 'oracle':
    case 'sqlserver':
    case 'dm_ods':
      return map['sql'];
    case 'supos':
      return map['template'];
    case 'dm_model':
      return map['dm'];
    case 'dm':
      return [...map['dm'], ...map['sql']];
    case 'all':
      return _.reduce(
        map,
        (prev: any[], next: any[]) => {
          return _.concat(prev, next);
        },
        []
      );
    default:
      return [];
  }
};

export const tableTypeMap = () => {
  const all = tableTypeList('all');
  const result: any = {};

  _.forEach(all, ({ key, showName }) => {
    result[key] = showName;
  });

  return result;
};

// 资产类型
export const assetTypesList: ListItem[] = [
  { key: 'TABLE', showName: '数据表', disable: false },
  { key: 'MODEL', showName: '对象模型', disable: false }
];

export const AssetTypeMap = new Map([
  ['TABLE', { type: 'TABLE', cnName: '数据表' }],
  ['VIEW', { type: 'TABLE', cnName: '数据表' }],
  ['SYSTEM VIEW', { type: 'TABLE', cnName: '数据表' }],
  ['FACT_TABLE', { type: 'TABLE', cnName: '数据表' }],
  ['DIM_TABLE', { type: 'TABLE', cnName: '数据表' }],
  ['SUM_TABLE', { type: 'TABLE', cnName: '数据表' }],
  ['ENTITY', { type: 'MODEL', cnName: '对象模型' }],
  ['FORM', { type: 'MODEL', cnName: '对象模型' }],
  ['RELATION', { type: 'MODEL', cnName: '对象模型' }]
]);
