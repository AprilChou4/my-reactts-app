import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import moment from 'moment';
import { bytesToSize, sepNumber, assemblyData } from '../../consts/utils';
import {
  getSourceListByType,
  getOverviewData,
  getTableTrendData,
  getSizeTrendData
} from '../overview.service';

class OverviewStore {
  @observable public dataType = 'ALL'; //数据源类型
  @observable public loading = false;
  @observable public overview = {
    source: '0',
    table: '0',
    storage: '0B',
    tableGrow: '0',
    storageGrow: '0B'
  }; //总览

  @observable public tableCount: any = []; //表数量分布{ name, y }
  @observable public tableRange: any = [moment().subtract(6, 'days'), moment()]; //表趋势区间
  @observable public tableTrend: any = []; //表数量趋势

  @observable public sizeCount: any = []; //存储量分布{ name, y }
  @observable public sizeRange: any = [moment().subtract(6, 'days'), moment()]; //存储量趋势区间
  @observable public sizeTrend: any = []; //存储量趋势

  @observable public databaseTopN: any = []; //数据库存储量top10
  @observable public tableTopN: any = []; //表存储量top10
  @observable public recordTopN: any = []; //表纪录数top10
  @observable public collectTopN: any = []; //收藏表top10

  public constructor(globalStore: any, history: any, parentHash: any) {
    globalStore.changeCachePageMethod(
      '/metadata/overview',
      'updateOverviewData',
      () => {
        this.handleDataTypeChange('ALL');
      }
    );

    if (parentHash) {
      const [hash, search] = parentHash.split('?');

      if (search) {
        history.push(`/metadata/list?${search}`);

        setTimeout(() => {
          window.parent.location.hash = hash;
        }, 100);
        return;
      }
    }

    this.getOverviewData();
    this.getTableTrend();
    this.getSizeTrend();
  }

  @action.bound
  public handleDataTypeChange(type: string) {
    this.dataType = type;

    //重置趋势时间范围
    this.tableRange = [moment().subtract(7, 'days'), moment()];
    this.sizeRange = [moment().subtract(7, 'days'), moment()];
    this.getOverviewData();
    this.getTableTrend();
    this.getSizeTrend();
  }

  //获取除表数量、存储量趋势外的其他数据
  @action.bound
  public async getOverviewData() {
    this.loading = true;
    const map: any = { other: '其他' };
    //先获取数据源列表，构建一个id:name的map表
    const res1: any = await getSourceListByType(_.toLower(this.dataType));

    if (res1.code !== 200) {
      message.error(`${res1.message}`);
      return;
    }

    _.forEach(res1.data.list || [], ({ sourceid, datasourceName }) => {
      map[sourceid] = datasourceName;
    });

    //取30天的日均新增数据（表、存储量）
    const res2: any = await getOverviewData(this.dataType, {
      startTime: moment().subtract(30, 'days').format('YYYY-MM-DD'),
      endTime: moment().format('YYYY-MM-DD')
    });

    runInAction(() => {
      this.loading = false;

      if (res2.code !== 200) {
        message.error(`${res2.message}`);
        return;
      }

      const {
        totalsources, //总数据源数
        totalTableNum, //总表数
        totalFileSize = 0, //总存储量
        tblAvg, //30天日新增表数
        fileAvg = 0, //30天日新增存储量
        tableNumBySource, //表数量分布
        filesizeBySource, //存储量分布
        filesizeTOPN, //数据库存储量top10
        tableNumTopN, //表存储量top10
        tableRecordTopN, //表记录数top10
        collectTopN //收藏量top10
      } = res2.data || {};

      this.overview = {
        source: sepNumber(totalsources),
        table: sepNumber(totalTableNum),
        storage: bytesToSize(+totalFileSize),
        tableGrow: sepNumber(tblAvg),
        storageGrow: bytesToSize(+fileAvg)
      };

      this.tableCount = _.map(
        assemblyData(tableNumBySource),
        ({ datasourceid, count }) => ({
          name: map[datasourceid] || '未知数据源',
          y: count
        })
      );

      this.sizeCount = _.map(
        assemblyData(filesizeBySource),
        ({ datasourceid, count }) => ({
          name: map[datasourceid] || '未知数据源',
          y: count
        })
      );

      this.databaseTopN = _.map(filesizeTOPN, ({ datasourceid, count }) => ({
        id: datasourceid,
        name: map[datasourceid] || '未知数据源',
        count: bytesToSize(+count)
      }));

      this.tableTopN = _.map(
        tableNumTopN,
        ({ dataSourceName, tableName, count }) => ({
          id: tableName,
          name: dataSourceName + '.' + tableName,
          count: bytesToSize(+count)
        })
      );

      this.recordTopN = _.map(
        tableRecordTopN,
        ({ dataSourceName, tableName, count }) => ({
          id: tableName,
          name: dataSourceName + '.' + tableName,
          count
        })
      );

      const collect: any = _.map(
        collectTopN,
        ({ dataSourceName, tableName, count }) => ({
          id: tableName,
          name: dataSourceName + '.' + tableName,
          count
        })
      );

      this.collectTopN = _.orderBy(collect, 'count', ['desc']);
    });
  }

  @action.bound
  public handleTableTrendChange(trend: any[]) {
    this.tableRange = trend;
    this.getTableTrend();
  }

  //获取表数量趋势
  @action.bound
  public async getTableTrend() {
    const [start, end] = this.tableRange;
    const res = await getTableTrendData({
      dbType: this.dataType,
      startTime: start.format('YYYY-MM-DD'),
      endTime: end.format('YYYY-MM-DD')
    });

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const result: any = [];
      _.forEach(res.data || {}, (value, key) => {
        result.push({
          x: moment(key).startOf('day').valueOf(),
          y: value
        });
      });

      this.tableTrend = _.sortBy(result, 'x');
    });
  }

  @action.bound
  public handleSizeTrendChange(trend: any[]) {
    this.sizeRange = trend;
    this.getSizeTrend();
  }

  //获取存储量趋势
  @action.bound
  public async getSizeTrend() {
    const [start, end] = this.sizeRange;
    const res = await getSizeTrendData({
      dbType: this.dataType,
      startTime: start.format('YYYY-MM-DD'),
      endTime: end.format('YYYY-MM-DD')
    });

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const result: any = [];
      _.forEach(res.data || {}, (value, key) => {
        result.push({
          x: moment(key).startOf('day').valueOf(),
          y: +(value / 1024).toFixed(2),
          count: value
        });
      });

      this.sizeTrend = _.sortBy(result, 'x');
    });
  }
}

export default OverviewStore;
