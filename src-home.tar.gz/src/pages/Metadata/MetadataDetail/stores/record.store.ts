import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getTableRecord } from '../detail.service';

class RecordStore {
  public readonly id: string;
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams = {
    updator: '',
    remark: '',
    updateColumn: [],
    order: { key: 'updateTime', orderType: 'DESC' }, // 默认为按时间倒序, 当有值时，传 {key:'',orderType:'ASE'|'DESC'},只允许有一个排序
    pageIndex: 1,
    pageSize: 20
  };

  public constructor(id: string) {
    this.id = id;
    this.getList();
  }

  @action.bound
  public async getList() {
    this.loading = true;

    const res = await getTableRecord({
      ...this.searchParams,
      tblMetaId: this.id
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const {
        pagination: { total },
        list
      } = res.data || {};

      this.list = list;
      this.count = total;
    });
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }
}

export default RecordStore;
