import http from '@services/http';
import { METADATA_URL, ASSET_URL } from '@config/env';

//根据数据源类型筛选数据源
export function getSourceListByType(type: string): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/source/${type}`);
}

//获取数据源下表
export function getSourceTables(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/list`, params);
}
//获取本地数仓数据源列表
export function getDWSourceTables(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/search`, params);
}
//获取所有收藏的表
export function getCollectTables(): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/collect`);
}

//收藏表
export function collectTable(id: any, params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/collect/${id}`, params);
}

//获取表-基本信息
export function getTableBase(id: any): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/base/${id}`);
}

//更新表-基本信息
export function updateTableBase(params: any): Promise<any> {
  return http.put(`${METADATA_URL}/mttbl/base`, params);
}

//获取表-字段信息
export function getTableFields(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/fields`, params);
}

//更新表-字段信息
export function updateTableFields(params: any): Promise<any> {
  return http.put(`${METADATA_URL}/mttbl/fields`, params);
}

//获取表-数据样例
export function getTableExample(params: any): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/example`, params);
}

//获取表-DDL语句
export function getTableDDL(id: string): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/ddl/${id}`);
}

//获取表-变更记录
export function getTableRecord(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/record`, params);
}

// 根据表的id获取表的基本信息
export function getTableInfos(ids: string[]): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/infos`, { ids });
}

export function getCatalogue(): Promise<any> {
  return http.get(`${ASSET_URL}/catalogue/list`);
}

// 发布资产数据
export function publish(body: any[]): Promise<any> {
  return http.post(`${ASSET_URL}/manager/release`, body);
}

// 获取业务系统
export function getTagName(): Promise<any> {
  return http.get(`${METADATA_URL}/mttbl/tagName`);
}

// 获取业板块
export function getBusinessmodel(body: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/list/businessmodel`, body);
}

// 获取主题域
export function getThememodel(body: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/list/thememodel`, body);
}
