import http from '@services/http';
import { METADATA_URL } from '@config/env';

export function getCollectList(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/getList`, params);
}

export function getSourceListByType(
  sourceType: string,
  params: any
): Promise<any> {
  return http.get(`${METADATA_URL}/resource/sourceList/${sourceType}`, params);
}

export function createCollect(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/create`, params);
}

export function updateCollect(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/update`, params);
}

// 立即采集
export function invokeCollect(sourceId: string): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/invoke/${sourceId}`);
}

// 停用计划
export function pauseCollect(sourceId: string): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/pause/${sourceId}`);
}

// 启用计划
export function resumeCollect(sourceId: string): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/resume/${sourceId}`);
}

export function deleteCollect(sourceId: string): Promise<any> {
  return http.delete(`${METADATA_URL}/schedulejob/delete/${sourceId}`);
}

export function getHistoryList(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/schedulejob/getHistoryList`, params);
}
