import React, { Component, Fragment } from 'react';
import { observer, inject } from 'mobx-react';
import { Table, Divider } from 'sup-ui';
import memoizeOne from 'memoize-one';
import moment from 'moment';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import TableFilter from '@components/TableFilter';
import KeywordSearch from '@components/KeywordSearch';
import { UTC2LocalDateTime } from '@utils/common';
import CollectStatus from '../components/CollectStatus';
import {
  collectStatusList,
  scheduleStatusList,
  sourceTypes,
  sourceTypeMap
} from '../../consts/enum';
import { collectColumns } from '../../consts/columns';
import ColumnFilter from '@components/ColumnFilter';
import styles from './index.less';

const typeMap = sourceTypeMap();

interface IProps {
  collectStore?: any;
  onCheckHistory: (currentRecord: any) => void;
}
interface IState {}
@inject('collectStore')
@observer
class CollectTable extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  private getEnumData = (dataIndex: string): any => {
    const newSourceTypes = _.filter(sourceTypes, item => item.isShow);
    switch (dataIndex) {
      case 'datasourceType':
        return newSourceTypes;
      case 'collectStatus':
        return collectStatusList;
      case 'sheduleStatus':
        return scheduleStatusList;
      default:
        return [];
    }
  };

  private handleSearch = (value: string) => {
    this.props.collectStore.updateKeyword(value);
  };

  private getColumnSearchProps = (dataIndex: string, isEnum: boolean) => ({
    filterDropdown: ({ setSelectedKeys, confirm, selectedKeys }: any) => (
      <TableFilter
        isEnum={isEnum}
        enumData={this.getEnumData(dataIndex)}
        confirm={confirm}
        selectedKeys={selectedKeys}
        setSelectedKeys={setSelectedKeys}
      />
    )
  });

  private handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;

    //筛选filters
    const {
      collectStatus = [],
      datasourceType = [],
      sheduleStatus = []
    } = filters;

    //排序sorter, sort只能触发一个
    const { columnKey, order } = sorter;

    this.props.collectStore.updateSearchParams({
      pageIndex: current,
      pageSize,
      collectStatus,
      datasourceType,
      sheduleStatus,
      order: _.isEmpty(sorter)
        ? { key: 'createTime', orderType: 'DESC' }
        : {
            key: columnKey,
            orderType: order === 'ascend' ? 'ASC' : 'DESC'
          }
    });
  };
  private getOrderType = (order: any) => {
    switch (_.get(order, 'orderType', '')) {
      case 'ASC':
        return 'ascend';
      case 'DESC':
        return 'descend';
      default:
        return '';
    }
  };

  private handleCollectDelete = (name: string, sourceId: string) => {
    const { deleteCollect } = this.props.collectStore;
    const config = {
      title: '删除',
      content: `删除后，${name}任务对应的数据库元数据将无法同步，是否删除？`,
      onOk: deleteCollect.bind(this, sourceId)
    };
    TipsDelete(config);
  };

  private getColumns = () => {
    const {
      editCollect,
      updateScheduleStatus,
      invokeCollect,
      searchParams: { order }
    } = this.props.collectStore;
    const orderKey = _.get(order, 'key', '');
    const orderType = this.getOrderType(order);
    return [
      // {
      //   title: '采集计划',
      //   dataIndex: 'name',
      //   width: 240,
      //   className: 'ellipsis-hide',
      //   render: (text: string, record: any) => (
      //     <a onClick={() => editCollect(record)}>
      //       <TableCellText text={text} />
      //     </a>
      //   )
      // },
      {
        title: '数据源名称',
        width: 180,
        dataIndex: 'datasourceName',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '数据源类型',
        dataIndex: 'datasourceType',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={typeMap[text]} />,
        ...this.getColumnSearchProps('datasourceType', true)
      },

      {
        title: '最近采集状态',
        dataIndex: 'collectStatus',
        width: 140,
        render: (value: string) => <CollectStatus value={value} />,
        ...this.getColumnSearchProps('collectStatus', true)
      },
      {
        title: '最近采集时间',
        dataIndex: 'lastCollectTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        sortOrder: orderKey === 'lastCollectTime' ? orderType : '',
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '调度周期',
        dataIndex: 'expr',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: string) => {
          const [second, minute, hour] = text.split(' ');

          return moment(`${hour}:${minute}:${second}`, 'H:m:s').format('HH:mm');
        }
      },
      {
        title: '调度状态',
        dataIndex: 'sheduleStatus',
        width: 120,
        className: 'ellipsis-hide',
        render: (status: string) => {
          return status === '1' ? (
            <div className={styles.sheduleStatus}>
              <i className={styles.success} />
              <p>启用</p>
            </div>
          ) : status === '0' ? (
            <div className={styles.sheduleStatus}>
              <i />
              <p>停用</p>
            </div>
          ) : null;
        },
        ...this.getColumnSearchProps('sheduleStatus', true)
      },
      {
        title: '添加人',
        dataIndex: 'creator',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '添加时间',
        dataIndex: 'createTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        sortOrder: orderKey === 'createTime' ? orderType : '',
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '修改人',
        dataIndex: 'modifier',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '修改时间',
        dataIndex: 'modifyTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        sortOrder: orderKey === 'modifyTime' ? orderType : '',
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '描述',
        dataIndex: 'comment',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 260,
        render: (_text: any, record: any) => (
          <Fragment>
            <div className="operator">
              {record.sheduleStatus === '1' && record.collectStatus !== '2' && (
                <Fragment>
                  <a
                    onClick={() => {
                      invokeCollect(record.sourceid);
                    }}
                  >
                    立即采集
                  </a>
                  <Divider type="vertical" />
                </Fragment>
              )}
              {record.collectStatus === '2' && (
                <Fragment>
                  <a className={styles.disabled}>采集中</a>
                  <Divider type="vertical" />
                </Fragment>
              )}
              <a
                className={record.collectStatus === '2' ? styles.disabled : ''}
                onClick={() => {
                  if (record.collectStatus === '2') return;
                  updateScheduleStatus(record);
                }}
              >
                {record.sheduleStatus === '1'
                  ? '停用'
                  : record.sheduleStatus === '0'
                  ? '启用'
                  : ''}
              </a>
              <Divider type="vertical" />
              <a
                onClick={() => {
                  this.props.onCheckHistory(record);
                }}
              >
                历史记录
              </a>
              <Divider type="vertical" />
              <a
                onClick={() => {
                  editCollect(record);
                }}
              >
                编辑
              </a>
              <Divider type="vertical" />
              <a
                className={record.sheduleStatus === '1' ? styles.disabled : ''}
                onClick={() => {
                  if (record.sheduleStatus === '1') return;
                  this.handleCollectDelete(record.name, record.sourceid);
                }}
              >
                删除
              </a>
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ];
  };

  private getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 20;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public render() {
    const {
      tableLoading,
      list,
      searchParams,
      count,
      checkedColumns,
      updateCheckedColumns
    } = this.props.collectStore;

    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );

    return (
      <div className={styles.wrapper}>
        <div className={styles.operator}>
          <div className={styles.search}>
            <KeywordSearch
              placeholder="请输入关键字搜索"
              value={searchParams.keyword}
              onSearch={this.handleSearch}
            />
          </div>
          <ColumnFilter
            sourceColumns={collectColumns}
            onOk={updateCheckedColumns}
          />
        </div>
        <div
          className={`${styles.tableWrapper} mp-table-gray-light mp-table-grow`}
        >
          <Table
            loading={tableLoading}
            columns={filterColumns}
            dataSource={list}
            onChange={this.handleTableChange}
            rowKey="id"
            pagination={{
              current: searchParams.pageIndex,
              pageSize: searchParams.pageSize,
              total: count,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging,
              pageSizeOptions: ['20', '50', '100'],
              showSizeChanger: true,
              showQuickJumper: true
            }}
            scroll={{
              x: totalWidthX,
              y: 'calc(100% - 40px)'
            }}
          />
        </div>
      </div>
    );
  }
}

export default CollectTable;
