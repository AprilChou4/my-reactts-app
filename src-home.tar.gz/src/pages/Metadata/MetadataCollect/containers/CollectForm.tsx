import React, { Component } from 'react';
import { observer, inject } from 'mobx-react';
import moment from 'moment';
import { Form, Input, Select, Tooltip, Radio, TimePicker } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import Icon from '@components/Icon';
import DialogModal from '@components/Modal/Dialog';
import SourceSelector from '../components/SourceSelector';
import {
  collectCycleList,
  collectStrategyList,
  sourceTypes
} from '../../consts/enum';
import styles from './index.less';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { TextArea } = Input;
const { Option } = Select;

interface IProps extends FormComponentProps {
  collectStore?: any;
}
interface IState {}

@inject('collectStore')
@observer
class CollectForm extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  private handleSourceTypeChange = () => {
    const {
      form: { setFieldsValue }
    } = this.props;

    setFieldsValue({
      datasource: {}
    });
  };

  private getExprInitValue = (expr: string) => {
    if (expr) {
      const [second, minute, hour] = expr.split(' ');
      return moment(`${hour}:${minute}:${second}`, 'H:m:s');
    }

    return moment('01:00', 'HH:mm');
  };

  private handleSubmit = () => {
    const { form, collectStore } = this.props;

    form.validateFields((errors, values) => {
      if (errors) {
        return;
      }

      const {
        // name,
        datasourceType,
        datasource: { id, displayName },
        collectPeriod,
        expr,
        adaptType,
        comment
      } = values;

      const params = {
        name: displayName,
        datasourceType,
        sourceid: id,
        datasourceName: displayName,
        collectPeriod,
        expr: expr.format('0 m H * * ?'),
        adaptType,
        comment: comment || ''
      };

      collectStore.submitCollect(params);
    });
  };

  private handleCancel = () => {
    this.props.collectStore.handleVisibleChange(false);
  };

  public render() {
    const {
      form: { getFieldDecorator, getFieldsValue },
      collectStore: {
        getSourceNames,
        formData,
        formVisible,
        formLoading,
        tableLoading
      }
    } = this.props;
    const isEdit = !_.isEmpty(formData);
    const { datasourceType = formData.datasourceType } = getFieldsValue([
      'datasourceType'
    ]);

    return (
      <DialogModal
        title={`${isEdit ? '编辑' : '新增'}采集计划`}
        visible={formVisible}
        loading={formLoading || tableLoading}
        onOk={this.handleSubmit}
        onCancel={this.handleCancel}
        width={560}
      >
        <Form colon={false} className={styles.formWrapper}>
          {/* <FormItem label="计划名称">
            {getFieldDecorator('name', {
              initialValue: formData.name,
              rules: [
                { required: true, message: '请输入计划名称' },
                { max: 50, message: '请输入不超过50的字符' }
              ]
            })(<Input autoComplete="off" size="large" />)}
          </FormItem> */}
          <FormItem label="数据源类型">
            {getFieldDecorator('datasourceType', {
              initialValue: formData.datasourceType,
              rules: [{ required: true, message: '请选择数据源类型' }]
            })(
              <Select
                onChange={this.handleSourceTypeChange}
                placeholder="—请选择—"
                size="large"
                disabled={isEdit}
              >
                {_.map(
                  sourceTypes,
                  (source: any) =>
                    source.isShow && (
                      <Option key={source.key} value={source.key}>
                        {source.showName}
                      </Option>
                    )
                )}
              </Select>
            )}
          </FormItem>
          <FormItem
            required
            label={
              <span className={styles.sourceLabel}>
                数据源
                <Tooltip
                  placement="right"
                  title="若没有相关的数据源，请在数据源管理中添加"
                  overlayStyle={{ maxWidth: '320px' }}
                >
                  <Icon type="circle-help" />
                </Tooltip>
              </span>
            }
          >
            {getFieldDecorator('datasource', {
              initialValue: {
                id: formData.sourceid,
                displayName: formData.datasourceName
              },
              rules: [
                {
                  validator: (_rule: any, value: any, callback: any) => {
                    if (_.isEmpty(value) || _.isNil(value.id)) {
                      callback('请选择数据源');
                    } else {
                      callback();
                    }
                  }
                }
              ]
            })(
              <SourceSelector
                disabled={isEdit}
                loadData={getSourceNames}
                type={datasourceType}
              />
            )}
          </FormItem>
          <FormItem label="采集周期">
            {getFieldDecorator('collectPeriod', {
              initialValue: formData.collectPeriod || 'day'
            })(
              <RadioGroup>
                {collectCycleList.map((item: any) => (
                  <Radio key={item.key} value={item.key}>
                    {item.showName}
                  </Radio>
                ))}
              </RadioGroup>
            )}
          </FormItem>
          <FormItem label="采集时间">
            {getFieldDecorator('expr', {
              initialValue: this.getExprInitValue(formData.expr),
              rules: [{ required: true, message: '请选择采集时间' }]
            })(<TimePicker allowClear={false} format="HH:mm" />)}
          </FormItem>
          <FormItem label="采集策略">
            {getFieldDecorator('adaptType', {
              initialValue: formData.adaptType || 'all'
            })(
              <RadioGroup>
                {collectStrategyList.map((item: any) => (
                  <Radio key={item.key} value={item.key}>
                    {item.showName}
                  </Radio>
                ))}
              </RadioGroup>
            )}
          </FormItem>
          <FormItem label="描述">
            {getFieldDecorator('comment', {
              initialValue: formData.comment,
              rules: [{ max: 255, message: '请输入不超过255的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>({
  name: 'collect'
})(CollectForm);
