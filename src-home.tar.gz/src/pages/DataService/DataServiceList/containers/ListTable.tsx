import React, { Component, Fragment } from 'react';
import { observer } from 'mobx-react';
import { Table, Divider, message } from 'sup-ui';
import memoizeOne from 'memoize-one';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import TableFilter from '@components/TableFilter';
import KeywordSearch from '@components/KeywordSearch';
import ColumnFilter from '@components/ColumnFilter';
import { UTC2LocalDateTime } from '@utils/common';
import { listTableColumns } from '../../consts/columns';
import { apiTypeList, apiStatus } from '../../consts/enum';
import { generateEnumMap } from '../../consts/utils';
import styles from '../index.less';

interface IProps {
  store?: any;
  history: any;
}
interface IState {
  checkedColumns: any[];
}

@observer
class ListTable extends Component<IProps, IState> {
  private readonly typeMap: any;
  public constructor(props: IProps) {
    super(props);
    const checkedItems = _.map(
      _.filter(listTableColumns, 'check'),
      'dataIndex'
    );

    this.state = {
      checkedColumns: checkedItems
    };
    this.typeMap = generateEnumMap(apiTypeList);
  }

  public updateCheckedColumns = (checkedItems: any[]) => {
    this.setState({
      checkedColumns: checkedItems
    });
  };

  private handleSearch = (value: string) => {
    this.props.store.updateKeyword(value);
  };

  public getEnumData = (dataIndex: string): any => {
    switch (dataIndex) {
      case 'type':
        return apiTypeList;
      case 'status':
        return apiStatus;
      default:
        return [];
    }
  };

  private getColumnSearchProps = (dataIndex: string, isEnum: boolean) => ({
    filterDropdown: ({ setSelectedKeys, confirm, selectedKeys }: any) => (
      <TableFilter
        isEnum={isEnum}
        enumData={this.getEnumData(dataIndex)}
        confirm={confirm}
        selectedKeys={selectedKeys}
        setSelectedKeys={setSelectedKeys}
      />
    )
  });

  private handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;

    //筛选filters
    const { type = [], status = [] } = filters;
    //排序sorter, sort只能触发一个
    const { columnKey, order } = sorter;

    this.props.store.updateSearchParams({
      pageIndex: current,
      pageSize,
      type,
      status,
      order: _.isEmpty(sorter)
        ? {
            key: 'createTime',
            orderType: 'DESC'
          }
        : {
            key: columnKey,
            orderType: order === 'ascend' ? 'ASC' : 'DESC'
          }
    });
  };

  private handleCheckData = (record: any) => {
    const { checkApiDetail } = this.props.store;
    checkApiDetail(record);
  };

  private handlePublish = (record: any) => {
    const { publishVersion, id } = record;
    const { handlePublishApi } = this.props.store;

    if (!_.isNil(publishVersion)) {
      const config = {
        title: '提示',
        content: `该服务存在线上版本，覆盖线上服务可能会导致调用此服务的应用无法继续使用，请通知调用者！`,
        onOk: () => {
          handlePublishApi(id);
        }
      };
      TipsDelete(config);
    } else {
      handlePublishApi(id);
    }
  };

  private handleCancel = (record: any) => {
    const { id } = record;
    const { handleCancelApi } = this.props.store;
    const config = {
      title: '提示',
      content: `撤销已保存内容，恢复为当前线上版本数据吗？`,
      onOk: () => {
        handleCancelApi(id);
      }
    };
    TipsDelete(config);
  };

  private handleEditData = (record: any) => {
    //优先编辑草稿
    const { id, draftId, name, type } = record;
    const eid = _.isNil(draftId) ? id : draftId;
    let routeType = 'register';

    if (type === 1) {
      routeType = 'data';
    }

    this.props.history.push(`/data-service/${routeType}/${eid}?tab=${name}`);
  };

  private handleCopyData = (record: any) => {
    const { id, type } = record;
    const { handleCopyApi } = this.props.store;
    let routeType = 'register';

    if (type === 1) {
      routeType = 'data';
    }

    handleCopyApi(() => {
      this.props.history.push(
        `/data-service/${routeType}/create?cid=${id}&tab=服务复制`
      );
    });
  };

  private handleDeleteData = (record: any) => {
    const { id, activeState } = record;
    const { handleDeleteApi } = this.props.store;

    if (activeState) {
      message.error(
        '该服务存在线上版本且已启用，请先至服务管理页禁用后再操作！'
      );
      return;
    }

    const config = {
      title: '删除',
      content: `确认删除${record.name}?`,
      onOk: () => {
        handleDeleteApi(id);
      }
    };
    TipsDelete(config);
  };

  private getColumns = () => {
    const {
      selectedCatalogue: { isGroup }
    } = this.props.store;

    return [
      {
        title: '服务名称',
        dataIndex: 'name',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <a onClick={() => this.handleCheckData(record)}>
            <TableCellText text={text} />
          </a>
        )
      },
      {
        title: '服务路径',
        dataIndex: 'path',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      isGroup && {
        title: '所属目录',
        dataIndex: 'catName',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '请求方法',
        dataIndex: 'reqHttpMethod',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '服务描述',
        width: 180,
        dataIndex: 'description',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'type',
        width: 120,
        render: (text: any) => <TableCellText text={this.typeMap[text]} />,
        ...this.getColumnSearchProps('type', true)
      },
      {
        title: '发布状态',
        dataIndex: 'status',
        width: 120,
        className: 'ellipsis-hide',
        render: (_text: any, record: any) => {
          //无草稿且有线上版本，则是已发布状态
          const { draftId, publishVersion } = record;
          const publish = _.isNil(draftId) && !_.isNil(publishVersion);

          return publish ? (
            <div className={styles.apiStatus}>
              <i className={styles.success} />
              <span>已发布</span>
            </div>
          ) : (
            <div className={styles.apiStatus}>
              <i />
              <span>待发布</span>
            </div>
          );
        },
        ...this.getColumnSearchProps('status', true)
      },
      {
        title: '线上版本',
        dataIndex: 'publishVersion',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: any) => (
          <TableCellText text={_.isNil(text) ? '无' : '有'} />
        )
      },
      {
        title: '创建人',
        dataIndex: 'creator',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '更新人',
        dataIndex: 'modifier',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '最近更新时间',
        dataIndex: 'modifyTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 260,
        render: (_text: any, record: any) => {
          //待发布: 有草稿 / 无线上版本
          const { draftId, publishVersion } = record;
          const publish = !_.isNil(draftId) || _.isNil(publishVersion);
          const revoke = !_.isNil(draftId);

          return (
            <Fragment>
              <div className="operator">
                {publish && (
                  <Fragment>
                    <a onClick={() => this.handlePublish(record)}>发布</a>
                    <Divider type="vertical" />
                  </Fragment>
                )}
                {revoke && (
                  <Fragment>
                    <a onClick={() => this.handleCancel(record)}>撤销</a>
                    <Divider type="vertical" />
                  </Fragment>
                )}
                <a onClick={() => this.handleEditData(record)}>编辑</a>
                <Divider type="vertical" />
                <a onClick={() => this.handleCopyData(record)}>复制</a>
                <Divider type="vertical" />
                <a
                  onClick={() => {
                    this.handleDeleteData(record);
                  }}
                >
                  删除
                </a>
              </div>
              <div className="more">
                <Icon type="ellipsis" width={13} />
              </div>
            </Fragment>
          );
        }
      }
    ].filter(Boolean);
  };

  private getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 20;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public render() {
    const { loading, list, searchParams, count } = this.props.store;
    const { checkedColumns } = this.state;
    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );

    return (
      <div className={styles.tableWrapper}>
        <div className={styles.operator}>
          <div className={styles.search}>
            <KeywordSearch
              placeholder="请输入关键字搜索"
              value={searchParams.keyword}
              onSearch={this.handleSearch}
            />
          </div>
          <ColumnFilter
            sourceColumns={listTableColumns}
            onOk={this.updateCheckedColumns}
          />
        </div>
        <div className={`${styles.table} mp-table-gray-light mp-table-grow`}>
          <Table
            loading={loading}
            columns={filterColumns}
            dataSource={list}
            onChange={this.handleTableChange}
            rowKey="id"
            pagination={{
              current: searchParams.pageIndex,
              pageSize: searchParams.pageSize,
              total: count,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging,
              pageSizeOptions: ['20', '50', '100'],
              showSizeChanger: true,
              showQuickJumper: true
            }}
            scroll={{
              x: totalWidthX,
              y: 'calc(100% - 40px)'
            }}
          />
        </div>
      </div>
    );
  }
}

export default ListTable;
