import React, { Component, Fragment } from 'react';
import { observer } from 'mobx-react';
import Header from '@components/Header';
import { AddBtn } from '@components/Button';
import APITypeModal from '../components/APITypeModal';

interface IProps {
  title: string;
  store: any;
  history: any;
}

interface IState {
  visible: boolean;
}

@observer
class ListHeader extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      visible: false
    };
  }

  private handleVisibleChange = (visible: boolean) => {
    this.setState({
      visible
    });
  };

  private handleOk = (type: number) => {
    const {
      selectedCatalogue: { id, fatherId, name, isGroup, parent }
    } = this.props.store;

    if (type === 0) {
      this.setState({
        visible: false
      });
      this.props.history.push({
        pathname: '/data-service/register/create',
        state: !isGroup
          ? {
              category: {
                sysId: fatherId,
                catId: id,
                catName: `${parent.name}/${name}`
              }
            }
          : undefined
      });
    }

    if (type === 1) {
      this.setState({
        visible: false
      });
      this.props.history.push({
        pathname: '/data-service/data/create',
        state: !isGroup
          ? {
              category: {
                sysId: fatherId,
                catId: id,
                catName: `${parent.name}/${name}`
              }
            }
          : undefined
      });
    }
  };

  public render() {
    const { title } = this.props;
    const { visible } = this.state;

    return (
      <Fragment>
        <Header
          left={title}
          center={
            <AddBtn
              ghost
              title="新增"
              style={{ marginRight: '10px' }}
              onClick={() => this.handleVisibleChange(true)}
            />
          }
        />
        <APITypeModal
          visible={visible}
          onOk={this.handleOk}
          onCancel={() => this.handleVisibleChange(false)}
        />
      </Fragment>
    );
  }
}

export default ListHeader;
