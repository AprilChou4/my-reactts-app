import React, { Component } from 'react';
import { message, TreeSelect } from 'sup-ui';

interface IProps {
  value?: any;
  onChange?: any;
  loadData: any;
}

interface IState {
  list: any[];
}

class CataSelectTree extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    this.state = {
      list: []
    };
  }

  public getDefaultTreeNodes = () => {
    const { loadData } = this.props;

    loadData({ id: 0 }).then((res: any) => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const treeData = _.map(res.data || [], (item: any) => ({
        id: item.id,
        title: item.name,
        key: item.id,
        value: item.id,
        isLeaf: false,
        selectable: false
      }));

      this.setState({
        list: treeData
      });
    });
  };

  public onLoadData = (treeNode: any) => {
    const { loadData } = this.props;
    const { list } = this.state;
    const { eventKey, loaded, id } = treeNode.props;

    return new Promise<void>(resolve => {
      loadData({ id }).then((res: any) => {
        if (res.code !== 200) {
          message.error(res.message);
          return;
        }

        if (loaded) {
          resolve();
          return;
        }

        const nodes = res.data || [];
        const target = _.find(list, ['id', id]);

        target.children = _.map(nodes, node => ({
          title: node.name,
          groupId: node.fatherId,
          value: `${eventKey}-${node.id}`,
          key: `${eventKey}-${node.id}`,
          isLeaf: true,
          selectable: true
        }));

        this.setState({
          list: [...this.state.list]
        });

        resolve();
      });
    });
  };

  public componentDidMount() {
    this.getDefaultTreeNodes();
  }

  public handleChange = ({ label, value }: any) => {
    const [pid, cid] = value.split('-');
    const pTitle = _.find(this.state.list, ['id', +pid])['title'];

    this.props.onChange({
      catName: `${pTitle} / ${label}`,
      catId: +cid,
      sysId: +pid
    });
  };

  public render() {
    const { list } = this.state;
    const { value: { sysId, catId, catName } = {} } = this.props;
    const sValue: any = !_.isNil(catId)
      ? { label: catName, value: `${sysId}-${catId}` }
      : undefined;

    return (
      <TreeSelect
        labelInValue
        style={{ width: '100%' }}
        value={sValue}
        dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
        getPopupContainer={triggerNode =>
          triggerNode.parentElement as HTMLElement
        }
        placeholder="-请选择-"
        onChange={this.handleChange}
        loadData={this.onLoadData}
        treeData={list}
      />
    );
  }
}

export default CataSelectTree;
