import React, { Component, createRef } from 'react';
import { observer } from 'mobx-react';
import { message } from 'sup-ui';
import JsonArea from './JsonArea';
import XmlArea from './XmlArea';
import TxtArea from './TxtArea';
import styles from './index.less';

interface IProps {
  title?: string; //JSON错误文案标题
  readOnly: boolean;
  type: 'JSON' | 'XML' | 'TEXT_PLAIN'; //类型
  value: any;
}

@observer
class RequestBody extends Component<IProps> {
  private readonly editorRef: any;
  public constructor(props: IProps) {
    super(props);
    this.editorRef = createRef();
  }

  public validateDatas = () => {
    //校验，拼装数据
    const { title = '' } = this.props;
    const editorValue = this.editorRef.current.getValue();

    //JsonEditor校验错误
    if (_.isBoolean(editorValue)) {
      message.error(`${title}JSON格式有误！`);
      return;
    }

    return editorValue || '';
  };

  public refreshEditor = () => {
    if (this.editorRef.current) {
      this.editorRef.current.refreshContent();
    }
  };

  public render() {
    const { type, readOnly, value } = this.props;

    return (
      <div className={styles.container}>
        {type === 'JSON' && (
          <div className={styles.editor}>
            <JsonArea ref={this.editorRef} readOnly={readOnly} value={value} />
          </div>
        )}
        {type === 'XML' && (
          <div className={styles.editor}>
            <XmlArea ref={this.editorRef} readOnly={readOnly} value={value} />
          </div>
        )}
        {type === 'TEXT_PLAIN' && (
          <TxtArea ref={this.editorRef} readOnly={readOnly} value={value} />
        )}
      </div>
    );
  }
}

export default RequestBody;
