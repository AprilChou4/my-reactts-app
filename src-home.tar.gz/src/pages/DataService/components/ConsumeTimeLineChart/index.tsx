// 调用耗时曲线图
import React, { useEffect, useRef } from 'react';
import * as echarts from 'echarts';
import styles from './index.less';

const ConsumeTimeLineChart = () => {
  // 初始化echarts实例
  const wrapRef: any = useRef();
  const chartRef: any = useRef();

  const initChart = () => {
    const chartDOM = wrapRef.current;
    chartRef.current = echarts.init(chartDOM);
    // chartDOM.style.width = chartDOM.innerWidth + 'px'; // 再增加这一行

    const option = {
      xAxis: {
        type: 'category',
        data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          data: [150, 230, 224, 218, 135, 147, 260],
          type: 'line'
        }
      ]
    };
    // 绘制图表
    chartRef.current.setOption(option);
  };

  const resizeChart = () => {
    chartRef.current.resize();
  };

  useEffect(() => {
    initChart();
    window.addEventListener('resize', resizeChart);
    return () => {
      window.removeEventListener('resize', resizeChart);
    };
  }, []);
  return <div ref={wrapRef} className={styles.consumeTimeLineChart} />;
};
export default ConsumeTimeLineChart;
