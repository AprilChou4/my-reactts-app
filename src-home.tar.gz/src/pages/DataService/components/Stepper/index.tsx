import React, { Component } from 'react';
import Icon from '@components/Icon';
import styles from './index.less';

const list = [
  { key: 1, showName: '属性配置' },
  { key: 2, showName: '参数配置' },
  { key: 3, showName: '测试' },
  { key: 4, showName: '保存/发布' }
];

interface IProps {
  step: number | string;
}

interface IState {}

class Stepper extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { step = 1 } = this.props;

    return (
      <div className={styles.container}>
        <ul>
          {list.map(item => (
            <li
              key={item.key}
              className={item.key <= step ? styles.active : ''}
            >
              {item.key < step ? (
                <div className={styles.icon}>
                  <Icon
                    type="circle-tick"
                    fill="#0091ff"
                    width={30}
                    height={30}
                  />
                </div>
              ) : (
                <div className={styles.serial}>{item.key}</div>
              )}
              <p>{item.showName}</p>
              <div className={styles.line} />
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default Stepper;
