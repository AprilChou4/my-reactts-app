import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import DialogModal from '@components/Modal/Dialog';
import { cateNameReg } from '../../consts/regexp';
import styles from '../index.less';

const FormItem = Form.Item;
const { TextArea } = Input;

interface IProps extends FormComponentProps {
  visible: boolean;
  onVisibleChange: any;
  values: any;
  onOk: any;
  loading: boolean;
}
interface IState {}

class AddCatalogueModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public handleOK = () => {
    const { form, onOk } = this.props;
    form.validateFields((error: any, formValues: any) => {
      if (error) return;

      onOk(formValues);
    });
  };

  public render() {
    const { visible, onVisibleChange, values, loading } = this.props;
    const {
      form: { getFieldDecorator }
    } = this.props;
    const update = !_.isEmpty(values);

    return (
      <DialogModal
        width={460}
        title="新增目录"
        visible={visible}
        loading={loading}
        maskClosable={false}
        onOk={this.handleOK}
        onCancel={() => onVisibleChange(false)}
        bodyStyle={{ padding: '20px 30px 6px' }}
        wrapClassName={styles.modalContainer}
      >
        <Form>
          <FormItem label="目录名称" colon={false}>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                { required: true, message: `请输入目录名称` },
                { max: 50, message: `目录名称长度不能超过50!` }
              ]
            })(<Input />)}
          </FormItem>
          <FormItem label="别名" colon={false}>
            {getFieldDecorator('otherName', {
              initialValue: values.otherName,
              rules: [
                { required: true, message: '请输入目录别名' },
                {
                  pattern: cateNameReg,
                  message: `只允许输入以字母开头，字母数字和_的组合名称，最长50字符`
                }
              ]
            })(<Input disabled={update} />)}
          </FormItem>
          <FormItem label="描述" colon={false}>
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: `描述长度不能超过255!` }]
            })(<TextArea autosize={{ minRows: 4, maxRows: 6 }} />)}
          </FormItem>
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>()(AddCatalogueModal);
