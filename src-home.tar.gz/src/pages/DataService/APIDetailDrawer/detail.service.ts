import http from '@services/http';
import { SERVICE_URL } from '@config/env';

//获取api详情
export function getAPIDetail(id: any): Promise<any> {
  return http.get(`${SERVICE_URL}/api/detail/${id}`);
}

//获取api调用日志
export function getInvokeLog(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/statistics/logs`, params);
}

//下载api文档
export function downloadDocs(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/docs`, params, '', {
    responseType: 'blob'
  });
}
