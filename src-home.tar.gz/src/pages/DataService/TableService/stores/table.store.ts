import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getApiList, startApi, forbidApi } from '../table.service';

class ManagerStore {
  private readonly info: any;
  private readonly globalStore: any;
  private readonly debounceGetList: any;
  @observable public noData = true;
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams: any = {
    keyword: '',
    activeState: [],
    order: {
      key: 'publishedAt',
      orderType: 'DESC'
    },
    pageIndex: 1,
    pageSize: 20
  };
  @observable public selectedCatalogue: any = {}; //当前选中目录
  @observable public visible = false; //详情drawer
  @observable public selectedAPI = null; //当前操作的api

  public constructor(globalStore: any, info: any) {
    this.globalStore = globalStore;
    this.info = info;

    const sourceId = _.get(info, 'source.sourceId', null);

    if (_.isEmpty(info) || _.isNil(sourceId)) {
      return;
    }

    this.debounceGetList = _.debounce(this.getList, 600);
    this.getList();
  }

  @action.bound
  public async getList() {
    const {
      source: { sourceId, sourceType },
      table: { tableName, schemaName }
    } = this.info;

    this.loading = true;
    const res = await getApiList({
      sourceId,
      tableName,
      ...(sourceType === 'sqlserver' && { schemaName }),
      ...this.searchParams
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const {
        pagination: { total },
        list
      } = res.data || {};

      this.list = list || [];
      this.count = total;

      if (this.noData) {
        this.noData = this.list.length === 0;
      }
    });
  }

  @action.bound
  public updateKeyword = (value: string) => {
    if (this.loading) {
      return;
    }

    this.searchParams = { ...this.searchParams, keyword: value, pageIndex: 1 };
    this.debounceGetList();
  };

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }

  @action.bound
  public async handleStartApi(record: any) {
    const { name, id } = record;
    const res = await startApi(id);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.getList();
      this.clearRelateCachePages();
      message.success(`${name}已启用`);
    });
  }

  @action.bound
  public async handleForbidApi(record: any) {
    const { name, id } = record;
    const res = await forbidApi(id);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.getList();
      this.clearRelateCachePages();
      message.success(`${name}已禁用`);
    });
  }

  //刷新api列表页，启用禁用影响删除逻辑
  @action.bound
  public clearRelateCachePages() {
    const cachePages = [`/data-service/develop`, `/data-service/manager`];

    this.globalStore.clearCachePages(cachePages);
  }
}

export default ManagerStore;
