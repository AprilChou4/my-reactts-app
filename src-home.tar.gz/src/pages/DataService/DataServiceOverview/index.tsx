import React, { Component } from 'react';
import { Row, Col } from 'sup-ui';
import { observer } from 'mobx-react';
import Header from '@components/Header';
import LineChart from './components/LineChart';
import LeaderBoard from './components/LeaderBoard';
import OverviewStore from './stores/overview.store';
import styles from './index.less';

interface IProps {}
interface IState {}

@observer
class DataServiceOverview extends Component<IProps, IState> {
  private readonly store: OverviewStore;
  public constructor(props: IProps) {
    super(props);
    this.store = new OverviewStore();
  }

  public render() {
    const {
      overview,
      invokeRange,
      invokeTrend,
      invokeCountTopN,
      invokeFailTopN,
      invokeTimeTopN,
      handleCallTrendChange
    } = this.store;

    return (
      <div className={styles.container}>
        <Header left="服务概览" />
        <div className={styles.cont}>
          <ul className={styles.overview}>
            <li>
              <span>服务在线总数</span>
              <p>{overview.totalOnLine}</p>
            </li>
            <li>
              <span>历史调用次数</span>
              <p>{overview.historyTotal}</p>
            </li>
            <li>
              <span>今日调用总次数</span>
              <p>{overview.todayCallCount}</p>
            </li>
            <li>
              <span>今日调用失败次数</span>
              <p>{overview.todayFailedCount}</p>
            </li>
          </ul>
          <div className={styles.dashboard}>
            <section>
              <Row>
                <Col span={24}>
                  <LineChart
                    range={invokeRange}
                    onRangeChange={handleCallTrendChange}
                    data={_.cloneDeep(invokeTrend)}
                  />
                </Col>
              </Row>
            </section>
            <section>
              <Row gutter={15}>
                <Col span={8}>
                  <LeaderBoard
                    title="服务调用次数排行"
                    unit="调用总次数(次)"
                    source={invokeCountTopN}
                    theme="blue"
                  />
                </Col>
                <Col span={8}>
                  <LeaderBoard
                    title="服务调用失败率排行"
                    unit="失败率(%)"
                    source={invokeFailTopN}
                    theme="green"
                  />
                </Col>
                <Col span={8}>
                  <LeaderBoard
                    title="服务调用耗时排行"
                    unit="耗时(ms)"
                    source={invokeTimeTopN}
                    theme="yellow"
                  />
                </Col>
              </Row>
            </section>
          </div>
        </div>
      </div>
    );
  }
}

export default DataServiceOverview;
