import React, { Component, createRef } from 'react';
import { observer } from 'mobx-react';
import { Select } from 'sup-ui';
import Highcharts from 'highcharts';
import moment from 'moment';
import { timeRanges } from '../../consts/enum';
import styles from '../index.less';

//复杂原因：xAxis设置type为datetime时，会涉及到highcharts的时区问题
Highcharts.setOptions({
  global: {
    useUTC: false
  }
});

const { Option } = Select;
const rangeMap: any = {
  1: [60, '%H:%M', 'HH:mm'], //近1小时
  2: [60 * 60, '%m-%d %H:00', 'HH:00'], //近24小时
  3: [24 * 60 * 60, '%m-%d', 'MM-DD'], //近7天
  4: [24 * 60 * 60, '%m-%d', 'MM-DD'] //近30天
};

interface IProps {
  range: any;
  onRangeChange: any;
  data: any;
}
interface IState {}

@observer
class LineChart extends Component<IProps, IState> {
  private readonly containerRef: any;
  private chart: any;
  public constructor(props: IProps) {
    super(props);
    this.containerRef = createRef();
  }

  public componentDidUpdate(prevProps: Readonly<IProps>): void {
    if (!_.isEqual(prevProps.data, this.props.data)) {
      const {
        range,
        data: [categories, total, fail]
      } = this.props;
      const [interval, tFormat, xFormat] = rangeMap[range];
      let startTime = categories[0];

      //分钟
      if (range === '1') {
        startTime = moment(startTime).startOf('minute').valueOf();
      }

      //小时
      if (range === '2') {
        startTime = moment(startTime).startOf('hour').valueOf();
      }

      //天
      if (range === '3' || range === '4') {
        startTime = moment(startTime).startOf('day').valueOf();
      }

      this.chart.series[0].update({
        name: '调用总次数',
        data: total,
        pointStart: startTime
      });

      this.chart.series[1].update({
        name: '失败次数',
        color: '#ed1c24',
        fillColor: 'rgba(237, 28, 36, 0.05)',
        data: fail,
        pointStart: startTime
      });

      this.chart.update({
        plotOptions: {
          series: {
            // pointStart: categories[0],
            pointInterval: interval * 1000
          }
        },
        tooltip: {
          xDateFormat: tFormat
        }
      });

      this.chart.yAxis[0].update({
        max: _.every(total, n => !n) && _.every(fail, n => !n) ? 100 : null
      });

      this.chart.xAxis[0].update({
        labels: {
          formatter(): any {
            return moment(this.value).format(xFormat);
          }
        } as any
      });
    }
  }

  public componentDidMount() {
    this.chart = Highcharts.chart(this.containerRef.current, {
      chart: {
        type: 'area',
        marginTop: 10,
        marginLeft: 70,
        marginRight: 50,
        marginBottom: 56
      },
      credits: {
        enabled: false
      },
      title: {
        text: ''
      },
      xAxis: {
        type: 'datetime',
        tickLength: 1, //x轴分割线长度
        crosshair: {
          width: 1,
          color: '#EAEBF0'
        },
        gridLineDashStyle: 'dash',
        gridLineWidth: 1
      },
      yAxis: {
        min: 0,
        max: 100,
        title: {
          text: '次数'
        },
        gridLineDashStyle: 'dash'
      },
      legend: {
        y: 10,
        enabled: true
      },
      plotOptions: {
        series: {
          color: '#4585ff',
          fillColor: 'rgba(69, 133, 255, 0.05)',
          marker: {
            lineColor: 'white',
            lineWidth: 2,
            radius: 4,
            symbol: 'circle'
          },
          states: {
            hover: {
              halo: false,
              lineWidthPlus: 0
            }
          },
          events: {
            legendItemClick() {
              return false; //禁用图例点击事件
            }
          }
        }
      },
      tooltip: {
        borderRadius: 6,
        backgroundColor: '#ffffff',
        borderWidth: 0,
        shadow: true,
        style: {
          fontSize: 12,
          color: '#354052'
        },
        crosshairs: true,
        shared: true,
        xDateFormat: '%H:%M',
        headerFormat: '<span style="font-size: 12px">{point.key}</span><br/>'
      } as any,
      series: [
        {
          name: '调用总次数',
          data: []
        },
        {
          name: '失败次数',
          color: '#ed1c24',
          fillColor: 'rgba(237, 28, 36, 0.05)',
          data: []
        }
      ]
    });
  }

  public render() {
    const { range, onRangeChange } = this.props;

    return (
      <div className={styles.graph}>
        <div className={styles.head}>
          <h3>调用次数分布</h3>
          <div className={styles.scope}>
            <Select value={range} onChange={onRangeChange}>
              {timeRanges.map((item: any) => (
                <Option key={item.key}>{item.showName}</Option>
              ))}
            </Select>
          </div>
        </div>
        <div
          style={{ width: '100%', height: '100%', flex: 1 }}
          ref={this.containerRef}
        />
      </div>
    );
  }
}

export default LineChart;
