import React, { Component } from 'react';

import styles from '../index.less';

interface IProps {
  title: string;
  unit: string;
  theme: 'blue' | 'green' | 'yellow';
  source: any[];
}

interface IState {}

class LeaderBoard extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { title, theme, source, unit } = this.props;

    return (
      <div className={styles.leaderBoard}>
        <h3 className={styles.title}>{title}</h3>
        <div className={styles.rankHead}>
          <i>排名</i>
          <p>服务名称</p>
          <span>{unit}</span>
        </div>
        <ul className={styles.list}>
          {source.map((item: any, i: number) => (
            <li key={i}>
              <i>{i + 1}</i>
              <p>{item.name}</p>
              <div className={`${styles.tag} ${styles[theme]}`}>
                {item.count}
              </div>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default LeaderBoard;
