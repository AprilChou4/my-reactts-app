import http from '@services/http';
import { SERVICE_URL } from '@config/env';

export function getOverviewData(): Promise<any> {
  return http.get(`${SERVICE_URL}/statistics/overview`);
}

export function getInvokeTrend(params: any): Promise<any> {
  return http.get(`${SERVICE_URL}/statistics/trend`, params);
}
