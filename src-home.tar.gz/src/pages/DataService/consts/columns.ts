export const listTableColumns: any = [
  {
    title: '服务名称',
    dataIndex: 'name',
    check: true
  },
  {
    title: '服务路径',
    dataIndex: 'path',
    check: true
  },
  {
    title: '所属目录',
    dataIndex: 'catName',
    check: false
  },
  {
    title: '请求方法',
    dataIndex: 'reqHttpMethod',
    check: false
  },
  {
    title: '服务描述',
    dataIndex: 'description',
    check: true
  },
  {
    title: '类型',
    dataIndex: 'type',
    check: true
  },
  {
    title: '发布状态',
    dataIndex: 'status',
    check: true
  },
  {
    title: '线上版本',
    dataIndex: 'publishVersion',
    check: true
  },
  {
    title: '创建人',
    dataIndex: 'creator',
    check: true
  },
  {
    title: '创建时间',
    dataIndex: 'createTime',
    check: false
  },
  {
    title: '更新人',
    dataIndex: 'modifier',
    check: false
  },
  {
    title: '最近更新时间',
    dataIndex: 'modifyTime',
    check: true
  }
];

export const managerTableColumns: any = [
  {
    title: '服务名称',
    dataIndex: 'name',
    check: true
  },
  {
    title: '服务路径',
    dataIndex: 'path',
    check: true
  },
  {
    title: '所属目录',
    dataIndex: 'catName',
    check: false
  },
  {
    title: '请求方法',
    dataIndex: 'reqHttpMethod',
    check: false
  },
  {
    title: '服务描述',
    dataIndex: 'description',
    check: true
  },
  {
    title: '类型',
    dataIndex: 'type',
    check: true
  },
  {
    title: '服务状态',
    dataIndex: 'activeState',
    check: true
  },
  {
    title: '发布时间',
    dataIndex: 'publishedAt',
    check: true
  }
];
