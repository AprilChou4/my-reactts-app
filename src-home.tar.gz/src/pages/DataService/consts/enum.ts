interface ListItem {
  key: number | string;
  showName: string;
  disable?: boolean;
}

//调用次数趋势时间范围
export const timeRanges = [
  { key: '1', showName: '近1小时' },
  { key: '2', showName: '近24小时' },
  { key: '3', showName: '近7天' },
  { key: '4', showName: '近30天' }
];

//api状态
export const apiStatus: ListItem[] = [
  { key: 0, showName: '待发布', disable: false },
  { key: 1, showName: '已发布', disable: false }
];

//api服务状态
export const serviceStatus: ListItem[] = [
  { key: 1, showName: '启用' },
  { key: 0, showName: '禁用' }
];

//api类型
export const apiTypeList: any[] = [
  {
    key: 0,
    showName: '注册服务',
    desc: '将已有服务注册到平台进行统一管理',
    disable: false
  },
  {
    key: 1,
    showName: '数据服务',
    desc: '通过向导或编写SQL的方式，将数据模型、数据表以服务的方式开放到外部',
    disable: false
  },
  {
    key: 2,
    showName: '服务编排',
    desc: '按照业务逻辑，以串行、并行和分支等结构编排多个服务及函数服务',
    disable: true
  }
];

//注册api请求方式
export const methods: ListItem[] = [
  { key: 'GET', showName: 'GET', disable: false },
  { key: 'POST', showName: 'POST', disable: false },
  { key: 'PUT', showName: 'PUT', disable: false },
  { key: 'DELETE', showName: 'DELETE', disable: false }
];

//数据api请求方式
export const dataApiMethods: ListItem[] = [
  { key: 'GET', showName: 'GET', disable: false },
  { key: 'POST', showName: 'POST', disable: false }
  // { key: 'PUT', showName: 'PUT', disable: false },
  // { key: 'DELETE', showName: 'DELETE', disable: false }
];

//返回类型
export const responseTypes: ListItem[] = [
  { key: 'penetrate', showName: '穿透', disable: false }
];

//参数类型
export const paramTypes = [
  { key: 'String', showName: 'String', disable: false },
  { key: 'Int', showName: 'Int', disable: false },
  { key: 'Long', showName: 'Long', disable: false },
  { key: 'Float', showName: 'Float', disable: false },
  { key: 'Double', showName: 'Double', disable: false },
  { key: 'Boolean', showName: 'Boolean', disable: false }
];

//参数位置
export const paramPos = [
  { key: 'QUERY', showName: 'QUERY', disable: false },
  { key: 'HEAD', showName: 'HEAD', disable: false }
];

//数据Api参数位置
export const dataApiParamPos = [
  { key: 'PATH', showName: 'PATH', disable: false },
  { key: 'QUERY', showName: 'QUERY', disable: false }
];

//content-type
export const contentTypes: ListItem[] = [
  { key: 'JSON', showName: 'application/json', disable: false },
  { key: 'XML', showName: 'application/xml', disable: false },
  {
    key: 'FORM_URLENCODED',
    showName: 'application/x-www-form-urlencoded',
    disable: false
  },
  // { key: 'MULTIPART', showName: 'multipart/form-data', disable: false },
  { key: 'TEXT_PLAIN', showName: 'text/plain', disable: false }
];

//数据源类型
export const sourceTypes: ListItem[] = [
  { key: 'all', showName: '全部', disable: false },
  { key: 'mysql', showName: 'MySQL', disable: false },
  { key: 'oracle', showName: 'Oracle', disable: false },
  { key: 'sqlserver', showName: 'SQLServer', disable: false },
  { key: 'supos', showName: 'supOS', disable: false },
  { key: 'localdw', showName: '本地数仓', disable: false }
  // { key: 'hive', showName: 'Hive', disable: false }
];

//符号类型
export const baseSignTypes: ListItem[] = [
  { key: '=', showName: '=', disable: false },
  { key: '>', showName: '>', disable: false },
  { key: '>=', showName: '>=', disable: false },
  { key: '<', showName: '<', disable: false },
  { key: '<=', showName: '<=', disable: false },
  { key: '!=', showName: '!=', disable: false },
  { key: 'LIKE', showName: '包含', disable: false },
  { key: 'NOT LIKE', showName: '不包含', disable: false }
];

//根据数据类型切换符号
export const signTypes = (dataType: string) => {
  switch (dataType) {
    case 'String':
      return [
        { key: '=', showName: '=', disable: false },
        { key: '!=', showName: '!=', disable: false },
        { key: 'LIKE', showName: '包含', disable: false },
        { key: 'NOT LIKE', showName: '不包含', disable: false }
      ];
    case 'Boolean':
      return [
        { key: '=', showName: '=', disable: false },
        { key: '!=', showName: '!=', disable: false }
      ];
    default:
      return [
        { key: '=', showName: '=', disable: false },
        { key: '>', showName: '>', disable: false },
        { key: '>=', showName: '>=', disable: false },
        { key: '<', showName: '<', disable: false },
        { key: '<=', showName: '<=', disable: false },
        { key: '!=', showName: '!=', disable: false }
      ];
  }
};

//响应模板类型
export const templateTypes: ListItem[] = [
  { key: 0, showName: '默认模板', disable: false }
  // { key: 1, showName: '天坊模板', disable: true }
];

//字段类型转换，将字段类型转为参数类型
export const transParamType = (type: string) => {
  const dataType = type ? type.toUpperCase() : '';

  switch (dataType) {
    case 'CHAR':
    case 'VARCHAR':
    case 'TINYTEXT':
    case 'TEXT':
    case 'MEDIUMTEXT':
    case 'LONGTEXT':
    case 'ENUM':
    case 'SET':
    case 'NCHAR':
    case 'NVARCHAR':
    case 'NTEXT':
    case 'VARCHAR2':
    case 'NVARCHAR2':
    case 'DATE':
    case 'YEAR':
    case 'TIME':
    case 'DATETIME':
    case 'TIMESTAMP':
      return 'String';

    case 'TINYINT':
    case 'SMALLINT':
    case 'INT':
    case 'INTEGER':
      return 'Int';

    case 'BIGINT':
    case 'LONG':
      return 'Long';

    case 'FLOAT':
    case 'REAL':
    case 'BINARY_FLOAT':
      return 'Float';

    case 'DOUBLE':
    case 'DECIMAL':
    case 'NUMERIC':
    case 'MONEY':
    case 'SMALLMONEY':
    case 'BINARY_DOUBLE':
    case 'NUMBER':
      return 'Double';

    case 'BIT':
    case 'BOOLEAN':
      return 'Boolean';

    default:
      return 'String';
  }
};

//时间类型
export const timeTypeList = ['DATE', 'YEAR', 'TIME', 'DATETIME', 'TIMESTAMP'];
