import React, { Component, Fragment } from 'react';
import { inject, observer } from 'mobx-react';
import { Table } from 'sup-ui';
import memoizeOne from 'memoize-one';
import Icon from '@components/Icon';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import TableFilter from '@components/TableFilter';
import KeywordSearch from '@components/KeywordSearch';
import ColumnFilter from '@components/ColumnFilter';
import { UTC2LocalDateTime } from '@utils/common';
import { managerTableColumns } from '../../consts/columns';
import { apiTypeList, serviceStatus } from '../../consts/enum';
import { generateEnumMap } from '../../consts/utils';
import APIDetailDrawer from '../../APIDetailDrawer';
import ManagerStore from '../stores/manager.store';
import styles from '../index.less';

interface IProps {
  global?: any;
  state: any;
  catalog: any;
}
interface IState {
  checkedColumns: any[];
}

@inject('global')
@observer
class ManagerTable extends Component<IProps, IState> {
  private readonly store: ManagerStore;
  private readonly typeMap: any;
  public constructor(props: IProps) {
    super(props);
    const checkedItems = _.map(
      _.filter(managerTableColumns, 'check'),
      'dataIndex'
    );

    this.state = {
      checkedColumns: checkedItems
    };
    this.typeMap = generateEnumMap(apiTypeList);
    this.store = new ManagerStore(props.global, props.state);
  }

  public updateCheckedColumns = (checkedItems: any[]) => {
    this.setState({
      checkedColumns: checkedItems
    });
  };

  private handleSearch = (value: string) => {
    this.store.updateKeyword(value);
  };

  public getEnumData = (dataIndex: string): any => {
    switch (dataIndex) {
      case 'type':
        return apiTypeList;
      case 'activeState':
        return serviceStatus;
      default:
        return [];
    }
  };

  private getColumnSearchProps = (dataIndex: string, isEnum: boolean) => ({
    filterDropdown: ({ setSelectedKeys, confirm, selectedKeys }: any) => (
      <TableFilter
        isEnum={isEnum}
        enumData={this.getEnumData(dataIndex)}
        confirm={confirm}
        selectedKeys={selectedKeys}
        setSelectedKeys={setSelectedKeys}
      />
    )
  });

  private handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;

    //筛选filters
    const { type = [], activeState = [] } = filters;
    //排序sorter, sort只能触发一个
    const { columnKey, order } = sorter;

    this.store.updateSearchParams({
      pageIndex: current,
      pageSize,
      type,
      activeState,
      order: _.isEmpty(sorter)
        ? {
            key: 'publishedAt',
            orderType: 'DESC'
          }
        : {
            key: columnKey,
            orderType: order === 'ascend' ? 'ASC' : 'DESC'
          }
    });
  };

  private handleCheckData = (record: any) => {
    const { checkApiDetail } = this.store;
    checkApiDetail(record);
  };

  private handleStartApi = (record: any) => {
    this.store.handleStartApi(record);
  };

  private handleForbidApi = (record: any) => {
    this.store.handleForbidApi(record);
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { catalog } = this.props;

    if (!_.isEqual(catalog, prevProps.catalog)) {
      this.store.handleCatalogueChange(catalog);
    }
  }

  public componentDidMount() {
    const { catalog } = this.props;

    this.store.handleCatalogueChange(catalog);
  }

  private getColumns = () => {
    const {
      selectedCatalogue: { isGroup }
    } = this.store;

    return [
      {
        title: '服务名称',
        dataIndex: 'name',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <a onClick={() => this.handleCheckData(record)}>
            <TableCellText text={text} />
          </a>
        )
      },
      {
        title: '服务路径',
        dataIndex: 'path',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      isGroup && {
        title: '所属目录',
        dataIndex: 'catName',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '请求方法',
        dataIndex: 'reqHttpMethod',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '服务描述',
        width: 180,
        dataIndex: 'description',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'type',
        width: 120,
        render: (text: string) => <TableCellText text={this.typeMap[text]} />,
        ...this.getColumnSearchProps('type', true)
      },
      {
        title: '服务状态',
        dataIndex: 'activeState',
        width: 120,
        className: 'ellipsis-hide',
        render: (status: any) => {
          return status === 1 ? (
            <div className={styles.apiStatus}>
              <i className={styles.success} />
              <span>启用</span>
            </div>
          ) : (
            <div className={styles.apiStatus}>
              <i />
              <span>禁用</span>
            </div>
          );
        },
        ...this.getColumnSearchProps('activeState', true)
      },
      {
        title: '发布时间',
        dataIndex: 'publishedAt',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        render: (text: string) => (
          <TableCellText text={UTC2LocalDateTime(text)} />
        )
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 100,
        render: (_text: any, record: any) => (
          <Fragment>
            <div className="operator">
              {record.activeState === 1 ? (
                <a onClick={() => this.handleForbidApi(record)}>禁用</a>
              ) : (
                <a onClick={() => this.handleStartApi(record)}>启用</a>
              )}
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ].filter(Boolean);
  };

  private getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 20;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public render() {
    const {
      status,
      loading,
      list,
      searchParams,
      count,
      visible,
      selectedAPI,
      handleVisibleChange,
      selectedCatalogue
    } = this.store;
    const { checkedColumns } = this.state;
    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );
    const isSystem =
      selectedCatalogue &&
      selectedCatalogue.isGroup &&
      selectedCatalogue.id !== -1;
    const txt = _.isNil(status) ? '未配置' : status ? '正常' : '异常';
    const cn = _.isNil(status) ? '' : status ? 'success' : 'error';

    return (
      <div className={styles.tableWrapper}>
        <div className={styles.operator}>
          {isSystem && (
            <div className={styles.status}>
              <p>健康状态</p>
              <span className={cn ? styles[cn] : ''}>{txt}</span>
            </div>
          )}
          <div className={styles.search}>
            <KeywordSearch
              placeholder="请输入关键字搜索"
              value={searchParams.keyword}
              onSearch={this.handleSearch}
            />
            <ColumnFilter
              sourceColumns={managerTableColumns}
              onOk={this.updateCheckedColumns}
            />
          </div>
        </div>
        <div className={`${styles.table} mp-table-gray-light mp-table-grow`}>
          <Table
            loading={loading}
            columns={filterColumns}
            dataSource={list}
            onChange={this.handleTableChange}
            rowKey="id"
            pagination={{
              current: searchParams.pageIndex,
              pageSize: searchParams.pageSize,
              total: count,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging,
              pageSizeOptions: ['20', '50', '100'],
              showSizeChanger: true,
              showQuickJumper: true
            }}
            scroll={{
              x: totalWidthX,
              y: 'calc(100% - 40px)'
            }}
          />
        </div>
        {visible && (
          <APIDetailDrawer
            showNav={false}
            record={selectedAPI}
            visible={visible}
            onVisibleChange={handleVisibleChange}
          />
        )}
      </div>
    );
  }
}

export default ManagerTable;
