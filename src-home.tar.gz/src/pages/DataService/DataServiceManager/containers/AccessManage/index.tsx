import React, { Component, Fragment } from 'react';
import { observer } from 'mobx-react';
import { Table, Switch, Radio, message } from 'sup-ui';
import Icon from '@components/Icon';
import { AddBtn, DelBtn } from '@components/Button';
import KeywordSearch from '@components/KeywordSearch';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import AddModal from './AddModel';
import AccessStore from '../../stores/access.store';

import styles from './index.less';
import TipsDelete from '@components/Modal/TipsDelete';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;

interface IProps {
  catalog: any;
}

interface IState {
  inputValue: any;
}

@observer
class AccessManage extends Component<IProps, IState> {
  private readonly store: AccessStore;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      inputValue: ''
    };
    this.store = new AccessStore();
  }

  private handleValueChange = (value: any) => {
    this.setState({
      inputValue: value
    });
  };

  private handleDeleteData = (ids?: any) => {
    const { selectedRowKeys, handleRemoveData } = this.store;

    if (!ids && !selectedRowKeys.length) {
      message.error('请选择要删除的数据!');
      return;
    }

    const config = {
      title: '提示',
      content: `确定删除该名单？`,
      onOk: () => {
        handleRemoveData(ids || selectedRowKeys);
      }
    };

    TipsDelete(config);
  };

  private getColumns = (): any[] => {
    return [
      {
        title: 'AccessKey',
        dataIndex: 'accessKey',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '调用者IP',
        dataIndex: 'callerIp',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '操作',
        align: 'center',
        width: 100,
        render: (_text: any, record: any) => (
          <Fragment>
            <div className="operator">
              <a onClick={() => this.handleDeleteData([record.id])}>删除</a>
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </Fragment>
        )
      }
    ];
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { catalog } = this.props;

    if (!_.isEqual(catalog, prevProps.catalog)) {
      this.store.handleCatalogueChange(catalog);
    }
  }

  public componentDidMount() {
    const { catalog } = this.props;

    this.store.handleCatalogueChange(catalog);
  }

  public render() {
    const { inputValue } = this.state;
    const {
      access,
      type,
      loading,
      list,
      addLoading,
      visible,
      handleAccessSwitch,
      handleTypeChange,
      handleVisibleChange,
      selectedRowKeys,
      updateSelectedRowKeys,
      handleAddData
    } = this.store;
    const rowSelection = {
      columnWidth: '50px',
      selectedRowKeys,
      onChange: updateSelectedRowKeys,
      hideDefaultSelections: true
    };
    const columns = this.getColumns();
    const filterList = _.filter(
      list,
      item =>
        _.includes(_.toLower(item.accessKey), _.toLower(inputValue)) ||
        _.includes(_.toLower(item.callerIp), _.toLower(inputValue))
    );

    return (
      <div className={styles.container}>
        <div className={styles.switch}>
          <div className={styles.item}>
            <label>访问权限:</label>
            <Switch checked={access} onChange={handleAccessSwitch} />
          </div>
          <RadioGroup
            value={type}
            onChange={e => handleTypeChange(e.target.value)}
            buttonStyle="solid"
          >
            <RadioButton value={0}>白名单</RadioButton>
            <RadioButton value={1}>黑名单</RadioButton>
          </RadioGroup>
        </div>
        <div className={styles.operator}>
          <div>
            <AddBtn
              ghost
              title="新增"
              style={{ marginRight: '10px' }}
              onClick={() => handleVisibleChange(true)}
            />
            <DelBtn onClick={() => this.handleDeleteData()} />
          </div>
          <div>
            <KeywordSearch
              placeholder="请输入AccessKey / IP搜索"
              value={inputValue}
              onSearch={this.handleValueChange}
            />
          </div>
        </div>
        <div className={`${styles.table} mp-table-gray-light mp-table-grow`}>
          <Table
            loading={loading}
            columns={columns}
            rowSelection={rowSelection}
            dataSource={filterList}
            rowKey="id"
            pagination={{
              defaultPageSize: 20,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging,
              pageSizeOptions: ['20', '50', '100'],
              showSizeChanger: true,
              showQuickJumper: true
            }}
            scroll={{
              y: 'calc(100% - 40px)'
            }}
          />
        </div>
        {visible && (
          <AddModal
            loading={addLoading}
            visible={visible}
            type={type}
            onVisibleChange={handleVisibleChange}
            onOk={handleAddData}
          />
        )}
      </div>
    );
  }
}

export default AccessManage;
