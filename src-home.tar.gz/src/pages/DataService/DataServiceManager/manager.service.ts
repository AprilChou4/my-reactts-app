import http from '@services/http';
import { SERVICE_URL } from '@config/env';

//获取api列表
export function getApiList(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/managerlist`, params);
}

//启用api
export function startApi(id: any): Promise<any> {
  return http.get(`${SERVICE_URL}/api/start/${id}`);
}

//停用api
export function forbidApi(id: any): Promise<any> {
  return http.get(`${SERVICE_URL}/api/forbid/${id}`);
}

//下载api文档
// export function downloadDocs(): Promise<any> {
//   return http.get(`${SERVICE_URL}/api/docs`, {}, '', {
//     responseType: 'blob'
//   });
// }

//获取名单列表
export function getAccessList(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/access/list`, params);
}

export function addAccess(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/access/add`, params);
}

export function deleteAccess(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/access/delete`, params);
}

export function switchAccess(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/access/switch`, params);
}

//健康检查
export function getHealthDetail(id: any): Promise<any> {
  return http.get(`${SERVICE_URL}/api/health/detail/${id}`);
}

export function saveHealth(params: any): Promise<any> {
  return http.post(`${SERVICE_URL}/api/health/save`, params);
}
