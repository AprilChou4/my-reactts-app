import { observable, action, runInAction, computed } from 'mobx';
import { message } from 'sup-ui';
import {
  getAccessList,
  deleteAccess,
  switchAccess,
  addAccess
} from '../manager.service';

class AccessStore {
  @observable public access: boolean = false; //是否开启权限
  @observable public selectedRowKeys: any[] = [];
  @observable public type: any = 0; //0白名单 1黑名单
  @observable public dataSource: any = {};
  @observable public loading = false;
  @observable public selectedCatalogue: any = {}; //当前选中目录
  @observable public visible = false;
  @observable public addLoading = false;

  @action.bound
  public handleCatalogueChange(catalog: any) {
    this.selectedCatalogue = catalog;
    this.selectedRowKeys = [];
    this.getList();
  }

  @action.bound
  public async getList() {
    const { id } = this.selectedCatalogue;

    if (_.isNil(id)) {
      return;
    }

    this.loading = true;

    const res = await getAccessList({
      categoryId: id
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const { whiteStatus, blackStatus } = res.data || {};

      this.access = !whiteStatus || !blackStatus; //黑白名单任一开启  0开启 1关闭

      if (this.access) {
        this.type = blackStatus === 1 ? 0 : 1; // 0白名单 1黑名单
      }

      this.dataSource = res.data;
    });
  }

  @computed
  public get list() {
    const { whiteAccess = [], blackAccess = [] } = this.dataSource;

    return this.type === 0 ? whiteAccess : blackAccess;
  }

  @action.bound
  public updateSelectedRowKeys(selectedRowKeys: string[] | number[]) {
    this.selectedRowKeys = selectedRowKeys;
  }

  @action.bound
  public async handleRemoveData(ids: any) {
    const res = await deleteAccess(ids);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.getList();
      this.selectedRowKeys = [];
    });
  }

  @action.bound
  public async handleAddData(values: any[]) {
    this.addLoading = true;

    const { id } = this.selectedCatalogue;
    const params = _.map(values, item => ({
      categoryId: id,
      ...item
    }));
    const res = await addAccess(params);

    runInAction(() => {
      this.addLoading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.getList();
      this.visible = false;
      message.success('新增成功!');
    });
  }

  @action.bound
  public async handleAccessSwitch(checked: boolean) {
    //启用时，需根据type，将对应的名单开启/关闭
    //禁用时，只需关闭当前打开的type
    const { id } = this.selectedCatalogue;
    let res: any;

    if (_.isNil(id)) {
      return;
    }

    if (checked) {
      res = await switchAccess({
        categoryId: id,
        accessType: this.type,
        status: 0 //0开启 1禁用
      });

      res = await switchAccess({
        categoryId: id,
        accessType: this.type === 0 ? 1 : 0,
        status: 1 //0开启 1禁用
      });
    } else {
      res = await switchAccess({
        categoryId: id,
        accessType: this.type,
        status: 1 //0开启 1禁用
      });
    }

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.access = checked;
    });
  }

  @action.bound
  public async handleTypeChange(type: number) {
    //切换type时，根据当前access状态确定是否调用接口
    if (!this.access) {
      this.type = type;
      return;
    }

    const { id } = this.selectedCatalogue;

    if (_.isNil(id)) {
      return;
    }

    let res: any;

    res = await switchAccess({
      categoryId: id,
      accessType: type,
      status: 0 //0开启 1禁用
    });

    res = await switchAccess({
      categoryId: id,
      accessType: type === 0 ? 1 : 0,
      status: 1 //0开启 1禁用
    });

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.type = type;
    });
  }

  @action.bound
  public handleVisibleChange(visible: boolean) {
    this.visible = visible;
  }
}

export default AccessStore;
