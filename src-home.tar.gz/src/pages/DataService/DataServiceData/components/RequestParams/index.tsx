import React, { Component, createContext } from 'react';
import { Select, Table, Input, message, Form } from 'sup-ui';
import Icon from '@components/Icon';
import { TableCellText } from '@components/Table';
import {
  dataApiParamPos,
  paramTypes,
  baseSignTypes,
  signTypes,
  transParamType,
  timeTypeList
} from '../../../consts/enum';
import { dataTypeReg } from '../../../consts/regexp';
import { generateEnumMap } from '../../../consts/utils';
import styles from './index.less';

const { Option } = Select;

const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;
    const dataType = record.dataType;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      if (dataIndex === 'name') {
        const val = values[dataIndex];

        if (!val) {
          message.error('参数名称不能为空!');
          return;
        }

        if (val && !/^[\w-]{1,50}$/.test(val)) {
          message.error(
            '参数名称仅支持字母、数字、下划线和连字符（-），且不能超过50个字符！'
          );
          return;
        }
      }

      //根据参数类型校验默认值
      if (dataIndex === 'defaultValue' && values[dataIndex]) {
        if (values[dataIndex].length > 50) {
          message.error('默认值的长度不能超过50个字符！');
          return;
        }

        const [reg, format] = dataTypeReg(dataType);
        if (!reg.test(values[dataIndex])) {
          message.error(`默认值的类型与参数类型不一致，格式：${format}！`);
          return;
        }
      }

      if (dataIndex === 'description' && values[dataIndex]) {
        if (values[dataIndex].length > 255) {
          message.error('描述的长度不能超过255个字符！');
          return;
        }
      }

      handleSave(dataIndex, { ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;
    const hasErr = dataIndex === 'name' && !record.name;
    const disable = dataIndex === 'defaultValue' && !!record.required;
    const isPageParam = dataIndex === 'name' && record.fieldName === '-';

    if (isPageParam) {
      return (
        <div className={styles.cellWrap}>
          <TableCellText text={record[dataIndex]} />
        </div>
      );
    }

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={`${styles['editable-cell-value-wrap']} ${
          hasErr ? styles.error : ''
        } ${disable ? styles.disable : ''}`}
        onClick={() => {
          if (!disable) {
            this.toggleEdit();
          }
        }}
      >
        {record[dataIndex] ? (
          <TableCellText text={record[dataIndex]} />
        ) : (
          <span style={{ color: 'rgba(53, 64, 82, 0.5)', fontSize: '14px' }}>
            请输入
          </span>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  id: any;
  mode: any; //0向导模式 1sql模式
  dataSource: any[];
}
interface IState {
  list: any[];
}

class RequestParams extends Component<IProps, IState> {
  public i = 0;
  public readonly tableRef: any;
  public readonly signMap: any;
  public constructor(props: IProps) {
    super(props);
    const { dataSource } = props;
    const temp = _.map(dataSource, (item: any, i: number) => ({
      key: i,
      ...item
    }));

    this.state = {
      list: temp
    };
    //初始化table key
    this.i = dataSource.length;
    this.tableRef = React.createRef();
    this.signMap = generateEnumMap(baseSignTypes);
  }

  public getColumns = (): any[] => {
    const { mode } = this.props;

    return [
      {
        title: '字段名',
        width: 80,
        dataIndex: 'fieldName',
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      },
      {
        title: '参数名称',
        width: 80,
        dataIndex: 'name',
        className: 'ellipsis-hide',
        editable: mode === 0,
        ...(mode === 1 && {
          render: (text: any) => <TableCellText text={text} />
        })
      },
      {
        title: '参数位置',
        width: 110,
        dataIndex: 'location',
        className: 'ellipsis-hide',
        render: (value: any, record: any): any => {
          const { fieldName } = record;
          const isPageParam = fieldName === '-';

          return (
            <Select
              value={value}
              placeholder="-请选择-"
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'location', val)
              }
            >
              {dataApiParamPos.map((item: any) => (
                <Option
                  value={item.key}
                  key={item.key}
                  disabled={isPageParam && item.key === 'PATH'}
                >
                  {item.showName}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '参数类型',
        width: mode === 0 ? 90 : 110,
        dataIndex: 'dataType',
        className: 'ellipsis-hide',
        render: (value: any, record: any): any => {
          if (mode === 0) {
            return <TableCellText text={value} />;
          }

          return (
            <Select
              value={value}
              disabled={mode === 0}
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'dataType', val)
              }
            >
              {paramTypes.map((item: any) => (
                <Option value={item.key} key={item.key}>
                  {item.showName}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '必填',
        width: 75,
        dataIndex: 'required',
        className: 'ellipsis-hide',
        render: (value: any, record: any): any => {
          const { location } = record;

          return (
            <Select
              value={value}
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'required', val)
              }
            >
              <Option value={1}>是</Option>
              <Option value={0} disabled={location === 'PATH'}>
                否
              </Option>
            </Select>
          );
        }
      },
      {
        title: '符号',
        width: mode === 1 ? 80 : 100,
        dataIndex: 'operator',
        className: 'ellipsis-hide',
        render: (value: any, record: any): any => {
          const { dataType, originDataType = '' } = record;

          if (mode === 1) {
            return <TableCellText text={this.signMap[value]} />;
          }

          let signs = signTypes(dataType);

          //时间类型字段符号取默认值
          if (
            originDataType &&
            _.includes(timeTypeList, originDataType.toUpperCase())
          ) {
            signs = signTypes('');
          }

          return (
            <Select
              value={value}
              disabled={mode === 1}
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'operator', val)
              }
            >
              {signs.map((item: any) => (
                <Option value={item.key} key={item.key}>
                  {item.showName}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '默认值',
        width: 85,
        dataIndex: 'defaultValue',
        editable: true
      },
      {
        title: '描述',
        width: 'auto',
        dataIndex: 'description',
        editable: true
      },
      mode === 0 && {
        title: '操作',
        width: 50,
        align: 'center',
        render: (_value: any, record: any) => {
          const { fieldName } = record;

          //分页参数不允许删除
          if (fieldName === '-') {
            return null;
          }

          return (
            <div style={{ height: '30px', padding: '5px 0' }}>
              <Icon
                type="remove"
                width={22}
                onClick={() => this.handleRemoveItems([record.key])}
              />
            </div>
          );
        }
      }
    ].filter(Boolean);
  };

  public handleAddItem = (fields: any) => {
    const { list } = this.state;
    const arr = _.map(
      fields,
      ({
        columnName,
        paramName,
        dataType,
        namespace,
        required = 1,
        operator = '=',
        defaultValue,
        description
      }) => ({
        key: this.i++,
        fieldName: columnName,
        name: paramName || columnName,
        namespace,
        location: 'QUERY',
        dataType: transParamType(dataType),
        originDataType: dataType,
        required,
        operator,
        defaultValue,
        description
      })
    );

    this.setState(
      {
        list: list.concat(arr)
      },
      () => {
        this.scrollToBottom(this.tableRef.current);
      }
    );
  };

  public scrollToBottom = (parentNode: any) => {
    const targetNode = parentNode.querySelector('.sup-table-body');
    const lastNode = parentNode.querySelector('.sup-table-tbody').lastChild;

    if (!lastNode) {
      return;
    }

    const top = lastNode.offsetTop;

    targetNode.scrollTo({
      top,
      behavior: 'smooth'
    });
  };

  public handleCellSave = (dataIndex: string, row: any) => {
    this.handleValueChange(row.key, dataIndex, row[dataIndex]);
  };

  public handleValueChange = (key: number, name: string, value: any): void => {
    const { list } = this.state;
    const temp = _.cloneDeep(list);
    const target = _.find(temp, ['key', key]);

    target[name] = value;

    if (name === 'dataType' || name === 'required') {
      //重置默认值
      target['defaultValue'] = undefined;
    }

    //PATH参数必填
    if (name === 'location' && value === 'PATH') {
      target['required'] = 1;
      target['defaultValue'] = undefined;
    }

    this.setState({
      list: temp
    });
  };

  //移除指定的fieldName
  public handleRemoveTargetField = (names: any[]) => {
    const { list } = this.state;
    const keys: any = [];

    _.forEach(names, name => {
      keys.push(..._.map(_.filter(list, ['fieldName', name]), 'key'));
    });

    this.handleRemoveItems(keys);
  };

  private handleRemoveItems = (keys: any) => {
    const { list } = this.state;
    const remainList = _.filter(list, item => !_.includes(keys, item.key));

    this.setState({
      list: remainList
    });
  };

  public validateDatas = () => {
    //校验，拼装数据
    const { list } = this.state;
    const hasError = _.find(list, data => !data.name);

    if (hasError) {
      message.error('参数名称不能为空!');
      return;
    }

    //参数名称不能重复
    if (list.length) {
      const uniqArr = _.uniqBy(list, 'name');

      if (uniqArr.length < list.length) {
        message.error('请求参数名称不能重复!');
        return;
      }
    }

    const temp = _.find(
      list,
      ({ required, defaultValue }) => !required && !defaultValue
    );

    if (temp) {
      message.error('请求参数非必填字段必须有默认值!');
      return;
    }

    return _.map(list, data => ({
      fieldName: data.fieldName,
      name: data.name,
      namespace: data.namespace,
      location: data.location,
      dataType: data.dataType,
      originDataType: data.originDataType,
      required: data.required,
      operator: data.operator,
      defaultValue: data.defaultValue || '',
      description: data.description || ''
    }));
  };

  public getOriginDatas = () => {
    return this.state.list;
  };

  public handleSetupList = (list: any[]) => {
    this.setState({
      list
    });
  };

  public handleResetList = () => {
    this.setState({
      list: []
    });
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { id, mode } = this.props;

    if (prevProps.mode === mode && !_.isEqual(prevProps.id, id)) {
      this.handleResetList();
    }
  }

  public render() {
    const { list } = this.state;
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });

    return (
      <div className={styles.params} ref={this.tableRef}>
        <Table
          size="small"
          rowKey="key"
          components={{
            body: {
              row: EditableFormRow,
              cell: EditableCell
            }
          }}
          columns={columns}
          dataSource={list}
          scroll={{ y: 182 }}
          pagination={false}
        />
      </div>
    );
  }
}

export default RequestParams;
