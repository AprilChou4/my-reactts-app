import React, { Component, createRef } from 'react';
import { message } from 'sup-ui';
import SqlEditor from './SqlEditor';
import Tips from './Tips';
import styles from './index.less';

interface IProps {
  value: any;
  onParse: any;
  onFormat: any;
  onChange: any;
}

interface IState {
  visible: boolean;
}

class SqlArea extends Component<IProps, IState> {
  private readonly sqlRef: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      visible: false
    };
    this.sqlRef = createRef();
  }

  public handleFormat = () => {
    const { onFormat } = this.props;

    if (this.sqlRef) {
      const value = this.sqlRef.current.getValue();

      onFormat(value, (sql: string) => {
        this.sqlRef.current.setValue(sql);
      });
    }
  };

  public handleParseSql = () => {
    const { onParse } = this.props;

    if (this.sqlRef) {
      const value = this.sqlRef.current.getValue();

      if (!value) {
        message.error('查询SQL不能为空!');
        return;
      }

      onParse(value);
    }
  };

  public getSqlValue = () => {
    if (this.sqlRef) {
      return this.sqlRef.current.getValue();
    }

    return '';
  };

  public handleVisibleChange = (visible: boolean) => {
    this.setState({
      visible
    });
  };

  public render() {
    const { value, onChange } = this.props;
    const { visible } = this.state;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <h4>编写查询SQL</h4>
          <div className={styles.operator}>
            <a onClick={() => this.handleVisibleChange(true)}>SQL编写提示</a>
            <div className={styles.btn} onClick={this.handleFormat}>
              格式化
            </div>
            <div className={styles.btn} onClick={this.handleParseSql}>
              解析
            </div>
          </div>
        </div>
        <div className={styles.cont}>
          <SqlEditor ref={this.sqlRef} value={value} onChange={onChange} />
        </div>
        {visible && (
          <Tips visible={visible} onVisibleChange={this.handleVisibleChange} />
        )}
      </div>
    );
  }
}

export default SqlArea;
