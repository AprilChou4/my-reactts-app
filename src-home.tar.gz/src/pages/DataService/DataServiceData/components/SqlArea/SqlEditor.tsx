import React, { Component } from 'react';
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/monokai.css';
import 'codemirror/mode/sql/sql';
import 'codemirror/addon/hint/show-hint.css';
import 'codemirror/addon/hint/show-hint';
import 'codemirror/addon/hint/sql-hint';
import 'codemirror/addon/display/autorefresh';
import CodeMirror from 'codemirror';

interface IProps {
  value: string;
  onChange: any;
}

class SqlEditor extends Component<IProps> {
  private sqlRef: any;
  private CodeMirrorEditor: any;
  public constructor(props: IProps) {
    super(props);
    this.sqlRef = null;
  }

  public completeIfInTag = (cm: any) => {
    return this.completeAfter(cm, function () {
      const tok = cm.getTokenAt(cm.getCursor());
      const reg = /['"]/;
      if (
        tok.type === 'string' &&
        (!reg.test(tok.string.charAt(tok.string.length - 1)) ||
          tok.string.length === 1)
      )
        return false;
      const inner = CodeMirror.innerMode(cm.getMode(), tok.state).state;
      return inner.tagName;
    });
  };

  public completeAfter = (cm: any, pred: any) => {
    if (!pred || pred())
      setTimeout(function () {
        if (!cm.state.completionActive)
          cm.showHint({
            completeSingle: false
          });
      }, 100);
    return CodeMirror.Pass;
  };

  public componentDidMount() {
    const { value } = this.props;

    this.CodeMirrorEditor = CodeMirror.fromTextArea(this.sqlRef, {
      mode: 'text/x-mysql',
      indentWithTabs: true,
      smartIndent: true,
      lineNumbers: true,
      matchBrackets: true,
      autoRefresh: true, //初始化由hidden到visible
      extraKeys: {
        "'a'": this.completeAfter,
        "'b'": this.completeAfter,
        "'c'": this.completeAfter,
        "'d'": this.completeAfter,
        "'e'": this.completeAfter,
        "'f'": this.completeAfter,
        "'g'": this.completeAfter,
        "'h'": this.completeAfter,
        "'i'": this.completeAfter,
        "'j'": this.completeAfter,
        "'k'": this.completeAfter,
        "'l'": this.completeAfter,
        "'m'": this.completeAfter,
        "'n'": this.completeAfter,
        "'o'": this.completeAfter,
        "'p'": this.completeAfter,
        "'q'": this.completeAfter,
        "'r'": this.completeAfter,
        "'s'": this.completeAfter,
        "'t'": this.completeAfter,
        "'u'": this.completeAfter,
        "'v'": this.completeAfter,
        "'w'": this.completeAfter,
        "'x'": this.completeAfter,
        "'y'": this.completeAfter,
        "'z'": this.completeAfter,
        "'.'": this.completeAfter,
        "'='": this.completeIfInTag,
        Ctrl: 'autocomplete',
        Tab(cm: any) {
          const spaces = Array(cm.getOption('indentUnit') + 1).join(' ');
          cm.replaceSelection(spaces);
        }
      },
      hintOptions: {
        tables: {
          users: ['name', 'score', 'birthDate'],
          countries: ['name', 'population', 'size']
        }
      }
    });
    this.CodeMirrorEditor.setSize(`100%`, `100%`);
    this.CodeMirrorEditor.setValue(value);
    //事件触发后执行事件
    this.CodeMirrorEditor.on('change', this.onChange);
  }

  public onChange = () => {
    this.props.onChange();
  };

  public getValue = () => {
    return this.CodeMirrorEditor.getValue();
  };

  public setValue = (value: string) => {
    this.CodeMirrorEditor.setValue(value);
  };

  public render() {
    return (
      <textarea
        ref={ref => {
          this.sqlRef = ref;
        }}
      />
    );
  }
}

export default SqlEditor;
