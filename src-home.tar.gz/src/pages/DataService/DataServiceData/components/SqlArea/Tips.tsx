import React, { Component } from 'react';
import DialogModal from '@components/Modal/Dialog';
import styles from './index.less';

interface IProps {
  visible: boolean;
  onVisibleChange: any;
}

interface IState {}

class Tips extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { visible, onVisibleChange } = this.props;

    return (
      <DialogModal
        width={580}
        title="编写提示"
        visible={visible}
        maskClosable={true}
        bodyStyle={{ padding: 0 }}
        onCancel={() => onVisibleChange(false)}
        wrapClassName={styles.modalContainer}
        footer={null}
      >
        <div className={styles.tips}>
          <h3>示例语句：</h3>
          <section>
            <h4>SELECT</h4>
            <ul>
              <li>
                <span>sales time</span>
                <p>SELECT查询的字段即为API返回参数。</p>
              </li>
              <li>
                <span>addr as address</span>
                <p>如果定义了字段别名，则返回参数名称为字段别名。</p>
              </li>
              <li>
                <span>sum(value) as total_amount</span>
                <p>支持SQL中sum、count等函数。</p>
              </li>
            </ul>
          </section>
          <section>
            <h4>FROM</h4>
            <ul>
              <li>
                <span>table_user</span>
              </li>
            </ul>
          </section>
          <section>
            <h4>WHERE</h4>
            <ul>
              <li>
                {/* eslint-disable-next-line no-template-curly-in-string */}
                <span>{'user_id = ${uid};'}</span>
                <p>
                  {/* eslint-disable-next-line no-template-curly-in-string */}
                  {'WHERE条件中的参数为API请求参数，参数格式必须为${参数名}。'}
                </p>
              </li>
            </ul>
          </section>
          <div className={styles.reminder}>
            <h5>注意：</h5>
            <ul>
              <li>1. 只支持输入一条完整的语句；</li>
              <li>2. 支持部分子语句查询；</li>
              <li>
                {
                  '3. Oracle数据源查询时，自定义SQL中的表名大小写需与源表保持一致。且查询其他用户下的表时，需要按照user."table"格式填写，表名需带双引号；'
                }
              </li>
              <li>
                4.
                编写完成后，可对参数信息进行设置，填写参数说明、打开分页查询按钮等，参数设置完毕后可进入测试环节；
              </li>
              <li>
                {
                  '5. WHERE条件值中的比较符号支持=、> 、>=、<、<=、!=，多个条件只能为AND关系；'
                }
              </li>
            </ul>
          </div>
        </div>
      </DialogModal>
    );
  }
}

export default Tips;
