import React from 'react';
import Exception from 'components/Exception';

const Error = () => <Exception type="500" />;
export default Error;
