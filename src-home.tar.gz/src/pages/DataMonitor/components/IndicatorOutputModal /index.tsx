/**
 * @description 指标输出弹窗
 * @author zhouxiaojuan
 */
import React, { FC, useEffect, useState } from 'react';
import { Spin, Tabs, message, DatePicker } from 'sup-ui';
import moment from 'moment';
import DialogModal from '@components/Modal/Dialog';
import SyncDetailTable from './SyncDetailTable';
import { getDisabledDate } from '../../const/utils';
import { queryOutputStat } from '../../monitor.service';
import StatList from '../StatList';
import styles from './index.less';

const { TabPane } = Tabs;

interface IProps {
  updateVisible: (v: boolean) => void;
}

const IndicatorOutputModal: FC<IProps> = (props: IProps) => {
  const { updateVisible } = props;
  const [loading, setloading] = useState<boolean>(false);
  const [tabKey, setTabKey] = useState<string>('1');
  const [date, setDate] = useState<string>(moment().format('YYYY-MM-DD'));

  const [statData, setStatData] = useState<any[]>([]);

  const handleCancel = () => {
    updateVisible(false);
  };

  // 获取统计数据
  const getStatList = async (params?: any) => {
    const allParams = {
      date,
      ...params
    };
    setloading(true);
    const res = await queryOutputStat(allParams);

    if (res.code === 200) {
      const {
        taskTotal,
        taskSuccess,
        taskFail,
        idcTotal,
        idcSuccess,
        idcFail
      } = res.data || {};
      const data = [
        {
          count: taskTotal,
          title: '执行任务总次数',
          unit: '次'
        },
        {
          count: taskSuccess,
          title: '成功次数',
          unit: '次'
        },
        {
          count: taskFail,
          title: '失败次数',
          unit: '次'
        },
        {
          count: idcTotal,
          title: '应同步的指标数量',
          unit: '条'
        },
        {
          count: idcSuccess,
          title: '同步成功指标数量',
          unit: '条'
        },
        {
          count: idcFail,
          title: '同步失败指标数量',
          unit: '条'
        }
      ];
      setStatData(data);
    } else {
      message.error(res.message);
    }
    setloading(false);
  };

  useEffect(() => {
    if (tabKey === '1') {
      getStatList();
    }
  }, [tabKey]);

  const handleDateChange = (_date: any, dateString: string) => {
    setDate(dateString);
    getStatList({
      date: dateString
    });
  };

  const onChangeTab = (key: string) => {
    setTabKey(key);
  };

  return (
    <DialogModal
      width={826}
      title="数据输出任务"
      centered
      visible
      cancelText="关闭"
      okButtonProps={{ style: { display: 'none' } }}
      onCancel={handleCancel}
      className={styles.indicatorOutputModal}
    >
      <Tabs activeKey={tabKey} onChange={onChangeTab}>
        <TabPane tab="任务执行统计" key="1">
          {tabKey === '1' ? (
            <Spin spinning={!!loading}>
              <div className={styles.statModule}>
                <div className={styles.header}>
                  <DatePicker
                    style={{ width: 180 }}
                    allowClear={false}
                    disabledDate={getDisabledDate}
                    onChange={handleDateChange}
                    value={moment(date)}
                  />
                </div>
                <StatList list={statData} column={3} />
              </div>
            </Spin>
          ) : null}
        </TabPane>
        <TabPane tab="数据同步详情" key="2">
          {tabKey === '2' ? (
            <SyncDetailTable setDate={setDate} date={date} />
          ) : null}
        </TabPane>
      </Tabs>
    </DialogModal>
  );
};
export default IndicatorOutputModal;
