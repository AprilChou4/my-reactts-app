/**
 * @description 通用card
 * @author zhouxiaojuan
 */
import React, { FC, ReactNode, useRef } from 'react';
import classnames from 'classnames';
import useDotLine from '../../hooks/useDotLine';
import styles from './index.less';
interface LineStyle {
  leftStyle?: React.CSSProperties;
  rightStyle?: React.CSSProperties;
  topStyle?: React.CSSProperties;
  bottomStyle?: React.CSSProperties;
}
interface IProps {
  text?: string | ReactNode;
  className?: string;
  style?: React.CSSProperties;
  status?: 'success' | 'error';
  // 背景图标
  image?: any;
  isCursor?: boolean;
  // 放向
  direction?: any;
  // 线条样式
  lineStyles?: LineStyle;
  onClick?: () => void;
}
const defaultDirection = {
  left: false,
  right: false,
  top: false,
  bottom: false
};
const MonitorCard: FC<IProps> = (props: IProps) => {
  const {
    text,
    className,
    status,
    style,
    image,
    direction,
    isCursor,
    lineStyles,
    ...rest
  } = props;
  const finalDirection = {
    ...defaultDirection,
    ...direction
  };
  const { left, right, bottom, top } = finalDirection;
  const { leftStyle, rightStyle, topStyle, bottomStyle } = lineStyles || {};

  const lLineRef = useRef(null);
  const rLineRef = useRef(null);
  const tLineRef = useRef(null);
  const bLineRef = useRef(null);
  const lineDirection = {
    left: top,
    right: bottom,
    top: left,
    bottom: right
  };
  useDotLine(lLineRef, lineDirection);
  useDotLine(rLineRef, lineDirection);
  useDotLine(tLineRef, lineDirection);
  useDotLine(bLineRef, lineDirection);

  return (
    <div className={classnames(styles.monitorCardWrap, className)}>
      <div
        className={classnames(
          styles.monitorCard,
          isCursor && styles.monitorCardPointer,
          'cardItem'
        )}
        style={{
          backgroundImage: `url(${image})`,
          ...style
        }}
        {...rest}
      >
        {text}
        <div
          className={classnames(styles.status, styles[`${status || 'none'}`])}
        />
      </div>
      {left && (
        <div
          style={leftStyle}
          className={classnames(styles.line, styles.lineLeft)}
          ref={lLineRef}
        />
      )}
      {right && (
        <div
          className={classnames(styles.line, styles.lineRight)}
          ref={rLineRef}
        />
      )}
      {top && (
        <div
          className={classnames(styles.line, styles.lineTop)}
          ref={tLineRef}
        />
      )}
      {bottom && (
        <div
          className={classnames(styles.line, styles.lineBottom)}
          ref={bLineRef}
        />
      )}
    </div>
  );
};
MonitorCard.defaultProps = {
  isCursor: false
};
export default MonitorCard;
