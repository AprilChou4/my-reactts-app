/**
 * @description 数据源详情弹窗
 * @author zhouxiaojuan
 */
import React, { FC, useEffect, useState } from 'react';
import { observer } from 'mobx-react';
import { Descriptions, message, Spin } from 'sup-ui';
import Icon from '@components/Icon';
import DialogModal from '@components/Modal/Dialog';
import { connectTest } from '../../monitor.service';
import styles from './index.less';

interface IProps {
  updateSourceDetailVisible: (v: boolean, record?: any) => void;
  sourceDetail: any;
  // 更新列表
  updateSourceList: () => void;
}

const SourceDetailModal: FC<IProps> = (props: IProps) => {
  const { updateSourceDetailVisible, sourceDetail, updateSourceList } = props;
  const handleCancel = () => {
    updateSourceDetailVisible(false);
  };
  const { resourceId, resourceName, subCatalog, connect } = sourceDetail;
  const [status, setStatus] = useState<number>(0);
  const [loading, setloading] = useState<boolean>(false);
  useEffect(() => {
    setStatus(connect);
  }, [connect]);

  // 刷新
  const refresh = async () => {
    setloading(true);
    const res = await connectTest({ resourceId });
    if (res.code === 200) {
      if (status !== res.data?.connect) {
        updateSourceList();
      }
      setStatus(res.data?.connect);
    } else {
      message.error(res.message);
    }
    setloading(false);
  };

  return (
    <DialogModal
      width={460}
      title="数据源详情"
      centered
      visible
      cancelText="关闭"
      okButtonProps={{ style: { display: 'none' } }}
      onCancel={handleCancel}
      className={styles.sourceDetailModal}
    >
      <Spin spinning={loading}>
        <Descriptions column={1}>
          <Descriptions.Item label="数据源名称">
            <span title={resourceName}>{resourceName}</span>
          </Descriptions.Item>
          <Descriptions.Item label="数据源类型">{subCatalog}</Descriptions.Item>
          <Descriptions.Item label="连接状态">
            <span>
              {status === 1 ? (
                <>
                  <Icon type="success" width="12px" height="12px" />
                  <span>&nbsp;正常</span>
                </>
              ) : (
                <>
                  <Icon type="error" width="11px" height="11px" />
                  <span style={{ color: 'red' }}>&nbsp;异常</span>
                </>
              )}
              <Icon
                type="reload"
                fill="#0075db"
                onClick={refresh}
                className={styles.refreshIcon}
              />
            </span>
          </Descriptions.Item>
        </Descriptions>
      </Spin>
    </DialogModal>
  );
};
export default observer(SourceDetailModal);
