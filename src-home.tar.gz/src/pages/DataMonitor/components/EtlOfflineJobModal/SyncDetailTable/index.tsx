// 异常数据明细
import React, { FC, useEffect, useMemo, useState } from 'react';
import { Table, message, DatePicker, Input } from 'sup-ui';
import { observer } from 'mobx-react';
import classnames from 'classnames';
import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import CustomPaging from '@components/CustomPaging';
import {
  formatTime,
  getDisabledDate,
  transferTimeToSeconds,
  transferCount
} from '../../../const/utils';
import { offlineStatusMap } from '../../../const/enum';

import { queryEtlOfflineDetail } from '../../../monitor.service';
import styles from './index.less';
import moment from 'moment';

interface IProps {
  setDate: (data: any) => void;
  date: any;
}

const orderMap: any = {
  ascend: 'ASC',
  descend: 'DESC'
};
const SyncDetailTable: FC<IProps> = (props: IProps) => {
  const { date, setDate } = props;
  const [loading, setLoading] = useState<boolean>(false);
  const [pageData, setPageData] = useState<any>({
    orderBy: {},
    // {
    //   name: 'executeTime',
    //   order: 'ASC' // 排序 ASC  DESC
    // },
    syncList: [],
    pageSize: 20,
    pageNum: 1,
    total: 0
  });
  // const [date, setDate] = useState<string>(moment().format('YYYY-MM-DD'));
  const [searchValue, setSearchValue] = useState<string | undefined>(undefined);

  const { orderBy, syncList, pageSize, pageNum, total } = pageData;

  const updatePageData = (params: any) => {
    setPageData({
      ...pageData,
      ...params
    });
  };

  useEffect(() => {
    getSyncList();
  }, []);

  const getSyncList = async (params: any = {}) => {
    const [startTime, endTime] = formatTime(date);
    const allParams = {
      startTime,
      endTime,
      orderBy,
      name: searchValue,
      pageSize,
      pageNum,
      ...params
    };
    setLoading(true);
    const res = await queryEtlOfflineDetail(allParams);
    if (res.code === 200) {
      const { list, pagination } = res.data || {};
      updatePageData({
        syncList: list || [],
        pageSize: allParams.pageSize,
        pageNum: allParams.pageNum,
        total: pagination?.total || 0,
        orderBy: allParams.orderBy
      });
      setSearchValue(allParams.name);
      setLoading(false);
    } else {
      message.error(res.message);
      setLoading(false);
    }
  };

  const handleTableChange = (pagination: any, _filters: any, sorter: any) => {
    //页码
    const { current, pageSize: pSize } = pagination;
    const { field, order: sortOrder } = sorter;
    getSyncList({
      orderBy: {
        name: field,
        order: orderMap[sortOrder]
      },
      pageNum: current,
      pageSize: pSize
    });
  };

  const handleDateChange = (_date: any, dateString: string) => {
    setDate(dateString);
    const [startTime, endTime] = formatTime(dateString);
    getSyncList({
      startTime,
      endTime,
      pageNum: 1
    });
  };

  const getDebounceList = _.debounce(getSyncList, 300);

  const handleSearch = (e: any) => {
    const { value } = e.target;
    getDebounceList({ name: value, pageNum: 1 });
  };

  const getColumns = () => {
    const columns = [
      {
        title: '任务名称',
        dataIndex: 'jobName',
        width: 160,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '执行时间',
        dataIndex: 'executeTime',
        width: 160,
        sorter: true,
        className: 'ellipsis-hide',
        render: (text: string) => {
          return (
            <TableCellText text={moment(text).format('YYYY-MM-DD HH:mm:ss')} />
          );
        }
      },

      {
        title: '执行时长',
        dataIndex: 'processTime',
        className: 'ellipsis-hide',
        width: 90,
        render: (text: any) => {
          return <TableCellText text={transferTimeToSeconds(text)} />;
        }
      },
      {
        title: '当前状态',
        dataIndex: 'status',
        className: 'ellipsis-hide',
        width: 100,
        render: (text: any) => {
          return <TableCellText text={offlineStatusMap[text]} />;
        }
      },
      {
        title: '执行结果',
        dataIndex: 'execCondition',
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '成功数量',
        dataIndex: 'successCount',
        className: 'ellipsis-hide',
        width: 90,
        render: (text: any) => {
          return <TableCellText text={transferCount(text)} />;
        }
      },
      {
        title: '失败数量',
        dataIndex: 'failCount',
        className: 'ellipsis-hide',
        width: 90,
        render: (text: any) => {
          return <TableCellText text={transferCount(text)} />;
        }
      }
    ];
    return columns;
  };

  const columns = useMemo(getColumns, []);
  return (
    <div
      className={classnames('mp-table-gray mp-table-grow', styles.tableWrapper)}
    >
      <div className={styles.search}>
        <DatePicker
          style={{ width: 180 }}
          allowClear={false}
          disabledDate={getDisabledDate}
          onChange={handleDateChange}
          value={moment(date)}
        />
        {/* <KeywordSearch
          placeholder="输入名称搜索"
          value={searchValue}
          prefix={<Icon type="search" />}
          suffix={
            searchValue && (
              <Icon
                type="circle-close"
                size="small"
                onClick={() => handleSearch()}
              />
            )
          }
          onSearch={handleSearch}
        /> */}
        <Input
          placeholder="输入名称搜索"
          prefix={<Icon type="search" />}
          style={{ width: 180 }}
          onChange={handleSearch}
          allowClear
        />
      </div>
      <Table
        loading={loading}
        columns={columns as any[]}
        dataSource={syncList}
        rowKey={(_record, index) => `${index + 1}`}
        onChange={handleTableChange}
        pagination={{
          current: pageNum,
          pageSize,
          total,
          showTotal: t => `共${t}条`,
          itemRender: CustomPaging,
          pageSizeOptions: ['20', '50', '100'],
          showSizeChanger: true,
          showQuickJumper: true
        }}
        scroll={{
          y: 382
        }}
      />
    </div>
  );
};
export default observer(SyncDetailTable);
