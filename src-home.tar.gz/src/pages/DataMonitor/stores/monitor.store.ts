import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { queryDBStatus, querySourceList } from '../monitor.service';

class MonitorStore {
  @observable public loading = false; // 页面loading
  @observable public sourceList: any[] = []; // 数据源列表
  @observable public dwMonitorVisible = false; // 数据源详情弹窗
  @observable public dwJobVisible = false; // Flink dw job弹窗
  @observable public etlRealtimeJobVisible = false; // etl实时 job弹窗
  @observable public etlOfflineJobVisible = false; // etl离线 job弹窗
  @observable public jobModelLevel = 0; // Flink modelLevel model层级，ods/0, dwd/1
  @observable public dbStatus = 0; // db状态 0=异常, 1=正常
  @observable public indicatorOutputVisible = false; // 指标输出弹窗

  public constructor() {
    this.initData();
  }

  /**
   * 更新数据源弹窗是否显示
   * @param v
   */
  @action.bound
  public async initData() {
    this.getDatasourceList();
    this.queryDBStatus();
  }
  /**
   * 获取数据源列表
   * @param v
   */
  @action.bound
  public async getDatasourceList() {
    this.loading = true;
    const res = await querySourceList();

    runInAction(() => {
      this.loading = false;
      const { real, offline } = res.data || {};
      // 进行分类
      const listData = [
        {
          title: '实时同步',
          key: '0',
          list: real || []
        },
        {
          title: '离线同步',
          key: '1',
          list: offline || []
        }
      ];
      if (res.code === 200) {
        this.sourceList = listData;
      } else {
        this.sourceList = listData;
        message.error(res.message);
      }
    });
  }

  /**
   * 更新数据源弹窗是否显示
   * @param v
   */
  @action.bound
  public async queryDBStatus(type = 'doris') {
    this.loading = true;
    const res = await queryDBStatus(type);
    runInAction(() => {
      this.loading = false;
      if (res.code === 200) {
        this.dbStatus = res.data.usable || 0;
      } else {
        message.error(res.message);
      }
    });
  }

  /**
   * 更新数据仓库监控弹窗是否显示
   * @param v
   */
  @action.bound
  public updateDwMonitorVisible(v: boolean) {
    this.dwMonitorVisible = v;
  }

  /**
   * 更新Flink Dw Job弹窗是否显示
   * @param v 是否显示
   * @param v
   */
  @action.bound
  public updateDwJobVisible(v: boolean) {
    this.dwJobVisible = v;
  }

  /**
   * 更新job类型
   * @param level
   */
  @action.bound
  public updateJobModelLevel(level: number) {
    this.jobModelLevel = level;
  }

  /**
   * 更新Etl etl实时是否显示
   * @param v 是否显示
   * @param v
   */
  @action.bound
  public updateEtlRealtimeJobVisible(v: boolean) {
    this.etlRealtimeJobVisible = v;
  }

  /**
   * 更新Etl etl离线弹窗是否显示
   * @param v 是否显示
   * @param v
   */
  @action.bound
  public updateEtlOfflineJobVisible(v: boolean) {
    this.etlOfflineJobVisible = v;
  }

  /**
   * 更新Etl 指标输出弹窗是否显示
   * @param v 是否显示
   * @param v
   */
  @action.bound
  public updateIndicatorOutputVisible(v: boolean) {
    this.indicatorOutputVisible = v;
  }
}

export default MonitorStore;
