import http from '@services/http';
import { MODEL_URL, ETL_URL, RESOURCE_URL } from '@config/env';

// 获取数仓数据源链接列表
export function querySourceList(): Promise<any> {
  return http.get(`${ETL_URL}/dataflow/monitor`);
}

//cdc 实时任务查询 —— 获取数据传输统计
export function queryCdcRealStat(params?: any): Promise<any> {
  return http.get(`${ETL_URL}/cdc/query/task/statistics`, params);
}

// cdc 实时任务查询 —— 获取数据同步详情
export function queryCdcRealDetail(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/query/task/status`, params);
}

//etl 离线任务查询 —— 获取数据传输统计
export function queryEtlOfflineStat(params: any): Promise<any> {
  return http.post(`${ETL_URL}/dataflow/monitor/execute/job`, params);
}

// etl 离线任务查询 —— 获取数据同步详情
export function queryEtlOfflineDetail(params: any): Promise<any> {
  return http.post(`${ETL_URL}/dataflow/monitor/offline/job`, params);
}

// etl 链接测试
// export function connectTest(params: any): Promise<any> {
//   return http.post(`${ETL_URL}/dataflow/monitor/connect/test`, params);
// }

// etl 链接测试新
export function connectTest(params: any): Promise<any> {
  return http.post(`${RESOURCE_URL}/connect/test`, params);
}

//查询queryDBMetric 数据仓库监控
export function queryDBMetric(dbType: string): Promise<any> {
  return http.get(`${MODEL_URL}/metric/queryDBMetric/${dbType}`);
}

// 查询状态
export function queryDBStatus(dbType: string): Promise<any> {
  return http.get(`${MODEL_URL}/metric/queryDBStatus/${dbType}`);
}

//查询queryDBMetric
export function queryFailedDetail(size: number): Promise<any> {
  return http.get(`${MODEL_URL}/metric/queryFailedDetail/${size}`);
}
//查询指标信息--数据传输统计
export function queryMetrics(params: any): Promise<any> {
  return http.get(`${MODEL_URL}/metric/queryMetrics`, params);
}

//数据服务输出统计信息
export function queryOutputStat(params: any): Promise<any> {
  return http.get(`${MODEL_URL}/output/task/statistics`, params);
}
//数据服务输出详情
export function queryOutputDetail(params: any): Promise<any> {
  return http.get(`${MODEL_URL}/output/task/detail`, params);
}
