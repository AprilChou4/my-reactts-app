import moment from 'moment';
/**
 * 获取比特单位 初始单位为B
 * 1KB=1024B  1MB=1024KB 1GB=1024MB 1TB=1024GB
 * @param bytes
 * @returns [count,unit]
 */
export const getByteUnit = (bytes: number): [number, string] => {
  if (_.isNil(bytes) || bytes === 0) return [0, 'B'];
  const k = 1024, // or 1024
    sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
    i = Math.floor(Math.log(bytes) / Math.log(k));
  const count = (bytes / Math.pow(k, i)).toPrecision(3);
  return [Number(count), sizes[i]];
};

// 数量转换为万/亿
export const transferCount = (
  count: number,
  unitName = ''
): [number, string] => {
  let finalCount = 0;
  let unit = '';
  if (count < 10000) {
    finalCount = count;
    unit = unitName;
  } else if (count >= 10000 && count < 100000000) {
    finalCount = Math.floor(count / 10000);
    unit = `万${unitName}`;
  } else {
    finalCount = Math.floor(count / 100000000);
    unit = `亿${unitName}`;
  }
  return [finalCount, unit];
};

// 时间转换为毫秒
export const formatTime = (d: string) => {
  const start = moment(`${d} 00:00:00`).format('x');
  const end = moment(`${d} 23:59:29`).format('x');
  return [Number(start), Number(end)];
};

// 毫秒转换为小时 并保留两位小数
export const transferTimeToHours = (time: any) => {
  if (_.isNil(time) || time === 0) {
    return '0h';
  }
  const hour = moment.duration(time).asHours();
  return hour?.toFixed(2) + 'h';
};

// 毫秒转换为秒 并保留两位小数
export const transferTimeToSeconds = (time: any) => {
  if (_.isNil(time) || time === 0) {
    return '0s';
  }
  const seconds = moment.duration(time).asSeconds();
  return seconds?.toFixed(2) + 's';
};

// 日历禁用日期  不能大于本日
export const getDisabledDate = (current: any) => {
  return current && current > moment().endOf('day');
};
