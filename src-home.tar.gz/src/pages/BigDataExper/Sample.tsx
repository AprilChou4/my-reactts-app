import React, { Component } from 'react';
import styles from './index.less';

interface IProps {}

interface IState {}

class Sample extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    return (
      <div className={styles.container}>
        <iframe src="/static/bigdata/samples" />
      </div>
    );
  }
}

export default Sample;
