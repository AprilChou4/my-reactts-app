import React, { Fragment } from 'react';
import UpdatePwdModel from '../User/UpdatePassword/UpdatePwdModel';
import styles from './index.less';

const isETL = process.env.MODULE === 'ETL';
const isWin = process.env.SYSTEM === 'WIN';

const Home: React.FunctionComponent = () => {
  return (
    <Fragment>
      <dl className={styles.wrapper}>
        <dt className={styles.title} />
        <dd className={styles.container}>
          {`欢迎使用supOS${isETL ? '数据交换工具' : '数据中台'}，很高兴见到你!`}
        </dd>
      </dl>
      {isWin && <UpdatePwdModel />}
    </Fragment>
  );
};

export default Home;
