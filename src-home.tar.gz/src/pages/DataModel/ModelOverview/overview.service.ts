import http from '@services/http';
import { MODEL_URL } from '@config/env';

export function getOverviewData(): Promise<any> {
  return http.get(`${MODEL_URL}/overview/summary`);
}
