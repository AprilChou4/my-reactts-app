import http from '@services/http';
import { INDICATOR_URL, MODEL_URL } from '@config/env';

//获取业务板块
export function getSegmentList(): Promise<any> {
  return http.get(`${MODEL_URL}/business/segment`);
}

//获取业务板块下主题
export function getSegmentTheme(id: any): Promise<any> {
  return http.get(`${MODEL_URL}/business/theme/segment/${id}`);
}

//新增业务板块
export function createSegment(data: any): Promise<any> {
  return http.post(`${MODEL_URL}/business/segment`, data);
}

//修改业务板块
export function editSegment(id: any, data: any): Promise<any> {
  return http.put(`${MODEL_URL}/business/segment/${id}`, data);
}

//删除业务板块
export function deleteSegment(id: any): Promise<any> {
  return http.delete(`${MODEL_URL}/business/segment/${id}`);
}

//新增主题
export function createTheme(data: any): Promise<any> {
  return http.post(`${MODEL_URL}/business/theme`, data);
}

//修改主题
export function editTheme(id: any, data: any): Promise<any> {
  return http.put(`${MODEL_URL}/business/theme/${id}`, data);
}

//删除主题
export function deleteTheme(id: any): Promise<any> {
  return http.delete(`${MODEL_URL}/business/theme/${id}`);
}

//搜索主题
export function searchThemeList(params: any): Promise<any> {
  return http.get(`${MODEL_URL}/business/theme`, params);
}

//主题组排序
export function moveThemeGroup(data: any): Promise<any> {
  return http.post(`${INDICATOR_URL}/theme/group/move`, data);
}

//主题排序
export function moveThemeBase(data: any): Promise<any> {
  return http.post(`${INDICATOR_URL}/theme/base/move`, data);
}
