import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getPreviewList } from '../design.service';

class PreviewStore {
  private readonly modelId: any;
  @observable public loading = false;
  @observable public previewList: any[] = [];
  @observable public count = 0; //数量
  @observable public dynamicColumns: any[] = []; //动态列
  @observable public defaultColumnList: any[] = []; //过滤列源数据
  @observable public checkedColumns: any[] = []; //选中的列
  @observable public searchParams: any = {
    pageIndex: 1,
    pageSize: 20
  };

  public constructor(modelId: any) {
    this.modelId = modelId;
    this.getInitPreviewList();
  }

  @action.bound
  public async getInitPreviewList() {
    //初始化数据，处理动态column
    this.loading = true;

    const res = await getPreviewList(this.modelId, this.searchParams);

    runInAction(() => {
      this.loading = false;
    });

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    const {
      pagination: { total },
      heads,
      list
    } = res.data || {};

    const defaultColumns = _.map(heads, (column, index: number) => ({
      dataIndex: column.name,
      title: column.title,
      check: index < 30
    }));

    const checkedColumns = _.map(_.take(heads, 30), 'name');

    const dynamicColumns = _.map(heads, column => ({
      dataIndex: column.name,
      title: column.title,
      dataType: column.dataType,
      width: 100
    }));

    // const ts = _.map(heads, 'name');

    runInAction(() => {
      // this.previewList = _.orderBy(list, ts);
      this.previewList = list;
      this.count = total;
      this.dynamicColumns = dynamicColumns;
      this.defaultColumnList = defaultColumns;
      this.checkedColumns = checkedColumns;
    });
  }

  @action.bound
  public async getPreviewList() {
    this.loading = true;

    const res = await getPreviewList(this.modelId, this.searchParams);

    runInAction(() => {
      this.loading = false;
    });

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    const {
      pagination: { total },
      list
    } = res.data || {};

    runInAction(() => {
      this.previewList = list;
      this.count = total;
    });
  }

  @action.bound
  public updateColumns = (checkedItems: any[]) => {
    this.checkedColumns = checkedItems;
  };

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getPreviewList();
  }
}

export default PreviewStore;
