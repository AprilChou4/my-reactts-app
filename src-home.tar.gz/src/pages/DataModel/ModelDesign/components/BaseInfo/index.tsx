import React, { Component } from 'react';
import Icon from '@components/Icon';
import { Form, Input, message, Select } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import { dataGradings } from '../../../consts/enum';
import styles from './index.less';

//临时
const modelTypeMap: any = {
  2: 'DIM',
  1: 'DWD',
  3: 'DWS'
};

const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const formLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 }
};

interface IProps extends FormComponentProps {
  themeList: any;
  values: any;
  onClose: any;
  markChange: any;
}

interface IState {}

class BaseInfo extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public validateValues = () => {
    //校验，拼装数据
    const {
      form,
      values: { name }
    } = this.props;
    let result: any;

    form.validateFields((error: any, values: any) => {
      if (error) {
        message.error('基本信息有误，请检查!');
        return;
      }

      result = { ...values, name };
    });

    return result;
  };

  public render() {
    const {
      themeList,
      values,
      onClose,
      markChange,
      form: { getFieldDecorator }
    } = this.props;
    const {
      dataLevel,
      businessSegmentShowName,
      subjectDomainId,
      director,
      name,
      showName,
      description,
      modelType
    } = values;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <span className={styles.close} onClick={onClose}>
            <Icon type="close" width={24} height={24} />
          </span>
          <h3>基本信息</h3>
        </div>
        <div className={styles.content}>
          <Form {...formLayout} labelAlign="left">
            <FormItem label="业务板块" colon={false}>
              {businessSegmentShowName}
            </FormItem>
            <FormItem label="主题域" colon={false}>
              {getFieldDecorator(`subjectDomainId`, {
                initialValue: subjectDomainId
              })(
                <Select placeholder="-请选择-" onChange={markChange}>
                  {themeList.map((item: any) => (
                    <Option key={item.id} value={item.id}>
                      {item.showName}
                    </Option>
                  ))}
                </Select>
              )}
            </FormItem>
            <FormItem label="数据分级" colon={false}>
              {getFieldDecorator(`dataLevel`, {
                initialValue: dataLevel,
                rules: [{ required: true, message: `请选择数据分级` }]
              })(
                <Select placeholder="-请选择-" onChange={markChange}>
                  {dataGradings.map((item: any) => (
                    <Option key={item.key} value={item.key}>
                      {item.showName}
                    </Option>
                  ))}
                </Select>
              )}
            </FormItem>
            <FormItem label="数仓层级" colon={false}>
              {modelTypeMap[modelType]}
            </FormItem>
            <FormItem label="表名称" colon={false}>
              {name}
            </FormItem>
            {/*<FormItem label="表名称" colon={false}>*/}
            {/*  {getFieldDecorator('name', {*/}
            {/*    initialValue: values.name,*/}
            {/*    rules: [*/}
            {/*      { required: true, message: `请输入中文名称` },*/}
            {/*      { max: 50, message: `中文名称名称长度不能超过50!` }*/}
            {/*    ]*/}
            {/*  })(<Input />)}*/}
            {/*</FormItem>*/}
            <FormItem label="中文名称" colon={false}>
              {getFieldDecorator('showName', {
                initialValue: showName,
                rules: [
                  { required: true, message: `请输入中文名称` },
                  { max: 50, message: `中文名称名称长度不能超过50!` }
                ]
              })(<Input onChange={markChange} />)}
            </FormItem>
            <FormItem label="创建人" colon={false}>
              {director}
            </FormItem>
            <FormItem label="描述" colon={false}>
              {getFieldDecorator('description', {
                initialValue: description,
                rules: [{ max: 255, message: `描述长度不能超过255!` }]
              })(
                <TextArea
                  onChange={markChange}
                  autosize={{ minRows: 4, maxRows: 6 }}
                />
              )}
            </FormItem>
          </Form>
        </div>
        <div className={styles.footer}>
          <div className={styles.btn} onClick={onClose}>
            关闭
          </div>
        </div>
      </div>
    );
  }
}

export default Form.create<IProps>()(BaseInfo);
