import React, { Component, Fragment } from 'react';
import { Input, Form, Col, Row } from 'sup-ui';
import styles from './index.less';

const FormItem = Form.Item;

interface IProps {
  form: any;
  disabled: boolean;
  dataType: string;
  values: any;
  markChange: any;
}

interface IState {}

class Attr extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator, getFieldValue, validateFields },
      values,
      dataType,
      markChange,
      disabled
    } = this.props;

    return (
      <div className={styles.attrWrapper}>
        <Row gutter={16}>
          {dataType === 'DECIMAL' && (
            <Fragment>
              <Col span={6}>
                <FormItem label="长度" colon={false}>
                  {getFieldDecorator('dataSize', {
                    initialValue: values.dataSize || '10',
                    validateFirst: true,
                    rules: [
                      {
                        validator: (_rule: any, value: any, callback: any) => {
                          if (
                            !/^\d{1,2}$/g.test(value) ||
                            value < 1 ||
                            value > 27
                          ) {
                            callback('请输入有效长度，范围[1,27]!');
                          } else {
                            validateFields(['dataDigit'], { force: true });
                            callback();
                          }
                        }
                      }
                    ]
                  })(<Input disabled={disabled} onChange={markChange} />)}
                </FormItem>
              </Col>
              <Col span={6}>
                <FormItem label="精度" colon={false}>
                  {getFieldDecorator('dataDigit', {
                    initialValue: values.dataDigit || '2',
                    rules: [
                      {
                        validator: (_rule: any, value: any, callback: any) => {
                          if (!/^\d$/.test(value) || value < 1 || value > 9) {
                            callback('请输入有效精度，范围[1,9]!');
                          } else if (value > +getFieldValue('dataSize')) {
                            callback('精度必须小于等于长度!');
                          } else {
                            callback();
                          }
                        }
                      }
                    ]
                  })(<Input disabled={disabled} onChange={markChange} />)}
                </FormItem>
              </Col>
            </Fragment>
          )}
          {dataType === 'STRING' && (
            <Col span={6}>
              <FormItem label="长度" colon={false}>
                {getFieldDecorator('dataSize', {
                  initialValue: values.dataSize || '255',
                  validateFirst: true,
                  rules: [
                    {
                      validator: (_rule: any, value: any, callback: any) => {
                        if (
                          !/^\d{1,5}$/.test(value) ||
                          value < 1 ||
                          value > 65535
                        ) {
                          callback('请输入有效长度，范围[1,65535]!');
                        } else {
                          callback();
                        }
                      }
                    }
                  ]
                })(<Input disabled={disabled} onChange={markChange} />)}
              </FormItem>
            </Col>
          )}
          <Col span={8}>
            <FormItem label="描述" colon={false}>
              {getFieldDecorator('description', {
                initialValue: values.description,
                rules: [{ max: 255, message: `描述长度不能超过255!` }]
              })(<Input onChange={markChange} style={{ width: '92%' }} />)}
            </FormItem>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Attr;
