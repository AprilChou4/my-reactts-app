import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';
import {
  getModelBasic,
  getModelDetail,
  saveModel,
  releaseModel,
  getModelVersionList,
  revokeModel,
  getSegmentTheme
} from '../dim.service';

class DimStore {
  private readonly model: any; //模型基础信息
  private readonly updateTab: any;
  private originalDominId: any; //记录原始主题域id，用于对比
  private originalShowName: any; //记录原始主题域showName，用于对比
  private originalDataLevel: any; //记录原始dataLevel，用于对比
  @observable public status = 1; //1已发布（草稿与线上版本一样） 2未发布（草稿） 3未发布（有线上版本）
  @observable public hasPub = false; //是否有发布版本，禁止某些操作
  @observable public baseInfo: any = {};
  @observable public attrInfo: any[] = [];
  @observable public physicalInfo: any = {};
  @observable public versionList: any[] = [];
  @observable public themeList: any[] = []; //当前板块下主题域列表
  @observable public loading = false;
  @observable public saving = false;

  public constructor(model: any, updateTab: any) {
    this.model = model;
    this.updateTab = updateTab;
    this.fetchDetail();
    this.getVersionList();
  }

  @action.bound
  public handleChangeBaseInfo(values: any) {
    this.baseInfo = {
      ...this.baseInfo,
      ...values
    };
  }

  @action.bound
  public handleChangeAttrInfo(values: any) {
    this.physicalInfo = {
      ...this.physicalInfo,
      fields: values
    };
  }

  @action.bound
  public async fetchDetail() {
    this.loading = true;

    const { id } = this.model;
    const res1 = await getModelBasic(id);

    if (res1.code !== 200) {
      message.error(`${res1.message}`);
      return;
    }

    this.updateTab(id, { showName: res1.data.showName });

    const res2 = await getModelDetail(id);

    runInAction(() => {
      if (res2.code !== 200) {
        message.error(`${res2.message}`);
        return;
      }

      const {
        draft = null,
        lastVersion,
        modelStatus = 1,
        draftChange
      } = res2.data || {};
      const {
        fields = [],
        fieldSourceMap = [],
        physicalMode,
        furtherSync
      } = JSON.parse(draft) || {};

      this.baseInfo = res1.data || {};

      this.getThemeList(this.baseInfo.businessSegmentId);

      this.originalDominId = this.baseInfo.subjectDomainId;
      this.originalShowName = this.baseInfo.showName;
      this.originalDataLevel = this.baseInfo.dataLevel;

      //已发布的字段不允许修改，使用lastVersion内的fields标记字段的disabled
      const temp = lastVersion ? lastVersion.fields || [] : [];
      const pubFieldNames = _.map(temp, 'name');

      _.forEach(fields, item => {
        item.disabled = _.includes(pubFieldNames, item.name);
      });

      this.attrInfo = fields;

      const tableName = fieldSourceMap[0]
        ? fieldSourceMap[0]['sourceName']
        : undefined;
      const links = _.map(fieldSourceMap, ({ sourceFieldId, fieldName }) => [
        sourceFieldId,
        fieldName
      ]);

      this.physicalInfo = {
        mode: physicalMode,
        furtherSync,
        tableName,
        links,
        fields
      };

      this.hasPub = modelStatus === 2;

      this.status = lastVersion ? (draftChange ? 3 : 1) : 2;

      this.loading = false;
    });
  }

  @action.bound
  public async getVersionList() {
    const res = await getModelVersionList(this.model.id);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.versionList = res.data.list || [];
    });
  }

  @action.bound
  public async getThemeList(segId: any) {
    const res = await getSegmentTheme(segId);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.themeList = res.data.list || [];
    });
  }

  @action.bound
  public async handleSaveModel(values: any, callback: any) {
    if (this.saving) {
      return;
    }

    this.saving = true;

    const {
      struct,
      struct: {
        baseInfo: { showName, description, subjectDomainId, dataLevel }
      }
    } = values;
    const fields = _.map(struct.fields, item => _.omit(item, ['disabled']));

    const res = await saveModel({
      modelId: values.modelId,
      showName,
      description,
      subjectDomainId,
      dataLevel,
      draft: JSON.stringify({ ...struct, fields })
    });

    runInAction(() => {
      this.saving = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const resetTree =
        this.originalDominId !== subjectDomainId ||
        this.originalShowName !== showName ||
        this.originalDataLevel !== dataLevel;

      this.fetchDetail();
      callback(resetTree);
      message.success('保存成功');
    });
  }

  @action.bound
  public async handleReleaseModel(values: any, callback: any) {
    if (this.saving) {
      return;
    }

    this.saving = true;

    const { modelId, struct } = values;
    const fields = _.map(struct.fields, item => _.omit(item, ['disabled']));

    const res = await releaseModel({
      modelId,
      struct: {
        ...values.struct,
        fields
      },
      webConfig: JSON.stringify({ ...struct, fields })
    });

    runInAction(() => {
      this.saving = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const resetTree =
        this.originalDominId !== struct.baseInfo.subjectDomainId ||
        this.originalShowName !== struct.baseInfo.showName ||
        this.originalDataLevel !== struct.baseInfo.dataLevel;

      //发布后获取最新版本列表
      this.getVersionList();
      this.fetchDetail();
      callback(resetTree);
      message.success('发布成功');
    });
  }

  //撤销
  @action.bound
  public async handleRevokeModel(callback: any) {
    const res = await revokeModel(this.model.id);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.fetchDetail();
      callback();
      message.success('操作成功!');
    });
  }
}

export default DimStore;
