import React, { Component, createContext, Fragment } from 'react';
import { observer } from 'mobx-react';
import { Form, Input, message, Select, Switch, Table } from 'sup-ui';
import Icon from '@components/Icon';
import { AddBtn, DelBtn } from '@components/Button';
import { TableCellText } from '@components/Table';
import Extra from '../../../components/Extra';
import { dataTypes, fieldTypes } from '../../../../consts/enum';
import { fieldNameReg, shortNameReg } from '../../../../consts/regexp';
import { dataTypeToDim } from '../../../../consts/typeMap';
import styles from './index.less';

const { Search } = Input;
const { Option } = Select;

const swap = (a: number, b: number, arr: any[]) => {
  const temp = arr[a];
  arr[a] = arr[b];
  arr[b] = temp;
};

const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      if (dataIndex === 'name') {
        const val = values[dataIndex];

        if (!val) {
          message.error('字段名称不能为空!');
          return;
        }

        if (val && !fieldNameReg.test(val)) {
          message.error(
            '字段名称仅支持字母开头、字母、数字、“_”的组合，非"_"结尾，且不能超过50个字符！'
          );
          return;
        }
      }

      if (dataIndex === 'showName') {
        const val = values[dataIndex];

        if (!val) {
          message.error('中文名称不能为空!');
          return;
        }

        if (val && !shortNameReg.test(val)) {
          message.error('中文名称不支持空格，且不能超过50个字符！');
          return;
        }
      }

      handleSave(dataIndex, { ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;
    const hasErr = dataIndex === 'name' && (!record.name || record.dup1);
    const hasErr2 =
      dataIndex === 'showName' && (!record.showName || record.dup2);

    if (record.disabled && dataIndex === 'name') {
      return <TableCellText text={record[dataIndex]} />;
    }

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
            onClick={e => e.stopPropagation()}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={`${styles['editable-cell-value-wrap']} ${
          hasErr || hasErr2 ? styles.error : ''
        }`}
        onClick={e => {
          e.stopPropagation();
          this.toggleEdit();
        }}
      >
        {record[dataIndex] ? (
          <TableCellText text={record[dataIndex]} />
        ) : (
          <span style={{ color: 'rgba(53, 64, 82, 0.5)', fontSize: '14px' }}>
            请输入
          </span>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  hasPub: boolean;
  onClose: any;
  markChange: any;
  dataSource: any;
}

interface IState {
  list: any;
  selectedRowKeys: any;
  inputValue: any;
  selectedRow: any; //当前选定的Row
}

@observer
class AttrFields extends Component<IProps, IState> {
  public i = 0;
  public extraRef: any;
  public readonly tableRef: any;
  public constructor(props: IProps) {
    super(props);

    const { dataSource } = props;

    const temp = _.map(
      dataSource,
      (
        {
          name,
          showName,
          dataType,
          fieldType,
          dataDigit,
          dataSize,
          pkField,
          description,
          disabled
        },
        i
      ) => ({
        key: i,
        name,
        showName,
        dataType,
        fieldType,
        pkField,
        extra: {
          dataSize,
          dataDigit,
          description
        },
        dup1: false,
        dup2: false,
        modify: true,
        disabled
      })
    );

    this.state = {
      list: temp,
      selectedRowKeys: [],
      inputValue: '',
      selectedRow: null
    };
    //初始化table key
    this.i = dataSource.length;
    this.tableRef = React.createRef();
  }

  public handleSearch = (value: any) => {
    this.setState({
      inputValue: value
    });
  };

  public updateSelectedRowKeys = (selectedKeys: string[] | number[]) => {
    this.setState({
      selectedRowKeys: selectedKeys
    });
  };

  public handleAddItem = () => {
    const { list } = this.state;
    const { markChange } = this.props;
    const item = {
      key: this.i++,
      name: undefined,
      showName: undefined,
      dataType: dataTypes[0]['key'],
      fieldType: fieldTypes[0]['key'],
      pkField: false,
      extra: {
        dataDigit: '',
        dataSize: '255', // String默认长度255
        description: ''
      },
      dup1: false,
      dup2: false,
      modify: false, //标识是否修改过字段类型
      disabled: false
    };

    this.setState(
      {
        list: list.concat([item])
      },
      () => {
        markChange();
        this.scrollToBottom(this.tableRef.current);
      }
    );
  };

  public scrollToBottom = (parentNode: any) => {
    const targetNode = parentNode.querySelector('.sup-table-body');
    const lastNode = parentNode.querySelector('.sup-table-tbody').lastChild;

    if (lastNode) {
      const top = lastNode.offsetTop;

      targetNode.scrollTo({
        top,
        behavior: 'smooth'
      });
    }
  };

  public handleBatchRemove = () => {
    const { selectedRowKeys } = this.state;

    if (!selectedRowKeys.length) {
      message.warning('请选择要删除的字段!');
      return;
    }

    this.handleRemoveItems(selectedRowKeys);
  };

  public handleRemoveItems = (keys: any[]) => {
    const { markChange } = this.props;
    const { list, selectedRowKeys, selectedRow } = this.state;
    let remainList = _.filter(list, item => !_.includes(keys, item.key));
    const remainKeys = _.filter(selectedRowKeys, key => !_.includes(keys, key));
    const row =
      selectedRow && _.includes(keys, selectedRow.key) ? null : selectedRow;

    //删除项后重新校验重复性
    remainList = this.markDupName(remainList, 'name');
    remainList = this.markDupName(remainList, 'showName');

    this.setState({
      list: remainList,
      selectedRowKeys: remainKeys,
      selectedRow: row
    });

    markChange();
  };

  public handleMoveItems = (up = true) => {
    const { selectedRowKeys, list } = this.state;

    if (!selectedRowKeys.length) {
      // message.warning('请选择要移动的项！');
      return;
    }

    //根据disabled将列表分为两部分，!disabled的列表移动
    const [arr1, arr2] = _.partition(list, ['disabled', true]);

    if (!up) {
      _.reverse(arr2);
    }

    for (let i = 0; i < arr2.length; i++) {
      if (_.includes(selectedRowKeys, arr2[i].key)) {
        continue;
      }

      if (!arr2[i + 1]) {
        break;
      }

      if (_.includes(selectedRowKeys, arr2[i + 1].key)) {
        swap(i, i + 1, arr2);
      }
    }

    if (!up) {
      _.reverse(arr2);
    }

    this.setState({
      list: _.concat(arr1, arr2)
    });
  };

  public handleCellSave = (dataIndex: string, row: any) => {
    this.handleValueChange(row.key, dataIndex, row[dataIndex]);
  };

  public handleValueChange = (key: number, name: string, value: any): void => {
    const { markChange } = this.props;
    const { list, selectedRow } = this.state;
    let arr = _.cloneDeep(list);
    const target = _.find(arr, ['key', key]);

    target[name] = value;

    if (name === 'dataType') {
      //修改dataType需要重置dataSize和dataDigit
      if (value === 'STRING') {
        target.extra.dataSize = '255';
        target.extra.dataDigit = '';
      }

      if (value === 'DECIMAL') {
        target.extra.dataSize = '10';
        target.extra.dataDigit = '2';
      }

      if (value !== 'STRING' && value !== 'DECIMAL') {
        target.extra.dataSize = '';
        target.extra.dataDigit = '';
      }

      //索引不能用float和double
      if (value === 'FLOAT' || value === 'DOUBLE' || value === 'DECIMAL') {
        if (target.pkField) {
          message.error('主键字段不能使用FLOAT、DOUBLE和DECIMAL类型!');
        }

        target.pkField = false;
      }

      //联动修改字段类型
      if (!target.modify) {
        target.fieldType = dataTypeToDim(value);
      }
    }

    //修改过一次字段类型后，标记修改
    if (name === 'fieldType') {
      target.modify = true;
    }

    //修改字段名时校验重复性
    if (name === 'name' || name === 'showName') {
      arr = this.markDupName(arr, name);
    }

    //修改索引时校验数量
    if (name === 'pkField') {
      const pkCount = _.filter(arr, 'pkField').length;

      if (pkCount < 1) {
        message.error('至少有一个字段作为唯一主键!');
      }

      if (pkCount > 5) {
        message.error('联合唯一主键不能超过5个!');
      }
    }

    this.setState({
      list: arr
    });

    //更新选中项
    if (selectedRow && selectedRow.key === key) {
      this.setState({
        selectedRow: target
      });
    }

    markChange();
  };

  public markDupName = (list: any, fieldName: string) => {
    const result = _.cloneDeep(list),
      map: any = {},
      key = fieldName === 'name' ? 'dup1' : 'dup2';

    _.forEach(result, field => {
      if (field[fieldName]) {
        const name =
          fieldName === 'name'
            ? field[fieldName].toLowerCase()
            : field[fieldName];

        if (map[name]) {
          field[key] = true;
          map[name][key] = true;
        } else {
          map[name] = field;
          field[key] = false;
          // field[key] = !name || !fieldNameReg.test(name);
        }
      }
    });

    return result;
  };

  public handleRowClick = (record: any) => {
    //切换详情前校验，校验后再切换
    const { key } = record;
    const { selectedRow, list } = this.state;
    const row = selectedRow && selectedRow.key === key ? null : record;
    let values: any;

    if (this.extraRef) {
      values = this.extraRef.validateValues();

      if (!values) {
        return;
      }

      const temp = _.cloneDeep(list);
      const target = _.find(temp, ['key', selectedRow.key]);

      target.extra = values;

      this.setState({
        list: temp
      });
    }

    this.setState({
      selectedRow: row
    });
  };

  public validateValues = (release = false) => {
    //校验各字段必填项，注意extra信息也要校验
    let { list } = this.state;
    let pkCount = 0;

    //数量校验
    if (!list.length && release) {
      message.error('请添加最少一条属性字段!');
      return;
    }

    //特殊情况，若Extra未关闭，切换drawer需要校验一下当前Extra
    //同时需要更新这个Extra到对应的row
    if (this.extraRef) {
      const { selectedRow } = this.state;
      const extra = this.extraRef.validateValues();

      if (!extra) {
        return;
      }

      const temp = _.cloneDeep(list);
      const target = _.find(temp, ['key', selectedRow.key]);

      target.extra = extra;

      list = temp;
    }

    //字段校验
    for (let i = 0; i < list.length; i++) {
      const { name, showName, pkField, dup1, dup2 } = list[i];

      //切换tab时提醒
      if (!name || !showName) {
        message.error('字段名或中文名不能为空!');
        return;
      }

      if (dup1) {
        message.error('字段名不能重复(大小写不敏感)，请检查字段列表!');
        return;
      }

      if (dup2) {
        message.error('字段中文名不能重复，请检查字段列表!');
        return;
      }

      pkCount += pkField;
    }

    //索引校验
    if ((pkCount > 5 || pkCount < 1) && release) {
      message.error('至少有一个字段作为唯一主键，且联合唯一主键不能超过5个!');
      return;
    }

    return _.map(
      list,
      (
        { name, showName, dataType, fieldType, pkField, extra, disabled },
        i
      ) => {
        const { dataDigit, dataSize, description } = extra;

        return {
          sort: i,
          name,
          physicalName: name,
          showName,
          dataType,
          fieldType,
          pkField,
          dataDigit,
          dataSize,
          defaultValue: '', //默认传空
          description,
          disabled
        };
      }
    );
  };

  //临时获取验证后的数据，物理化用
  public getVerifiedValues = () => {
    const { list } = this.state;
    const unique: any[] = _.uniqBy(list, 'name');

    return _.filter(unique, item => item.name && item.showName);
  };

  public getColumns = (): any[] => {
    const { hasPub } = this.props;

    return [
      {
        title: '字段名',
        width: 'auto',
        dataIndex: 'name',
        editable: true
      },
      {
        title: '中文名',
        dataIndex: 'showName',
        width: 'auto',
        editable: true
      },
      {
        title: '数据类型',
        dataIndex: 'dataType',
        width: 170,
        render: (value: any, record: any): any => {
          return (
            <div onClick={e => e.stopPropagation()}>
              <Select
                value={value}
                disabled={record.disabled}
                onChange={(val: string) =>
                  this.handleValueChange(record.key, 'dataType', val)
                }
              >
                {dataTypes.map((item: any) => (
                  <Option value={item.key} key={item.key}>
                    {item.showName}
                  </Option>
                ))}
              </Select>
            </div>
          );
        }
      },
      {
        title: '字段类型',
        dataIndex: 'fieldType',
        width: 170,
        render: (value: any, record: any): any => {
          return (
            <div onClick={e => e.stopPropagation()}>
              <Select
                value={value}
                onChange={(val: string) =>
                  this.handleValueChange(record.key, 'fieldType', val)
                }
              >
                {fieldTypes.map((item: any) => (
                  <Option value={item.key} key={item.key}>
                    {item.showName}
                  </Option>
                ))}
              </Select>
            </div>
          );
        }
      },
      {
        title: '主键',
        width: 120,
        dataIndex: 'pkField',
        className: 'ellipsis-hide',
        render: (_text: any, record: any) => {
          const { key, pkField, dataType, disabled } = record;
          //索引不能用float、double、decimal
          const disTypes = _.includes(['FLOAT', 'DOUBLE', 'DECIMAL'], dataType);

          return (
            <span onClick={e => e.stopPropagation()}>
              <Switch
                disabled={disabled || disTypes || hasPub}
                checked={pkField}
                onChange={checked =>
                  this.handleValueChange(key, 'pkField', checked)
                }
              />
            </span>
          );
        }
      },
      {
        title: '操作',
        width: 100,
        align: 'center',
        render: (_text: any, record: any) => {
          return (
            <Fragment>
              <div className="operator">
                {!record.disabled && (
                  <a
                    onClick={e => {
                      e.stopPropagation();
                      this.handleRemoveItems([record.key]);
                    }}
                  >
                    删除
                  </a>
                )}
              </div>
              <div className="more">
                <Icon type="ellipsis" width={13} />
              </div>
            </Fragment>
          );
        }
      }
    ];
  };

  public render() {
    const { onClose, markChange } = this.props;
    const { list, selectedRowKeys, inputValue, selectedRow } = this.state;
    const rowSelection = {
      columnWidth: 50,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true,
      getCheckboxProps: (record: any): any => ({
        disabled: record.disabled
      })
    };
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });
    const filterValue = _.filter(
      list,
      ({ name, showName }) =>
        !name ||
        !showName ||
        _.includes(name, inputValue) ||
        _.includes(showName, inputValue)
    );
    const disableBtn = selectedRowKeys.length === 0;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <span className={styles.close} onClick={onClose}>
            <Icon type="close" width={24} height={24} />
          </span>
          <h3>属性字段</h3>
        </div>
        <div className={styles.content}>
          <div className={styles.cont}>
            <div className={styles.operator}>
              <div className={styles.box}>
                <AddBtn ghost title="新建" onClick={this.handleAddItem} />
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  onClick={() => this.handleMoveItems()}
                >
                  上移
                </div>
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  style={{ marginRight: '8px' }}
                  onClick={() => this.handleMoveItems(false)}
                >
                  下移
                </div>
                <DelBtn
                  disabled={disableBtn}
                  onClick={this.handleBatchRemove}
                />
              </div>
              <Search
                placeholder="输入字段名搜索"
                onSearch={this.handleSearch}
                style={{ width: 200 }}
              />
            </div>
            <div className={`${styles.list} mp-table-grow`} ref={this.tableRef}>
              <Table
                size="small"
                rowKey="key"
                rowSelection={rowSelection}
                components={{
                  body: {
                    row: EditableFormRow,
                    cell: EditableCell
                  }
                }}
                rowClassName={(record: any) =>
                  selectedRow && record.key === selectedRow.key
                    ? styles.selected
                    : ''
                }
                onRow={(record: any) => ({
                  onClick: () => this.handleRowClick(record)
                })}
                columns={columns}
                dataSource={filterValue}
                scroll={{ y: 'calc(100% - 40px)' }}
                pagination={false}
              />
            </div>
            {!_.isNil(selectedRow) && (
              <div className={styles.extra}>
                <Extra
                  rowKey={selectedRow.key}
                  wrappedComponentRef={(ref: any) => {
                    this.extraRef = ref;
                  }}
                  markChange={markChange}
                  values={selectedRow}
                  onClose={this.handleRowClick}
                />
              </div>
            )}
          </div>
        </div>
        <div className={styles.footer}>
          <div className={styles.btn} onClick={onClose}>
            关闭
          </div>
        </div>
      </div>
    );
  }
}

export default AttrFields;
