import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Dropdown, Menu, Tooltip } from 'sup-ui';
import Icon from '@components/Icon';
import styles from './index.less';

interface IProps {
  node: any;
  active: boolean;
  infos: any; //下拉属性信息
  onSelect: any;
}

interface IState {
  visible: boolean;
}

@observer
class TableNode extends Component<IProps, IState> {
  private visible = true;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      visible: true
    };
  }

  public handleIconClick = () => {
    this.visible = !this.visible;
  };

  public handleDropVisibleChange = () => {
    this.setState({
      visible: this.visible
    });
  };

  public renderContextMenu = () => {
    const { infos } = this.props;

    if (!infos.length) {
      return (
        <Menu selectable={false}>
          <Menu.Item>
            <h4>暂无字段</h4>
            <p>请至`属性字段`添加</p>
          </Menu.Item>
        </Menu>
      );
    }

    return (
      <Menu selectable={false}>
        {infos.map((item: any) => (
          <Menu.Item key={item.name}>
            <h4>{item.name}</h4>
            <p>{item.showName}</p>
            {item.pkField && (
              <Tooltip title="主键">
                <Icon type="index" width={16} height={16} />
              </Tooltip>
            )}
          </Menu.Item>
        ))}
      </Menu>
    );
  };

  public render() {
    const { node, active, onSelect } = this.props;
    const { visible } = this.state;

    return (
      <div
        className={`${styles.container} ${active ? styles.active : ''}`}
        onClick={e => e.stopPropagation()}
      >
        <Dropdown
          align={{ overflow: { adjustY: false } }}
          visible={visible}
          overlay={this.renderContextMenu}
          trigger={['click']}
          getPopupContainer={triggerNode =>
            triggerNode.parentElement as HTMLElement
          }
          overlayClassName={styles.dropList}
          onVisibleChange={this.handleDropVisibleChange}
        >
          <div className={styles.icon} onClick={this.handleIconClick}>
            <i className={visible ? styles.down : ''} />
          </div>
        </Dropdown>
        <div className={styles.info} onClick={() => onSelect(!active)}>
          <h4>{node.name}</h4>
          <p>{node.showName}</p>
        </div>
      </div>
    );
  }
}

export default TableNode;
