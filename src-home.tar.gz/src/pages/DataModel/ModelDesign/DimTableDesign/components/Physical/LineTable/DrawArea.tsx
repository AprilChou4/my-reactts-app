import React, { Component, createRef } from 'react';
import styles from './index.less';

const baseHeight = 48; //默认左右table行高一致，均为48px
const patchX = -23; //dom计算起始点

const generatePoints = (ids: any[], x = 0, scrollTop = 0) => {
  const map: any = {};

  _.reduce(
    ids,
    (prev, id) => {
      const [px, py] = prev;
      const ny = py + baseHeight;
      const nx = px;

      map[id] = [nx, ny];

      return [nx, ny];
    },
    [x, scrollTop]
  );

  return map;
};

interface IProps {
  scrollTop: any; //{ source, target }
  sourceIds: any; //ids
  targetIds: any;
  links: any; // [[ sourceId, targetId ], ...]
  onLink: any; //连线或断线
}

interface IState {
  canvas: any; //canvas信息 width height
  sourceIdPointMap: any; //{ '1': [x, y] } id与点坐标map
  targetIdPointMap: any; //{ '1': [x, y] }
  sources: any[]; //已连id
  targets: any[];
}

class DrawArea extends Component<IProps, IState> {
  private readonly areaRef: any;
  private readonly topRef: any;
  private readonly bottomRef: any;
  private readonly ob: any; //监视areaRef的可见性
  private tcanvas: any; //绘制拖动的线
  private bcanvas: any; //绘制连接的线
  private tempRect: any; //临时存储容器信息（滚动时原有容器位置实时变化）
  private currentSourceId: any; //拖动点的id
  public constructor(props: IProps) {
    super(props);

    this.state = {
      canvas: {
        width: 0,
        height: 0
      },
      sourceIdPointMap: {},
      targetIdPointMap: {},
      sources: [],
      targets: []
    };

    this.areaRef = createRef();
    this.topRef = createRef();
    this.bottomRef = createRef();

    this.tempRect = null;
    this.currentSourceId = null;
    this.ob = new IntersectionObserver(this.initData);
  }

  public drawLine = (
    ctx: any,
    sx: number,
    sy: number,
    ex: number,
    ey: number
  ) => {
    const theta = 22.5, //箭头夹角
      len = 12, //箭头斜边长
      angle = (Math.atan2(sy - ey, sx - ex) * 180) / Math.PI,
      angle1 = ((angle + theta) * Math.PI) / 180,
      angle2 = ((angle - theta) * Math.PI) / 180,
      topX = len * Math.cos(angle1),
      topY = len * Math.sin(angle1),
      botX = len * Math.cos(angle2),
      botY = len * Math.sin(angle2);
    let arrowX, arrowY;

    //画直线
    ctx.moveTo(sx, sy);
    ctx.lineTo(ex, ey);

    //画箭头
    arrowX = ex + topX;
    arrowY = ey + topY;

    ctx.moveTo(arrowX, arrowY);
    ctx.lineTo(ex, ey);

    arrowX = ex + botX;
    arrowY = ey + botY;

    ctx.lineTo(arrowX, arrowY);
  };

  //在bcanvas上绘制所有连线
  public drawing = () => {
    const { links } = this.props;
    const { canvas, sourceIdPointMap, targetIdPointMap } = this.state;
    const ctx = this.bcanvas;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();

    ctx.strokeStyle = '#0f71e2';
    ctx.fillStyle = '#0f71e2';
    ctx.lineWidth = 1;

    _.forEach(links, ([sourceId, targetId]) => {
      const [sx, sy] = sourceIdPointMap[sourceId];
      const [tx, ty] = targetIdPointMap[targetId];

      this.drawLine(ctx, sx, sy, tx, ty);
    });

    ctx.fill();
    ctx.stroke();
  };

  //拖动事件，绘制连线
  public handleMouseDown = (id: any) => {
    const { sources } = this.state;

    if (_.includes(sources, id)) {
      return;
    }

    this.tempRect = this.areaRef.current.getBoundingClientRect();
    this.currentSourceId = id;
  };

  public handleMouseMove = (e: any) => {
    if (_.isNil(this.currentSourceId)) {
      return;
    }

    const { sourceIdPointMap } = this.state;
    const { x, y, width, height } = this.tempRect;

    const [sx, sy] = sourceIdPointMap[this.currentSourceId];
    const ctx = this.tcanvas;

    ctx.clearRect(0, 0, width, height);
    ctx.beginPath();

    ctx.strokeStyle = '#0f71e2';
    ctx.fillStyle = '#0f71e2';
    ctx.lineWidth = 1;

    this.drawLine(ctx, sx, sy, e.clientX - x, e.clientY - y);
    ctx.fill();
    ctx.stroke();
  };

  public handleMouseUp = (e: any) => {
    const { targets } = this.state;
    const { onLink } = this.props;

    if (_.isNil(this.currentSourceId)) {
      return;
    }

    const { width, height } = this.tempRect;
    const ctx = this.tcanvas;
    const sourceId = this.currentSourceId;

    ctx.clearRect(0, 0, width, height);
    this.currentSourceId = null;
    this.tempRect = null;

    if (e.target && e.target.tagName === 'SPAN' && e.target.dataset.id) {
      const targetId = e.target.dataset.id;

      if (_.includes(targets, targetId)) {
        return;
      }

      onLink('join', [sourceId, targetId]);
    }
  };

  public handleRepaintLines = () => {
    const {
      canvas: { width }
    } = this.state;
    const {
      sourceIds,
      targetIds,
      scrollTop: { source, target }
    } = this.props;

    const sourceIdPointMap = generatePoints(sourceIds, 9, patchX - source);
    const targetIdPointMap = generatePoints(
      targetIds,
      width - 9,
      patchX - target
    );

    this.setState({
      sourceIdPointMap,
      targetIdPointMap
    });

    window.requestAnimationFrame(this.drawing);
    // this.drawing();
  };

  public handleRemoveLine = (targetId: any) => {
    const { onLink } = this.props;

    onLink('cut', targetId);
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { scrollTop, links, sourceIds, targetIds } = this.props;
    if (!_.isEqual(prevProps.scrollTop, scrollTop)) {
      this.handleRepaintLines();
    }

    if (
      !_.isEqual(prevProps.links, links) ||
      !_.isEqual(prevProps.sourceIds, sourceIds) ||
      !_.isEqual(prevProps.targetIds, targetIds)
    ) {
      //未initData时，无需更新
      if (!this.tcanvas || !this.bcanvas) {
        return;
      }

      const sources: any[] = [],
        targets: any[] = [];

      _.forEach(links, ([sourceId, targetId]) => {
        sources.push(sourceId);
        targets.push(targetId);
      });

      this.setState({
        sources,
        targets
      });

      this.handleRepaintLines();
    }
  }

  public initData = (entries: any[]) => {
    if (!entries[0].isIntersecting) {
      return;
    }

    const { sourceIds, targetIds, links } = this.props;
    const { width, height } = this.areaRef.current.getBoundingClientRect();
    const sources: any[] = [],
      targets: any[] = [];

    this.tcanvas = this.topRef.current.getContext('2d');
    this.bcanvas = this.bottomRef.current.getContext('2d');

    const sourceIdPointMap = generatePoints(sourceIds, 9, patchX);
    const targetIdPointMap = generatePoints(targetIds, width - 9, patchX);

    _.forEach(links, ([sourceId, targetId]) => {
      sources.push(sourceId);
      targets.push(targetId);
    });

    this.setState({
      canvas: {
        width,
        height
      },
      sourceIdPointMap,
      targetIdPointMap,
      sources,
      targets
    });

    setTimeout(() => {
      this.drawing();
    });

    this.ob.disconnect();
  };

  public componentDidMount() {
    this.ob.observe(this.areaRef.current);
  }

  public componentWillUnmount() {
    this.ob.disconnect();
  }

  public render() {
    const {
      canvas: { width, height },
      sources,
      targets
    } = this.state;
    const {
      scrollTop: { source, target },
      sourceIds,
      targetIds
    } = this.props;

    return (
      <div
        className={styles.drawArea}
        ref={this.areaRef}
        onMouseMove={this.handleMouseMove}
        onMouseUp={this.handleMouseUp}
      >
        <div className={styles.domLayer} draggable={false}>
          <ul style={{ top: -source, left: 0 }}>
            {sourceIds.map((id: any) => {
              const linked = _.includes(sources, id);
              return (
                <li key={id} className={linked ? styles.linked : ''}>
                  <span onMouseDown={() => this.handleMouseDown(id)} />
                </li>
              );
            })}
          </ul>
          <ul className={styles.r} style={{ top: -target, right: 0 }}>
            {targetIds.map((id: any) => {
              const linked = _.includes(targets, id);
              return (
                <li key={id} className={linked ? styles.linked : ''}>
                  {linked && <i onClick={() => this.handleRemoveLine(id)} />}
                  <span data-id={id} />
                </li>
              );
            })}
          </ul>
        </div>
        <canvas
          className={styles.canvas1}
          width={width}
          height={height}
          ref={this.topRef}
        />
        <canvas
          className={styles.canvas2}
          width={width}
          height={height}
          ref={this.bottomRef}
        />
        <div className={styles.mask} />
      </div>
    );
  }
}

export default DrawArea;
