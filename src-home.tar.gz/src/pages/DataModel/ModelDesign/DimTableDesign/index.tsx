import React, { Component, createRef } from 'react';
import { Spin, Dropdown, Menu, message } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import TableNode from './components/TableNode';
import BaseInfo from '../components/BaseInfo';
import AttrFields from './components/AttrFields';
import Physical from './components/Physical';
import VersionManager from '../components/VersionManager';
import Preview from '../containers/Preview';
import DimStore from './stores/dim.store';
import styles from './index.less';

const tabs = [
  { key: 'base', showName: '基本信息' },
  { key: 'attr', showName: '属性字段' },
  { key: 'physics', showName: '物理化' },
  // { key: 'standard', showName: '数据标准' },
  { key: 'version', showName: '版本管理' },
  { key: 'preview', showName: '数据预览' }
  // { key: 'rule', showName: '质检规则' }
];

const modelTyeMap: any = {
  1: 'FACT_TABLE',
  2: 'DIM_TABLE',
  3: 'SUM_TABLE'
};

interface IProps {
  global?: any;
  model: any; //只使用model内的id字段
  markDirty: any; //标记是否有修改
  handleUpdateTab: any;
}

interface IState {
  tab: string;
  errorTabs: any[]; //未校验通过的tab
  selected: boolean;
  dirty: boolean;
}

@inject('global')
@observer
class DimTableDesign extends Component<IProps, IState> {
  private readonly ob: any; //监视modelRef的可见性
  private readonly store: DimStore;
  private baseRef: any = {};
  private readonly attrRef: any;
  private readonly physicsRef: any;
  private readonly modelRef: any;
  private inView = true; //是否在视窗内
  public constructor(props: IProps) {
    super(props);

    this.store = new DimStore(props.model, props.handleUpdateTab);
    this.state = {
      tab: 'empty',
      errorTabs: [],
      selected: false,
      dirty: false
    };
    this.attrRef = createRef();
    this.physicsRef = createRef();
    this.modelRef = createRef();
    this.ob = new IntersectionObserver(this.changeView);
  }

  public changeView = (entries: any[]) => {
    this.inView = entries[0].isIntersecting;
  };

  public handleDrawAreaClick = () => {
    if (this.state.selected) {
      this.setState({
        selected: false
      });
    }
  };

  public handleSelectNode = (selected: boolean) => {
    this.setState({
      selected
    });
  };

  public handleTabSwitch = (key: string) => {
    //切换或关闭时校验当前模块，标注是否错误
    const { handleChangeBaseInfo, handleChangeAttrInfo, hasPub } = this.store;
    const { tab, errorTabs } = this.state;
    const arr = _.cloneDeep(errorTabs);
    let hasError = false;

    if (tab === 'base') {
      const values = this.baseRef.validateValues();

      if (values) {
        handleChangeBaseInfo(values);
      }

      hasError = !values;
    }

    if (tab === 'attr') {
      const values = this.attrRef.current.validateValues();
      const temp = this.attrRef.current.getVerifiedValues();

      handleChangeAttrInfo(values || temp);

      hasError = !values;
    }

    if (tab === 'physics') {
      hasError = !this.physicsRef.current.validateValues();
    }

    if (key === 'preview') {
      if (!hasPub) {
        message.warning('请先发布模型!');
        return;
      }
    }

    hasError ? arr.push(tab) : _.pull(arr, tab);

    this.setState({
      tab: key === tab ? 'empty' : key,
      errorTabs: _.uniq(arr)
    });
  };

  public renderStatusBtn = () => {
    const { status } = this.store;

    if (status === 1) {
      return <div className={styles.pub}>已发布</div>;
    }

    if (status === 2) {
      return <div className={styles.unpub}>未发布</div>;
    }

    if (status === 3) {
      const menu = (
        <Menu>
          <Menu.Item>
            <a onClick={this.handleRevoke}>恢复至最新发布版本</a>
          </Menu.Item>
        </Menu>
      );

      return (
        <Dropdown overlay={menu} placement="bottomCenter">
          <div className={styles.unpub2}>未发布</div>
        </Dropdown>
      );
    }

    return null;
  };

  public handleRevoke = () => {
    const { handleRevokeModel } = this.store;
    const config = {
      title: '请确认恢复',
      content: '该模型将会被恢复至最新发布版本',
      onOk: () => {
        handleRevokeModel(() => {
          this.markModelChange(false);
        });
      }
    };

    TipsDelete(config);
  };

  public handleSave = (release = false) => {
    const { dirty } = this.state;
    const { status } = this.store;

    if (status === 1 && !dirty) {
      return;
    }

    const { model, global } = this.props;
    const { baseInfo, handleSaveModel, handleReleaseModel } = this.store;
    const base = this.baseRef.validateValues();
    const attrs = this.attrRef.current.validateValues(release);
    const physical = this.physicsRef.current.validateValues(release);

    if (!base || !attrs || !physical) {
      return;
    }

    const { subjectDomainId, name, showName, description, dataLevel } = base;
    const { physicalMode, furtherSync, fieldMap } = physical;
    const params = {
      modelId: model.id,
      struct: {
        modelId: model.id,
        modelType: modelTyeMap[baseInfo.modelType],
        physicalMode,
        furtherSync,
        baseInfo: {
          subjectDomainId,
          name,
          physicalName: name,
          dataLevel,
          showName,
          description
        },
        fields: attrs,
        fieldSourceMap: fieldMap,
        modelSourceJoin: {} //汇总表用
      }
    };

    const execFunc = release ? handleReleaseModel : handleSaveModel;

    execFunc(params, (resetTree: boolean) => {
      if (resetTree) {
        //重置模型树
        global.executeCacheMethod('/data-model/design', 'refreshModelTree', {});
      }

      //发布后清空版本页缓存
      if (release) {
        global.clearCachePages([`/data-model/version/${model.id}`]);
      }

      this.markModelChange(false);
    });
  };

  public markModelChange = (dirty = true) => {
    //model有任何改变时，标记该tab为未保存
    const {
      markDirty,
      model: { id }
    } = this.props;

    if (!dirty) {
      markDirty(id, false);

      this.setState({
        dirty: false
      });
      return;
    }

    //有变化时，避免多次调用该方法
    if (this.state.dirty) {
      return;
    }

    markDirty(id, true);

    this.setState({
      dirty: true
    });
  };

  public keyboardListener = (e: any) => {
    const { tab } = this.state;

    if (e.keyCode === 27 && this.inView && tab !== 'empty') {
      this.handleTabSwitch('empty');
    }
  };

  public componentDidMount(): void {
    document.addEventListener('keyup', this.keyboardListener);
    this.ob.observe(this.modelRef.current);
  }

  public componentWillUnmount(): void {
    document.removeEventListener('keyup', this.keyboardListener);
    this.ob.disconnect();
  }

  public render() {
    const { selected, tab, errorTabs, dirty } = this.state;
    const {
      status,
      hasPub,
      loading,
      baseInfo,
      attrInfo,
      physicalInfo,
      saving,
      versionList,
      themeList
    } = this.store;
    const disableBtn = status === 1 && !dirty; //已发布，未做修改

    return (
      <div className={styles.container} ref={this.modelRef}>
        {loading ? (
          <div className={styles.loading}>
            <Spin />
          </div>
        ) : (
          <Spin spinning={saving}>
            <div className={styles.area} onClick={this.handleDrawAreaClick}>
              <div className={styles.view}>
                <TableNode
                  active={selected}
                  node={baseInfo}
                  infos={physicalInfo.fields}
                  onSelect={this.handleSelectNode}
                />
              </div>
              <div className={styles.topBar}>
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  onClick={() => this.handleSave()}
                >
                  <Icon type="save" fill={disableBtn ? '#a6a6a7' : '#0f71e2'} />
                  保存
                </div>
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  onClick={() => this.handleSave(true)}
                >
                  <Icon
                    type="publish-small"
                    fill={disableBtn ? '#a6a6a7' : '#0f71e2'}
                    width={17}
                    height={17}
                  />
                  发布
                </div>
                <div className={styles.status}>{this.renderStatusBtn()}</div>
              </div>
              <div className={styles.infoWrapper}>
                <div style={{ display: tab === 'base' ? 'block' : 'none' }}>
                  <BaseInfo
                    wrappedComponentRef={(ref: any) => {
                      this.baseRef = ref;
                    }}
                    themeList={themeList}
                    values={baseInfo}
                    markChange={this.markModelChange}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'attr' ? 'block' : 'none' }}>
                  <AttrFields
                    ref={this.attrRef}
                    dataSource={attrInfo}
                    hasPub={hasPub}
                    markChange={this.markModelChange}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'physics' ? 'block' : 'none' }}>
                  <Physical
                    ref={this.physicsRef}
                    hasPub={hasPub}
                    values={physicalInfo}
                    markChange={this.markModelChange}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'version' ? 'block' : 'none' }}>
                  <VersionManager
                    dataSource={versionList}
                    modelId={baseInfo.id}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                {tab === 'preview' && (
                  <div>
                    <Preview
                      modelId={baseInfo.id}
                      onClose={() => this.handleTabSwitch('empty')}
                    />
                  </div>
                )}
              </div>
            </div>
            <div className={styles.operator}>
              <ul>
                {tabs.map((item: any) => {
                  const hasError = _.includes(errorTabs, item.key);

                  return (
                    <li
                      key={item.key}
                      className={`${tab === item.key ? styles.active : ''} ${
                        hasError ? styles.error : ''
                      }`}
                      onClick={() => this.handleTabSwitch(item.key)}
                    >
                      {item.showName}
                    </li>
                  );
                })}
              </ul>
            </div>
          </Spin>
        )}
      </div>
    );
  }
}

export default DimTableDesign;
