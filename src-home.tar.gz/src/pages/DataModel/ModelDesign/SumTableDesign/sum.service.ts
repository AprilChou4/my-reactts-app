import http from '@services/http';
import { MODEL_URL } from '@config/env';

//获取模型
export function getModelDetail(modelId: any): Promise<any> {
  return http.get(`${MODEL_URL}/design/model/detail/${modelId}`);
}

//获取模型基础信息
export function getModelBasic(modelId: any): Promise<any> {
  return http.get(`${MODEL_URL}/design/model/${modelId}/basic`);
}

//保存模型
export function saveModel(params: any): Promise<any> {
  return http.put(`${MODEL_URL}/design/model/save`, params);
}

//发布模型
export function releaseModel(params: any): Promise<any> {
  return http.post(`${MODEL_URL}/design/model/release`, params);
}

//获取模型字段
export function getModelFields(modelId: any): Promise<any> {
  return http.get(`${MODEL_URL}/design/model/${modelId}/fields`);
}

//获取版本列表
export function getModelVersionList(modelId: any): Promise<any> {
  return http.get(`${MODEL_URL}/design/model/version/${modelId}`);
}

//撤销模型
export function revokeModel(modelId: any): Promise<any> {
  return http.delete(`${MODEL_URL}/design/model/revoke/${modelId}`);
}

//获取业务板块下主题
export function getSegmentTheme(id: any): Promise<any> {
  return http.get(`${MODEL_URL}/business/theme/segment/${id}`);
}
