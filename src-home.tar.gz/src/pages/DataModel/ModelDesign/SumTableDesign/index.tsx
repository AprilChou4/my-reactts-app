import React, { Component, createRef } from 'react';
import { Dropdown, Menu, message, Spin } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import Icon from '@components/Icon';
import DrawArea from './containers/DrawArea';
import BaseInfo from '../components/BaseInfo';
import AttrFields from './components/AttrFields';
import Physical from './components/Physical';
import VersionManager from '../components/VersionManager';
import Preview from '../containers/Preview';
import SumStore from './stores/sum.store';
import AreaStore from './stores/area.store';
import styles from './index.less';
import TipsDelete from '@components/Modal/TipsDelete';

const tabs = [
  { key: 'base', showName: '基本信息' },
  { key: 'attr', showName: '属性字段' },
  { key: 'physics', showName: '物理化' },
  // { key: 'standard', showName: '数据标准' },
  { key: 'version', showName: '版本管理' },
  { key: 'preview', showName: '数据预览' }
  // { key: 'rule', showName: '质检规则' }
];

const modelTyeMap: any = {
  1: 'FACT_TABLE',
  2: 'DIM_TABLE',
  3: 'SUM_TABLE'
};

const fieldTyeMap: any = {
  1: 'DIM',
  2: 'TIME',
  3: 'MEASURE'
};

interface IProps {
  global?: any;
  model: any;
  markDirty: any; //标记是否有修改
  jumpModel: any; //新建模型tab
  handleUpdateTab: any;
}

interface IState {
  tab: string;
  errorTabs: any[]; //未校验通过的tab
  dirty: boolean;
}

@inject('global')
@observer
class SumTableDesign extends Component<IProps, IState> {
  private readonly sumStore: SumStore;
  private readonly areaStore: AreaStore;
  private baseRef: any = {};
  private readonly attrRef: any;
  private readonly physicsRef: any;
  public constructor(props: IProps) {
    super(props);

    this.areaStore = new AreaStore(this.markModelChange);
    this.sumStore = new SumStore(
      props.model,
      props.handleUpdateTab,
      this.areaStore
    );
    this.state = {
      tab: 'empty',
      errorTabs: [],
      dirty: false
    };
    this.attrRef = createRef();
    this.physicsRef = createRef();
  }

  public handleTabSwitch = (key: string) => {
    //切换或关闭时校验当前模块，标注是否错误
    const { baseInfo } = this.sumStore;
    const { tab, errorTabs } = this.state;
    const arr = _.cloneDeep(errorTabs);
    let hasError = false;

    if (tab === 'base') {
      hasError = !this.baseRef.validateValues();
    }

    if (tab === 'attr') {
      hasError = !this.attrRef.current.validateValues();
    }

    if (key === 'preview') {
      if (baseInfo.modelStatus !== 2) {
        message.warning('请先发布模型!');
        return;
      }
    }

    hasError ? arr.push(tab) : _.pull(arr, tab);

    this.setState({
      tab: key === tab ? 'empty' : key,
      errorTabs: _.uniq(arr)
    });
  };

  public renderStatusBtn = () => {
    const { status } = this.sumStore;

    if (status === 1) {
      return <div className={styles.pub}>已发布</div>;
    }

    if (status === 2) {
      return <div className={styles.unpub}>未发布</div>;
    }

    if (status === 3) {
      const menu = (
        <Menu>
          <Menu.Item>
            <a onClick={this.handleRevoke}>恢复至最新发布版本</a>
          </Menu.Item>
        </Menu>
      );

      return (
        <Dropdown overlay={menu} placement="bottomCenter">
          <div className={styles.unpub2}>未发布</div>
        </Dropdown>
      );
    }

    return null;
  };

  public handleRevoke = () => {
    const { handleRevokeModel } = this.sumStore;
    const config = {
      title: '请确认恢复',
      content: '该模型将会被恢复至最新发布版本',
      onOk: () => {
        handleRevokeModel(() => {
          this.markModelChange(false);
        });
      }
    };

    TipsDelete(config);
  };

  public handleSave = (release = false) => {
    const { dirty } = this.state;
    const { status } = this.sumStore;

    if (status === 1 && !dirty) {
      return;
    }

    const { model, global } = this.props;
    const { baseInfo, handleSaveModel, handleReleaseModel } = this.sumStore;
    const { saveConfig } = this.areaStore;
    const base = this.baseRef.validateValues();
    const attrs = this.attrRef.current.validateValues(release);
    const areas = saveConfig();

    if (!base || !attrs || !areas) {
      return;
    }

    const { subjectDomainId, name, showName, description, dataLevel } = base;
    const fieldSourceMap = _.map(attrs, field => {
      const { sourceFieldId, tableName, sourceDataType, used } = field;

      return {
        associateField: used,
        fieldName: field.name,
        sourceDataType,
        sourceFieldId,
        sourceName: tableName
      };
    });

    const fields = _.map(attrs, (field, i) => {
      const { dataType, fieldType, extra, pkField } = field;

      return {
        name: field.name,
        physicalName: field.name,
        showName: field.showName,
        dataType,
        fieldType: fieldTyeMap[fieldType],
        dataDigit: extra.dataDigit,
        dataSize: extra.dataSize,
        defaultValue: '',
        description: extra.description,
        pkField,
        sort: i
      };
    });

    const { modelSourceJoin, webConfig } = areas;

    const params = {
      modelId: model.id,
      struct: {
        modelId: model.id,
        modelType: modelTyeMap[baseInfo.modelType],
        physicalMode: 'NO_PHYSICAL', //汇总表暂时使用该类型
        furtherSync: false, //汇总表写死
        baseInfo: {
          subjectDomainId,
          name,
          physicalName: name,
          showName,
          description,
          dataLevel
        },
        fields,
        fieldSourceMap,
        modelSourceJoin
      },
      webConfig: {
        baseInfo: {
          name,
          showName,
          description
        },
        ...webConfig
      }
    };

    const execFunc = release ? handleReleaseModel : handleSaveModel;

    execFunc(params, (resetTree: boolean) => {
      if (resetTree) {
        //重置模型树
        global.executeCacheMethod('/data-model/design', 'refreshModelTree', {});
      }

      //发布后清空版本页缓存
      if (release) {
        global.clearCachePages([`/data-model/version/${model.id}`]);
      }

      this.markModelChange(false);
    });
  };

  public markModelChange = (dirty = true) => {
    //model有任何改变时，标记该tab为未保存
    const {
      markDirty,
      model: { id }
    } = this.props;

    if (!dirty) {
      markDirty(id, false);

      this.setState({
        dirty: false
      });
      return;
    }

    //有变化时，避免多次调用该方法
    if (this.state.dirty) {
      return;
    }

    markDirty(id, true);

    this.setState({
      dirty: true
    });
  };

  public render() {
    const { jumpModel } = this.props;
    const { tab, errorTabs, dirty } = this.state;
    const { status, loading, baseInfo, saving, versionList, themeList } =
      this.sumStore;
    const disableBtn = status === 1 && !dirty; //已发布，未做修改

    return (
      <div className={styles.container}>
        {loading ? (
          <div className={styles.loading}>
            <Spin />
          </div>
        ) : (
          <Spin spinning={saving}>
            <div className={styles.area}>
              <div className={styles.view}>
                <DrawArea jumpModel={jumpModel} store={this.areaStore} />
              </div>
              <div className={styles.topBar}>
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  onClick={() => this.handleSave()}
                >
                  <Icon type="save" fill={disableBtn ? '#a6a6a7' : '#0f71e2'} />
                  保存
                </div>
                <div
                  className={`${styles.btn} ${
                    disableBtn ? styles.disable : ''
                  }`}
                  onClick={() => this.handleSave(true)}
                >
                  <Icon
                    type="publish-small"
                    fill={disableBtn ? '#a6a6a7' : '#0f71e2'}
                    width={17}
                    height={17}
                  />
                  发布
                </div>
                <div className={styles.status}>{this.renderStatusBtn()}</div>
              </div>
              <div className={styles.infoWrapper}>
                <div style={{ display: tab === 'base' ? 'block' : 'none' }}>
                  <BaseInfo
                    wrappedComponentRef={(ref: any) => {
                      this.baseRef = ref;
                    }}
                    themeList={themeList}
                    values={baseInfo}
                    markChange={this.markModelChange}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'attr' ? 'block' : 'none' }}>
                  <AttrFields
                    ref={this.attrRef}
                    store={this.areaStore}
                    markChange={this.markModelChange}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'physics' ? 'block' : 'none' }}>
                  <Physical
                    ref={this.physicsRef}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                <div style={{ display: tab === 'version' ? 'block' : 'none' }}>
                  <VersionManager
                    dataSource={versionList}
                    modelId={baseInfo.id}
                    onClose={() => this.handleTabSwitch('empty')}
                  />
                </div>
                {tab === 'preview' && (
                  <div>
                    <Preview
                      modelId={baseInfo.id}
                      onClose={() => this.handleTabSwitch('empty')}
                    />
                  </div>
                )}
              </div>
            </div>
            <div className={styles.operator}>
              <ul>
                {tabs.map((item: any) => {
                  const hasError = _.includes(errorTabs, item.key);

                  return (
                    <li
                      key={item.key}
                      className={`${tab === item.key ? styles.active : ''} ${
                        hasError ? styles.error : ''
                      }`}
                      onClick={() => this.handleTabSwitch(item.key)}
                    >
                      {item.showName}
                    </li>
                  );
                })}
              </ul>
            </div>
          </Spin>
        )}
      </div>
    );
  }
}

export default SumTableDesign;
