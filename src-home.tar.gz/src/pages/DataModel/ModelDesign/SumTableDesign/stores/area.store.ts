import { action, observable, runInAction, computed } from 'mobx';
import { message } from 'sup-ui';
import uuid from '@utils/uuid';
import {
  SourceTableItem,
  DataFieldItem,
  PipeItem,
  FieldItemType
} from '../consts/typings';
import { getModelFields } from '../sum.service';

class AreaStore {
  public hasDirty = false; //主题是否已修改
  public manuallyOpenPipe: any; //手动打开pipe弹窗
  private readonly markChange: any; //标记修改
  @observable public drawLoading = false; //画布loading

  @observable public sourceTableMap: SourceTableItem = {}; //1.源table表
  @observable public dataFieldsList: DataFieldItem[] = []; //2.组态结构表
  @observable public pipeConfigMap: PipeItem = {}; //3.管道表
  @observable public fieldsList: FieldItemType[] = []; //4.字段列表

  @observable public selectedPipe: any = null; //选中的管道
  @observable public visible = false; //关联条件modal弹窗
  @observable public fieldModalVisible = false; //字段弹窗可见性
  @observable public fieldModalList: any[] = []; //字段弹窗列表
  @observable public sqlModalVisible = false; //mySql弹窗可见性
  @observable public sqlModalData: any = {}; //mySql数据: name, sourceName, sqlValue, dropId
  @observable public sqlModalLoading = false; //mySql弹窗loading

  @observable public dupModalVisible = false; //重复检测弹窗可见性
  @observable public dataStructSearchText = ''; //数据结构字段搜索
  @observable public selectedRowKeys: any[] = []; //数据结构选中项

  public constructor(markChange: any) {
    this.markChange = markChange;
  }

  //初始化组态结构
  @action.bound
  public initConfig(config: any) {
    const {
      sourceTableMap = {},
      dataFieldsList = [],
      pipeConfigMap = {},
      fieldsList = []
    } = config;

    this.sourceTableMap = sourceTableMap;
    this.dataFieldsList = dataFieldsList;
    this.pipeConfigMap = pipeConfigMap;
    this.fieldsList = fieldsList;
  }

  //保存组态
  @action.bound
  public saveConfig(): any {
    //关联条件不能为空,且必须配置
    const unVerify = _.find(this.pipeConfigMap, ['verify', false]);

    if (unVerify) {
      message.error('各模型间的关联条件不能为空!');
      return;
    }

    //表名重复问题
    const hasDup = _.find(this.dupSourceTableMap, 'dup');

    if (hasDup) {
      message.error('模型表名称不能重复!');
      return;
    }

    const sourceLabelMap: any = {}, //表名对应map
      relations: any = []; //关联条件

    //关联条件
    _.forOwn(this.pipeConfigMap, pipe => {
      const { id, mainId: mid, dataTable, linkType } = pipe;
      const leftSourceLabel = this.sourceTableMap[mid]['name'];
      const rightSourceLabel = this.sourceTableMap[id]['name'];

      const conditions = _.map(dataTable, data => {
        const { main, vice } = data;
        const mProps = main.split('|:|');
        const vProps = vice.split('|:|');

        return {
          leftFieldId: +mProps[2],
          rightFieldId: +vProps[2]
        };
      });

      relations.push({
        joinType: linkType,
        leftSourceLabel,
        rightSourceLabel,
        conditions
      });
    });

    //数据源表
    _.forOwn(this.sourceTableMap, table => {
      const { name, id } = table;

      sourceLabelMap[name] = id;
    });

    //主表sourceName, 即主表表名
    let mainSourceLabel;

    if (this.dataFieldsList.length) {
      const mainId = this.dataFieldsList[0]['id'];
      mainSourceLabel = this.sourceTableMap[mainId]['name'];
    }

    //webConfig配置信息，回显时使用
    const config = {
      sourceTableMap: this.sourceTableMap,
      dataFieldsList: this.dataFieldsList,
      pipeConfigMap: this.pipeConfigMap,
      fieldsList: this.fieldsList
    };

    return {
      modelSourceJoin: {
        mainSourceLabel,
        relations,
        sourceLabelMap
      },
      webConfig: config
    };
  }

  @action.bound
  public placeNodeInPosi = (dropId: any, node: any) => {
    const recurse = (childs: any) => {
      _.forEach(childs, (item: any): any => {
        if (item.id === dropId) {
          node.column = item.column + 1;
          item.child.push(node);
          return false;
        }

        if (item.child.length) {
          recurse(item.child);
        }
      });
    };

    recurse(this.dataFieldsList);
  };

  //放置节点
  @action.bound
  public async handleDrop(dragInfo: any, dropId: any) {
    //dragInfo不存在，return掉
    if (_.isEmpty(dragInfo)) {
      return;
    }

    const { id: modelId, modelType, name: tableName } = dragInfo;

    if (this.dataFieldsList.length === 0 && modelType !== 1) {
      message.error('只能将事实表作为主表，请重新选择!');
      return;
    }

    this.drawLoading = true;

    const uniqueId = uuid(10);

    //首先获取drag节点的字段列表
    const res = await getModelFields(modelId);

    runInAction(() => {
      this.drawLoading = false;
    });

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    const { fields = [], ...baseInfo } = res.data || {};
    let mainId: any;

    if (!fields.length) {
      message.error('该模型无字段，请重新选择!');
      return;
    }

    //新节点基础字段
    const newNodeInfo: any = {
      id: uniqueId,
      type: modelType,
      column: 0,
      child: []
    };

    runInAction(() => {
      if (!_.isNil(dropId)) {
        //dropId存在，落在了node节点上
        this.placeNodeInPosi(dropId, newNodeInfo);
        mainId = dropId;
      } else {
        //dropId不存在, 要么是第一张表(主表), 要么连接到主表上
        if (this.dataFieldsList.length === 0) {
          //主表
          this.dataFieldsList = [newNodeInfo];
        } else {
          newNodeInfo['column'] = 1;
          this.dataFieldsList[0]['child'].push(newNodeInfo);
          mainId = this.dataFieldsList[0]['id'];
        }
      }

      //生成字段后缀
      const index = this.generateTableIndex(modelId);
      const suffix = index ? `_${index}` : '';

      //更新pipeConfigMap表
      if (mainId) {
        this.pipeConfigMap[uniqueId] = {
          id: uniqueId,
          mainId,
          linkType: 'LEFT_JOIN',
          verify: false, //dataTable验证
          disabled: false,
          dataTable: []
        };
      }

      //新增字段列表
      const arr = _.map(fields, (field: any) => {
        const {
          id,
          name,
          showName,
          fieldDataType,
          fieldType,
          pkField,
          description
        } = field;

        return {
          key: `${uniqueId}_${field.name}`, //item的唯一标识符号
          uniqueId,
          tableName,
          sourceFieldId: id,
          sourceName: name,
          sourceDataType: fieldDataType,
          name: `${name}${suffix}`,
          showName,
          dataType: fieldDataType.name,
          fieldType,
          pkField,
          extra: {
            dataDigit: fieldDataType.digit,
            dataSize: fieldDataType.size,
            description
          },
          checked: true,
          used: false,
          disabled: false
        };
      });

      this.fieldsList.push(...arr);

      //更新sourceTableMap表
      this.sourceTableMap[uniqueId] = {
        id: modelId,
        uniqueId,
        name: tableName,
        originalName: tableName,
        showName: baseInfo.showName, //从详情取最新的
        modelType,
        disabled: false,
        index
      };

      //手动打开对应pipe
      if (mainId) {
        setTimeout(() => {
          this.manuallyOpenPipe(uniqueId);
        }, 100);
      }

      this.markChange();
    });
  }

  //删除节点
  @action.bound
  public async handleDeleteNode(nodeId: string) {
    //重点在于删除四大表中对应的数据
    //删除组态表中对应节点，同时递归收集子节点id
    let cacheNode: any[] = [],
      cacheIndex = 0,
      cacheChilds: any[] = [];
    const deleteIds: any = [];
    const getTargetNode = (childs: any) => {
      _.forEach(childs, (node: any, idx: number): any => {
        if (node.id === nodeId) {
          cacheNode = childs;
          cacheIndex = idx;
          cacheChilds = node.child;
          return false;
        }

        if (node.child.length) {
          getTargetNode(node.child);
        }
      });
    };
    getTargetNode(this.dataFieldsList);

    const collectIds = (childs: any) => {
      _.forEach(childs, (node: any): any => {
        deleteIds.push(node.id);

        if (node.child.length) {
          collectIds(node.child);
        }
      });
    };
    collectIds(cacheChilds);

    deleteIds.unshift(nodeId);
    cacheNode.splice(cacheIndex, 1);

    //删除管道表、字段表、table表对应的数据
    _.forEach(deleteIds, id => {
      delete this.pipeConfigMap[id];
      delete this.sourceTableMap[id];
    });

    this.fieldsList = _.filter(
      this.fieldsList,
      field => !_.includes(deleteIds, field.uniqueId)
    );

    this.markChange();
    message.success('删除成功');
  }

  @action.bound
  public async handleContextMenuClick(type: string, node: any) {
    //type: 1-选择字段; 2-修改名称; 3-刷新字段; 4-删除字段;
    if (type === '1') {
      this.fieldModalList = _.filter(this.fieldsList, ['uniqueId', node.id]);
      this.fieldModalVisible = true;
    }

    // if (type === '3') {
    //   this.refreshTableFields(node);
    // }

    if (type === '4') {
      this.handleDeleteNode(node.id);
    }
  }

  @action.bound
  public updateSourceTableMap(id: string, key: string, value: any) {
    this.sourceTableMap[id][key] = value;
    this.markChange();
  }

  //标记table表name的重复性
  @computed
  public get dupSourceTableMap() {
    const result = _.cloneDeep(this.sourceTableMap);
    const map: any = {};
    let flag = false;

    _.forEach(result, table => {
      const { name } = table;

      if (map[name]) {
        table.dup = true;
        map[name].dup = true;
        flag = true;
      } else {
        map[name] = table;
        table.dup = false;
      }
    });

    if (flag) {
      setTimeout(() => {
        message.error('数据表名不能重复，请修改!');
      }, 0);
    }

    return result;
  }

  //选择字段弹窗
  @action.bound
  public handleFieldModalVisible(visible: boolean) {
    this.fieldModalVisible = visible;
  }

  @action.bound
  public handleFieldModalOk(keys: any[], fieldsNameMap: any, id: string) {
    this.fieldModalVisible = false;

    _.forEach(this.fieldsList, field => {
      if (field.uniqueId === id) {
        field.checked = _.includes(keys, field.sourceName);
        field.name = fieldsNameMap[field.sourceName];
      }
    });

    this.markChange();
  }

  //计算节点所占空间及位置
  public recurseSpace(childs: any) {
    childs.forEach((node: any, i: number) => {
      const { child } = node;

      if (i > 0) {
        const { top, space } = childs[i - 1];
        node.top = top + space;
      }

      if (child.length > 0) {
        child[0]['top'] = node.top || 0;
        this.recurseSpace(node.child);
      }

      node.space = Math.max(
        1,
        _.reduce(child, (prev, next) => prev + next.space, 0)
      );
    });
  }

  //递归生成渲染数据
  public recurseNode(childs: any, result: any[] = []) {
    const column = childs[0]['column'];

    if (!result[column]) {
      result[column] = [];
    }

    const arr: any = _.map(childs, (node, i: number) => ({
      id: node.id,
      type: node.type,
      top: node.top,
      space: node.space,
      isHead: i === 0,
      isTail: i === childs.length - 1,
      hasChild: node.child.length > 0
    }));

    const last: any = _.last(result[column]);
    const head: any = _.head(arr);
    let pad = 0;

    if (last) {
      const { top, space } = _.last(last) as any;
      pad = top + space;
    }

    head.mt = head.top - pad; //将每组的MT存在第一个node的mt属性上

    result[column].push(arr);

    childs.forEach((node: any) => {
      if (node.child.length > 0) {
        this.recurseNode(node.child, result);
      }
    });

    //三维数组: [ column[ group[ node{} ] ] ]
    return result;
  }

  @computed
  public get drawList() {
    const arr = _.cloneDeep(this.dataFieldsList);

    if (!arr.length) {
      return [];
    }

    this.recurseSpace(arr);

    return this.recurseNode(arr);
  }

  //pipe管道相关
  @action.bound
  public changeModalVisible(visible: boolean) {
    //dataTable可见性
    this.visible = visible;

    if (!visible) {
      //关闭后计算一次该pipe的dataTable是否正确
      const pipe = this.selectedPipe;
      const { dataTable } = this.pipeConfigMap[pipe];
      const hasError =
        !dataTable.length ||
        _.find(dataTable, data => !data.main || !data.vice);

      this.pipeConfigMap[pipe]['verify'] = !hasError;
      this.selectedPipe = null;

      //关闭pipe后，需要将dataTable内存在的字段在fieldsList内设置checked和used为true
      this.resetFieldsListAttr(this.pipeConfigMap[pipe]);
    }
  }

  //重置字段列表的 checked和used 属性
  @action.bound
  public resetFieldsListAttr(pipe: any) {
    const { mainId, id } = pipe;

    let leftUsedFields: any[] = [],
      rightUsedFields: any[] = [];
    _.forEach(this.pipeConfigMap, p => {
      if (p.id === mainId) {
        leftUsedFields.push(..._.map(p.dataTable, 'vice'));
      }

      if (p.mainId === mainId) {
        leftUsedFields.push(..._.map(p.dataTable, 'main'));
      }

      if (p.id === id) {
        rightUsedFields.push(..._.map(p.dataTable, 'vice'));
      }

      if (p.mainId === id) {
        rightUsedFields.push(..._.map(p.dataTable, 'main'));
      }
    });

    leftUsedFields = _.uniq(leftUsedFields);
    rightUsedFields = _.uniq(rightUsedFields);

    _.forEach(this.fieldsList, field => {
      const key = `${field.sourceName}|:|${field.dataType}|:|${field.sourceFieldId}`;

      if (field.uniqueId === mainId) {
        if (_.includes(leftUsedFields, key)) {
          field.checked = true;
          field.used = true;
        } else {
          field.used = false;
        }
      }

      if (field.uniqueId === id) {
        if (_.includes(rightUsedFields, key)) {
          field.checked = true;
          field.used = true;
        } else {
          field.used = false;
        }
      }
    });
  }

  @action.bound
  public switchSelectedPipe(pipe: string) {
    this.selectedPipe = pipe;
  }

  //当前选中管道的linkType
  @computed
  public get currentPipeInfo() {
    const pipe = this.selectedPipe;

    return this.pipeConfigMap[pipe];
  }

  //当前选中管道主副节点字段，需拼接sourceName|:|dataType|:|id
  @computed
  public get fieldSelectList() {
    const pipe = this.selectedPipe;

    if (!pipe) {
      return [[], []];
    }

    const { id, mainId } = this.pipeConfigMap[pipe];
    const mainTitle = this.sourceTableMap[mainId]['name'];
    const viceTitle = this.sourceTableMap[id]['name'];

    const mainFields = _.map(
      _.filter(this.fieldsList, ['uniqueId', mainId]),
      field => ({
        ...field,
        uniKey: `${field.sourceName}|:|${field.dataType}|:|${field.sourceFieldId}`
      })
    );
    const viceFields = _.map(
      _.filter(this.fieldsList, ['uniqueId', id]),
      field => ({
        ...field,
        uniKey: `${field.sourceName}|:|${field.dataType}|:|${field.sourceFieldId}`
      })
    );

    return [mainFields, viceFields, mainTitle, viceTitle];
  }

  //更新管道linkType / dataTable
  @action.bound
  public updatePipeConfig(prop: string, value: any, key?: any, index?: any) {
    const pipe = this.selectedPipe;

    if (prop === 'linkType') {
      this.pipeConfigMap[pipe][prop] = value;
    }

    if (prop === 'dataTable') {
      this.pipeConfigMap[pipe][prop][index][key] = value;
    }

    this.markChange();
  }

  //当前选中管道的dataTable数据
  @computed
  public get currentDataTableList() {
    const pipe = this.selectedPipe;

    if (!pipe) {
      return [];
    }

    const dataTable = this.pipeConfigMap[pipe]['dataTable'];

    return _.map(dataTable, (data: any, index: number) => ({
      ...data,
      key: index
    }));
  }

  //dataTable新增数据
  @action.bound
  public addNewTableData() {
    const pipe = this.selectedPipe;
    const key = this.pipeConfigMap[pipe]['dataTable'].length;

    this.pipeConfigMap[pipe]['dataTable'].push({
      key,
      main: undefined,
      vice: undefined
    });

    this.markChange();
  }

  //dataTable删除数据
  @action.bound
  public deleteTableData(keys: number[]) {
    const pipe = this.selectedPipe;

    _.forEach(keys, key => {
      this.pipeConfigMap[pipe]['dataTable'].splice(key, 1);
    });

    this.markChange();
  }

  //修改表名后，更新fieldsList内的表名
  @action.bound
  public updateFieldsListTableName(id: string, tableName: string) {
    _.forEach(this.fieldsList, field => {
      if (field.uniqueId === id) {
        field.tableName = tableName;
      }
    });

    this.markChange();
  }

  //将选中项的checked值设为false
  @action.bound
  public updateFieldsListChecked(keys: any[]) {
    // let hasUsedField = false;

    _.forEach(this.fieldsList, field => {
      const { key } = field;

      if (_.includes(keys, key)) {
        field.checked = false;
        // if (used) {
        //   hasUsedField = true;
        // } else {
        //   field.checked = false;
        // }
      }
    });

    // if (hasUsedField) {
    //   message.warning('关联关系中已使用的字段不允许删除!');
    // }

    this.markChange();
  }

  //整个更新fieldsList
  @action.bound
  public updateFieldsList(list: any[]) {
    this.fieldsList = list;
    this.markChange();
  }

  @action.bound
  public updateFieldsListItem(key: any, name: string, value: any) {
    const target: any = _.find(this.fieldsList, ['key', key]);

    target[name] = value;

    this.markChange();
  }

  //根据模型id检测重复的数据模型，生成table索引
  @action.bound
  public generateTableIndex(modelId: any) {
    let max = 0;
    const sameTables = _.filter(this.sourceTableMap, ['id', modelId]);

    if (sameTables.length) {
      max = (_.maxBy(sameTables, 'index') as any)['index'] + 1;
    }

    return max;
  }

  //注册手动打开弹窗func
  public registerOpenPipeFunc(callback: any) {
    this.manuallyOpenPipe = callback;
  }
}

export default AreaStore;
