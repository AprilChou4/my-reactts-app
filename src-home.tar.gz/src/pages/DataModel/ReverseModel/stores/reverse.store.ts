import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';
import {
  getDataSourceList,
  getOdsTables,
  getOdsSourceIds,
  getSegmentTheme,
  generateModel
} from '../reverse.service';

class ReverseStore {
  public sourceMap: any = {};
  @observable public step = 1;
  @observable public selectedSource: any = {}; //当前选中数据源
  @observable public sourceList: any[] = []; //数据源列表
  @observable public sourceLoading = false; //数据源列表loading
  @observable public searchParams: any = {
    tableName: '',
    pageIndex: 1,
    pageSize: 20
  };
  @observable public tableCount = 0;
  @observable public tableList: any[] = [];
  @observable public tableLoading = false;
  @observable public chooseTable: any[] = [];
  @observable public resultTable: any[] = []; //结果列表
  @observable public themeList: any[] = []; //主题域列表
  @observable public saving = false;

  public constructor(segmentId: any) {
    this.getSourceList('all');
    this.getThemeList(segmentId);
  }

  @action.bound
  public updateStep(step: number) {
    this.step = step;
  }

  @action.bound
  public async getSourceList(type: string) {
    this.sourceLoading = true;

    const params = {
      catalog: {
        opr: '',
        val: ''
      },
      id: {
        opr: '',
        val: ''
      },
      name: {
        opr: '',
        val: ''
      },
      namespace: {
        opr: '',
        val: ''
      },
      orderBy: {
        name: ['update_time'],
        order: 'desc' //可能值： descend/ascend/false
      },
      pageFilter: {
        pageNum: 1,
        pageSize: 500
      },
      status: {
        opr: '',
        val: ''
      },
      subCatalog: {
        opr: '',
        val: ''
      }
    };

    if (type !== 'all') {
      params.subCatalog = {
        opr: 'in',
        val: type
      };
    }

    const res1 = await getOdsSourceIds();

    if (res1.code !== 200) {
      message.error(`${res1.message}`);
      return;
    }

    const res2 = await getDataSourceList(params);

    runInAction(() => {
      this.sourceLoading = false;

      if (res2.code !== 200) {
        message.error(`${res2.message}`);
        return;
      }

      //ods表内所有数据源id
      const { list: sourceIds = [] } = res1.data || {};

      //拼接全部数据源nav
      const { infos = [] } = res2.data || {};
      const list = _.filter(infos, item => _.includes(sourceIds, item.id));

      list.unshift({
        id: 'all',
        name: '全部',
        subCatalog: type, //类型跟数据源select值一致(all, mysql...)
        spec: { dbName: '' }
      });

      this.selectedSource = list[0];

      this.getList();

      this.sourceList = list;

      if (_.isEmpty(this.sourceMap)) {
        const map: any = {};

        _.forEach(list, item => {
          map[item.id] = item;
        });

        this.sourceMap = map;
      }
    });
  }

  @action.bound
  public handleSourceChange(id: any) {
    this.selectedSource = _.find(this.sourceList, ['id', id]);
    this.getList();
  }

  @action.bound
  public async getList() {
    const { id } = this.selectedSource;

    if (!id) {
      return;
    }

    this.tableLoading = true;

    const res = await getOdsTables({
      ...this.searchParams,
      sourceId: id === 'all' ? '' : id
    });

    runInAction(() => {
      this.tableLoading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      const {
        pagination: { total },
        list = []
      } = res.data || {};

      this.tableList = _.map(list, ({ odsTableName, sourceId, comment }) => {
        const { name, subCatalog, spec = {} } = this.sourceMap[sourceId] || {};

        return {
          id: odsTableName,
          tableName: odsTableName,
          tableCnName: comment,
          datasourceName: name || '--',
          datasourceType: subCatalog || '--',
          schemaName: spec.dbName || '--'
        };
      });
      this.tableCount = total;
    });
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }

  @action.bound
  public updateChooseTable(tables: any[]) {
    this.chooseTable = tables;
  }

  //主题域列表
  @action.bound
  public async getThemeList(segmentId: any) {
    const res = await getSegmentTheme(segmentId);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.themeList = res.data.list || [];
    });
  }

  @action.bound
  public async handleGenerateModel(values: any, errCallback: any) {
    this.saving = true;

    const modelReqs = _.map(values, item => {
      const {
        tableName,
        modelName,
        modelShowName,
        modelType,
        themeField,
        director,
        description,
        dataLevel
      } = item;

      return {
        odsTableName: tableName,
        modelName,
        modelPhysicalName: modelName,
        modelShowName,
        modelType,
        subjectDomainId: themeField,
        director: director ? director.name : undefined,
        description,
        dataLevel
      };
    });

    message.loading('解析中...');

    const res = await generateModel({ modelReqs });

    runInAction(() => {
      this.saving = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);

        errCallback(res.data);
        return;
      }

      const failMap = res.data || {};

      //标记各模型表状态
      _.forEach(modelReqs, (item: any) => {
        if (failMap[item.modelName] && !failMap[item.modelName].success) {
          item.status = 0;
          item.message = failMap[item.modelName].message;
        } else {
          item.status = 1;
        }
      });

      this.resultTable = modelReqs;
      this.step = 3;
    });
  }
}

export default ReverseStore;
