import React, { Component, Fragment, createRef } from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { inject, observer } from 'mobx-react';
import { message } from 'sup-ui';
import Stepper from '@components/Stepper';
import ChooseTable from './containers/ChooseTable';
import ConfirmModel from './containers/ConfirmModel';
import GenerateModel from './containers/GenerateModel';
import ReverseStore from './stores/reverse.store';
import styles from './index.less';

const steps = [
  { key: 1, showName: '选择物理表' },
  { key: 2, showName: '确认模型信息' },
  { key: 3, showName: '生成模型' }
];

interface IProps extends RouteComponentProps {
  global?: any;
}

interface IState {
  uniqueId: number; //标识是否需要更新模型信息
  cacheMap: any; //处理2,3步Table滚动样式问题
}

@inject('global')
@observer
class ReverseModel extends Component<IProps, IState> {
  private readonly confirmRef: any;
  private readonly store: ReverseStore;
  public constructor(props: IProps) {
    super(props);

    const { id } = (props.match.params as any) || {};
    this.store = new ReverseStore(id);
    this.confirmRef = createRef();
    this.state = {
      uniqueId: 0,
      cacheMap: {
        1: true,
        2: false,
        3: false
      }
    };
  }

  public handlePrev = () => {
    this.store.updateStep(1);
  };

  public handleNext = () => {
    const { cacheMap, uniqueId } = this.state;
    const { saving, step, chooseTable, updateStep, handleGenerateModel } =
      this.store;

    //下一步
    if (step === 1) {
      if (!chooseTable.length) {
        message.error('请选择至少一张物理表!');
        return;
      }

      updateStep(2);
      this.setState({
        uniqueId: uniqueId + 1,
        cacheMap: {
          ...cacheMap,
          2: true
        }
      });
    }

    //生成模型
    if (step === 2) {
      if (saving) {
        return;
      }

      const values = this.confirmRef.current.validateValues();

      if (!values) {
        return;
      }

      handleGenerateModel(values, (data: any) => {
        this.confirmRef.current.setDupModel(data);
      });
    }
  };

  public handleDone = () => {
    const { history, global, location } = this.props;

    history.push('/data-model/design');

    //重置模型树
    global.executeCacheMethod('/data-model/design', 'refreshModelTree', {});

    setTimeout(() => {
      global.closeTabPage([location.pathname]);
    });
  };

  public handleBack = () => {
    const { history } = this.props;

    history.push('/data-model/design');
  };

  public render() {
    const { step, chooseTable, themeList, saving, resultTable } = this.store;
    const { cacheMap, uniqueId } = this.state;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <a onClick={this.handleBack}>模型设计</a>
          <p>/ 逆向建模</p>
        </div>
        <div className={styles.content}>
          <div className={styles.step}>
            <Stepper step={step} dataSource={steps} />
          </div>
          <div className={styles.cont}>
            <div style={{ display: step === 1 ? 'block' : 'none' }}>
              <ChooseTable store={this.store} />
            </div>
            {cacheMap[2] && (
              <div style={{ display: step === 2 ? 'block' : 'none' }}>
                <ConfirmModel
                  ref={this.confirmRef}
                  sign={uniqueId}
                  dataSource={chooseTable}
                  loading={saving}
                  themeList={themeList}
                />
              </div>
            )}
            {step === 3 && (
              <GenerateModel dataSource={resultTable} themeList={themeList} />
            )}
          </div>
        </div>
        <div className={styles.footer}>
          <div className={styles.left}>
            {step === 2 && (
              <button className={styles.prev} onClick={this.handlePrev}>
                上一步
              </button>
            )}
          </div>
          <div className={styles.right}>
            {step === 3 ? (
              <button className={styles.done} onClick={this.handleDone}>
                完成
              </button>
            ) : (
              <Fragment>
                <button
                  className={styles.next}
                  onClick={this.handleNext}
                  disabled={saving}
                >
                  {step === 1 ? '下一步' : '开始生成'}
                </button>
                <button className={styles.cancel} onClick={this.handleDone}>
                  取消
                </button>
              </Fragment>
            )}
          </div>
        </div>
      </div>
    );
  }
}

export default ReverseModel;
