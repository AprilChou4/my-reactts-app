import React, { Component } from 'react';
import { Switch, Table } from 'sup-ui';
import { TableCellText } from '@components/Table';
import Extra from './Extra';
import { generateEnumMap } from '../../consts/typeMap';
import { fieldTypes } from '../../consts/enum';
import styles from '../index.less';

interface IProps {
  dataSource: any[];
}

interface IState {
  selectedRow: any;
}

class AttrFields extends Component<IProps, IState> {
  private readonly fieldTypeMap: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      selectedRow: null
    };
    this.fieldTypeMap = generateEnumMap(fieldTypes);
  }

  public getColumns = (): any[] => {
    return [
      {
        title: '字段名',
        dataIndex: 'name',
        width: 'auto',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '中文名',
        dataIndex: 'showName',
        width: 130,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '数据类型',
        dataIndex: 'dataType',
        width: 110,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段类型',
        dataIndex: 'fieldType',
        width: 110,
        className: 'ellipsis-hide',
        render: (text: string) => (
          <TableCellText text={this.fieldTypeMap[text]} />
        )
      },
      {
        title: '主键',
        width: 90,
        dataIndex: 'pkField',
        className: 'ellipsis-hide',
        render: (text: boolean) => <Switch disabled checked={text} />
      }
    ];
  };

  public handleRowClick = (record: any) => {
    const { name } = record;
    const { selectedRow } = this.state;
    const row = selectedRow && selectedRow.name === name ? null : record;

    this.setState({
      selectedRow: row
    });
  };

  public render() {
    const { dataSource } = this.props;
    const { selectedRow } = this.state;
    const columns = this.getColumns();

    return (
      <div className={styles.attrFields}>
        <div className={`${styles.list} mp-table-gray-light mp-table-grow`}>
          <Table
            rowKey="name"
            rowClassName={(record: any) =>
              selectedRow && record.name === selectedRow.name
                ? styles.selected
                : ''
            }
            onRow={(record: any) => ({
              onClick: () => this.handleRowClick(record)
            })}
            columns={columns}
            dataSource={dataSource}
            scroll={{ y: 'calc(100% - 40px)' }}
            pagination={false}
          />
        </div>
        {!_.isNil(selectedRow) && (
          <div className={styles.extra}>
            <Extra rowKey={selectedRow.key} values={selectedRow} />
          </div>
        )}
      </div>
    );
  }
}

export default AttrFields;
