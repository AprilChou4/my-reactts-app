import React, { Component, Fragment } from 'react';
import { Input } from 'sup-ui';
import styles from './index.less';

const { TextArea } = Input;

interface IProps {
  values: any;
}

interface IState {}

class Attr extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { dataType, dataDigit, dataSize, description } = this.props.values;

    return (
      <div className={styles.attrWrapper}>
        <ul>
          {dataType === 'STRING' && (
            <li>
              <span>长度</span>
              <p>{dataSize}</p>
            </li>
          )}
          {dataType === 'DECIMAL' && (
            <Fragment>
              <li>
                <span>长度</span>
                <p>{dataSize}</p>
              </li>
              <li>
                <span>精度</span>
                <p>{dataDigit}</p>
              </li>
            </Fragment>
          )}
          <li>
            <span>描述</span>
            <TextArea
              disabled={true}
              value={description}
              autosize={{ minRows: 2, maxRows: 2 }}
            />
          </li>
        </ul>
      </div>
    );
  }
}

export default Attr;
