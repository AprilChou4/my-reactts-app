import React, { Component } from 'react';
import { Table } from 'sup-ui';
import { TableCellText } from '@components/Table';
import styles from './index.less';

interface IProps {
  type: 'source' | 'target';
  dataSource: any;
  onScroll: any;
}

interface IState {}

class LineTable extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public getColumns = (): any[] => {
    return [
      {
        title: '字段',
        dataIndex: 'name',
        width: 'auto',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      // {
      //   title: '字段含义',
      //   dataIndex: 'comment',
      //   width: 'auto',
      //   className: 'ellipsis-hide',
      //   render: (text: string) => <TableCellText text={text} />
      // },
      {
        title: '数据类型',
        dataIndex: 'dataType',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      }
    ];
  };

  public handleTableScroll = (e: any) => {
    const {
      target: { scrollTop }
    } = e;

    this.props.onScroll(scrollTop);
  };

  public render() {
    const { dataSource, type } = this.props;
    const columns = this.getColumns();
    const title = type === 'source' ? '物理表字段' : '模型表字段';
    const rowKey = type === 'source' ? 'id' : 'name';

    return (
      <div className={styles.lineTable}>
        <div className={styles.tit}>{title}</div>
        <div
          className={`${styles.table} mp-table-grow`}
          onScroll={this.handleTableScroll}
        >
          <Table
            size="small"
            rowKey={rowKey}
            columns={columns}
            dataSource={dataSource}
            scroll={{ y: 'calc(100% - 36px)' }}
            pagination={false}
          />
        </div>
      </div>
    );
  }
}

export default LineTable;
