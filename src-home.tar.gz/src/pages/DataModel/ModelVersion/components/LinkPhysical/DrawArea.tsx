import React, { Component, createRef } from 'react';
import styles from './index.less';

const baseHeight = 48; //默认左右table行高一致，均为48px
const patchX = -23; //dom计算起始点

const generatePoints = (ids: any[], x = 0, scrollTop = 0) => {
  const map: any = {};

  _.reduce(
    ids,
    (prev, id) => {
      const [px, py] = prev;
      const ny = py + baseHeight;
      const nx = px;

      map[id] = [nx, ny];

      return [nx, ny];
    },
    [x, scrollTop]
  );

  return map;
};

interface IProps {
  scrollTop: any; //{ source, target }
  sourceIds: any; //ids
  targetIds: any;
  links: any; // [[ sourceId, targetId ], ...]
}

interface IState {
  canvas: any; //canvas信息 width height
  sourceIdPointMap: any; //{ '1': [x, y] } id与点坐标map
  targetIdPointMap: any; //{ '1': [x, y] }
  sources: any[]; //已连id
  targets: any[];
}

class DrawArea extends Component<IProps, IState> {
  private readonly areaRef: any;
  private readonly bottomRef: any;
  private bcanvas: any; //绘制连接的线
  public constructor(props: IProps) {
    super(props);

    this.state = {
      canvas: {
        width: 0,
        height: 0
      },
      sourceIdPointMap: {},
      targetIdPointMap: {},
      sources: [],
      targets: []
    };

    this.areaRef = createRef();
    this.bottomRef = createRef();
  }

  public drawLine = (
    ctx: any,
    sx: number,
    sy: number,
    ex: number,
    ey: number
  ) => {
    const theta = 22.5, //箭头夹角
      len = 12, //箭头斜边长
      angle = (Math.atan2(sy - ey, sx - ex) * 180) / Math.PI,
      angle1 = ((angle + theta) * Math.PI) / 180,
      angle2 = ((angle - theta) * Math.PI) / 180,
      topX = len * Math.cos(angle1),
      topY = len * Math.sin(angle1),
      botX = len * Math.cos(angle2),
      botY = len * Math.sin(angle2);
    let arrowX, arrowY;

    //画直线
    ctx.moveTo(sx, sy);
    ctx.lineTo(ex, ey);

    //画箭头
    arrowX = ex + topX;
    arrowY = ey + topY;

    ctx.moveTo(arrowX, arrowY);
    ctx.lineTo(ex, ey);

    arrowX = ex + botX;
    arrowY = ey + botY;

    ctx.lineTo(arrowX, arrowY);
  };

  //在bcanvas上绘制所有连线
  public drawing = () => {
    const { links } = this.props;
    const { canvas, sourceIdPointMap, targetIdPointMap } = this.state;
    const ctx = this.bcanvas;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.beginPath();

    ctx.strokeStyle = '#0f71e2';
    ctx.fillStyle = '#0f71e2';
    ctx.lineWidth = 1;

    _.forEach(links, ([sourceId, targetId]) => {
      const [sx, sy] = sourceIdPointMap[sourceId];
      const [tx, ty] = targetIdPointMap[targetId];

      this.drawLine(ctx, sx, sy, tx, ty);
    });

    ctx.fill();
    ctx.stroke();
  };

  public handleRepaintLines = () => {
    const {
      canvas: { width }
    } = this.state;
    const {
      sourceIds,
      targetIds,
      scrollTop: { source, target }
    } = this.props;

    const sourceIdPointMap = generatePoints(sourceIds, 9, patchX - source);
    const targetIdPointMap = generatePoints(
      targetIds,
      width - 9,
      patchX - target
    );

    this.setState({
      sourceIdPointMap,
      targetIdPointMap
    });

    window.requestAnimationFrame(this.drawing);
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { scrollTop, links, sourceIds, targetIds } = this.props;
    if (!_.isEqual(prevProps.scrollTop, scrollTop)) {
      this.handleRepaintLines();
    }

    if (
      !_.isEqual(prevProps.links, links) ||
      !_.isEqual(prevProps.sourceIds, sourceIds) ||
      !_.isEqual(prevProps.targetIds, targetIds)
    ) {
      const sources: any[] = [],
        targets: any[] = [];

      _.forEach(links, ([sourceId, targetId]) => {
        sources.push(sourceId);
        targets.push(targetId);
      });

      this.setState({
        sources,
        targets
      });

      this.handleRepaintLines();
    }
  }

  public initData = () => {
    const { sourceIds, targetIds, links } = this.props;
    const { width, height } = this.areaRef.current.getBoundingClientRect();
    const sources: any[] = [],
      targets: any[] = [];

    this.bcanvas = this.bottomRef.current.getContext('2d');

    const sourceIdPointMap = generatePoints(sourceIds, 9, patchX);
    const targetIdPointMap = generatePoints(targetIds, width - 9, patchX);

    _.forEach(links, ([sourceId, targetId]) => {
      sources.push(sourceId);
      targets.push(targetId);
    });

    this.setState({
      canvas: {
        width,
        height
      },
      sourceIdPointMap,
      targetIdPointMap,
      sources,
      targets
    });

    setTimeout(() => {
      this.drawing();
    });
  };

  public componentDidMount() {
    this.initData();
  }

  public render() {
    const {
      canvas: { width, height }
    } = this.state;
    const {
      scrollTop: { source, target },
      sourceIds,
      targetIds
    } = this.props;

    return (
      <div className={styles.drawArea} ref={this.areaRef}>
        <div className={styles.domLayer} draggable={false}>
          <ul style={{ top: -source, left: 0 }}>
            {sourceIds.map((id: any) => (
              <li key={id}>
                <span />
              </li>
            ))}
          </ul>
          <ul className={styles.r} style={{ top: -target, right: 0 }}>
            {targetIds.map((id: any) => (
              <li key={id}>
                <span />
              </li>
            ))}
          </ul>
        </div>
        <canvas
          className={styles.canvas2}
          width={width}
          height={height}
          ref={this.bottomRef}
        />
        <div className={styles.mask} />
      </div>
    );
  }
}

export default DrawArea;
