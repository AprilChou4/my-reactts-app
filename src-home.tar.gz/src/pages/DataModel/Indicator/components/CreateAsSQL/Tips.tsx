import React, { Component } from 'react';
import DialogModal from '@components/Modal/Dialog';
import styles from './index.less';

interface IProps {
  visible: boolean;
  onVisibleChange: any;
}

interface IState {}

class Tips extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { visible, onVisibleChange } = this.props;

    return (
      <DialogModal
        width={580}
        title="编写提示"
        visible={visible}
        maskClosable={true}
        bodyStyle={{ padding: 0 }}
        onCancel={() => onVisibleChange(false)}
        wrapClassName={styles.modalContainer}
        footer={null}
      >
        <div className={styles.tips}>
          <h3>示例语句：</h3>
          <section>
            <h4>SELECT</h4>
            <ul>
              <li>
                <span>sales time</span>
              </li>
              <li>
                <span>addr as address</span>
                <p>如果定义了字段别名，则返回参数名称为字段别名。</p>
              </li>
              <li>
                <span>sum(value) as total_amount</span>
                <p>如果是函数项，则必须给别名</p>
              </li>
              <li>
                <span>max(value)-min(value) as diff</span>
                <p>如果是组合运算项，则必须给别名</p>
              </li>
            </ul>
          </section>
          <section>
            <h4>FROM</h4>
            <ul>
              <li>
                <span>table_user</span>
              </li>
            </ul>
          </section>
          <section>
            <h4>WHERE</h4>
            <ul>
              <li>
                <span>{'user_id = 1;'}</span>
              </li>
            </ul>
          </section>
          <div className={styles.reminder}>
            <h5>注意：</h5>
            <ul>
              <li>1. 只支持作select查询的语句，且需满足mysql的查询语义</li>
              <li>2. select项中不支持 * 号查询</li>
              <li>
                3.
                指标项应是数值类型的字段，数值类型包括：INTEGER,LONG,FLOAT,DOUBLE,DECIMAL
              </li>
            </ul>
          </div>
        </div>
      </DialogModal>
    );
  }
}

export default Tips;
