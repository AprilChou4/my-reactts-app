export const matchFields = (str: string) => {
  let fieldArr: string[] = [];
  try {
    fieldArr = _.map(_.uniq(str.match(/\$(\w+)\$/g)), i => i.slice(1, -1));
  } catch (error) {
    console.error(error);
  }
  return fieldArr;
};

export const matchVar = (str: string) => {
  let fieldArr: string[] = [];
  try {
    fieldArr = _.map(_.uniq(str.match(/\#(\w+)\#/g)), i => i.slice(1, -1));
  } catch (error) {
    console.error(error);
  }
  return fieldArr;
};
