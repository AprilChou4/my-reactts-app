import React, {
  FC,
  Fragment,
  useState,
  useRef,
  useMemo,
  useEffect
} from 'react';
import { Radio, Tree, Input } from 'sup-ui';
import classnames from 'classnames';
import HOCDndProvider from '@components/HOCDndProvider';
import TipItem from './TipItem';
import DragItem from './DragItem';
import DropWrapper from './DropWrapper';
import { fun, getCommonFun } from './expr.const';
import styles from './index.less';
import { ModelFieldType } from '../../const/enmu';
const { TreeNode } = Tree;
const { TextArea } = Input;

const commonFun = getCommonFun();

interface IProps {
  expr?: string;
  fields: any;
  isCustom?: boolean;
  onChange: (expr: string) => void;
}

const SqlExpression: FC<IProps> = (props: IProps) => {
  const [exprString, setExprString] = useState(_.get(props, 'expr', ''));
  const [siderView, setSiderView] = useState('field');
  const [cursorPositon, setCursorPositon] = useState(0);
  const expressionRef = useRef<any>(null);
  const [expandedKeys, setExpandedKeys] = useState(['1']);
  const fileterFields = useMemo(() => {
    const tempfields: any[] = [];
    ModelFieldType.forEach(item => {
      _.forEach(props.fields[item.attrName], iter => tempfields.push(iter));
    });
    return tempfields;
  }, [props.fields.timer, props.fields.dimension, props.fields.indicator]);

  useEffect(() => {
    props.onChange(exprString);
  }, [exprString]);

  const handleSiderChange = (e: any) => {
    setSiderView(e.target.value);
  };

  const handleExprChange = (e: any) => {
    const { value } = e.target;
    setExprString(value);
    setCursorPositon(expressionRef.current.textAreaRef.selectionStart);
  };

  const handleExprInsert = (insertText: string) => {
    const expr1 = exprString.slice(0, cursorPositon);
    const expr2 = exprString.slice(cursorPositon);
    setExprString(expr1 + insertText + expr2);

    // 更新光标位置
    expressionRef.current.textAreaRef.focus();
    setTimeout(() => {
      expressionRef.current.textAreaRef.selectionStart =
        cursorPositon + insertText.length;
      expressionRef.current.textAreaRef.selectionEnd =
        cursorPositon + insertText.length;
    });
    setCursorPositon(cursorPositon + insertText.length);
  };

  const handleTextAreaClick = () => {
    setCursorPositon(expressionRef.current.textAreaRef.selectionStart);
  };

  const renderFunTreeNode = (data: any[]) => {
    return _.map(data, item => {
      if (item.children) {
        return (
          <TreeNode key={item.key} title={item.menuName}>
            {renderFunTreeNode(item.children)}
          </TreeNode>
        );
      }
      return props?.isCustom
        ? !item.disabled && item.customEnable && (
            <TreeNode
              key={item.displayName}
              title={
                <DragItem
                  value={item.expr}
                  displayName={item.displayName}
                  tooltip={
                    <Fragment>
                      <TipItem name="示例" value={item.expr} />
                      <TipItem name="描述" value={item.description} />
                    </Fragment>
                  }
                  valueType="fun"
                  onClick={() => {
                    handleExprInsert(item.expr);
                  }}
                />
              }
            />
          )
        : !item.disabled && (
            <TreeNode
              key={item.displayName}
              title={
                <DragItem
                  value={item.expr}
                  displayName={item.displayName}
                  tooltip={
                    <Fragment>
                      <TipItem name="示例" value={item.expr} />
                      <TipItem name="描述" value={item.description} />
                    </Fragment>
                  }
                  valueType="fun"
                  onClick={() => {
                    handleExprInsert(item.expr);
                  }}
                />
              }
            />
          );
    });
  };

  const handeleExpand = (keys: string[]) => {
    setExpandedKeys(keys);
  };
  return (
    <HOCDndProvider>
      <dl className={styles.exprWrapper}>
        <dt className={styles.sider}>
          <Radio.Group
            className={styles.tabHeader}
            value={siderView}
            size="small"
            onChange={handleSiderChange}
          >
            <Radio.Button value="field">字段</Radio.Button>
            <Radio.Button value="fun">函数</Radio.Button>
          </Radio.Group>
          <div
            className={classnames(
              styles.tabWrapper,
              styles.funList,
              siderView === 'fun' && styles.tabActive
            )}
          >
            <Tree expandedKeys={expandedKeys} onExpand={handeleExpand}>
              {renderFunTreeNode(fun)}
            </Tree>
          </div>
          <ul
            className={classnames(
              styles.tabWrapper,
              siderView === 'field' && styles.tabActive
            )}
          >
            {_.map(fileterFields, item => (
              <li key={item.name} className={styles.fieldItem}>
                <DragItem
                  value={item.name}
                  displayName={item.name}
                  tooltip={
                    <Fragment>
                      <TipItem name="字段" value={item.name} />
                      <TipItem name="中文" value={item.showName} />
                      <TipItem
                        name="类型"
                        value={_.get(item, 'fieldDataType.name', '')}
                      />
                    </Fragment>
                  }
                  valueType="field"
                  onClick={() => {
                    handleExprInsert(`${item.name}`);
                  }}
                />
              </li>
            ))}
          </ul>
        </dt>
        <dd className={styles.content}>
          <ul className={styles.commonFun}>
            {_.map(commonFun, i => (
              <li
                className={styles.commonFunItem}
                key={i.displayName}
                onClick={() => {
                  handleExprInsert(i.expr);
                }}
              >
                <DragItem
                  value={i.expr}
                  displayName={i.displayName}
                  tooltip={
                    <Fragment>
                      <TipItem name="示例" value={i.expr} />
                      <TipItem name="描述" value={i.description} />
                    </Fragment>
                  }
                  valueType="fun"
                />
              </li>
            ))}
          </ul>
          <div className={styles.editWrapper}>
            <DropWrapper
              onDrop={(v: any) => {
                const value = _.get(v, 'target');
                handleExprInsert(value);
              }}
            >
              <TextArea
                rows={18}
                className={styles.textArea}
                value={exprString}
                onChange={handleExprChange}
                onClick={handleTextAreaClick}
                ref={expressionRef}
              />
            </DropWrapper>
          </div>
        </dd>
      </dl>
    </HOCDndProvider>
  );
};

export default SqlExpression;
