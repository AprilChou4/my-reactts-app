import React, { FC, useState } from 'react';
import { Form, Input, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form';
import CommonDrawer from '@components/Drawer/CommonDrawer';
import { checkUniqueName } from '../../utils';
const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  info: any;
  DragedLists: any;
  onOk: (params: any) => void;
  onCancel: () => void;
}
/**
 * 维度组件
 */
const DimensionDrawer: FC<IProps> = ({
  info,
  DragedLists,
  form,
  onOk,
  onCancel
}: IProps) => {
  const [state, setState] = useState({
    dimName: info.dimName || info.name,
    dimPhysicalName: info.dimPhysicalName || info.name,
    sort: info.sort
  });

  const handleOk = () => {
    form.validateFields(errors => {
      if (errors) return;
      if (!checkUniqueName(state.dimName, DragedLists, info)) {
        message.error('已存在相同名称的数据期,维度或指标');
        return;
      }
      onOk(state);
    });
  };
  const handleInputChange = (e: any) => {
    setState({
      ...state,
      dimName: e.target.value,
      dimPhysicalName: e.target.value
    });
  };
  return (
    <CommonDrawer
      visible={true}
      title={info.name}
      width="520"
      onOk={handleOk}
      onCancel={onCancel}
    >
      <FormItem label="维度列名称">
        {form.getFieldDecorator('dimName', {
          initialValue: state.dimName || '',
          rules: [
            { required: true, message: '内容不能为空' },
            { max: 50, message: '长度不能超过50' }
          ]
        })(<Input onChange={handleInputChange} />)}
      </FormItem>
    </CommonDrawer>
  );
};

export default Form.create<IProps>({})(DimensionDrawer);
