import React, { FC, useState } from 'react';
import { Button, message } from 'sup-ui';

import SQLExpression from '../SQLExpression';
import CommonDrawer from '@components/Drawer/CommonDrawer';

interface IProps {
  isEdit: boolean;
  expr: string;
  fields: any;
  onOk: (expr: string) => void;
  onCancel: () => void;
  filterTest: (params: any) => Promise<any>;
  dataModel: any;
}

const FilterDrawer: FC<IProps> = (props: IProps) => {
  const [exprString, setExprString] = useState(_.get(props, 'expr', ''));
  const [checked, setChecked] = useState(props.isEdit ? true : false);
  const [loading, setLoading] = useState(false);

  const handleOk = () => {
    if (!checked && exprString) {
      message.error('请先通过SQL语法验证');
      return;
    }
    props.onOk(exprString);
  };

  const handleFilterTest = async () => {
    if (!exprString) {
      message.error('过滤条件不能为空');
      return;
    }
    if (props.dataModel.id) {
      setLoading(true);
      const res = await props.filterTest({
        baseModelId: props.dataModel.id,
        filter: exprString
      });
      if (res.code !== 200) {
        message.error(res.message);
        setLoading(false);
        return;
      }
      if (res.code === 200) {
        setLoading(false);
        if (res.data.success === false) {
          message.error('条件校验未通过，请检查过滤语句');
          return;
        }
        if (res.data.success) {
          setChecked(true);
          message.success('条件校验通过');
        }
      }
    }
  };
  const handleExprChange = (str: string) => {
    setExprString(str);
    checked && setChecked(false);
  };

  return (
    <CommonDrawer
      visible={true}
      title={'数据过滤'}
      width="800"
      onOk={handleOk}
      onCancel={props.onCancel}
    >
      <SQLExpression
        isCustom
        expr={props.expr}
        fields={props.fields}
        onChange={handleExprChange}
      />
      <Button
        disabled={loading}
        size="large"
        ghost
        style={{ position: 'absolute', bottom: '20px', right: '20px' }}
        onClick={handleFilterTest}
      >
        验证
      </Button>
    </CommonDrawer>
  );
};

export default FilterDrawer;
