import React, { FC, useRef, Fragment } from 'react';
import { useDrag } from 'ahooks';
import { FieldModelType } from '../../IndicatorDevelop/store/createAsWM.store';
import { Tooltip, Row, Col } from 'sup-ui';
import styles from './index.less';
interface DragItemProps {
  data: FieldModelType;
}

const DragItem: FC<DragItemProps> = ({ data }: DragItemProps) => {
  const dragRef = useRef(null);
  //const [dragging, setDragging] = useState(false);
  useDrag(data, dragRef, {
    // onDragStart: () => {
    //   setDragging(true);
    // },
    // onDragEnd: () => {
    //   setDragging(false);
    // }
  });
  return (
    <div ref={dragRef}>
      <Tooltip
        overlayClassName={styles.tooltipWrapper}
        placement={'right'}
        mouseEnterDelay={0.5}
        title={
          <Fragment>
            <Row>
              <Col span={7} className={styles.tooltipLabel}>
                字段名
              </Col>
              <Col span={17}>{data.name}</Col>
            </Row>
            <Row>
              <Col span={7} className={styles.tooltipLabel}>
                中文名
              </Col>
              <Col span={17}>{data.showName}</Col>
            </Row>
            <Row>
              <Col span={7} className={styles.tooltipLabel}>
                类型
              </Col>
              <Col span={17}>{data.fieldDataType.name}</Col>
            </Row>
          </Fragment>
        }
      >
        <div className={styles.dragItemname}>{data.showName || data.name}</div>
      </Tooltip>
    </div>
  );
};

export default DragItem;
