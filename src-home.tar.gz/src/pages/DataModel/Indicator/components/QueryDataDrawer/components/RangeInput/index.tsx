/**
 * 范围值输入组件（不包含Form的处理，纯输入组件）
 *
 * @demo
 <RangeInput
 placeholder={['最小值','~','最大值']}
 rows='8'
 maxlength="500"
 styles={[]}
 />
 */
//  Integer:[-2147483648,2147483647]
//  Long:[-9223372036854775808, 9223372036854775807]
//  Float: 无限制
//  Double: 无限制
//  Decimal: M: [1,27] , D：[1,9]，默认0，且D<=M

import React, { PureComponent } from 'react';
import { Input, InputNumber } from 'sup-ui';
import classnames from 'classnames';
import styles from './index.less';

interface IProps {
  value?: any;
  onChange?: (v: any) => void;
  style?: React.CSSProperties;
  placeholder?: string[];
  styleArr?: any[];
  min?: number;
  max?: number;
  precision?: number;
  formatter?: any;
  parser?: any;
  className?: string;
}
interface IState {
  value: any;
}
class RangeInput extends PureComponent<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      value: props.value || []
    };
  }
  public static defaultProps = {
    min: -2147483648,
    max: 2147483647
  };

  public static getDerivedStateFromProps(nextProps: IProps) {
    // Should be a controlled component.
    if ('value' in nextProps) {
      return {
        ...({ value: nextProps.value } || {})
      };
    }
    return null;
  }

  public handleInputChange = (value: any, index: number) => {
    const { value: oldValue = [] } = this.state;
    const { onChange } = this.props;
    oldValue[index] = value;
    this.setState({ value: oldValue });
    if (onChange) {
      onChange(oldValue);
    }
  };

  /* 限制数字输入框只能输入整数 */
  public limitNumber = (value: any) => {
    const { precision } = this.props;
    // 只能为整数
    if (precision === 0) {
      return String(value).replace(/[^-\d]/g, '');
    }
    return value;
  };

  public render() {
    const {
      placeholder,
      styleArr,
      min,
      max,
      style,
      formatter,
      parser,
      precision,
      className
    } = this.props;
    const { value } = this.state;
    return (
      <Input.Group
        compact
        style={style}
        className={classnames(styles.rangeInput, className)}
      >
        <div className={styles.rangeWrap}>
          <InputNumber
            style={styleArr && styleArr[0]}
            className={styles.firstInputNum}
            min={min}
            max={max}
            precision={precision}
            formatter={formatter}
            parser={parser || this.limitNumber}
            placeholder={(placeholder && placeholder[0]) || '最小值'}
            value={value && value[0]}
            onChange={e => this.handleInputChange(e, 0)}
          />

          <Input
            style={styleArr && styleArr[1]}
            className={styles.midInput}
            placeholder={(placeholder && placeholder[1]) || '~'}
            disabled
          />

          <InputNumber
            style={styleArr && styleArr[2]}
            className={styles.lastInputNum}
            precision={precision}
            formatter={formatter}
            parser={parser || this.limitNumber}
            placeholder={(placeholder && placeholder[2]) || '最大值'}
            value={value && value[1]}
            onChange={e => this.handleInputChange(e, 1)}
            min={(value && Number(value[0])) || min}
            max={max}
          />
        </div>
      </Input.Group>
    );
  }
}

export default RangeInput;
