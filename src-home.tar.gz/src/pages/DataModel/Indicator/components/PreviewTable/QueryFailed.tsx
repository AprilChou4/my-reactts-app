import React, { FC } from 'react';
import styles from './index.less';
import Icon from '@components/Icon';
interface IProps {
  message: string;
}
const QueryFialed: FC<IProps> = props => {
  return (
    <div className={styles.failedContainer}>
      <div className={styles.title}>
        <Icon type="error" width={'18px'} height={'18px'} />
        <h3>查询数据失败</h3>
      </div>
      <div className={styles.content}>{props.message}</div>
    </div>
  );
};

export default QueryFialed;
