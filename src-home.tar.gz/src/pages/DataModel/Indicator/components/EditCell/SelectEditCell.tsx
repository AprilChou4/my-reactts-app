import React, { FunctionComponent } from 'react';

import { Select, Form } from 'sup-ui';
import styles from './index.less';
const FormItem = Form.Item;
const { Option } = Select;
interface ICellProps {
  lists: any[];
  formKey: string;
  getFieldDecorator: any;
  initialValue: string | undefined;
  onChange: (value: string) => void;
  keyName?: string;
  valueName?: string;
  valueAsKey?: boolean; //是否以key作为值
}

const SelectEditCell: FunctionComponent<ICellProps> = (props: ICellProps) => {
  const keyName = props.keyName || 'id';
  const valueName = props.valueName || 'userName';
  const valueAsKey = props.valueAsKey || false;

  return (
    <FormItem className={styles.formItem}>
      {props.getFieldDecorator(props.formKey, {
        initialValue: props.initialValue || undefined,
        rules: [
          {
            required: true,
            message: '-请选择-'
          }
        ],
        validateTrigger: ['onChange']
      })(
        <Select
          showSearch
          placeholder="—请选择—"
          size="small"
          style={{ width: '120px' }}
          onChange={props.onChange}
        >
          {props.lists.map(item => (
            <Option
              key={item[keyName]}
              value={valueAsKey ? item[keyName] : item[valueName]}
            >
              {item[valueName]}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};
export default SelectEditCell;
