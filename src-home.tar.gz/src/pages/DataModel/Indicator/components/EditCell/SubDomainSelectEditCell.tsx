import React, { FunctionComponent, useEffect, useState } from 'react';
import { Select, Form } from 'sup-ui';
import styles from './index.less';
const FormItem = Form.Item;
const { Option } = Select;
interface ICellProps {
  formKey: string;
  getFieldDecorator: any;
  initialValue: string | undefined;
  onChange: (value: string) => void;
  lists: any[];
  segmentId: number | undefined;
}

const SelectEditCell: FunctionComponent<ICellProps> = (props: ICellProps) => {
  const [domainList, setDomainList] = useState<any[]>([]);
  useEffect(() => {
    setDomainList(
      props.lists.filter(item => item.businessSegmentId === props.segmentId)
    );
  }, [props.lists, props.segmentId]);
  return (
    <FormItem className={styles.formItem}>
      {props.getFieldDecorator(props.formKey, {
        initialValue: props.initialValue || undefined,
        rules: [
          {
            required: true,
            message: '-请选择-'
          }
        ],
        validateTrigger: ['onChange']
      })(
        <Select
          showSearch
          placeholder="—请选择—"
          size="small"
          style={{ width: '120px' }}
          onChange={props.onChange}
        >
          {domainList.map(item => (
            <Option key={item.id} value={item.id}>
              {item.showName}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};
export default SelectEditCell;
