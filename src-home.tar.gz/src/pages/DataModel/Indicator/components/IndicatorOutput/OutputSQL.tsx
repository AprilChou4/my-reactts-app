import React, { FunctionComponent, Fragment } from 'react';
import { Form, Input, Select } from 'sup-ui';
import { nameRule } from '@consts/rules';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  getFieldDecorator: any;
  sourceType: undefined | string;
  sourceTypes: any[];
  sourceList: any[];
  loading: boolean;
  resourceId: undefined | string;
  formName: string;
  formAlias: string;
  getSourceList: (sourceType: string) => void;
}

const OutputSQL: FunctionComponent<IProps> = (props: IProps) => {
  const {
    getFieldDecorator,
    resourceId,
    loading,
    formName,
    formAlias,
    sourceType,
    sourceTypes,
    sourceList,
    getSourceList
  } = props;
  return (
    <Fragment>
      <FormItem label="数据源类型">
        {getFieldDecorator('sourceType', {
          initialValue: sourceType,
          rules: [{ required: true, message: '请选择数据源类型!' }]
        })(
          <Select
            placeholder="—请选择—"
            loading={loading}
            onChange={(value: string) => {
              getSourceList(value);
            }}
          >
            {_.map(sourceTypes, item => (
              <Option
                key={item.id}
                value={item.id}
                disabled={item.id !== 'mysql'}
              >
                {item.showName}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      <FormItem label="数据源">
        {getFieldDecorator('resourceId', {
          initialValue: resourceId,
          rules: [{ required: true, message: '请选择数据源!' }]
        })(
          <Select placeholder="—请选择—" loading={loading}>
            {_.map(sourceList, item => (
              <Option key={item.id} value={item.id}>
                {item.showName}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      <FormItem label="表中文名" colon={false}>
        {getFieldDecorator('formName', {
          initialValue: formName,
          rules: [
            { message: `请输入表单模板名称`, required: true },
            { max: 50, message: `长度不能超过50!` }
          ]
        })(<Input />)}
      </FormItem>
      <FormItem label="表名" colon={false}>
        {getFieldDecorator('formAlias', {
          initialValue: formAlias,
          rules: [
            { message: `请输入表单模板别名`, required: true },
            { pattern: nameRule.pattern, message: nameRule.message }
          ]
        })(<Input />)}
      </FormItem>
    </Fragment>
  );
};

export default OutputSQL;
