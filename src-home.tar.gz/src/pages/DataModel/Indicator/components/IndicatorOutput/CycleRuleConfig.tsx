import React, { Component } from 'react';
import { Form, DatePicker, Radio } from 'sup-ui';
import moment from 'moment';

import CycleDay from './CycleTime/CycleDay';
import CycleHour from './CycleTime/CycleHour';
import CycleWeek from './CycleTime/CycleWeek';
import CycleMonth from './CycleTime/CycleMonth';
import CycleMinute from './CycleTime/CycleMinute';

import styles from './index.less';

interface IProps {
  form: any;
  ruleInfo: any;
  updateHourRule: (rule: boolean) => void;
}
interface IState {
  timeType: string;
  effectDate: any[];
}

const FormItem = Form.Item;
const { RangePicker } = DatePicker;

class CycleRuleConfig extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const { ruleInfo } = props;
    const startDate = moment();
    const endDate = moment().add(1, 'months');
    const effectDate = _.get(ruleInfo, 'effectDate', [startDate, endDate]);

    this.state = {
      effectDate,
      timeType: _.get(ruleInfo, 'timeType', 'day')
    };
  }

  public cycleTimeNode = () => {
    const { timeType } = this.state;
    const { form, ruleInfo, updateHourRule } = this.props;

    switch (timeType) {
      case 'minute':
        return <CycleMinute form={form} ruleInfo={ruleInfo} />;
      case 'hour':
        return (
          <CycleHour
            form={form}
            ruleInfo={ruleInfo}
            updateHourRule={updateHourRule}
          />
        );
      case 'day':
        return <CycleDay form={form} ruleInfo={ruleInfo} />;
      case 'week':
        return <CycleWeek form={form} ruleInfo={ruleInfo} />;
      case 'month':
        return <CycleMonth form={form} ruleInfo={ruleInfo} />;
      default:
        return null;
    }
  };

  public handleCuringChange = (e: any) => {
    const {
      target: { value }
    } = e;
    this.setState(
      {
        timeType: value
      },
      () => {
        const { timeType } = this.state;
        if (timeType === 'minute' || timeType === 'hour') {
          this.props.form.setFieldsValue({
            startTimeMinute: '0',
            endTimeMinute: '23'
          });
        }
      }
    );
  };

  public render() {
    const {
      form: { getFieldDecorator }
    } = this.props;
    const {
      timeType,
      effectDate: [startDate, endDate]
    } = this.state;

    return (
      <div className={styles.cycleRule}>
        <FormItem label="生效时间">
          {getFieldDecorator('effectDate', {
            rules: [
              {
                required: true,
                message: '请选择生效时间'
              }
            ],
            initialValue: [
              moment(startDate, 'YYYY-MM-DD'),
              moment(endDate, 'YYYY-MM-DD')
            ]
          })(<RangePicker allowClear={false} />)}
        </FormItem>
        <FormItem label="固化周期">
          {getFieldDecorator('timeType', {
            rules: [
              {
                required: true,
                message: '请选择固化周期'
              }
            ],
            initialValue: timeType
          })(
            <Radio.Group onChange={this.handleCuringChange}>
              <Radio value="minute">分钟</Radio>
              <Radio value="hour">小时</Radio>
              <Radio value="day">日</Radio>
              <Radio value="week">周</Radio>
              <Radio value="month">月</Radio>
            </Radio.Group>
          )}
        </FormItem>
        {this.cycleTimeNode()}
      </div>
    );
  }
}

export default CycleRuleConfig;
