import React, { Component } from 'react';
import { Select } from 'sup-ui';

interface IProps {
  list: any[];
  value?: any;
  mode?: string;
  onChange?: any;
  disabled?: boolean;
}

const { Option } = Select;

class TimeOption extends Component<IProps> {
  public handleChange = (value: any) => {
    const { onChange } = this.props;
    if (onChange) {
      onChange(value);
    }
  };

  public render() {
    const { mode = '', list, disabled = false, value } = this.props;
    return (
      <Select
        mode={mode}
        value={value}
        disabled={disabled}
        onChange={this.handleChange}
      >
        {_.map(list, (item: any) => (
          <Option key={item.key} value={item.key} disabled={item.disabled}>
            {item.name}
          </Option>
        ))}
      </Select>
    );
  }
}

// const TimeOption: FunctionComponent<IProps> = (props: IProps) => {
//   const { onChange, mode = '', list, disabled = false, value } = props;

//   const handleChange = (value: any) => {
//     if (onChange) {
//       onChange(value);
//     }
//   };

//   return (
//     <Select
//       mode={mode}
//       value={value}
//       disabled={disabled}
//       onChange={handleChange}
//     >
//       {_.map(list, (item: any) => (
//         <Option key={item.key} value={item.key} disabled={item.disabled}>
//           {item.name}
//         </Option>
//       ))}
//     </Select>
//   );
// };

export default TimeOption;
