import React, { Component, Fragment } from 'react';
import { Form } from 'sup-ui';

import TimeOption from './TimeOption';

import { dayList, startMinute } from '../indicatorRuleConfig.helper';

interface IProps {
  form: any;
  ruleInfo: any;
}
interface IState {
  hourStatus: string;
}

const FormItem = Form.Item;

class CycleMonth extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const { ruleInfo } = props;
    this.state = {
      hourStatus: _.get(ruleInfo, 'hourStatus', '1')
    };
  }

  public handleChange = (e: any) => {
    const {
      target: { value }
    } = e;

    this.setState({
      hourStatus: value
    });
  };

  public render() {
    const {
      ruleInfo,
      form: { getFieldDecorator }
    } = this.props;
    return (
      <Fragment>
        <FormItem label="指定时间">
          {getFieldDecorator('appointMonth', {
            rules: [
              {
                required: true,
                message: '请选择结束时间'
              }
            ],
            initialValue: _.get(ruleInfo, 'appointMonth', ['2'])
          })(<TimeOption mode="tags" list={dayList} />)}
        </FormItem>
        <FormItem label="具体时间">
          {getFieldDecorator('specTimeMonth', {
            rules: [
              {
                required: true,
                message: '请选择结束时间'
              }
            ],
            initialValue: _.get(ruleInfo, 'specTimeMonth', ['0'])
          })(<TimeOption mode="tags" list={startMinute} />)}
        </FormItem>
      </Fragment>
    );
  }
}

export default CycleMonth;
