import React, { FunctionComponent } from 'react';

import Header from '@components/Header';

interface IProps {
  type?: number; //0 无 1 新增 2 编辑
}

const SourceHeader: FunctionComponent<IProps> = ({ type }: IProps) => {
  return (
    <Header
      style={{ height: '48px', boxShadow: 'none' }}
      left={
        <div>
          {type ? (
            <span style={{ fontSize: '14px', color: '#7f8fa4' }}>指标开发</span>
          ) : (
            <span style={{ fontSize: '16px', color: '#354052' }}>指标管理</span>
          )}
          {type === 1 && (
            <span style={{ fontSize: '16px', color: '#354052' }}>
              /新增指标
            </span>
          )}
          {type === 2 && (
            <span style={{ fontSize: '16px', color: '#354052' }}>
              /编辑指标
            </span>
          )}
        </div>
      }
    />
  );
};

export default SourceHeader;
