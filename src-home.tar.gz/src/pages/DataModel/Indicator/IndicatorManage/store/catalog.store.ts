import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import {
  createCatalog,
  updateCatalog,
  deleteCatalog,
  getCatalogTree,
  getCatalogList,
  getCatalogChildTree,
  moveCatalog
} from '../service/catalog.service';

export interface TreeNodeModel {
  parentId?: number | string;
  catalogId: number | string;
  name: string;
  children: TreeNodeModel[] | null;
  depth?: number;
}

class CatalogStore {
  private readonly onSelectTree: any;
  public readonly debounceGetCatalogList;
  @observable public treeLoading = false;
  @observable public treeNodes: TreeNodeModel[] = [];
  @observable public mapTreeNodeKey: any = {}; //目录id和treenode的映射
  @observable public selectedKeys: any[] = []; //选中的key
  @observable public expandedKeys: any[] = []; //展开的key
  @observable public selectedCatalog: any = {};
  @observable public searchCatalogList: any[] = []; // 目录查询列表

  @observable public searchText = ''; //目录查询searchText
  @observable public searchKey = ''; //目录查询searchText对应的key
  @observable public tabKey = 'catalog'; // catalog:指标目录 tag:业务主题

  @observable public selectedSubject: any = {
    id: -1,
    key: '-1',
    showName: '全部',
    isGroup: true
  }; // 选中的主题域

  @observable public modalLoading = false;
  @observable public addVisible = false; // 新增目录弹窗是否显示
  @observable public addType = 'root';

  public constructor(props: any) {
    const { onSelectTree } = props || {};
    // 获取目录
    this.debounceGetCatalogList = _.debounce(this.getCatalogList, 300);
    // 选中获取列表
    this.onSelectTree = onSelectTree;
  }

  @action.bound
  public updateTabkey(key: string) {
    this.tabKey = key;
    const node =
      key === 'catalog' ? this.selectedCatalog : this.selectedSubject;
    this.onSelectTree(node, key);
  }

  // 加上depth和parentId属性
  private addTreedepth = (
    treeNodes: TreeNodeModel[],
    depth = 0,
    parentId: string | number = -1,
    pIndex?: any
  ) => {
    treeNodes.forEach((node: TreeNodeModel, index: number) => {
      node.depth = depth;
      node.parentId = parentId;
      const key = _.isNil(pIndex) ? index.toString() : `${pIndex}_${index}`;
      this.mapTreeNodeKey[node.catalogId] = key;
      if (Array.isArray(node.children)) {
        this.addTreedepth(node.children, depth + 1, node.catalogId, key);
      }
    });
    return treeNodes;
  };

  @action.bound
  public updateExpandedKeys(keys: any) {
    this.expandedKeys = keys;
  }

  @action.bound
  public getAllIndicatorList() {
    const node = { catalogId: -1 };
    this.handleCatalogNodeSelect([`${node.catalogId}`], {
      node: { props: { dataRef: node } }
    });
  }

  //切换目录
  @action.bound
  public handleCatalogNodeSelect(selectedKeys: string[], selectedNode: any) {
    if (this.selectedKeys[0] === selectedKeys[0]) {
      return;
    }
    const { node } = selectedNode;
    this.selectedKeys = selectedKeys;
    const { dataRef } = node.props;
    this.selectedCatalog = dataRef;
    this.onSelectTree(dataRef, this.tabKey);
  }

  //切换主题
  @action.bound
  public handleSubjectNodeSelect(node: any) {
    this.selectedSubject = node;
    this.onSelectTree(node, this.tabKey);
  }

  @action.bound
  public async getTreeNodes() {
    const res = this.searchKey
      ? await getCatalogChildTree(this.searchKey)
      : await getCatalogTree();
    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      const resData = res.data || {};
      let { list } = resData || {};
      // 目录查询的时候
      if (!Array.isArray(list)) {
        list = _.isEmpty(resData) ? [] : [resData];
      }
      // 数据根据sort排序
      const loop = (arr: any[]) => {
        arr.sort((a, b) => a.sort - b.sort);
        return arr.map((item: any) => {
          if (item.children && item.children.length) {
            item.children = loop(item.children);
          }
          return item;
        });
      };
      const sortList = loop(list);
      this.treeNodes = this.addTreedepth(sortList);
      if (this.searchKey) {
        this.selectedCatalog = _.isEmpty(resData) ? { catalogId: -1 } : resData;
        this.selectedKeys = [`${this.selectedCatalog.catalogId}`];
        this.onSelectTree(this.selectedCatalog, 'catalog');
      }
    });
  }
  // 获取目录列表--用于目录查询
  @action.bound
  public async getCatalogList(params: any) {
    const res = await getCatalogList(params);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      this.searchCatalogList = res.data || [];
    });
  }

  @action.bound
  public async updateCatalogVisible(v: any) {
    this.addVisible = v;
  }

  @action.bound
  public async updateCatalogAddType(type: any) {
    this.addType = type;
  }

  @action.bound
  public async createCatalog(params: any) {
    this.modalLoading = true;
    const res = await createCatalog(params);
    runInAction(() => {
      const { code, data } = res;
      if (code !== 200) {
        message.error(res.message);
        this.modalLoading = false;
        return;
      }
      this.modalLoading = false;
      this.addVisible = false;
      this.selectedKeys = [`${data.id}`];
      this.expandedKeys = [...this.expandedKeys, `${params.parentId}`];
      this.selectedCatalog = {
        ...params,
        catalogId: data.id
      };
      this.onSelectTree(this.selectedCatalog, 'catalog');
      this.getTreeNodes();
    });
  }

  @action.bound
  public async updateCatalog(id: string, params: any) {
    const res = await updateCatalog(id, params);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      this.getTreeNodes();
    });
  }

  @action.bound
  public async deleteCatalog(id: string) {
    const res = await deleteCatalog(id);
    runInAction(async () => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      await this.getTreeNodes();
      runInAction(() => {
        if (this.selectedCatalog.catalogId === id) {
          // this.selectedCatalog = this.treeNodes[0] || {};
          this.selectedCatalog = { catalogId: -1 };
          this.selectedKeys =
            this.treeNodes && this.treeNodes.length
              ? [`${this.selectedCatalog.catalogId}`]
              : [];
          this.onSelectTree(this.selectedCatalog, this.tabKey);
        }
      });
    });
  }

  @action.bound
  public async moveCatalog(params: any) {
    const res = await moveCatalog(params);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      this.getTreeNodes();
    });
  }

  @action.bound
  public updateSearchText(v: string) {
    this.searchText = v;
  }

  @action.bound
  public updateSearchKey(v: string) {
    this.searchKey = v;
  }

  @action.bound
  public updateSearchCatalogList(list: any) {
    this.searchCatalogList = list;
  }
}
export default CatalogStore;
