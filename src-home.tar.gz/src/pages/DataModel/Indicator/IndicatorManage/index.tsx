import React, { FC } from 'react';
import { inject, observer, Provider, useLocalStore } from 'mobx-react';
import IndicatorDevelopHeader from '../components/DevelopHeader';
import IndicatorDevelopBody from './containers';
import IndicatorManageStore from './store/indicatorManage.store';

import styles from './index.less';
interface IProps {
  global: any;
}
const IndicatorManage: FC<IProps> = (props: IProps) => {
  const { global } = props;
  const indicatorStore: IndicatorManageStore = useLocalStore(
    () => new IndicatorManageStore({ globalStore: global })
  );

  return (
    <Provider indicatorStore={indicatorStore}>
      <div className={styles.developContainer}>
        <div className={styles.developHeader}>
          <IndicatorDevelopHeader />
        </div>
        <div className={styles.developContent}>
          <IndicatorDevelopBody
            manageStore={indicatorStore}
            globalStore={global}
          />
        </div>
      </div>
    </Provider>
  );
};

export default inject('global')(observer(IndicatorManage));
