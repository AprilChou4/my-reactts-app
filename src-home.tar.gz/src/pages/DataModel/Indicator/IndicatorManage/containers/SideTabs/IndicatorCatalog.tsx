import React, { FC, useEffect } from 'react';
import { Tree, message, Empty } from 'sup-ui';
import { observer } from 'mobx-react';
import CatalogNode from '@components/CatalogNode';
import TipsDelete from '@components/Modal/TipsDelete';
import Icon from '@components/Icon';
import styles from './index.less';
const { TreeNode, DirectoryTree } = Tree;
interface CatalogProps {
  store: any;
}

const Catalog: FC<CatalogProps> = ({ store }: CatalogProps) => {
  const {
    getTreeNodes,
    treeNodes,
    handleCatalogNodeSelect,
    mapTreeNodeKey,
    moveCatalog,
    selectedKeys,
    getAllIndicatorList
  } = store;

  useEffect(() => {
    getTreeNodes();
  }, []);

  /**
   * 编辑目录
   * @param folderId
   * @param value
   * @returns
   */
  const editNode = (folderId: string, value: string) => {
    if (!value) {
      message.warning('请输入目录名称！');
      return;
    }
    store.updateCatalog(folderId, {
      name: value
      // description: ''
    });
  };

  /**
   * 删除目录
   * @param nodeItem
   */
  const removeNode = (nodeItem: any) => {
    const config = {
      title: '提示',
      content: `确定删除【${nodeItem.name}】目录？`,
      onOk: () => {
        store.deleteCatalog(nodeItem.catalogId);
      }
    };
    TipsDelete(config);
  };

  //获取节点的目录层级数量
  const getLevelCount = (tree: any[], level = 0): number => {
    let result = level;

    for (const node of tree) {
      let temp = level;

      if (Array.isArray(node.children) && node.children.length) {
        temp = getLevelCount(node.children, level + 1);

        result = Math.max(temp, result);
      }
    }

    return result;
  };
  /**
   * 寻找afterId(表示afterid之后，afterid==-1则为最前)
   * @param dropId
   * @param parentId
   * @returns
   */
  const getAfterId = (
    dropId: string | number,
    parentId: string | number
  ): number | string => {
    let afterId = -1;
    if (parentId === -1) {
      const idx = treeNodes.findIndex((val: any) => +val.catalogId === +dropId);
      afterId = idx !== -1 ? treeNodes[idx - 1]['catalogId'] : -1;
    } else {
      const key = mapTreeNodeKey[parentId].split('_');
      let children: any[] = [];
      for (let i = 0; i < key.length; i++) {
        children =
          i === 0 ? treeNodes[+key[i]].children : children[+key[i]].children;
        if (!children) return -1;
      }

      const idx = children.findIndex((val: any) => +val.catalogId === +dropId);

      afterId = idx !== -1 ? children[idx - 1]['catalogId'] : -1;
    }
    return afterId;
  };
  /**
   * 移动目录
   * @param info
   * @returns
   */
  const handleDrop = (info: any) => {
    const { eventKey: dragId, dataRef: dragDataRef } = info.dragNode.props;
    const {
      eventKey: dropId,
      dataRef: dropDataRef,
      dragOverGapTop,
      dragOverGapBottom
    } = info.node.props;
    //dropToGap == false 表示移入目录
    const { dropToGap } = info;

    //先获取drag/drop的目录层级
    const dropLevel = dropDataRef.depth;
    const dragCount = getLevelCount([dragDataRef]);
    const pad = dropToGap ? 0 : 1;

    if (dragCount + dropLevel + pad > 2) {
      message.error('最大支持3级目录!');
      return;
    }

    let params: any;
    if (dragOverGapTop) {
      //往上拖
      params = {
        afterId: +getAfterId(dropId, dropDataRef.parentId),
        nodeId: +dragId,
        parentId: +dropDataRef.parentId
      };
    } else if (dragOverGapBottom) {
      //往下拖
      params = {
        afterId: +dropId,
        nodeId: +dragId,
        parentId: +dropDataRef.parentId
      };
    } else if (dragOverGapTop === false && dragOverGapBottom === false) {
      //往里拖
      params = {
        afterId: -1,
        nodeId: +dragId,
        parentId: +dropId
      };
    } else {
      return;
    }
    moveCatalog(params);
  };
  /**
   * 选中目录
   * @param sKeys
   * @param selectedNode
   */
  const handleSelectCatalog = (sKeys?: string[], e?: any) => {
    handleCatalogNodeSelect(sKeys, e);
  };

  //递归节点树结构
  const loopTreeNode = (data: any) => {
    return (
      data.length &&
      data.map((item: any) => {
        if (item.children) {
          return (
            <TreeNode
              key={item.catalogId}
              dataRef={item}
              selectable={item.selectable}
              title={
                <CatalogNode
                  name={item.name}
                  onChange={value => editNode(item.catalogId, value)}
                  onRemove={() => removeNode(item)}
                />
              }
            >
              {loopTreeNode(item.children)}
            </TreeNode>
          );
        }

        return (
          <TreeNode
            key={item.catalogId}
            dataRef={item}
            isLeaf={item.isLeaf}
            selectable={item.selectable}
            title={
              <CatalogNode
                name={item.name}
                onChange={value => editNode(item.catalogId, value)}
                onRemove={() => removeNode(item)}
              />
            }
          />
        );
      })
    );
  };
  return (
    <>
      <div
        className={`${styles.all} ${
          selectedKeys.length && selectedKeys[0] === '-1'
            ? styles.allChecked
            : ''
        }`}
        onClick={getAllIndicatorList}
      >
        <div className={styles.icon}>
          <Icon type="collect" fill="#354052" width={14} height={14} />
        </div>
        全部
      </div>
      {treeNodes.length > 0 ? (
        <DirectoryTree
          expandAction={false}
          blockNode
          draggable={true}
          onDrop={handleDrop}
          selectedKeys={store.selectedKeys}
          expandedKeys={store.expandedKeys}
          onExpand={store.updateExpandedKeys}
          onSelect={handleSelectCatalog}
        >
          {loopTreeNode(store.treeNodes)}
        </DirectoryTree>
      ) : (
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      )}
    </>
  );
};

export default observer(Catalog);
