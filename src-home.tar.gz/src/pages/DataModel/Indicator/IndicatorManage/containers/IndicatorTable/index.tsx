import React, { FunctionComponent, useMemo, useRef } from 'react';
import { observer } from 'mobx-react';
import { Table, Divider, Tooltip } from 'sup-ui';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import { TableCellText } from '@components/Table';
import CustomPaging from '@components/CustomPaging';
import { AddIncidatorType, DATETimeTypeMapping } from '../../../const/enmu';
import classnames from 'classnames';
import styles from './index.less';
import moment from 'moment';

interface TableProps {
  history: any;
  manageStore: any;
}

const IndicatorTable: FunctionComponent<TableProps> = (props: TableProps) => {
  const { manageStore: store, history } = props;
  const {
    indicatorLists,
    tableLoading,
    getIndicatorList,
    deleteIndicator,
    selectedCatalog,
    selectedSubject,
    tabKey,
    treeNodes,
    searchParams,
    count
  } = store;
  const handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;
    //排序sorter, sort只能触发一个
    const { columnKey, order } = sorter;

    const orderBy: any = {
      nameOrderBy: null,
      createTimeOrderBy: null
    };
    // dataIndex VS 排序字段
    const orderEnum: any = {
      name: 'nameOrderBy',
      createTime: 'createTimeOrderBy'
    };
    if (_.isEmpty(sorter)) {
      orderBy['createTimeOrderBy'] = false;
    } else {
      orderBy[orderEnum[columnKey]] = order === 'ascend';
    }
    // false 降序 true 升序
    getIndicatorList({
      pageIndex: current,
      pageSize,
      ...orderBy
    });
  };

  const handleDelete = (record: any) => {
    const { name, id } = record;
    const config = {
      title: '删除',
      content: `是否删除${name}？`,
      onOk: async () => {
        await deleteIndicator({
          id
        });
      }
    };
    TipsDelete(config);
  };

  /**
   * 点击编辑
   * @param record
   */
  const handleEditIndicator = (record: any) => {
    history.push(
      `/data-model/indicator/model/${record.id}?createMode=${record.createMode}`
    );
  };

  const filterDataPeriod = (val: any) => {
    const list = DATETimeTypeMapping.filter(item => item.datePeriod === val);
    if (list.length) {
      return list[0].name;
    }
    return '';
  };

  const getColumns = () => {
    const columns = [
      {
        title: '指标名称',
        dataIndex: 'name',
        sorter: true,
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <Tooltip placement="topLeft" title={text}>
            <a onClick={() => store.changeDetailVisible(true, record)}>
              {text}
            </a>
          </Tooltip>
        )
      },
      {
        title: '维度',
        dataIndex: 'dim',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => {
          return <TableCellText text={text && text.replace(/,/g, ', ')} />;
        }
      },
      {
        title: '数据期',
        dataIndex: 'dataPeriod',
        width: 80,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={filterDataPeriod(text) || ''} />;
        }
      },
      {
        title: '业务口径',
        dataIndex: 'caliber',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text || ''} />;
        }
      },
      {
        title: '创建时间',
        dataIndex: 'createTime',
        width: 140,
        className: 'ellipsis-hide',
        defaultSortOrder: searchParams.createTimeOrderBy ? 'ascend' : 'descend',
        sorter: true,
        render: (text: any) => {
          return (
            <TableCellText
              text={text ? moment(text).format('YYYY-MM-DD HH:mm') : ''}
            />
          );
        }
      },
      {
        title: '创建方式',
        dataIndex: 'createMode',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          const item = AddIncidatorType.find(val => val.key === text);
          return <TableCellText text={item ? item.tableName : ''} />;
        }
      },
      {
        title: '负责人',
        dataIndex: 'director',
        width: 80,
        className: 'ellipsis-hide'
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 240,
        render: (_text: any, record: any) => (
          <>
            <div className="operator">
              <a onClick={() => store.changeDataSearchVisible(true, record)}>
                查询数据
              </a>
              <Divider type="vertical" />
              <a onClick={() => handleEditIndicator(record)}>编辑</a>
              <Divider type="vertical" />
              <a onClick={() => store.changeMoveVisible(true, record)}>移动</a>
              <Divider type="vertical" />
              <a onClick={() => handleDelete(record)}>删除</a>
            </div>
            <div className="more">
              <Icon type="ellipsis" width={13} />
            </div>
          </>
        )
      }
    ];
    let totalWidthX = 50;
    _.forEach(
      columns,
      column =>
        column.width &&
        _.isNumber(column.width) &&
        (totalWidthX += column.width)
    );
    if (columns.length > 1) {
      //将倒数第二列的宽度置为auto
      columns[columns.length - 2]['width'] = 'auto' as any;
    }

    return { columns, totalWidthX };
  };
  const rowSelection = {
    columnWidth: 50,
    selectedRowKeys: store.selectedRowKeys,
    onChange: store.updateSelectedRowKeys,
    hideDefaultSelections: true
  };
  const { columns, totalWidthX } = useMemo(getColumns, []);
  const isShowTable =
    indicatorLists.length ||
    searchParams.keyword ||
    (selectedCatalog.catalogId && tabKey === 'catalog') ||
    (selectedSubject.id && tabKey === 'tag');
  return (
    <>
      <div
        className={classnames(
          'mp-table-gray mp-table-grow',
          styles.tableWrapper
        )}
      >
        {isShowTable ? (
          <Table
            loading={tableLoading}
            columns={columns as any[]}
            rowSelection={rowSelection}
            dataSource={indicatorLists}
            onChange={handleTableChange}
            rowKey="id"
            pagination={{
              current: searchParams.pageIndex,
              pageSize: searchParams.pageSize,
              total: count,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging,
              pageSizeOptions: ['20', '50', '100'],
              showSizeChanger: true,
              showQuickJumper: true
            }}
            {...(indicatorLists.length
              ? {
                  scroll: {
                    x: totalWidthX,
                    y: 'calc(100% - 36px)'
                  }
                }
              : {})}
          />
        ) : (
          <div className={styles.noCont}>
            <p>
              {!treeNodes.length
                ? '请先添加指标目录'
                : '请选择指标目录或业务主题'}
            </p>
          </div>
        )}
      </div>
    </>
  );
};

export default observer(IndicatorTable);
