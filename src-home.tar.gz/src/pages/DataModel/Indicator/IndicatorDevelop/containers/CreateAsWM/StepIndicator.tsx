import React, { FunctionComponent, useState, useEffect } from 'react';
import { observer } from 'mobx-react';
import { useDebounceEffect } from 'ahooks';
import { FieldModelType } from '../../store/createAsWM.store';
import DropField from '../../../components/Field/DropField';
import DragItem from '../../../components/Field/DragItem';
import { Button, Input, Icon, Menu, message, Tooltip, Row, Col } from 'sup-ui';
import DimensionDrawer from '../../../components/CreateAsWMDrawer/DimensionDrawer';
import IndicatorDrawer from '../../../components/CreateAsWMDrawer/IndicatorDrawer';
import CustomIndicatorDrawer from '../../../components/CreateAsWMDrawer/CustomIndicatorDrawer';
import TimerDrawer from '../../../components/CreateAsWMDrawer/TimerDrawer';
import DataModelDialog from '../../../components/DataModelDialog';
import PreviewTable from '../../../components/PreviewTable';
import { ModelFieldType } from '../../../const/enmu';
import FilterDrawer from '../../../components/FilterDrawer';
import { indicatorFilterTest } from '../../service/createIndicator.service';
import styles from './index.less';
import TipsDelete from '@components/Modal/TipsDelete';
import { AddBtn } from '@components/Button';
const { SubMenu } = Menu;

interface IProps {
  isEdit: boolean;
  indicatorId: number | undefined;
  currentStep: number;
  changeStep: any;
  onCancel: () => void;
  store: any;
}
const StepIndicator: FunctionComponent<IProps> = ({
  isEdit,
  indicatorId,
  currentStep,
  changeStep,
  onCancel,
  store: localStore
}: IProps) => {
  const [filterVisible, setFilterVisible] = useState(false);
  const [customVisible, setCustomVisible] = useState(false);
  const [dataModelDialogVisible, setDataModelDialogVisible] = useState(false);
  const [selectDrawer, setSelectDrawer] = useState<{
    type: number;
    drawerInfo: any;
  }>({
    type: 0,
    drawerInfo: {}
  });
  const [openMenu, setOpenMenu] = useState(['timer', 'dimension', 'indicator']);
  /**
   * 编辑态 获取 指标组态详情
   */
  useEffect(() => {
    if (isEdit && indicatorId && _.isEmpty(localStore.DragedLists.indicator)) {
      localStore.getIndicatorConfigInfo(indicatorId);
    }
  }, []);
  /**
   * datamodel改变副作用
   */
  useEffect(() => {
    localStore.dataModel.id &&
      localStore.getFieldLists(localStore.dataModel.id);
  }, [localStore.dataModel.id]);

  const handleNext = () => {
    const {
      uneditIndicator,
      editedDimList,
      editedIndicatorList,
      previewStatus
    } = localStore;
    if (!previewStatus) {
      message.warning('数据预览失败，请检查配置');
      return;
    }
    if (uneditIndicator) {
      message.warning('还有待配置的指标组态，请检查');
      return;
    }
    if (
      editedDimList.length === 0 &&
      localStore.DragedLists.timer.length === 0
    ) {
      message.warning('数据期或维度至少需要一个');
      return;
    }
    if (editedIndicatorList.length === 0) {
      message.warning('至少需要一个指标');
      return;
    }
    changeStep(currentStep + 1);
    localStore.setCurrentStep(currentStep + 1);
  };

  /**
   * 重选数据模型
   * @param _type
   * @param seletItem
   * @returns
   */
  const handleDataModelSelect = (_type: number, seletItem: any) => {
    if (seletItem.id === localStore.dataModel.id) {
      //未改变
      setDataModelDialogVisible(false);
      return;
    } else {
      localStore.resetDragedLists();
      localStore.updateDataModel(seletItem);
    }
  };
  /**
   * 处理menu 展示/隐藏
   * @param openKeys
   */
  const handleOpenChange = (openKeys: string[]) => {
    setOpenMenu(openKeys);
  };
  /**
   * 点击展示drawer
   * @param type 0 none 1 dimension 2 indicator 3 timer
   * @param info
   */
  const handleSelect = (type: number, info: any) => {
    let tempinfo = info;
    if (isEdit && type === 2) {
      const finditem = _.find(
        localStore.fieldLists.timer,
        item => item.id === info.sourceFieldId
      );
      if (finditem) {
        tempinfo = { ...tempinfo, fieldDataType: finditem.fieldDataType };
      }
    }
    setSelectDrawer({
      type,
      drawerInfo: tempinfo
    });
  };
  const handleCancel = () => {
    setSelectDrawer({ drawerInfo: {}, type: 0 });
    customVisible && setCustomVisible(false);
  };
  const handleTimeUpdate = (param: any) => {
    localStore.updateTimeLists(param);
    setSelectDrawer({ drawerInfo: {}, type: 0 });
  };
  const handleDimUpdate = (param: any) => {
    localStore.updateDimLists(param);
    setSelectDrawer({ drawerInfo: {}, type: 0 });
  };
  const handleIndicatorUpdate = (param: any) => {
    localStore.updateIndicatorLists(param);
    setSelectDrawer({ drawerInfo: {}, type: 0 });
  };

  const handleCustomIndicatorUpdate = (param: any) => {
    if (customVisible) {
      //新增自定义
      localStore.updateDragedLists(3, {
        ...param,
        name: param.indicatorName,
        showName: param.indicatorName
      });
      setCustomVisible(false);
    } else {
      //编辑自定义指标
      localStore.updateIndicatorLists(param);
      setSelectDrawer({ drawerInfo: {}, type: 0 });
    }
  };
  const handleRemove = (type: string, index: number) => {
    localStore.deleteDragedLists(type, index);
  };

  const handleFilterUpdate = (filter: string) => {
    localStore.updateDataFilter(filter);
    setFilterVisible(false);
  };
  const [searchData, setSearchData] = useState(localStore.fieldLists);
  const [searchValue, setSearchValue] = useState('');
  const handleSearchInput = (event: any) => {
    const { value } = event.target;
    setSearchValue(value);
  };

  useEffect(() => {
    setSearchData(localStore.fieldLists);
  }, [localStore.fieldLists]);

  useDebounceEffect(
    () => {
      ModelFieldType.forEach(modelfield => {
        const filterResult = _.filter(
          localStore.fieldLists[modelfield.attrName],
          item =>
            item.name.toLowerCase().includes(searchValue.toLowerCase()) ||
            item.showName.toLowerCase().includes(searchValue.toLowerCase())
        );
        setSearchData((pre: any) => ({
          ...pre,
          [modelfield.attrName]: filterResult
        }));
      });
    },
    [searchValue],
    { wait: 500 }
  );
  return (
    <div className={styles.step1Container}>
      <div className={styles.step1ContainerContent}>
        <div className={styles.contentSider}>
          <span>数据模型</span>

          <Tooltip
            overlayClassName={styles.tooltipWrapper}
            mouseEnterDelay={0.5}
            title={
              <>
                <Row>
                  <Col span={7} className={styles.tooltipLabel}>
                    表名称
                  </Col>
                  <Col span={17}>{localStore.dataModel.name}</Col>
                </Row>
                <Row>
                  <Col span={7} className={styles.tooltipLabel}>
                    中文名
                  </Col>
                  <Col span={17}>{localStore.dataModel.showName}</Col>
                </Row>
              </>
            }
          >
            <div className={styles.dataModel}>
              <div
                className={
                  isEdit ? styles.dataModelNameNotAllowed : styles.dataModelName
                }
                onClick={() => {
                  !isEdit && setDataModelDialogVisible(true);
                }}
              >
                <div>{localStore.dataModel.name}</div>
                <div style={{ color: '#969CA6 ' }}>
                  {localStore.dataModel.showName}
                </div>
              </div>
              <div
                className={
                  isEdit ? styles.exchangeImgNotAllowed : styles.exchangeImg
                }
                onClick={() => {
                  !isEdit && setDataModelDialogVisible(true);
                }}
              />
            </div>
          </Tooltip>

          <Input
            prefix={<Icon type="search" />}
            onChange={handleSearchInput}
            className={styles.search}
          />
          <div>
            <Menu
              mode="inline"
              openKeys={openMenu}
              onOpenChange={handleOpenChange}
              selectable={false}
            >
              <SubMenu
                key="timer"
                title={
                  <span className={styles.flex}>
                    <div className={styles.timeImg} />
                    <span>时间</span>
                  </span>
                }
              >
                {_.map(searchData.timer, (item: FieldModelType) => (
                  <Menu.Item key={item.id}>
                    <DragItem data={item} />
                  </Menu.Item>
                ))}
              </SubMenu>
              <SubMenu
                key="dimension"
                title={
                  <span className={styles.flex}>
                    <div className={styles.dimensionalityImg} />
                    <span>维度</span>
                  </span>
                }
              >
                {_.map(searchData.dimension || [], (item: FieldModelType) => (
                  <Menu.Item key={item.id}>
                    <DragItem data={item} />
                  </Menu.Item>
                ))}
              </SubMenu>
              <SubMenu
                key="indicator"
                title={
                  <span className={styles.flex}>
                    <div className={styles.measureImg} />
                    <span>度量</span>
                  </span>
                }
              >
                {_.map(searchData.indicator || [], (item: FieldModelType) => (
                  <Menu.Item key={item.id}>
                    <DragItem data={item} />
                  </Menu.Item>
                ))}
              </SubMenu>
            </Menu>
          </div>
        </div>
        <div className={styles.contentBody}>
          <DropField
            title="数据期"
            acceptType={[2]}
            position={'timer'}
            fieldLists={localStore.DragedLists.timer}
            onMove={localStore.updateDragedLists}
            onSelect={handleSelect}
            onExchange={localStore.updateDragedListsByExchange}
            onRemove={handleRemove}
          />
          <DropField
            title="维度"
            acceptType={[1, 2]}
            position={'dimension'}
            fieldLists={localStore.DragedLists.dimension}
            onMove={localStore.updateDragedLists}
            onRemove={handleRemove}
            onSelect={handleSelect}
            onExchange={localStore.updateDragedListsByExchange}
          >
            {/* <AddBtn
              ghost
              style={{ margin: '10px 8px' }}
              title="数据过滤"
              onClick={() => setFilterVisible(true)}
            /> */}
            <Button
              type={'default'}
              style={{
                margin: '10px 8px',
                border: '1px solid #0F71E2',
                color: '#0F71E2'
              }}
              onClick={() => setFilterVisible(true)}
            >
              数据过滤
            </Button>
          </DropField>
          <DropField
            title="指标"
            acceptType={[1, 3]}
            position={'indicator'}
            fieldLists={localStore.DragedLists.indicator}
            onMove={localStore.updateDragedLists}
            onRemove={handleRemove}
            onSelect={handleSelect}
            onExchange={localStore.updateDragedListsByExchange}
          >
            <AddBtn
              ghost
              style={{ margin: '10px 8px' }}
              title="自定义"
              onClick={() => setCustomVisible(true)}
            />
          </DropField>
          {!!localStore.previewColumns.length && (
            <PreviewTable
              tableLoading={localStore.previewLoading}
              columns={localStore.previewColumns}
              indicatorLists={localStore.previewLists}
            />
          )}
        </div>
      </div>
      <div className={styles.step1ContainerFooter}>
        <Button
          type="primary"
          onClick={handleNext}
          style={{
            marginRight: '16px',
            background: '#0F71E2 ',
            height: '36px'
          }}
        >
          下一步
        </Button>
        <Button
          onClick={() => {
            if (
              localStore.DragedLists.timer.length +
                localStore.DragedLists.dimension.length +
                localStore.DragedLists.indicator.length ===
              0
            ) {
              onCancel();
              return;
            }
            const config = {
              title: '取消提示',
              content: '取消后配置数据不保存，是否取消？',
              onOk: onCancel
            };

            TipsDelete(config);
          }}
          style={{ marginRight: '32px', height: '36px' }}
        >
          取消
        </Button>
      </div>
      {/* 维度配置 */}
      {selectDrawer.type === 1 && (
        <DimensionDrawer
          info={selectDrawer.drawerInfo}
          DragedLists={localStore.DragedLists}
          onCancel={handleCancel}
          onOk={handleDimUpdate}
        />
      )}
      {/* 指标配置 */}
      {selectDrawer.type === 3 && !selectDrawer.drawerInfo.expression && (
        <IndicatorDrawer
          indicatorInfo={selectDrawer.drawerInfo}
          DragedLists={localStore.DragedLists}
          indicatorLists={localStore.DragedLists.indicator}
          onCancel={handleCancel}
          onOk={handleIndicatorUpdate}
        />
      )}
      {/* 自定义指标配置 */}
      {((selectDrawer.type === 3 && selectDrawer.drawerInfo.expression) ||
        customVisible) && (
        <CustomIndicatorDrawer
          indicatorInfo={selectDrawer.drawerInfo}
          DragedLists={localStore.DragedLists}
          fields={localStore.fieldLists}
          onCancel={handleCancel}
          onOk={handleCustomIndicatorUpdate}
        />
      )}
      {/* 数据期配置 */}
      {selectDrawer.type === 2 && (
        <TimerDrawer
          timeInfo={selectDrawer.drawerInfo}
          DragedLists={localStore.DragedLists}
          onCancel={handleCancel}
          onOk={handleTimeUpdate}
        />
      )}
      {/* 条件过滤 */}
      {filterVisible && (
        <FilterDrawer
          isEdit={isEdit}
          expr={localStore.dataFilter}
          fields={localStore.fieldLists}
          onOk={handleFilterUpdate}
          onCancel={() => setFilterVisible(false)}
          dataModel={localStore.dataModel}
          filterTest={indicatorFilterTest}
        />
      )}
      {/* 模型选择 */}
      {dataModelDialogVisible && (
        <DataModelDialog
          onVisible={() => setDataModelDialogVisible(false)}
          onSelected={handleDataModelSelect}
          selectedItem={localStore.dataModel}
        />
      )}
    </div>
  );
};

export default observer(StepIndicator);
