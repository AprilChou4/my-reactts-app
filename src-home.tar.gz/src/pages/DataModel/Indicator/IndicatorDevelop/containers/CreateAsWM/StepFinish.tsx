import React, { FunctionComponent, useMemo, useState } from 'react';
import { observer, inject } from 'mobx-react';
import { Button, message } from 'sup-ui';
import FinishTable from '../../../components/FinishTable';
import TipsDelete from '@components/Modal/TipsDelete';
import styles from './index.less';
interface IPros {
  isEdit: boolean;
  indicatorId: number | undefined;
  currentStep: number;
  changeStep: any;
  onCancel: () => void;
  store: any;
  global?: any;
}

interface DimType {
  dimName: string;
  dimPhysicalName: string;
  sort: number;
  sourceFieldId: number;
}
interface IndicatorType {
  accuracy: number; //精度
  aggrType: string; //计算方式
  businessSegmentId: number; //业务板块
  caliber: string; //业务口径
  catalogId: number; //目录id
  dataUnit: string; //指标单位
  director: string; //负责人
  indicatorCode: string; //指标编码
  indicatorName: string; //指标名称
  indicatorPhysicalName: string;
  expression: string;
  sourceFieldId: number;
  subjectDomainId: number; //业务域
  output: null | any; //指标输出
}
const StepFinish: FunctionComponent<IPros> = ({
  isEdit,
  indicatorId,
  currentStep,
  changeStep,
  onCancel,
  store: localStore,
  global
}: IPros) => {
  const [submitLoading, setSubmitloading] = useState(false);
  const dim = useMemo(() => {
    let tempDim = [];
    tempDim = _.map(localStore.DragedLists.timer, item => item.dimName);
    _.forEach(localStore.DragedLists.dimension, item => {
      tempDim.push(item.dimName);
    });
    return tempDim;
  }, []);

  const data = useMemo(
    () =>
      _.map(localStore.DragedLists.indicator, (item, index) => ({
        id: index,
        indicatorName: item.indicatorName,
        name: item?.name ?? '',
        dim,
        output: item?.output,
        subjectDomainName: item?.subjectDomainName ?? ''
      })),
    [localStore.DragedLists.indicator]
  );

  const handelBack = () => {
    changeStep(currentStep - 1);
    localStore.setCurrentStep(currentStep - 1);
  };
  const handleSubmit = async () => {
    const {
      dataModel,
      dataFilter,
      DragedLists: { timer, dimension, indicator }
    } = localStore;
    const params = {
      baseModelId: dataModel.id,
      filter: dataFilter,
      listDim: _.map(dimension, (item: DimType) => ({
        dimName: item.dimName,
        dimPhysicalName: item.dimPhysicalName,
        sort: item.sort,
        sourceFieldId: item.sourceFieldId
      })),
      listIndicator: _.map(indicator, (item: IndicatorType) => ({
        accuracy: item.accuracy,
        aggrType: item.aggrType,
        businessSegmentId: item.businessSegmentId,
        caliber: item.caliber,
        catalogId: item.catalogId,
        dataUnit: item.dataUnit,
        director: JSON.parse(item.director).name,
        indicatorName: item.indicatorName,
        indicatorPhysicalName: item.indicatorPhysicalName,
        expression: item.expression,
        sourceFieldId: item.sourceFieldId,
        subjectDomainId: item.subjectDomainId,
        output: item.output || null,
        webConfig: item.director
      })),
      physicalName: '',
      timeDim:
        timer.length && timer[0].dataPeriod
          ? {
              dataPeriod: timer[0].dataPeriod,
              dimName: timer[0].dimName,
              dimPhysicalName: timer[0].dimPhysicalName,
              sourceFieldId: timer[0].sourceFieldId
            }
          : null
    };
    setSubmitloading(true);
    const res = isEdit
      ? await localStore.indicatorEdit(indicatorId, params)
      : await localStore.createIndicator(params);
    setSubmitloading(false);
    if (res.code === 200) {
      // 刷新指标列表
      message.success(`指标${isEdit ? '编辑' : '新增'}成功`);
      global.executeCacheMethod(
        '/data-model/indicator/manager',
        'refreshIndicatorList',
        { pageIndex: 1 }
      );

      onCancel();
    }
  };

  return (
    <div className={styles.step2Container}>
      <div className={styles.step2ContainerContent}>
        <FinishTable
          isEdit={isEdit}
          indicatorId={indicatorId}
          data={data}
          updateIndicatorLists={localStore.updateIndicatorLists}
        />
      </div>
      <div className={styles.step2ContainerFooter}>
        <Button
          type="primary"
          onClick={handelBack}
          style={{
            marginLeft: '32px',
            background: '#fff',
            height: '36px',
            color: '#005fe1'
          }}
        >
          上一步
        </Button>
        <div>
          <Button
            type="primary"
            onClick={handleSubmit}
            disabled={submitLoading}
            style={{
              marginRight: '16px',
              background: '#0F71E2',
              height: '36px'
            }}
          >
            提交
          </Button>
          <Button
            onClick={() => {
              const config = {
                title: '取消提示',
                content: '取消后配置数据不保存，是否取消？',
                onOk: onCancel
              };

              TipsDelete(config);
            }}
            style={{ marginRight: '32px', height: '36px' }}
          >
            取消
          </Button>
        </div>
      </div>
    </div>
  );
};

export default inject('global')(observer(StepFinish));
