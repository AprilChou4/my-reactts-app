import React, { FC, useState } from 'react';
import BaseInfo from './BaseInfo';
import MappingInfo from './MappingInfo';
import { useAsyncEffect } from 'ahooks';
import CommonDrawer from '@components/Drawer/CommonDrawer';
import { Tabs, message, Spin } from 'sup-ui';
import { getStandardDetail } from '../../service/execution.service';
import { getMappingList } from '../../containers/ExecutionMapping/service/addMapping.service';
import styles from './index.less';

const { TabPane } = Tabs;

interface IProps {
  standardInfo: {
    cnName: string;
    id: string;
  };
  onCancel: () => void;
}
/**
 * 标准详情抽屉
 * @param props
 * @returns
 */
const DetailDrawer: FC<IProps> = ({ standardInfo, onCancel }) => {
  const { cnName, id } = standardInfo;
  const [loading, setLoading] = useState(false);
  const [baseInfo, setBaseInfo] = useState<any>({});
  const [mappingList, setMappingList] = useState<any[]>([]);
  useAsyncEffect(async () => {
    setLoading(true);
    const baseinfo = await getStandardDetail(id);
    const mapplist = await getMappingList({ id, type: 1 });
    setLoading(false);
    if (baseinfo.code !== 200) {
      message.error(baseinfo.message);
    } else {
      const attributeTypeDetailList = [
        {
          attributeCnName: '标准中文名称',
          attributeValue: baseinfo.data?.cnName || ''
        },
        {
          attributeCnName: '标准英文名称',
          attributeValue: baseinfo.data?.enName || ''
        },
        {
          attributeCnName: '标准编码',
          attributeValue: baseinfo.data?.code || ''
        }
      ];
      if (
        Array.isArray(baseinfo.data?.standardShowTypeDetails) &&
        baseinfo.data?.standardShowTypeDetails.length
      ) {
        const index = baseinfo.data?.standardShowTypeDetails.findIndex(
          (detail: any) => detail.name === '业务属性'
        );

        if (index !== -1) {
          baseinfo.data?.standardShowTypeDetails[
            index
          ]?.attributeTypeDetailList.unshift(...attributeTypeDetailList);
        } else {
          baseinfo.data.standardShowTypeDetails.unshift({
            name: '业务属性',
            id: '业务属性',
            attributeTypeDetailList
          });
        }
      } else {
        baseinfo.data.standardShowTypeDetails = [
          {
            name: '业务属性',
            id: '业务属性',
            attributeTypeDetailList
          }
        ];
      }

      setBaseInfo(baseinfo.data || {});
    }
    if (mapplist.code !== 200) {
      message.error(mapplist.message);
    } else {
      setMappingList(mapplist.data || []);
    }
  }, []);
  return (
    <CommonDrawer
      closable={true}
      title={cnName}
      visible={true}
      width={900}
      onCancel={onCancel}
      wrapClassName={styles.drawerWrapper}
      footer={null}
    >
      <Spin spinning={loading}>
        <Tabs
          defaultActiveKey="baseInfo"
          tabBarStyle={{
            marginBottom: 4
          }}
        >
          <TabPane tab={'基础信息'} key={'baseInfo'}>
            <BaseInfo info={baseInfo} />
          </TabPane>
          <TabPane tab={'落地映射信息'} key={'mappingInfo'}>
            <MappingInfo info={mappingList} />
          </TabPane>
        </Tabs>
      </Spin>
    </CommonDrawer>
  );
};

export default DetailDrawer;
