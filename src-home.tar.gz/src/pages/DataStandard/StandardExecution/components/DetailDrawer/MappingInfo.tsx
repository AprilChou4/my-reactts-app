import React, { FC, useState } from 'react';
import { Table, Empty } from 'sup-ui';
import { TableCellText } from '@components/Table';
import styles from './index.less';
interface IProps {
  info: any[];
}
/**
 * 落地映射信息组件
 * @param props
 * @returns
 */
const MappingInfo: FC<IProps> = ({ info }) => {
  const getColumns = () => {
    const columns = [
      {
        title: '标准编号',
        dataIndex: 'standardCode',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '标准名称',
        dataIndex: 'cnName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '英文名称',
        dataIndex: 'enName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '落地字段',
        dataIndex: 'fieldName',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段显示名',
        dataIndex: 'cnFieldName',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: string) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '字段路径',
        dataIndex: 'fieldPath',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '映射方式',
        dataIndex: 'mappingMode',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text} />;
        }
      }
    ];
    let totalWidthX = 50;
    _.forEach(
      columns,
      column =>
        column.width &&
        _.isNumber(column.width) &&
        (totalWidthX += column.width)
    );

    return { columns, totalWidthX };
  };
  const { columns, totalWidthX } = getColumns();
  return (
    <div className={`${styles.tableWrapper} mp-table-gray-light mp-table-grow`}>
      {info?.length ? (
        <Table
          columns={columns as any[]}
          dataSource={info}
          rowKey="id"
          pagination={false}
          scroll={{
            x: totalWidthX,
            y: 'calc(100% - 36px)'
          }}
        />
      ) : (
        <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
      )}
    </div>
  );
};

export default MappingInfo;
