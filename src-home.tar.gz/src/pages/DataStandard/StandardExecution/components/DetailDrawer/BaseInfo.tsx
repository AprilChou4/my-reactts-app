import React, { FC } from 'react';
import { Descriptions } from 'sup-ui';
import styles from './index.less';
const { Item } = Descriptions;
interface IProps {
  info: any;
}

const desProps = {
  layout: 'vertical',
  colon: true,
  column: 1
};
// 获取动态列的值-主要处理特殊字段如数据规范
const getColumValue = (type: string, value: any) => {
  switch (type) {
    case 'standard_rule':
    case 'subordinate_department': {
      try {
        const { showValue } = value
          ? JSON.parse(value)
          : { showValue: undefined };
        return showValue;
      } catch {
        return value;
      }
    }
    default:
      return value;
  }
};
/**
 * 基本信息组件
 * @param props
 * @returns
 */
const BaseInfo: FC<IProps> = ({ info }) => {
  const { standardShowTypeDetails = [] } = info;

  return (
    <div className={styles.baseinfoContainer}>
      {standardShowTypeDetails.map((detail: any) => {
        return (
          <Descriptions title={detail.name} {...desProps} key={detail.id}>
            {detail?.attributeTypeDetailList.map((list: any, index: number) => {
              return (
                <Item label={list?.attributeCnName} key={index}>
                  {getColumValue(list?.attributeEnName, list?.attributeValue) ||
                    '-'}
                </Item>
              );
            })}
          </Descriptions>
        );
      })}
    </div>
  );
};

export default BaseInfo;
