import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import {
  batchDisable,
  batchEnable,
  getStandardList
} from '../service/execution.service';
export interface listDto {
  cnName: string;
  code: string;
  enName: string;
  id: string;
  operateStatus: string; //0 启用 1 停用
  releaseStatus: string;
  standardSetId: string;
}

export interface searchParamsDto {
  releaseStatus: number[];
  folderId: string;
  searchName?: string;
  operateStatus?: number;
  pageIndex?: number;
  pageSize?: number;
  timeOrderByIsAsc?: boolean;
}

export interface StandardFolderDTO {
  folders: StandardFolderDTO[];
  id: string;
  name: string;
  nextId: string;
  parentId: string;
  previousId: string;
  totalNum: number;
  type: string;
}
class ExecutionStore {
  private readonly clearCachePages: any;
  @observable public tableLoading = false;
  @observable public mappingVisible = false;
  @observable public selectedStandardSet: StandardFolderDTO | undefined; // 选中的标准集
  @observable public lists: listDto[] = []; //标准list
  @observable public dynamicColumns: any[] = []; //动态扩展Table columns
  @observable public count = 0; //标准列表数量
  @observable public searchParams: searchParamsDto = {
    folderId: '',
    searchName: '',
    operateStatus: -1, //全部
    releaseStatus: [1, 2] //已发布 写死
    //pageIndex: 1,
    //pageSize: 20
  };
  @observable public selectedRowKeys: any[] = []; //选中的标准

  public constructor(props: any) {
    this.clearCachePages = props.clearCachePages;
  }
  @action.bound
  public updateMappingVisible = (visible: boolean) => {
    this.mappingVisible = visible;
  };
  // 清楚标准管理页
  private clearStandardManage() {
    this.clearCachePages([`/data-standard/manager`]);
  }

  @action.bound
  public updateSearchParams = (params: Partial<searchParamsDto>) => {
    this.searchParams = {
      ...this.searchParams,
      ...params
    };
    this.getStandardList(this.searchParams);
  };

  // 目录选中
  @action.bound
  public onSelectTree(node: StandardFolderDTO) {
    this.selectedStandardSet = node;
    if (node.type === 'STANDARD') {
      this.updateSearchParams({
        ...this.searchParams,
        folderId: node.id
      });
    }
  }

  /**
   * 获取数据标准列表
   * @param params
   */
  @action.bound
  public async getStandardList(params: any = {}) {
    this.tableLoading = true;
    const res = await getStandardList(params);
    runInAction(() => {
      this.tableLoading = false;
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      this.lists = res.data?.standardList || [];
      this.dynamicColumns = res.data?.columns || [];
    });
  }

  /**
   * 批量启停标准
   * @param params string[]
   * @param type 0 停用 1 启用
   */
  @action.bound
  public async batchControlStandsrd(params: string[] = [], type = 0) {
    this.clearStandardManage();
    const res =
      type === 0 ? await batchDisable(params) : await batchEnable(params);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }
      this.getStandardList(this.searchParams);
    });
  }

  /**
   * 更新列表选择行
   * @param selectedKeys 选中的key
   * @param selectedRows 选中的行
   */
  @action.bound
  public updateSelectedRowKeys(selectedKeys: string[], _selectedRows: any[]) {
    this.selectedRowKeys = selectedKeys;
  }
}
export default ExecutionStore;
