import React, { FC } from 'react';
import { inject, observer, Provider, useLocalStore } from 'mobx-react';
import ExecutionHead from './containers/ExecutionHead';
import ExecutionTable from './containers/ExecutionTable';
import ExecutionMapping from './containers/ExecutionMapping';
import StandardTree from '../StandardTree';
import ExecutionStore from './store/execution.store';

import styles from './index.less';
interface IProps {
  global?: any;
}
const IndicatorManage: FC<IProps> = ({ global }) => {
  const executionStore: ExecutionStore = useLocalStore(
    () =>
      new ExecutionStore({
        clearCachePages: global.clearCachePages
      })
  );
  const {
    mappingVisible,
    onSelectTree,
    selectedStandardSet,
    updateMappingVisible
  } = executionStore;
  // 判断选中的是否为标准集
  const isSet: boolean = selectedStandardSet?.type === 'STANDARD';
  return (
    <Provider executionStore={executionStore}>
      <div className={styles.container}>
        <div
          className={styles.sider}
          style={mappingVisible ? { display: 'none' } : { display: 'block' }}
        >
          <StandardTree
            onSelectTree={onSelectTree}
            editable={false}
            dragable={false}
          />
        </div>
        <div
          className={styles.cont}
          style={mappingVisible ? { display: 'none' } : { display: 'block' }}
        >
          {isSet ? (
            <>
              <ExecutionHead />
              <ExecutionTable />
            </>
          ) : (
            <div className={styles.noCont}>
              <p>请选择数据标准集</p>
            </div>
          )}
        </div>

        {mappingVisible && (
          <ExecutionMapping
            standardSet={selectedStandardSet}
            onCancel={() => updateMappingVisible(false)}
          />
        )}
      </div>
    </Provider>
  );
};

export default inject('global')(observer(IndicatorManage));
