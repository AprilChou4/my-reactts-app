// 标准管理列表
import React, { FC, useRef, useState, useEffect } from 'react';

import { Button, Select, Tooltip } from 'sup-ui';
import { observer, inject } from 'mobx-react';

import Header from '@components/Header';
import KeywordSearch from '@components/KeywordSearch';
import Icon from '@components/Icon';
import { executionStatus, StandardEnum } from '../../const/enmu';
import TipsDelete from '@components/Modal/TipsDelete';
import ExecutionStore from '../../store/execution.store';
import styles from './index.less';

const { Option } = Select;
interface IProps {
  executionStore?: ExecutionStore;
}
const ExecutionHeader: FC<IProps> = ({ executionStore }) => {
  const {
    selectedRowKeys,
    searchParams,
    lists,
    updateSearchParams,
    updateMappingVisible,
    batchControlStandsrd,
    getStandardList
  } = executionStore!;

  const searchRef: any = useRef();
  const [isFocus, setFocus] = useState<boolean>(false);

  const cancelFocus = () => {
    setFocus(false);
  };

  // 因为点取消按钮时候，会触发blur，输入框会闪烁下，故增加isFocus参数
  useEffect(() => {
    document.addEventListener('click', cancelFocus);
    return () => {
      document.removeEventListener('click', cancelFocus);
    };
  }, []);
  // 标准列表查询
  const handleSearch = (value?: string) => {
    updateSearchParams({
      ...searchParams,
      searchName: value || undefined
    });
  };
  // 选择状态查询条件
  const handleStatusChange = (value: string) => {
    updateSearchParams({
      operateStatus: +value ?? -1
    });
  };

  const searchInputFocus = (e: any) => {
    if (searchRef) {
      searchRef.current?.focus();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation();
      setFocus(true);
    }
  };

  const handleLandMappingClick = () => {
    updateMappingVisible(true);
  };

  const handleEnableStandard = () => {
    if (selectedRowKeys.length) {
      batchControlStandsrd(selectedRowKeys, StandardEnum.ENABLE);
    }
  };
  const handleDisableStandard = () => {
    if (selectedRowKeys.length) {
      const config = {
        title: '停用标准',
        content: '是否批量停用标准？',
        onOk: () => {
          batchControlStandsrd(selectedRowKeys, StandardEnum.DISABLE);
        }
      };
      TipsDelete(config);
    }
  };
  const handleRefresh = () => {
    getStandardList(searchParams);
  };
  const { searchName, operateStatus } = searchParams;
  const tooltipTitle = (() => {
    if (!lists.length) {
      return {
        title: '该标准集下没有标准',
        disabled: true
      };
    }
    return {
      title: '',
      disabled: false
    };
  })();

  return (
    <div className={styles.headerWrap}>
      <Header
        className={styles.header}
        left={
          <>
            {/* <Tooltip placement="topLeft" title={tooltipTitle.title}>
              <Button
                onClick={handleLandMappingClick}
                disabled={tooltipTitle.disabled}
              >
                <Icon
                  type="land-mapping"
                  style={{ verticalAlign: '-4px' }}
                  fill={tooltipTitle.disabled ? '#bfbfbf' : '#0F71E2'}
                />
                <span
                  style={{
                    color: `${
                      tooltipTitle.disabled
                        ? 'rgba(53, 64, 82, 0.5)'
                        : '#0F71E2'
                    }`
                  }}
                >
                  落地映射
                </span>
              </Button>
            </Tooltip> */}
            <Button
              onClick={handleLandMappingClick}
              style={{ border: '1px solid #0F71E2' }}
            >
              <Icon
                type="land-mapping"
                style={{ verticalAlign: '-4px' }}
                fill={'#0F71E2'}
              />
              <span style={{ color: `#0F71E2` }}>落地映射</span>
            </Button>
            <Button
              disabled={!selectedRowKeys?.length}
              onClick={handleEnableStandard}
            >
              启用
            </Button>
            <Button
              disabled={!selectedRowKeys?.length}
              onClick={handleDisableStandard}
            >
              停用
            </Button>
            <Button onClick={handleRefresh}>刷新</Button>
          </>
        }
        right={
          <>
            <Select
              placeholder="请选择"
              style={{ width: 118, marginRight: 4 }}
              value={operateStatus?.toString() ?? '-1'}
              onChange={handleStatusChange}
            >
              {executionStatus.map(item => (
                <Option value={item.key.toString()} key={item.key.toString()}>
                  {item.name}
                </Option>
              ))}
            </Select>
            <KeywordSearch
              placeholder="输入名称搜索"
              value={searchName || ''}
              className={isFocus || searchName ? styles.searchActive : ''}
              ref={searchRef}
              suffix={
                searchName ? (
                  <Icon
                    type="circle-close"
                    size="small"
                    onClick={e => {
                      searchInputFocus(e);
                      handleSearch();
                    }}
                  />
                ) : (
                  <Icon type="search" onClick={searchInputFocus} />
                )
              }
              onSearch={handleSearch}
            />
          </>
        }
      />
    </div>
  );
};
export default inject('executionStore')(observer(ExecutionHeader));
