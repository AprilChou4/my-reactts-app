import React, { FC, useState } from 'react';
import { inject, observer } from 'mobx-react';
import AddMappingStore from './store/addMapping.store';
import { Tooltip, Table } from 'sup-ui';
import { TableCellText } from '@components/Table';
import TipsDelete from '@components/Modal/TipsDelete';
import Icon from '@components/Icon';
import styles from './index.less';
interface IProps {
  addMappingStore?: AddMappingStore;
}
const MappingTable: FC<IProps> = ({ addMappingStore }) => {
  const {
    loading,
    mappingList,
    selectedRowKeys,
    selectedStandard,
    updateSelectedRowKeys,
    deleteBatchMapping
  } = addMappingStore!;

  const handelDelete = (record: any) => {
    const config = {
      title: '删除',
      content: `是否删除？`,
      onOk: () => {
        deleteBatchMapping([record.id]);
      }
    };
    TipsDelete(config);
  };

  const getColumns = (): [any, number] => {
    const columns = [
      {
        title: '标准编号',
        dataIndex: 'standardCode',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        },
        show: false
      },
      {
        title: '标准名称',
        dataIndex: 'cnName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        },
        show: false
      },
      {
        title: '英文名称',
        dataIndex: 'enName',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: number) => {
          return <TableCellText text={text} />;
        },
        show: false
      },
      {
        title: '落地字段',
        dataIndex: 'fieldName',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段显示名',
        dataIndex: 'cnFieldName',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: string) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '字段路径',
        dataIndex: 'fieldPath',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text} />;
        }
      },
      {
        title: '映射方式',
        dataIndex: 'mappingMode',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: any) => {
          return <TableCellText text={text} />;
        }
      },

      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 120,
        render: (_text: any, record: any) => (
          <>
            <div className="operator">
              <a onClick={() => handelDelete(record)}>删除</a>
            </div>
            <div className="more">
              <Icon type="ellipsis" />
            </div>
          </>
        )
      }
    ];

    const newColumns = columns.filter((value: any) => {
      if (typeof selectedStandard?.mappingCount == 'number') {
        return value?.show === false ? false : true;
      }
      return true;
    });
    let totalWidthX = 50;
    _.forEach(
      newColumns,
      column =>
        column.width &&
        _.isNumber(column.width) &&
        (totalWidthX += column.width)
    );
    if (newColumns.length > 1) {
      newColumns[newColumns.length - 3]['width'] = 'auto' as any;
    }

    return [newColumns, totalWidthX];
  };
  const rowSelection = {
    columnWidth: 50,
    selectedRowKeys,
    onChange: updateSelectedRowKeys,
    hideDefaultSelections: true
  };
  const [columns, totalWidthX] = getColumns();
  return (
    <div className={`${styles.tableWrapper} mp-table-gray mp-table-grow`}>
      <Table
        loading={loading}
        columns={columns as any[]}
        rowSelection={rowSelection as any}
        dataSource={mappingList}
        rowKey="id"
        pagination={false}
        scroll={{
          x: totalWidthX,
          y: 'calc(100% - 36px)'
        }}
      />
    </div>
  );
};

export default inject('addMappingStore')(observer(MappingTable));
