import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import DialogModal from '@components/Modal/Dialog';
import { ruleNameReg } from '../consts/regexp';
import styles from '../index.less';

const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  visible: boolean;
  onVisibleChange: any;
  values: any;
  handleOk: any;
}
interface IState {
  loading: boolean;
}

class EditDocModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    this.state = {
      loading: false
    };
  }

  public handleOK = () => {
    const { form, handleOk } = this.props;

    form.validateFields((error: any, formValues: any) => {
      if (error) return;

      handleOk(formValues, (fail: boolean) => {
        if (fail) {
          this.setState({
            loading: false
          });
        }
      });
    });
  };

  public render() {
    const {
      visible,
      values,
      onVisibleChange,
      form: { getFieldDecorator }
    } = this.props;
    const { loading } = this.state;

    return (
      <DialogModal
        width={480}
        title="重命名"
        visible={visible}
        loading={loading}
        maskClosable={false}
        onOk={this.handleOK}
        onCancel={() => onVisibleChange(false)}
        wrapClassName={styles.modalContainer}
      >
        <Form>
          <FormItem label="文档名称" colon={false}>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                {
                  required: true,
                  pattern: ruleNameReg,
                  message: `仅限中英文、数字和下划线, 长度不超50`
                }
              ]
            })(<Input placeholder="请输入文件夹名称" />)}
          </FormItem>
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>()(EditDocModal);
