import React, { Component } from 'react';
import { observer } from 'mobx-react';
import CatalogTree from './components/CatalogTree';
import CatalogueStore from './stores/catalogue.store';
import AddCatalogueModal from './components/AddCatalogueModal';
import styles from './index.less';
import Icon from '@components/Icon';

interface IProps {
  onChange: any;
  history: any;
}
interface IState {
  inputValue: any;
}

@observer
class SiderTree extends Component<IProps, IState> {
  private readonly store: CatalogueStore;
  private readonly handleSearch: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      inputValue: ''
    };
    this.store = new CatalogueStore(props.history, props.onChange);
    this.handleSearch = _.debounce(this.store.handleSearchChange, 500);
  }

  public handleValueChange = (e: any) => {
    const inputValue = e.target.value;

    this.setState({
      inputValue
    });

    this.handleSearch(inputValue);
  };

  public componentDidMount() {
    this.store.getDefaultTreeNodes();
  }

  public render() {
    const { inputValue } = this.state;
    const {
      changeModalVisible,
      formData,
      loading,
      visible,
      modifyNode,
      addNode
    } = this.store;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <div className={styles.search}>
            <Icon type="search" fill="#969CA6" width={20} height={20} />
            <input
              value={inputValue}
              onChange={this.handleValueChange}
              type="text"
            />
          </div>
          <div className={styles.addBtn} onClick={addNode}>
            <Icon primary type="add" width={24} height={24} />
          </div>
        </div>
        <CatalogTree store={this.store} />
        {visible && (
          <AddCatalogueModal
            onOk={modifyNode}
            loading={loading}
            values={formData}
            visible={visible}
            onVisibleChange={changeModalVisible}
          />
        )}
      </div>
    );
  }
}

export default SiderTree;
