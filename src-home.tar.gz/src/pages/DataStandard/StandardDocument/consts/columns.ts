export const listColumns: any = [
  {
    title: '文档名称',
    dataIndex: 'name',
    check: true
  },
  {
    title: '文档类型',
    dataIndex: 'type',
    check: true
  },
  {
    title: '大小',
    dataIndex: 'fileSize',
    check: true
  },
  {
    title: '更新时间',
    dataIndex: 'updateTime',
    check: true
  }
];
