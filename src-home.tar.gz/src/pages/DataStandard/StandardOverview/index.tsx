// 标准概览
import React from 'react';
import classnames from 'classnames';
import QPSLineChart from './components/QPSLineChart';
import styles from './index.less';
const StandardOverview = () => {
  // 重要统计指标
  const statList = [
    {
      title: '标准集总数',
      count: 100
    },
    {
      title: '数据标准分布',
      count: 100
    },
    {
      title: '落地映射分布',
      count: 100
    },
    {
      title: '标准文档总数',
      count: 100
    }
  ];

  return (
    <div className={styles.standardOverview}>
      <div className={styles.headTitle}>标准概览</div>
      <ul className={styles.statList}>
        {statList.map((item, key) => (
          <li key={key}>
            <div>{item.title}</div>
            <div>{item.count}</div>
          </li>
        ))}
      </ul>
      <ul className={styles.chartList}>
        <li>
          <div className={styles.title}>标准集趋势</div>
          <div className={styles.chartWrap}>{/* <QPSLineChart /> */}</div>
        </li>
        <li>
          <div className={styles.title}>数据标准趋势</div>
          <div className={styles.chartWrap}>{/* <QPSLineChart /> */}</div>
        </li>
      </ul>
      <ul className={styles.chartList}>
        <li>
          <div className={styles.title}>主要数据标准及相应的质检分布</div>
          <div className={styles.chartWrap}>111</div>
        </li>
      </ul>
      <div className={styles.statWrap}>
        <div className={classnames(styles.statItem, styles.standardStat)}>
          数据标准统计
        </div>
        <div className={classnames(styles.statItem, styles.documentStat)}>
          <div>标准文档参考排行TOP10</div>
          <ul>
            <li>标准文档参考排行TOP1</li>
            <li>标准文档参考排行TOP2</li>
            <li>标准文档参考排行TOP3</li>
            <li>标准文档参考排行TOP4</li>
            <li>标准文档参考排行TOP5</li>
            <li>标准文档参考排行TOP6</li>
            <li>标准文档参考排行TOP7</li>
            <li>标准文档参考排行TOP8</li>
            <li>标准文档参考排行TOP9</li>
            <li>标准文档参考排行TOP10</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
export default StandardOverview;
