// 标准管理列表
import React, { FC, useState, useRef, useEffect } from 'react';

import { Dropdown, Menu, Button, Select, Icon as AIcon } from 'sup-ui';
import { observer, inject } from 'mobx-react';
import { useMemoizedFn } from 'ahooks';
import TipsDelete from '@components/Modal/TipsDelete';
import Header from '@components/Header';
import { AddBtn, DelBtn } from '@components/Button';
import KeywordSearch from '@components/KeywordSearch';
import Icon from '@components/Icon';
import { standardStatus, operateStatusEnum } from '../../const/enmu';
import AddStandard from '../../components/AddStandard';
import Progress from '../../components/Progress';
import InfoModal from '../../components/InfoModal';
import styles from './index.less';

const { Option } = Select;
interface IProps {
  standardStore?: any;
}
const StandardHeader: FC<IProps> = (props: IProps) => {
  const { standardStore } = props;
  const {
    selectedRowKeys,
    searchParams,
    deleteStandard,
    addStandardVisible,
    updateAddStandardVisible,
    updateSearchParams,
    exportStandard,
    exportStandardTemplate,
    importStandard,
    publishStandard,
    resultVisible,
    changeResultVisible,
    importInfo
  } = standardStore;

  const [isFocus, setFocus] = useState<boolean>(false);
  const searchRef: any = useRef();

  const cancelFocus = () => {
    setFocus(false);
  };

  // 因为点取消按钮时候，会触发blur，输入框会闪烁下，故增加isFocus参数
  useEffect(() => {
    document.addEventListener('click', cancelFocus);
    return () => {
      document.removeEventListener('click', cancelFocus);
    };
  }, []);

  //TODO 批量删除
  const handleBatchDelete = useMemoizedFn(() => {
    const config = {
      title: '确认删除此标准',
      onOk: async () => {
        await deleteStandard(selectedRowKeys);
      }
    };
    TipsDelete(config);
  });

  //TODO 批量发布
  const handleBatchPublish = useMemoizedFn(() => {
    publishStandard(selectedRowKeys);
  });

  // 标准列表查询
  const handleSearch = (value?: string) => {
    updateSearchParams({
      searchName: value || undefined
    });
  };

  const searchInputFocus = (e: any) => {
    if (searchRef) {
      searchRef.current?.focus();
      e.stopPropagation();
      e.nativeEvent.stopImmediatePropagation();
      setFocus(true);
    }
  };

  const handleStatusChange = (value: any) => {
    updateSearchParams({
      releaseStatus: value
    });
  };

  // 新建标准
  const handleAddStandard = () => {
    updateAddStandardVisible(true, operateStatusEnum.ADD_STATUS);
  };

  // 点击导入menu
  const handleMenuClick = (item: any) => {
    if (item.key === '1') {
      exportStandardTemplate();
    }
  };
  const menu = (
    <Menu>
      <Menu.Item key="1" onClick={handleMenuClick}>
        下载模板
      </Menu.Item>
      <Menu.Item key="2">
        <label htmlFor="upload_standard" style={{ cursor: 'pointer' }}>
          导入标准
        </label>
        <input
          type="file"
          id="upload_standard"
          accept=".xls,.xlsx"
          onChange={importStandard}
          hidden
        />
      </Menu.Item>
    </Menu>
  );

  const { searchName, releaseStatus } = searchParams;
  return (
    <div className={styles.headerWrap}>
      <Header
        className={styles.header}
        left={
          <>
            <AddBtn title="新增标准" ghost onClick={handleAddStandard} />
            <Button.Group className={styles.importBtnGroup}>
              <Button className={styles.importBtn}>
                <label
                  htmlFor="upload_standard-1"
                  style={{ cursor: 'pointer' }}
                >
                  导入
                </label>
                <input
                  type="file"
                  id="upload_standard-1"
                  accept=".xls,.xlsx"
                  onChange={importStandard}
                  hidden
                />
              </Button>
              <Dropdown overlay={menu}>
                <div className={styles.downIcon}>
                  <Icon type="down" />
                </div>
              </Dropdown>
            </Button.Group>

            <Button ghost onClick={exportStandard}>
              导出
            </Button>
            <DelBtn
              onClick={handleBatchDelete}
              disabled={!selectedRowKeys.length}
            />
            <Button
              ghost
              onClick={handleBatchPublish}
              disabled={!selectedRowKeys.length}
            >
              发布
            </Button>
          </>
        }
        right={
          <>
            <Select
              placeholder="请选择"
              style={{ width: 118, marginRight: 4 }}
              defaultValue={releaseStatus}
              onChange={handleStatusChange}
            >
              {standardStatus.map(item => (
                <Option value={item.key} key={item.key}>
                  {item.name}
                </Option>
              ))}
            </Select>
            <KeywordSearch
              placeholder="输入名称搜索"
              value={searchName}
              className={isFocus || searchName ? styles.searchActive : ''}
              ref={searchRef}
              suffix={
                searchName ? (
                  <Icon
                    type="circle-close"
                    size="small"
                    onClick={e => {
                      searchInputFocus(e);
                      handleSearch();
                    }}
                  />
                ) : (
                  <Icon type="search" onClick={searchInputFocus} />
                )
              }
              onSearch={handleSearch}
            />
          </>
        }
      />
      {addStandardVisible && <AddStandard standardStore={standardStore} />}
      {/* {exportInfo.progressing && (
        <Progress
          type={exportInfo.type}
          status={exportInfo.status}
          // onVisibleChange={handleProgressChange}
        />
      )} */}
      {resultVisible && (
        <InfoModal
          visible={resultVisible}
          onVisibleChange={changeResultVisible}
          source={importInfo}
        />
      )}
    </div>
  );
};
export default inject('standardStore')(observer(StandardHeader));
