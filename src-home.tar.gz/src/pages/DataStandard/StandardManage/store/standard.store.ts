import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { operateStatusEnum, foldType } from '../const/enmu';
import { downloadByBlob } from '../const/util';
import {
  exportModel,
  getStandardList,
  getStandardCode,
  checkStandardCode,
  getSetAttrList,
  addStandard,
  updateStandard,
  publishStandard,
  deleteStandard,
  getStandardDetail,
  importStandard,
  exportStandard,
  exportStandardTemplate
} from '../service/standard.service';
// 列表单行对象
interface RecodDto {
  id: number;
  name: string;
  createMode: number;
  accuracy: number;
  baseId: number;
  businessSegment: string;
  businessSegmentId: number;
  caliber: string;
  catalogName: string;
  code: string;
  dataCaliber: string;
  dataPeriod: number;
  dataUnit: string;
  dept: string;
  director: string;
  listDim: any[];
  subjectDomain: string;
  subjectDomainId: number;
}
const { ADD_STATUS, LOOK_STATUS, EDIT_STATUS } = operateStatusEnum;

class StandardManageStore {
  private readonly debounceGetList: any;
  @observable public dynamicOptions: any[] = []; // 动态标准列选项
  @observable public standardList: any[] = []; // 标准列表
  @observable public tableLoading = false;
  @observable public selectedRowKeys: any[] = []; //选中的行
  @observable public selectedRows: any[] = []; //选中的行
  @observable public searchParams: any = {
    // 操作状态：０停用、１启用 -１、全部
    operateStatus: -1,
    // 发布状态：-1全部 ０未发布、１已发布、２修订中
    releaseStatus: -1,
    searchName: undefined,
    codeOrderByIsAsc: true
    // folderId: 'string',
  };
  // @observable public loading = false;
  @observable public currRecord = {};
  @observable public operateStatus = ADD_STATUS; // 新增/查看/编辑

  @observable public modalLoading = false; // 抽屉/弹窗loading
  @observable public addStandardVisible = false; // 新建标准抽屉是否显示
  @observable public standardDetail: any = {}; // 编辑标准获取详情
  @observable public setAttrList = []; // 新建标准属性列表
  @observable public standardCode = []; // 标准编号
  @observable public departmentTree = []; // 部门树

  @observable public selectedCatalog: any = {}; // 选中的/文件夹标准
  @observable public treeNodes: any = []; // 标准树源数据
  @observable public importInfo: any = {}; // 导入信息
  @observable public resultVisible = false; // 导入结果弹窗是否显示

  public constructor() {
    this.debounceGetList = _.debounce(this.getStandardList, 300);
  }

  /**
   * 选择树节点回调
   * @param node 选中的树节点
   */
  @action.bound
  public onSelectTree(node: any) {
    this.selectedCatalog = node;
    this.selectedRowKeys = [];
    this.selectedRows = [];
    // 标准集的时候请求接口 获取标准列表
    if (node.type === foldType['STANDARDSET']) {
      this.getStandardList();
    }
  }

  /**
   * 获取数据标准列表
   * @param params
   */
  @action.bound
  public async getStandardList(params: any = {}) {
    this.tableLoading = true;
    const allParams = {
      ...this.searchParams,
      // 左侧选中的节点
      folderId: this.selectedCatalog.id,
      ...params
    };

    const res = await getStandardList({
      ...allParams,
      releaseStatus:
        allParams?.releaseStatus === -1 ? [] : [allParams?.releaseStatus]
    });
    runInAction(() => {
      if (res.code !== 200) {
        this.tableLoading = false;
        message.error(res.message);
        return;
      }
      const { standardList, columns } = res.data || {};
      this.searchParams = {
        ...this.searchParams,
        ...(_.isBoolean(params.codeOrderByIsAsc)
          ? { codeOrderByIsAsc: params.codeOrderByIsAsc }
          : {})
      };
      this.dynamicOptions = columns || [];
      this.standardList = standardList || [];
      this.tableLoading = false;
    });
  }

  /**
   * 更新列表选择行
   * @param selectedKeys 选中的key
   * @param selectedRows 选中的行
   */
  @action.bound
  public updateSelectedRowKeys(selectedKeys: string[], selectedRows: any[]) {
    this.selectedRowKeys = selectedKeys;
    this.selectedRows = selectedRows;
  }

  /**
   * 新建标准抽屉是否显示
   * @param visible
   */
  @action.bound
  public updateAddStandardVisible(visible: boolean, type?: number) {
    this.addStandardVisible = visible;
    if (!_.isNil(type)) {
      this.operateStatus = type;
    }
  }

  /**
   * 更新当前操作行
   * @param record
   */
  @action.bound
  public updateCurrRecord(record: any) {
    this.currRecord = record;
  }

  // 更新查询参数
  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.debounceGetList();
  }
  /**
   * 添加标准--获取添加属性字段信息
   * @param standardSetId
   */
  @action.bound
  public async getSetAttrList() {
    this.modalLoading = true;
    const res = await getSetAttrList(this.selectedCatalog.id);
    runInAction(() => {
      this.modalLoading = false;
      if (res.code === 200) {
        this.setAttrList = res.data || [];
      } else {
        message.error(res.message);
        return;
      }
    });
  }

  /**
   * 添加标准-获取编号
   * @param standardSetId
   */
  @action.bound
  public async getStandardCode() {
    this.modalLoading = true;
    const res = await getStandardCode(this.selectedCatalog.id);
    runInAction(() => {
      this.modalLoading = false;
      if (res.code === 200) {
        this.standardCode = res.data || [];
      } else {
        message.error(res.message);
        return;
      }
    });
    return res.data || '';
  }

  /**
   *
   * @param code 校验标准code唯一性
   * @returns boolean
   */
  @action.bound
  public async checkStandardCode(code: string) {
    this.modalLoading = true;
    const res = await checkStandardCode({
      code,
      standardSetId: this.selectedCatalog.id,
      standardId: this.standardDetail.id
    });
    runInAction(() => {
      this.modalLoading = false;
    });
    if (res.code !== 200) {
      if (res.code === 90301001) {
        return { flag: false, msg: res.message, isUniq: false };
      }
      // message.error(res.message);
      return { flag: false, msg: res.message };
    }
    return {
      flag: res.data
    };
  }

  /**
   * 新增/编辑标准
   * @param
   */
  @action.bound
  public async dealStandard(params: any = {}) {
    this.modalLoading = true;
    const isUpdate = params.id;
    const url = isUpdate ? updateStandard : addStandard;
    const res = await url(params);
    runInAction(() => {
      this.modalLoading = false;
      if (res.code === 200) {
        message.success(`${isUpdate ? '编辑' : '新增'}标准成功！`);
        this.initStandardData();
        this.getStandardList();
        this.addStandardVisible = false;
      } else {
        message.error(res.message);
        return;
      }
    });
  }

  /**
   * 获取标准详情
   * @param
   */
  @action.bound
  public async getStandardDetail(standardId: string) {
    this.modalLoading = true;
    const res = await getStandardDetail(standardId);
    runInAction(() => {
      this.modalLoading = false;
      if (res.code === 200) {
        this.standardDetail = res.data || {};
        this.standardCode = res.data?.code;
      } else {
        message.error(res.message);
        return;
      }
    });
  }

  /**
   * 清空
   * @param
   */
  @action.bound
  public async initStandardData() {
    this.standardDetail = {};
    this.currRecord = {};
  }

  /**
   * 删除标准
   * @param id
   */
  @action.bound
  public async deleteStandard(params: any) {
    this.tableLoading = true;
    const res = await deleteStandard(params);
    runInAction(() => {
      this.tableLoading = false;
      if (res.code === 200) {
        message.success('删除成功！');
        this.selectedRowKeys = [];
        this.selectedRows = [];
        this.getStandardList();
      } else {
        message.error(res.message);
        this.getStandardList();
        return;
      }
    });
  }

  /**
   * 发布标准
   */
  @action.bound
  public async publishStandard(params: any) {
    this.tableLoading = true;
    const res = await publishStandard(params);
    runInAction(() => {
      this.tableLoading = false;
      if (res.code === 200) {
        message.success('发布成功!');
        this.selectedRowKeys = [];
        this.selectedRows = [];
        this.getStandardList();
      } else {
        message.error(`发布失败\n${res.message}`);
        this.getStandardList();
        // message.error(
        //   <div>
        //     <div>发布失败</div>
        //     <div>{res.message}}</div>
        //   </div>
        // );
        return;
      }
    });
  }

  /**
   * 导出标准
   * @param standardId 标准id
   */
  @action.bound
  public async exportStandard() {
    this.tableLoading = true;
    const res = await exportStandard({
      folderId: this.selectedCatalog.id,
      codeOrderByIsAsc: this.searchParams.codeOrderByIsAsc
    });

    runInAction(() => {
      if (!res) {
        this.tableLoading = false;
        message.error('文件下载错误，请稍后再试!');
        return;
      }
      downloadByBlob(res, `${this.selectedCatalog.name}_数据标准.xls`);
      this.tableLoading = false;
    });
  }

  /**
   * 导出标准模板
   * @param standardId 标准id
   */
  @action.bound
  public async exportStandardTemplate() {
    this.tableLoading = true;
    const res = await exportStandardTemplate({
      folderId: this.selectedCatalog.id,
      codeOrderByIsAsc: this.searchParams.codeOrderByIsAsc
    });
    runInAction(() => {
      if (!res) {
        this.tableLoading = false;
        message.error('文件下载错误，请稍后再试!');
        return;
      }
      downloadByBlob(res, `${this.selectedCatalog.name}_数据标准模板.xls`);
      this.tableLoading = false;
    });
  }

  @action.bound
  public async importStandard(e: any) {
    e.persist();
    const file = e.target.files[0];

    if (!file) {
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    this.tableLoading = true;
    const res = await importStandard(formData, this.selectedCatalog.id);
    //上传后重置value，多次上次相同文件不会触发onChange事件
    e.target.value = '';

    runInAction(() => {
      if (res.code !== 200) {
        this.tableLoading = false;
        message.error(res.message);
        return;
      }
      const {
        errorCount,
        successCount,
        result,
        status,
        message: msg
      } = res.data;
      // 导入模板格式错误
      if (status === 3) {
        this.tableLoading = false;
        setTimeout(() => {
          message.error(msg);
        }, 500);
        return;
      }

      if (result && !_.isEmpty(result)) {
        this.resultVisible = true;
        this.importInfo = {
          errorCount,
          successCount,
          result
        };
      } else {
        setTimeout(() => {
          message.success('标准导入成功!');
        }, 1000);
      }

      this.getStandardList();
    });
  }

  // 导入结果弹窗是否显示
  @action.bound
  public changeResultVisible(visible: boolean) {
    this.resultVisible = visible;
  }
}

export default StandardManageStore;
