import React, { FC, useState, useMemo, forwardRef } from 'react';
import { Input } from 'sup-ui';
import OrganizationSelector from '@components/OrganizationSelector';
import styles from './index.less';
interface IProps {
  value?: any;
  type?: 'Person' | 'Department';
  onChange: (param: any) => void;
}

interface SelectValue {
  code?: string;
  name?: string;
  company?: string;
}
const DepartmentTree: FC<IProps> = forwardRef((props: IProps, _ref: any) => {
  const { value, onChange, type = 'Department' } = props;
  const [visible, setVisible] = useState(false);

  const parsedValue: any = useMemo(() => {
    try {
      const valueJSon =
        typeof value === 'string'
          ? JSON.parse(value)
          : { keyValue: undefined, showValue: '' };
      const { keyValue, showValue, company } = valueJSon;
      return {
        code: keyValue,
        name: showValue,
        company
      };
    } catch (error) {
      console.error(error);
      return { keyValue: value, showValue: '' };
    }
  }, [value]);

  const handleChange = (param: any) => {
    setVisible(false);
    const { name, code, company } = param || {};
    onChange &&
      onChange(JSON.stringify({ keyValue: code, showValue: name, company }));
  };

  return (
    <div className={styles.infoItem}>
      <div className={`${styles.cont}`} onClick={() => setVisible(true)}>
        {/* {parsedValue?.name || '请选择'} */}
        <Input readOnly placeholder="请选择" value={parsedValue?.name || ''} />
      </div>
      {visible && (
        <OrganizationSelector
          value={parsedValue}
          selectType={type}
          visible={visible}
          onVisibleChange={(val: boolean) => setVisible(val)}
          onChange={handleChange}
        />
      )}
    </div>
  );
});

export default DepartmentTree;
