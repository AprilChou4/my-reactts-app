/**
 * @description 部门树
 */
import React, { FC, forwardRef, useState } from 'react';
import { TreeSelect } from 'sup-ui';
import { useAsyncEffect } from 'ahooks';
import { getDepartList } from '../../service/standard.service';

const { TreeNode } = TreeSelect;
interface IProps {
  onChange: any;
  value: any;
}

const DepartmentTree: FC<IProps> = forwardRef((props: IProps, ref: any) => {
  const { onChange, value, ...rest } = props;
  const [treeList, setTreeList] = useState<any[]>([]);

  let valueJSon: any;
  try {
    valueJSon = value
      ? JSON.parse(value)
      : { keyValue: undefined, showValue: '' };
  } catch {
    valueJSon = { keyValue: value, showValue: '' };
  }

  const { keyValue, showValue } = valueJSon;

  useAsyncEffect(async () => {
    const res = await getDepartList({
      // code: 'default_org_company',
      // pageNum: 1,
      current: 1,
      pageSize: 500
    });
    setTreeList(res.list || []);
  }, []);

  const handleOnChange = (v: any, label: any) => {
    onChange(JSON.stringify({ keyValue: v, showValue: label?.[0] }));
  };

  //递归节点树结构
  const loopTreeNode = (data: any) => {
    return data?.map((item: any) => {
      if (item.children) {
        return (
          <TreeNode
            key={item.code}
            value={item.code}
            dataRef={item}
            title={item.name}
          >
            {loopTreeNode(item.children)}
          </TreeNode>
        );
      }

      return (
        <TreeNode
          key={item.code}
          value={item.code}
          dataRef={item}
          isLeaf={item.isLeaf}
          title={item.name}
        />
      );
    });
  };

  return (
    <TreeSelect
      placeholder="请选择"
      onChange={handleOnChange}
      value={keyValue}
      getPopupContainer={triggerNode =>
        triggerNode.parentElement as HTMLElement
      }
      {...rest}
      ref={ref}
    >
      {loopTreeNode(treeList)}
    </TreeSelect>
  );
});

export default DepartmentTree;
