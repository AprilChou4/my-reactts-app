/**
 * @description 新增标准
 * @author zhouxiaojuan
 */
import React, { FC, useEffect } from 'react';
import { observer } from 'mobx-react';
import { Form, Spin, Button, Icon, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import CommonDrawer from '@components/Drawer/CommonDrawer';
import Header from '@components/Header';
import DataSettingForm from '@components/DataSettingForm';
import DataFormat from '../DataFormat';
import DepartmentTree from '../DepartmentTree';
// import StandardTheme from '../StandardTheme';
import classnames from 'classnames';
import { operateStatusEnum, attributeTypeEnum } from '../../const/enmu';
import { numberReg, nonNegativeNumReg } from '../../const/regex';
import { FieldItem } from '../../const/type.d';
import { valueRangeReg, numReg, setEnNameReg } from '../../const/regex';
import styles from './index.less';

interface IProps extends FormComponentProps {
  standardStore: any;
}

// 保存的时候
interface attributeTypeItem {
  attributeId: string;
  attributeValue: any;
  id: string;
  required: boolean;
}

const textLayout = {
  labelCol: {
    span: 3
  },
  wrapperCol: {
    span: 21
  }
};
const AddStandard: FC<IProps> = (props: IProps) => {
  const { form, standardStore } = props;
  const {
    modalLoading,
    addStandardVisible,
    updateAddStandardVisible,
    operateStatus,
    currRecord,
    dealStandard,
    getSetAttrList,
    setAttrList,
    selectedCatalog,
    getStandardCode,
    standardCode,
    checkStandardCode,
    getStandardDetail,
    standardDetail,
    initStandardData
  } = standardStore;
  const { ADD_STATUS, VIEW_STATUS, EDIT_STATUS } = operateStatusEnum;
  const isView = operateStatus === VIEW_STATUS;

  // 获取属性选项
  useEffect(() => {
    getSetAttrList();
  }, []);

  useEffect(() => {
    if (currRecord.id) {
      // 获取标准详情
      getStandardDetail(currRecord.id);
    } else {
      // 获取标准编号
      getStandardCode();
    }
  }, [currRecord.id]);

  const { cnName, enName, attributeTypeVOList = [] } = standardDetail || {};

  const getInitialValue = (type: string) => {
    const target = _.find(attributeTypeVOList, ['attributeEnName', type]);
    switch (type) {
      // 待修改
      case 'standard_code':
        return standardCode;
      case 'standard_cn_name':
        return cnName;
      case 'standard_en_name':
        return enName;
      // 是否加密 默认否
      case 'sensitivencryp':
        return target?.attributeValue || '0';
      // 数据完整 不可为空（默认1）、可为空0
      case 'null_rule':
        return target?.attributeValue || '1';
      default: {
        return target?.attributeValue || undefined;
      }
    }
  };

  const getRules = (item: any) => {
    const { attributeId, attributeEnName: type } = item;
    switch (type) {
      case 'standard_code':
        return [
          {
            validator: async (_rule: any, value: any, callback: any) => {
              if (!value) {
                return;
              }
              if (value.length > 20) {
                callback('编码长度不能超过20位字符');
                return;
              }
              try {
                const { flag, msg, isUniq } =
                  (await checkStandardCode(value)) || {};

                if (!_.isNil(isUniq)) {
                  const code = await getStandardCode();
                  form.setFieldsValue({
                    [`${attributeId}.attributeValue`]: code
                  });
                  message.warning(msg);
                  callback();
                }
                if (!flag) {
                  callback(msg || '请输入唯一标准编码');
                } else {
                  callback();
                }
              } catch {
                callback();
              }
            }
          }
        ];
      case 'standard_en_name': {
        return [
          {
            pattern: setEnNameReg,
            message: '只允许输入英文和下划线,下划线不能在最后'
          }
        ];
      }
      // 值域范围
      case 'range_rule':
        return [
          {
            validator: async (_rule: any, value: any, callback: any) => {
              if (!value) {
                callback();
              }
              const rangeList = _.trim(value)?.split(';');
              for (let i = 0; i < rangeList.length; i++) {
                const range = rangeList[i];
                const reg = valueRangeReg.exec(range);
                if (!reg) {
                  callback(
                    '请输入正确的值域范围，如(-∞,1],[3,+∞)，不能同时为∞，以;分隔'
                  );
                  return;
                }

                const leftVal = reg[3],
                  rightVal = reg[5];

                if (!leftVal && !rightVal) {
                  callback('不支持(-∞,+∞)值域，请重新输入!');
                  return;
                }

                if (leftVal && !numReg.test(leftVal)) {
                  callback('左值域请填写正确的数字，支持小数!');
                  return;
                }

                if (rightVal && !numReg.test(rightVal)) {
                  callback('右值域请填写正确的数字，支持小数!');
                  return;
                }

                if (+rightVal <= +leftVal) {
                  callback('值域请填写正确的数字, 且左值需小于右值!');
                  return;
                }
                callback();
              }
            }
          }
        ];
      case 'enums_values':
        return [
          {
            validator: async (_rule: any, value: any, callback: any) => {
              const arr = value?.split(',');
              const hasEmpty = !_.every(arr, Boolean);
              if (!value) {
                callback();
              }
              if (_.includes(value, '，')) {
                callback('枚举值不允许使用中文逗号分隔!');
                return;
              }
              if (_.startsWith(value, ',') || _.endsWith(value, ',')) {
                callback('枚举值不允许以逗号开头或结尾!');
                return;
              }

              if (hasEmpty) {
                callback('枚举值不能为空');
                return;
              }
              callback();
            }
          }
        ];
      // 数据长度
      case 'data_length':
        return [
          {
            pattern: numberReg,
            message: '请输入正整数'
          }
        ];
      // 数据精度（小数位数）
      case 'data_scale':
        return [
          {
            pattern: nonNegativeNumReg,
            message: '请输入非负整数'
          }
        ];
      default:
        return [];
    }
  };

  const getPlaceholder = (type: string) => {
    switch (type) {
      // 值域范围
      case 'range_rule':
        return '支持区间格式，如(-∞,1];[3,+∞)等等，以;分隔';
      // 枚举值
      case 'enums_values':
        return '如: 昨天,今天,明天 请用英文逗号隔开';
      case 'data_scale':
        return '请输入数据精度（小数位数）';
      default:
        return '';
    }
  };

  // 特殊的属性 // 待修改
  const getComponent = (type: string, config: any) => {
    switch (type) {
      // 数据规范
      case 'standard_rule':
        return <DataFormat form={form} {...config} />;
      // 归属部门
      case 'subordinate_department':
        return <DepartmentTree {...config} />;
      // case '标准主题':
      //   return <StandardTheme />;
      default:
        return null;
    }
  };
  /**
   * 获取表单配置项
   * @param list
   * @param typeId 属性类型id
   * @returns
   */
  const getFormConfigList = (list: FieldItem[]) => {
    const newList = _.map(list, item => {
      const {
        attributeId,
        attributeCnName,
        attributeEnName,
        attributeLength,
        isRequired,
        standardFieldTypeVO
      } = item;
      const required = isRequired === 1;
      const { attributeInputType, attributeValues } = standardFieldTypeVO || {};
      const formatAttributeValues = _.map(attributeValues, o => ({
        itemName: o.attributeFieldName,
        itemKey: o.attributeFieldValue
      }));

      const target =
        _.find(attributeTypeVOList, ['attributeId', attributeId]) || {};
      const newItem: any[] = [
        {
          label: attributeCnName,
          display: 'none',
          key: `${attributeId}.attributeId`,
          type: 'input',
          initialValue: attributeId
        },
        {
          label: attributeCnName,
          display: 'none',
          key: `${attributeId}.id`,
          type: 'input',
          initialValue: target.id
        }
      ];
      // 特殊属性处理
      if (
        ['standard_rule', 'subordinate_department'].includes(attributeEnName)
      ) {
        newItem.push({
          label: `${attributeCnName}`,
          key: `${attributeId}.attributeValue`,
          colon: isView,
          type: 'component',
          component: getComponent(attributeEnName, {
            maxLength: attributeLength,
            disabled: isView
          }),
          initialValue: getInitialValue(attributeEnName),
          rules: [{ required, message: '必填项' }, ...getRules(item)],
          fieldDecorator: {
            validateTrigger: 'onChange'
          }
        });
        return newItem;
      }

      newItem.push({
        label: `${attributeCnName}`,
        placeholder: getPlaceholder(attributeEnName),
        key: `${attributeId}.attributeValue`,
        colon: isView,
        type: attributeTypeEnum[attributeInputType],
        options: formatAttributeValues || [],
        maxLength: attributeLength,
        disabled: isView,
        initialValue: getInitialValue(attributeEnName),
        rules: [{ required, message: '必填项' }, ...getRules(item)],
        ...(attributeEnName === 'standard_code'
          ? {
              fieldDecorator: {
                validateTrigger: 'onBlur'
              }
            }
          : {})
      });
      return newItem;
    });
    return _.flatten(newList);
  };

  const handleEdit = () => {
    updateAddStandardVisible(true, EDIT_STATUS);
  };

  const handleOK = () => {
    form.validateFieldsAndScroll((err, values) => {
      if (err) {
        return;
      }
      const finalAttrList: any[] = [];
      _.forIn(values, v => {
        if (!v?.attributeId) {
          return;
        }
        finalAttrList.push(v);
      });
      const params = {
        attributeTypeVOList: finalAttrList,
        folderId: selectedCatalog.id,
        id: standardDetail.id //  待修改-新增不用传
      };
      // 新增标准
      dealStandard(params);
    });
  };

  const handleCancel = () => {
    updateAddStandardVisible(false);
    initStandardData();
  };

  return (
    <CommonDrawer
      closable={true}
      title={null}
      visible={addStandardVisible}
      width={900}
      onOk={handleOK}
      onCancel={handleCancel}
      wrapClassName={styles.operateStandardWrapper}
      okButtonProps={{ disabled: isView }}
      loading={modalLoading}
    >
      <Spin spinning={modalLoading} tip="加载中...">
        <div className={styles.container}>
          <Header
            className={styles.titleHeader}
            left={
              <h3>
                标准管理<span>/</span>
                <small
                  {...(currRecord?.cnName?.length > 48
                    ? { title: currRecord?.cnName }
                    : {})}
                >
                  {operateStatus === ADD_STATUS
                    ? '新建标准'
                    : currRecord?.cnName}
                </small>
              </h3>
            }
            right={
              operateStatus === VIEW_STATUS && (
                <Button
                  type="primary"
                  ghost
                  style={{ padding: '0 12px' }}
                  onClick={handleEdit}
                >
                  <Icon type="edit" />
                  编辑
                </Button>
              )
            }
          />

          <div className={styles.content}>
            {setAttrList.map((item: any) => {
              const { id, name, fieldList } = item;

              const configList = getFormConfigList(fieldList);
              return (
                <div key={id}>
                  <h3>{name}</h3>
                  <Form
                    className={classnames(
                      styles.setForm,
                      isView ? styles['setFormText'] : ''
                    )}
                  >
                    <DataSettingForm
                      form={form}
                      list={configList}
                      displayForm={isView ? 'text' : 'form'}
                      {...(isView && { formItemLayout: textLayout })}
                    />
                  </Form>
                </div>
              );
            })}
          </div>
        </div>
      </Spin>
    </CommonDrawer>
  );
};
const AddStandardOb = observer(AddStandard);
export default Form.create<IProps>()(AddStandardOb);
