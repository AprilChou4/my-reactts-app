import React, { Component } from 'react';
import DialogModal from '@components/Modal/Dialog';
import styles from './index.less';

interface IProps {
  source: any;
  visible: boolean;
  onVisibleChange: any;
}

interface IState {}

class InfoModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      visible,
      onVisibleChange,
      source: { errorCount, successCount, result }
    } = this.props;

    return (
      <DialogModal
        width={500}
        title="导入结果"
        visible={visible}
        maskClosable={false}
        bodyStyle={{ padding: 0 }}
        onCancel={() => onVisibleChange(false)}
        wrapClassName={styles.modalContainer}
        footer={null}
      >
        <div className={styles.container}>
          <p>
            导入成功的标准数{successCount}个，导入失败的标准数{errorCount}
            个。失败详情：
          </p>
          <ul>
            {_.map(result, (value, key) => (
              <li key={key}>
                {/* {key}:  */}
                {value}
              </li>
            ))}
          </ul>
        </div>
      </DialogModal>
    );
  }
}

export default InfoModal;
