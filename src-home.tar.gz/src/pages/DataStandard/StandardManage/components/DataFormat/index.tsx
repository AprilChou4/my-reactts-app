/**
 * @description 数据规范
 * @author zhouxiaojuan
 */
import React, { FC, forwardRef, useEffect, useState } from 'react';
import { Select, Input, Form } from 'sup-ui';
import { dataFormat } from '@consts/rules';

const { Option } = Select;
interface IProps {
  form: any;
  [propName: string]: any;
}
const generateRegMap = (source: any[]) => {
  const map: any = {};
  _.forEach(source, ({ key, reg }) => {
    map[key] = reg;
  });
  return map;
};

// 正则的映射
const regMap = generateRegMap(dataFormat);

const DataFormat: FC<IProps> = forwardRef((props: IProps, ref: any) => {
  // 自定义未10
  const [regType, setRegType] = useState('1');
  const { form, onChange, value, ...rest } = _.omit(props, ['onBlur']);
  const { setFieldsValue, getFieldDecorator } = form;

  let valueJSon: any;
  try {
    valueJSon = value
      ? JSON.parse(value)
      : { keyValue: undefined, showValue: '' };
  } catch {
    valueJSon = { keyValue: value, showValue: '' };
  }

  const { keyValue, showValue } = valueJSon;
  //
  useEffect(() => {
    setFieldsValue({
      regularExpression: regMap[props.value]
    });
  }, [props.value]);

  const handleFormatChange = (v: any) => {
    const regexVal = regMap[v];
    setRegType(v);
    onChange(JSON.stringify({ keyValue: v, showValue: regexVal }));
  };

  useEffect(() => {
    setFieldsValue({
      regularExpression: showValue
    });
  }, [showValue]);
  return (
    <>
      <Select
        placeholder="-请选择-"
        onChange={handleFormatChange}
        onBlur={handleFormatChange}
        {...rest}
        ref={ref}
        value={keyValue}
      >
        {dataFormat.map((item: any) => (
          <Option key={item.key} value={item.key} title={item.sample || ''}>
            {item.showName}
          </Option>
        ))}
      </Select>
      <Form.Item label="表达式" style={{ marginBottom: 0 }}>
        {getFieldDecorator('regularExpression', {
          initialValue: showValue || ''
        })(<Input placeholder="请输入表达式" disabled={regType !== '10'} />)}
      </Form.Item>
    </>
  );
});
export default DataFormat;
