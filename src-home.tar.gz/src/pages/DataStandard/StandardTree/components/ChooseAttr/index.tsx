/**
 * @description 选择属性
 * @author zhouxiaojuan
 */
import React, { FC, useEffect, useState } from 'react';
import { observer } from 'mobx-react';
import { Checkbox, Table, Spin, Button } from 'sup-ui';
import DialogModal from '@components/Modal/Dialog';
import KeywordSearch from '@components/KeywordSearch';
import { TableCellText } from '@components/Table';
import AttrType from '../AttrType';
import styles from './index.less';

const CheckboxGroup = Checkbox.Group;

interface IProps {
  standardSetStore: any;
  onOk: (list: any[]) => void;
  // 选中的list 对应选中的list
  tableFields: any[];
}
const timer = null;
const ChooseAttr: FC<IProps> = (props: IProps) => {
  const { standardSetStore, onOk } = props;
  const {
    updateChooseAttrVisible,
    updateLoading,
    handleSelectAttrType,
    selectedAttrTypeNode,
    attrList,
    allAttrList,
    searchParams,
    updateSearchParams,
    attrTypeList,
    getAttrTypeList,
    loading
  } = standardSetStore;

  // 右侧选中的列表
  const [rightAttrList, setRightAttrList] = useState<any[]>([]);
  const [selectedRowKeys, setSelectedRowKeys] = useState<any[]>([]);
  const [checkAll, setCheckAll] = useState(false);
  const [checkedKeys, setCheckedKeys] = useState<any[]>([]);

  // 新增的时候--未选属性时--
  useEffect(() => {
    if (!props.tableFields.length) {
      const list = _.filter(allAttrList, o => o.requiredItem === 1);
      setRightAttrList(list);
      setSelectedRowKeys(_.map(list, 'attributeId'));
    }
  }, [allAttrList.length]);

  // 编辑的时候--已选属性
  useEffect(() => {
    if (props.tableFields.length) {
      // 待修改 详情返回的数据和属性列表不一致
      const ids = _.map(props.tableFields, v => v.attributeId);
      setRightAttrList(props.tableFields);
      setSelectedRowKeys(ids);
    }
  }, [props.tableFields]);

  // 获取列表
  useEffect(() => {
    getAttrTypeList();
  }, []);

  const getColumns = (): any[] => {
    return [
      {
        title: '属性名称',
        dataIndex: 'attributeCnName',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '属性描述',
        dataIndex: 'description',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      }
    ];
  };

  const rowSelection = {
    columnWidth: 50,
    selectedRowKeys,
    onChange: setSelectedRowKeys,
    getCheckboxProps: (record: any) => {
      return {
        disabled: record.requiredItem === 1
      };
    },
    hideDefaultSelections: true
  };

  // 全选
  const onCheckAllChange = (e: any) => {
    const { checked } = e.target;
    const filterRightList = _.filter(rightAttrList, o => o.requiredItem !== 1);
    const cKeys = checked ? _.map(filterRightList, i => i.attributeId) : [];
    setCheckAll(checked);
    setCheckedKeys(cKeys);
  };

  // check右侧复选框
  const handleChangeChecked = (cKeys: any[]) => {
    const isCheckAll = cKeys.length === rightAttrList.length;
    setCheckedKeys(cKeys);
    setCheckAll(isCheckAll);
  };

  // 向左移动
  const handleMoveToLeft = () => {
    const list = _.cloneDeep(rightAttrList);
    _.remove(list, (item: any) => _.includes(checkedKeys, item.attributeId));
    setRightAttrList(list);
    setCheckedKeys([]);
    setCheckAll(false);
    const newIds = _.map(list, 'attributeId');
    setSelectedRowKeys(_.uniq(newIds));
  };

  // 向右移动
  const handleMoveToRight = () => {
    const newList: any[] = [];
    const currRightIds = _.map(rightAttrList, 'attributeId');
    _.forEach(selectedRowKeys, item => {
      const target = _.find(attrList, i => i.attributeId === item);
      if (!_.isNil(target) && !currRightIds.includes(target.attributeId)) {
        newList.push(target);
      }
    });
    const newRightList = _.concat(rightAttrList, newList);
    setRightAttrList(newRightList);
    const newIds = _.map(newRightList, 'attributeId');
    setSelectedRowKeys(_.uniq(newIds));
  };

  const handleCancel = () => {
    updateChooseAttrVisible(false);
  };

  const handleOK = () => {
    updateChooseAttrVisible(false);
    updateLoading(true);
    // 略卡 加loading过渡
    setTimeout(() => {
      const dealedList = _.map(rightAttrList, item => {
        return {
          ...item,
          isDisplay: item.isDisplay ?? 1
        };
      });
      onOk(dealedList);
      updateLoading(false);
    }, 20);
  };
  return (
    <DialogModal
      width={1200}
      title="选择属性"
      centered
      visible
      onOk={handleOK}
      onCancel={handleCancel}
      className={styles.chooseAttrModal}
    >
      <Spin spinning={!!loading}>
        <div className={styles.container}>
          <div className={styles.sider}>
            <AttrType
              attrTypeList={attrTypeList}
              selectedNode={selectedAttrTypeNode}
              onSelectAttrType={handleSelectAttrType}
            />
          </div>
          <div className={styles.tableWrapper}>
            <KeywordSearch
              value={searchParams.searchName}
              placeholder="请输入关键字搜索"
              className={styles.searchWrapper}
              onSearch={value =>
                updateSearchParams({ searchName: value || undefined })
              }
            />
            <Table
              // loading={tableLoading}
              columns={getColumns()}
              rowSelection={rowSelection}
              className={`${styles.attrTable} mp-table-gray mp-table-grow`}
              dataSource={attrList}
              rowKey="attributeId"
              onRow={() => {
                return {
                  // 点击行选中复选框
                  onClick: (event: any) => {
                    event.currentTarget
                      .getElementsByClassName('sup-checkbox-wrapper')[0]
                      .click();
                  }
                };
              }}
              pagination={false}
              scroll={{
                y: true
              }}
            />
          </div>

          <div className={styles.operation}>
            <Button
              icon="right"
              title="右移"
              type="primary"
              className={styles.operationBtn}
              disabled={!selectedRowKeys.length}
              onClick={handleMoveToRight}
            />
            <Button
              icon="left"
              title="左移"
              className={styles.operationBtn}
              onClick={handleMoveToLeft}
              disabled={!checkedKeys.length}
            />
          </div>

          {/* <h3 className={styles.selectedCount}>
            已选&nbsp;:&nbsp; */}
          {/* {rightAttrList.length} */}
          {/* </h3> */}
          <div className={styles.selectedListContainer}>
            <div className={styles.checkAll}>
              <Checkbox onChange={onCheckAllChange} checked={checkAll}>
                全选
              </Checkbox>
            </div>
            <CheckboxGroup value={checkedKeys} onChange={handleChangeChecked}>
              {_.map(rightAttrList, (item: any) => (
                <Checkbox
                  value={item.attributeId}
                  key={item.attributeId}
                  disabled={item.requiredItem === 1}
                >
                  {item.attributeCnName}
                </Checkbox>
              ))}
            </CheckboxGroup>
          </div>
        </div>
      </Spin>
    </DialogModal>
  );
};
export default React.memo(observer(ChooseAttr));
