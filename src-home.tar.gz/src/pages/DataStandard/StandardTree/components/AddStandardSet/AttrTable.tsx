/**
 * @description 属性配置表格
 * @author zhouxiaojuan
 */
import React, { FC } from 'react';
import { observer } from 'mobx-react';
import { Divider, Button, Select } from 'sup-ui';
import Icon from '@components/Icon';
import EditTable from '@components/Table/EditTable';
import { TableCellText } from '@components/Table';
import classnames from 'classnames';
import styles from './index.less';

const { Option } = Select;
interface IProps {
  dataSource: any[];
  updateDataList: (list: any[]) => void;
}

const booleanOptions = [
  { name: '是', key: 1 },
  { name: '否', key: 0 }
];

const AttrTable: FC<IProps> = (props: IProps) => {
  const { dataSource, updateDataList } = props;
  // const [form, setForm] = useState<any>();

  // 上移
  const handleToUp = (index: number) => {
    const newList = _.cloneDeep(dataSource);
    if (index !== 0) {
      newList[index] = newList.splice(index - 1, 1, newList[index])[0];
    }
    // form?.resetFields();
    updateDataList(newList);
  };

  // 下移
  const handleToDown = (index: number) => {
    const newList = _.cloneDeep(dataSource);

    if (index !== newList.length - 1) {
      newList[index] = newList.splice(index + 1, 1, newList[index])[0];
    }
    // form?.resetFields();
    updateDataList(newList);
  };
  // 删除行
  const handleDelete = (record: any) => {
    const newDataSource = dataSource.filter(
      (item: any) => item.attributeId !== record.attributeId
    );
    // form?.resetFields();
    updateDataList(newDataSource);
  };

  const getColumns = () => {
    return [
      {
        title: '属性名称',
        dataIndex: 'attributeCnName',
        key: 'attributeCnName',
        className: 'ellipsis-hide',
        width: 130,
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '属性类型',
        dataIndex: 'attributeTypeName',
        key: 'attributeTypeName',
        width: 100,
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段类型',
        dataIndex: 'attributeDataType',
        key: 'attributeDataType',
        width: 110,
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '字段长度',
        dataIndex: 'attributeLength',
        key: 'attributeLength',
        width: 80,
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '必填项',
        dataIndex: 'isRequired',
        key: 'isRequired',
        width: 80,
        editable: true,
        fieldDecorator: (record: any) => {
          return {
            initialValue: record.isRequired ?? 0
          };
        },
        render: (text: any, record: any) => {
          const { requiredItem } = record;
          return requiredItem === 1 ? (
            <div>是</div>
          ) : (
            <Select
              placeholder="请选择"
              style={{ width: '100%' }}
              getPopupContainer={triggerNode =>
                triggerNode.parentElement as HTMLElement
              }
              onChange={value => {
                onRowSave({
                  ...record,
                  isRequired: value
                });
              }}
            >
              {booleanOptions.map(item => (
                <Option value={item.key} key={item.key}>
                  {item.name}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '属性描述',
        dataIndex: 'description',
        key: 'description',
        width: 110,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '列表显示',
        dataIndex: 'isDisplay',
        key: 'isDisplay',
        width: 80,
        editable: true,
        trigger: 'onChange',
        type: 'select',
        fieldDecorator: (record: any) => {
          return {
            initialValue: _.isNil(record.isDisplay) ? 1 : record.isDisplay
          };
        },
        render: (text: any, record: any) => {
          return [
            'standard_code',
            'standard_cn_name',
            'standard_en_name'
          ].includes(record.attributeEnName) ? (
            <div>是</div>
          ) : (
            <Select
              placeholder="请选择"
              style={{ width: '100%' }}
              onChange={value => {
                onRowSave({
                  ...record,
                  isDisplay: value
                });
              }}
              getPopupContainer={triggerNode =>
                triggerNode.parentElement as HTMLElement
              }
            >
              {booleanOptions.map(item => (
                <Option value={item.key} key={item.key}>
                  {item.name}
                </Option>
              ))}
            </Select>
          );
        }
        // config: {
        //   selectOptions: booleanOptions,
        //   keyName: 'key',
        //   valueName: 'name'
        // }
      },
      // 产品说先隐藏
      // {
      //   title: '默认值',
      //   dataIndex: 'defaultValue',
      //   key: 'defaultValue',
      //   width: 80,
      //   editable: true,
      //   fieldDecorator: {
      //     rules: [{ required: true, message: '请输入默认值' }]
      //   },
      //   type: 'input'
      // },
      {
        title: '操作',
        width: 140,
        align: 'center',
        render: (_text: any, record: any, index: number) => {
          const { requiredItem } = record;
          const isDisabled = requiredItem === 1;
          return (
            <>
              <div className="operator">
                <Button
                  type="link"
                  disabled={index === 0}
                  onClick={() => handleToUp(index)}
                >
                  上移
                </Button>
                <Divider type="vertical" />
                <Button
                  type="link"
                  disabled={index === dataSource.length - 1}
                  onClick={() => handleToDown(index)}
                >
                  下移
                </Button>
                <Divider type="vertical" />
                <Button
                  type="link"
                  onClick={() => handleDelete(record)}
                  disabled={isDisabled}
                >
                  删除
                </Button>
              </div>
              <div className="more">
                <Icon type="ellipsis" width={13} />
              </div>
            </>
          );
        }
      }
    ];
  };

  /**
   *  单行操作保存
   * @param row  最新的行数据
   */
  const onRowSave = (row: any) => {
    const newDataSource = _.map(dataSource, (item: any) => {
      return row.attributeId === item.attributeId ? { ...item, ...row } : item;
    });
    updateDataList(newDataSource);
  };

  const columns = getColumns();
  return (
    <div
      className={classnames('mp-table-gray mp-table-grow', styles.tableWrapper)}
    >
      <EditTable
        size="small"
        theme="light"
        rowKey="attributeId"
        columns={columns}
        dataSource={dataSource}
        onRowSave={onRowSave}
        scroll={{ y: 380 }}
        pagination={false}
        // getForm={(f: any) => setForm(f)}
      />
    </div>
  );
};
export default React.memo(observer(AttrTable));
