/**
 * @description 标准树
 * @author zhouxiaojuan
 */
import React, { FC, useEffect } from 'react';
import { observer, useLocalStore, inject } from 'mobx-react';
import { Spin, Dropdown, Menu, Input } from 'sup-ui';
import Icon from '@components/Icon';
import TreeModule from './components/TreeModule';
import AddFolder from './components/AddFolder';
import AddStandardSet from './components/AddStandardSet';
import TreeStore from './stores/tree.store';

import styles from './index.less';

const MenuItem = Menu.Item;

interface IProps {
  // 选中节点回调
  onSelectTree: (node: any) => void;
  // 是否支持新增编辑删除
  editable?: boolean;
  // 是否可拖动
  dragable?: boolean;
  getTree?: (tree: any[]) => void;
  global?: any;
}
const StandardTree: FC<IProps> = (props: IProps) => {
  const { global, onSelectTree, editable, dragable, getTree } = props;
  const treeStore: TreeStore = useLocalStore(
    () =>
      new TreeStore({
        onSelectTree,
        globalStore: global
      })
  );
  const {
    addFolderVisible,
    addStandardSetVisible,
    updateFolderVisible,
    updateStandardSetVisible,
    updateSearchText,
    searchText,
    getTreeNodes,
    treeNodes,
    debounceGetTreeNode
  } = treeStore;

  useEffect(() => {
    if (getTree) {
      getTree(treeNodes);
    }
  }, [treeNodes]);

  const handleSearchFolder = (e: any) => {
    updateSearchText(e.target.value);
    debounceGetTreeNode();
  };
  // 新增文件夹
  const handleAddFolder = () => {
    updateFolderVisible(true);
  };

  // 新增标准集
  const handleAddStandardSet = () => {
    updateStandardSetVisible(true);
  };
  const menu = (
    <Menu>
      <MenuItem onClick={() => handleAddFolder()}>新增文件夹</MenuItem>
      <MenuItem
        // disabled={_.isEmpty(selectedCatalog) || selectedCatalog.depth === 2}
        onClick={() => handleAddStandardSet()}
      >
        新增标准集
      </MenuItem>
    </Menu>
  );
  return (
    <div className={styles.siderTree}>
      <div className={styles.search}>
        <Input
          value={searchText}
          onPressEnter={getTreeNodes}
          onChange={handleSearchFolder}
          placeholder="搜索"
          type="text"
          prefix={<Icon type="search" fill="#969CA6" />}
          allowClear
          size="small"
        />
        {editable && (
          <Dropdown overlay={menu} className={styles.addbutton}>
            <div>
              <Icon primary type="add" fill="#000" />
            </div>
          </Dropdown>
        )}
      </div>
      <div className={styles.content}>
        <TreeModule
          treeStore={treeStore}
          editable={!!editable}
          dragable={!!dragable}
        />
      </div>

      {/* 新增文件夹 */}
      {addFolderVisible && <AddFolder treeStore={treeStore} />}
      {/* 新增标准集 */}
      {addStandardSetVisible && <AddStandardSet treeStore={treeStore} />}
    </div>
  );
};
StandardTree.defaultProps = {
  editable: true,
  dragable: true,
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onSelectTree: (node: any) => {}
};
export default inject('global')(observer(StandardTree));
