import http from '@services/http';
import { STANDRARD_URL } from '@config/env';

const PrefixURL = `${STANDRARD_URL}/manage`;
/**
 * 数据标准属性类型列表－新建标准集－选择属性-全部类型
 * @param params
 * @returns
 */
export const getAttrTypeList = (): Promise<any> => {
  return http.post(`${PrefixURL}/set/attribute/manager/attribute/type/list`);
};

/**
 * 数据标准属性类型列表－新建标准集－选择属性类型－返回类型下属性列表
 * @param params {
    "attributeTypId": "string", // 类型id
    "searchName": "string"  // 查询名称
  }
 * @returns 
 */
export const getAttrList = (params: any): Promise<any> => {
  return http.post(`${PrefixURL}/set/attribute/manager/attribute/list`, params);
};

/**
 * 新增标准集－获取编号前缀
 * @returns
 */
export const getCodePrefix = (): Promise<any> => {
  return http.get(`${PrefixURL}/set/manager/codePrefix`);
};

/**
 * 新增标准集－检查编号前缀唯一性
 * @returns
 */
export const checkCodePrefix = (
  standardSetId: string,
  codePrefix: string
): Promise<any> => {
  return http.get(
    `${PrefixURL}/set/manager/check/${standardSetId}/${codePrefix}`
  );
};

/**
 * 标准集新增
 * @param params
 * @returns
 */
export const addStandardSet = (params: any): Promise<any> => {
  return http.post(`${PrefixURL}/set/manager/add`, params);
};

/**
 * 标准集修改
 * @param params
 * @returns
 */
export const updateStandardSet = (params: any): Promise<any> => {
  return http.post(`${PrefixURL}/set/manager/update`, params);
};

/**
 * 查看标准集详情－传入目录ＩＤ须为标准集类型
 * @param folderId
 * @returns
 */
export const getStandardSetDetail = (folderId: string): Promise<any> => {
  return http.get(`${PrefixURL}/set/manager/detail/${folderId}`);
};
