// 标准集code 规则
export const setCodeRule = {
  // pattern: /^[A-Z](?!.*?_$)[A-Za-z0-9_]{0,9}$/,
  pattern: /^[A-Z][A-Za-z0-9_]{0,9}$/,
  message: '请输入以大写字母开头，字母数字和_的组合名称，不超过10个字符'
};

// 目录名称规则-用于标准集、文件夹，与后端保持一致-产品意见：暂不控制
export const folderNameRule = {
  pattern: /^(?!\\d)[()\\[\\]<>a-zA-Z0-9_\\u4e00-\\u9fa5]+$/,
  message: ''
};
