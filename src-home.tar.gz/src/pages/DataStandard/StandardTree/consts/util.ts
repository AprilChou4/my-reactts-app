export const getParentIds = (tragetId: any, treeList: any[]) => {
  // 深度遍历查找
  function dfs(data: any[], id: any, parents: any[]) {
    for (let i = 0; i < data.length; i++) {
      const item = data[i];
      // 找到id则返回父级id
      if (item.parentId === id) return parents;
      // children不存在或为空则不递归
      if (!item.folders || !item.folders.length) continue;
      // 往下查找时将当前id入栈
      parents.push(item.parentId);

      if (dfs(item.folders, id, parents).length) return parents;
      // 深度遍历查找未找到时当前id 出栈
      parents.pop();
    }
    // 未找到时返回空数组
    return [];
  }

  return dfs(treeList, tragetId, [tragetId]);
};
