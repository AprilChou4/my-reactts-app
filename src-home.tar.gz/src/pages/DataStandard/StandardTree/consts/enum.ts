// export const foldType: {
//   FOLDER: boolean;
//   STANDARD: boolean;
// } = {
//   FOLDER: true, // 文件夹
//   STANDARD: false // 标准集
// };

export const foldType = {
  FOLDER: 'FOLDER', // 文件夹
  STANDARDSET: 'STANDARD' // 标准集
};
