import React, { Component, Fragment } from 'react';
import { Form, Radio, DatePicker } from 'sup-ui';
import moment from 'moment';
import RadioGroup from 'sup-ui/lib/radio/group';
import { transJsonParse } from '@utils/common';
import { cycle } from '@consts/dispatch';
import styles from './PeriodDispatch.less';

interface IProps {
  form: any;
  schedule: any;
  objConfig: any;
  dataFormat: string;
  effectDate: any;
  errorNumber: any;
  retryCount: number;
  intervalChange: any;
  minAgainMode: any;
  radioTimeChange: any;
  errorSwitchChange: boolean;
}
interface IState {
  triggerMode: string;
}

const FormItem = Form.Item;
const { RangePicker } = DatePicker;

class PeriodDispatch extends Component<IProps, IState> {
  public state = {
    triggerMode: '1'
  };

  public handleChangeInfo = (value: string) => {
    this.setState({
      triggerMode: value
    });
  };

  public render() {
    const {
      form: { getFieldDecorator, getFieldsValue },
      objConfig,
      // schedule,
      schedule: { scheduleDetail },
      // retryCount,
      effectDate,
      dataFormat,
      // errorNumber,
      // minAgainMode,
      // intervalChange,
      radioTimeChange
      // errorSwitchChange
    } = this.props;
    const initEffect = scheduleDetail
      ? _.get(transJsonParse(scheduleDetail), 'effect', 2)
      : 1;
    const { effect = initEffect } = getFieldsValue(['effect']);

    return (
      <Fragment>
        {/*<FormItem label="出错重试" colon={false} className={styles.formItem}>*/}
        {/*  {getFieldDecorator('errorSwitchChange', {*/}
        {/*    valuePropName: 'checked',*/}
        {/*    initialValue: _.get(*/}
        {/*      scheduleDetail,*/}
        {/*      'errorSwitchChange',*/}
        {/*      errorSwitchChange*/}
        {/*    )*/}
        {/*  })(<Switch onChange={objConfig.errorChange} />)}*/}
        {/*</FormItem>*/}

        {/*<FormItem*/}
        {/*  label="重试次数"*/}
        {/*  style={{ ...errorNumber }}*/}
        {/*  colon={false}*/}
        {/*  className={`${styles.formItem} ${styles.errNumber}`}*/}
        {/*>*/}
        {/*  {getFieldDecorator('errorNum', {*/}
        {/*    rules: [{ required: true, message: '请输入重试次数!' }],*/}
        {/*    initialValue: _.get(schedule, 'retryCount', retryCount)*/}
        {/*  })(*/}
        {/*    <InputNumber*/}
        {/*      size="large"*/}
        {/*      {...minAgainMode}*/}
        {/*      onChange={objConfig.NumberChange}*/}
        {/*    />*/}
        {/*  )}*/}
        {/*</FormItem>*/}
        <FormItem label="调度周期" colon={false} className={styles.formItem}>
          {getFieldDecorator('cycle', {
            rules: [{ required: true, message: '请输入调度周期!' }],
            initialValue: _.get(
              scheduleDetail,
              'radioTimeChange',
              radioTimeChange
            )
          })(
            <RadioGroup onChange={objConfig.radioTimeChange}>
              {_.map(cycle, (i: any) => (
                <Radio key={i.value} value={i.value}>
                  {i.name}
                </Radio>
              ))}
            </RadioGroup>
          )}
        </FormItem>
        {radioTimeChange ? objConfig.intervalComponents(radioTimeChange) : null}
        <FormItem label="有效日期" colon={false} required>
          {getFieldDecorator('effect', {
            initialValue: initEffect
          })(
            <RadioGroup>
              <Radio value={1}>长期有效</Radio>
              <Radio value={2}>时间区间内有效</Radio>
            </RadioGroup>
          )}
        </FormItem>
        <div style={{ display: effect === 2 ? 'block' : 'none' }}>
          <FormItem
            label=""
            colon={false}
            className={`${styles.formItem} ${styles.effect} `}
          >
            {getFieldDecorator('effecDate', {
              rules: [{ required: true, message: '请输入生效日期!' }],
              initialValue: [
                moment(effectDate[0], dataFormat),
                moment(effectDate[1], dataFormat)
              ]
            })(
              <RangePicker
                size="large"
                allowClear={false}
                onChange={objConfig.effectDate}
              />
            )}
          </FormItem>
        </div>
      </Fragment>
    );
  }
}

export default PeriodDispatch;
