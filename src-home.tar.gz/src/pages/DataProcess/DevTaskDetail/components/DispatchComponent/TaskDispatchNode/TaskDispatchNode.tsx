import React, { Component } from 'react';
import { Form } from 'sup-ui';
import RadioGroup from 'sup-ui/lib/radio/group';
import RadioButton from 'sup-ui/lib/radio/radioButton';

import DialogModel from '@components/Modal/Dialog';
import PeriodDispatch from './containers/PeriodDispatch';
import MessageDriven from '../MessageDriven';

interface ITaskDispatchNodeProps {
  form: any;
  visible: any;
  schedule: any;
  effectDate: any;
  errorNumber: any;
  radioTimeChange: string;
  intervalChange: boolean;
  dataFormat: string;
  objConfig: any;
  retryCount: string;
  errorSwitchChange: boolean;
  minAgainMode: any;
  onOkLoading: boolean;
}
interface ITaskDispatchNodeState {
  taskType: string;
}

const FormItem = Form.Item;

class TaskDispatchNode extends Component<
  ITaskDispatchNodeProps,
  ITaskDispatchNodeState
> {
  private messageRef: any;

  public constructor(props: ITaskDispatchNodeProps) {
    super(props);

    const { schedule } = props;
    const mode = _.toString(_.get(schedule, 'triggerMode', '0'));

    this.state = {
      taskType: mode === '2' ? '1' : mode
    };
  }

  public handleChangeTask = (e: any) => {
    const {
      target: { value }
    } = e;

    this.setState({
      taskType: value
    });
  };

  public getDrivenValues = () => {
    const { taskType } = this.state;

    if (taskType === '0') {
      return {
        triggerMode: taskType
      };
    } else {
      const messageValue = this.messageRef.getMesDriven();
      const { drivenMode } = messageValue;
      const messageParams = _.omit(messageValue, 'drivenMode');

      return {
        ...messageParams,
        triggerMode: drivenMode
      };
    }
  };

  public render() {
    const {
      form,
      form: { getFieldDecorator },
      visible,
      schedule,
      effectDate,
      errorNumber,
      radioTimeChange,
      intervalChange,
      dataFormat,
      objConfig,
      retryCount,
      errorSwitchChange,
      minAgainMode,
      onOkLoading
    } = this.props;

    const { taskType } = this.state;

    return (
      <DialogModel
        title="调度任务"
        visible={visible}
        maskClosable={false}
        onOk={objConfig.onOk}
        onCancel={objConfig.onCancel}
        disabled={onOkLoading}
      >
        <FormItem>
          {getFieldDecorator('triggerMode', {
            initialValue: taskType
          })(
            <RadioGroup buttonStyle="solid" onChange={this.handleChangeTask}>
              <RadioButton value="0">周期调度</RadioButton>
              <RadioButton value="1">消息驱动</RadioButton>
            </RadioGroup>
          )}
        </FormItem>

        {taskType === '0' ? (
          <PeriodDispatch
            form={form}
            schedule={schedule}
            objConfig={objConfig}
            dataFormat={dataFormat}
            effectDate={effectDate}
            errorNumber={errorNumber}
            retryCount={retryCount}
            minAgainMode={minAgainMode}
            intervalChange={intervalChange}
            radioTimeChange={radioTimeChange}
            errorSwitchChange={errorSwitchChange}
          />
        ) : (
          <MessageDriven
            schedule={schedule}
            form={form}
            ref={(ref: any) => (this.messageRef = ref)}
          />
        )}
      </DialogModel>
    );
  }
}

export default TaskDispatchNode;
