/**
 * 任务调度
 */
import React, { Component } from 'react';
import { Form } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import DispatchComponent from './DispatchComponent';

interface IProps extends FormComponentProps {
  visible: boolean;
  schedule: any;
  loading: boolean;
  onSave: (formData: any) => void;
  toggleModalVisible: (visible: boolean) => void;
}

class TaskDispatch extends Component<IProps> {
  public render() {
    const { visible, schedule, loading, onSave, toggleModalVisible } =
      this.props;
    return (
      <DispatchComponent
        flag="taskDispatch"
        visible={visible}
        schedule={schedule}
        onSave={onSave}
        onOkLoading={loading}
        toggleModalVisible={toggleModalVisible}
      />
    );
  }
}

export default Form.create<IProps>()(TaskDispatch);
