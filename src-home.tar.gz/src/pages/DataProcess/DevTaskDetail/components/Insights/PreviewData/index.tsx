import React, { Component } from 'react';
import { Table, Tooltip } from 'sup-ui';
import { TableCellText } from '@components/Table';
import { formatValueByType } from '../../../../devTask.helper';
import styles from './index.less';

const getColumnWidth = (dataType: string) => {
  switch (dataType) {
    case 'Boolean':
      return '80px';
    case 'Timestamp':
      return '180px';
    case 'Date':
      return '120px';
    default:
      return `120px`;
  }
};

interface IProps {
  dataSource: any;
  columnTitles: any[];
  dataModuleTag: string;
  getNodeInfoByTag: any;
}

interface IState {
  activeTab: any;
  tabs: any[];
  [propName: string]: any;
}

class PreviewData extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    this.state = {
      activeTab: '',
      tabs: []
    };
  }

  public handleTabChange = (tab: any) => {
    this.setState({
      activeTab: tab
    });
  };

  public getColumns = () => {
    const { columnTitles, dataModuleTag, getNodeInfoByTag, dataSource } =
      this.props;
    const { alias } = getNodeInfoByTag(dataModuleTag) || {};

    if (alias === 'TableTransposeModule') {
      const fields =
        _.isArray(dataSource) && dataSource.length > 0
          ? _.keys(dataSource[0])
          : [];

      return _.map(fields, dataIndex => ({
        title: <Tooltip title={dataIndex}>{dataIndex}</Tooltip>,
        dataIndex,
        width: 100,
        className: 'ellipsis-hide',
        render: (text: any) => {
          const v = _.isObject(text) ? JSON.stringify(text) : text;
          return <TableCellText text={v} />;
        }
      }));
    }

    return _.map(columnTitles, ({ name, dataType }) => ({
      title: <Tooltip title={name}>{name}</Tooltip>,
      dataIndex: name,
      width: getColumnWidth(dataType),
      className: 'ellipsis-hide',
      render: (text: any) => (
        <TableCellText text={formatValueByType(text, dataType)} />
      )
    }));
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { dataSource, getNodeInfoByTag, dataModuleTag } = this.props;

    if (!_.isEqual(prevProps.dataSource, dataSource)) {
      const { alias } = getNodeInfoByTag(dataModuleTag) || {};
      const tabs = _.map(Object.keys(dataSource), tag => {
        const { name } = getNodeInfoByTag(tag) || {};

        return {
          key: tag,
          showName: alias === 'BranchModule' ? `输出至${name}` : '输出数据'
        };
      });

      this.setState({
        tabs,
        activeTab: tabs[0].key
      });
    }
  }

  public render() {
    const { dataSource } = this.props;
    const { activeTab, tabs } = this.state;
    const list = dataSource[activeTab] || [];
    const columns = this.getColumns();

    return (
      <div className={styles.container}>
        <div className={styles.tabs}>
          <ul>
            {tabs.map(item => (
              <li
                key={item.key}
                className={item.key === activeTab ? styles.active : ''}
                onClick={() => this.handleTabChange(item.key)}
              >
                {item.showName}
              </li>
            ))}
          </ul>
        </div>
        <div className={`${styles.table} mp-table-grow mp-table-dark`}>
          <Table
            columns={columns}
            dataSource={list}
            rowKey={() => _.uniqueId('outputs_')}
            pagination={false}
            scroll={{
              x: 200,
              y: 'calc(100% - 31px)'
            }}
          />
        </div>
      </div>
    );
  }
}

export default PreviewData;
