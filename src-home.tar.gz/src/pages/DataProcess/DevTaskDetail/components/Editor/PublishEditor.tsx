import React, { PureComponent } from 'react';
import classnames from 'classnames';

import HTCanvas from '@components/HTCanvas';
import verifyTaskModule from '../../../Modules/ModuleVerifier';
import { isHtNode } from './Editor.helper';
import styles from './Editor.less';

interface IProps {
  onEventTypeChange: (
    eventType: string,
    isHtNode: boolean,
    htNode: any
  ) => void;
}

class PublishEditor extends PureComponent<IProps> {
  public static defaultProps = {
    className: ''
  };

  public ContainerRef: any;
  public HTModelEditor: any;

  public constructor(props: any) {
    super(props);
    this.ContainerRef = React.createRef();
    this.HTModelEditor = null;
  }

  /**
   * @description: getGraphViewNodeByTag - 设定GraphView中指定tag的Node
   * @param {string} tag - 初始化时生成的唯一标识符
   * @param {string|object} attrs - 属性集合的对象或者属性的名称
   * @param {*} attrValue - 若`attrs`为属性名时，此参数即为属性的值
   */
  public getGraphViewNodeByTag = (tag = '') => {
    if (!this.HTModelEditor || !tag) {
      return null;
    }

    return this.HTModelEditor.GraphView.dm().getDataByTag(tag) || null;
  };

  public getGraphViewNodesName = (): any[] => {
    if (this.HTModelEditor) {
      const names: string[] = [];
      this.HTModelEditor.GraphView.dm().toDatas((node: any) => {
        if (isHtNode(node)) {
          names.push(node.a('name') || '');
        }
      });
      return names;
    } else {
      return [];
    }
  };

  /**
   * @description: updateGraphViewNodeAttrsByTag - 设定GraphView中指定tag
   * @param {string} tag - 初始化时生成的唯一标识符
   * @param {string|object} attrs - 属性集合的对象或者属性的名称
   * @param {*} attrValue - 若`attrs`为属性名时，此参数即为属性的值
   */
  public updateGraphViewNodeAttrsByTag = (
    tag = '',
    attrs = '',
    attrValue = null
  ) => {
    const htNode = this.getGraphViewNodeByTag(tag);

    if (htNode) {
      if (_.isString(attrs)) {
        htNode.a(attrs, attrValue);
        // TODO - REMOVE
      } else if (_.isPlainObject(attrs)) {
        htNode.a(_.merge(_.cloneDeep(htNode.getAttrObject()), attrs));
      }
    }
  };

  /**
   * @description: 从node开始，递归检查其本身及其下游节点的状态
   * @param {Object|String} node - 待检查的组件对象或者其tag
   * @param {Array} checkedList - 已经检查过的节点
   * @param {Boolean} [enableRecursiveChecking = true] - 是否启用递归检查，默认启用
   */
  public checkNodeByModuleVerifier = (
    node: any,
    checkedList: string[] = [],
    enableRecursiveChecking = true
  ) => {
    const htNode = _.isString(node) ? this.getGraphViewNodeByTag(node) : node;
    if (!htNode) return;

    const { points, alias, config } = htNode.getAttrObject();
    const inputPoints = points.in;
    // 获取上游节点的数据结构，可能是集合
    const inputDatas: any[] = _.isArray(inputPoints)
      ? inputPoints.map(({ sourceNodeTag, type }) => {
          const sourceNode = this.getGraphViewNodeByTag(sourceNodeTag);
          // 组件内部存储的`outputDataStructures`
          // 根据输出节点的类型，组合成{data: [...], model: [...]}的形式
          const sourceNodeOutputDataStructures = _.isNil(sourceNode)
            ? {}
            : _.cloneDeep(sourceNode.a('outputDataStructures'));
          return {
            type,
            dataStructure:
              !_.isEmpty(sourceNodeOutputDataStructures) &&
              !_.isNil(sourceNodeOutputDataStructures[type])
                ? sourceNodeOutputDataStructures[type]
                : null
          };
        })
      : [];

    const htNodeTag: string = htNode.getTag();

    // 如果检查的节点与上次相同，则跳过检查，已提高性能
    if (_.last(checkedList) !== htNodeTag) {
      // 检查节点状态
      const taskModuleVerifiedResult = verifyTaskModule({
        alias,
        config,
        inputDatas
      });

      // 将节点tag加入已检查列表
      if (!_.includes(checkedList, htNodeTag)) {
        checkedList.push(htNodeTag);
      }

      // 更新组件的状态(status)及数据结构(struct)
      const status = taskModuleVerifiedResult.error !== null ? 'warning' : '';
      htNode.a('status', status);
      if (taskModuleVerifiedResult.error !== null) {
        htNode.a('validationErrorMessage', taskModuleVerifiedResult.error);
      }
      htNode.a(
        'outputDataStructures',
        _.cloneDeep(taskModuleVerifiedResult.outputDataStructures)
      );
    }

    // 检查输出节点是否已连线，递归检查下游的所有组件
    if (
      enableRecursiveChecking &&
      !_.isNil(points.out) &&
      points.out.length > 0
    ) {
      points.out.forEach(({ targetNodeTag }: any) => {
        if (_.isString(targetNodeTag) && targetNodeTag.length !== 0) {
          this.checkNodeByModuleVerifier(targetNodeTag, checkedList);
        }
      });
    }
  };

  /**
   * @description: 获取GraphView的DataModelSerialize
   * @see http://www.hightopo.com/guide/guide/core/datamodel/ht-datamodel-guide.html#ref_datamodel
   * @param {boolean|number} [space = 0] - 是否序列化成JSON格式字符串
   * @return {string} 根据space返回对象字面量或者字符串形式的当前GraphView的DataModel
   */
  public getGraphViewDataModelSerialize = (space = 0) => {
    if (this.HTModelEditor !== null) {
      return this.HTModelEditor.GraphView.dm().serialize(
        _.isNumber(space) ? Math.abs(Math.floor(space)) : 0
      );
      // TODO 后期将`config`独立存储以后需要加上此处理
      // 预处理字符串参数，避免字符串化的JSON参数常出现因换行信息导致解析出错
      // .replace(/\\n\s*/g, '')
    }
    return null;
  };

  /**
   * @description: 获取GraphView中校验通过流程的序列化数据
   * @see http://www.hightopo.com/guide/guide/core/datamodel/ht-datamodel-guide.html#ref_datamodel
   * @param {array} nodes - 组件对象集合或者组件tag的集合
   * @param {boolean|number} [space = 0] - 是否序列化成JSON格式字符串
   * @return {string} 根据space返回字符串形式的当前GraphView的DataModel
   */
  public getVerifiedProcessesSerialization = (nodes: any[], space = 0) => {
    if (!_.isArray(nodes) && _.isEmpty(nodes)) {
      return false;
    }

    // 获取验证过的tag
    const validatedNodeTags = nodes
      .map((node: any) =>
        node instanceof window.ht.Node
          ? this.getGraphViewNodeByTag(node).getTag()
          : node
      )
      .filter(tag =>
        // 过滤非字符串及位数没有10位的tag
        // isString(tag) && (`${tag}`).length === 10
        // TODO: 暂时去除tag字符数的判断
        _.isString(tag)
      );

    // 缓存ht对象中的isSerializable
    const isSerializableCached =
      window.ht.JSONSerializer.prototype.isSerializable;
    // 重载ht对象中的isSerializable
    window.ht.JSONSerializer.prototype.isSerializable = (node: any) => {
      let canSerializable = false;
      if (node instanceof window.ht.Node) {
        // 如果是Node类型，则直接判断是否在已验证的tag集合中
        canSerializable = _.includes(validatedNodeTags, node.getTag());
      } else if (node instanceof window.ht.Edge) {
        // 如果是Edge类型，则获取其起始点的Node，同时判断该Node的tag是否在已验证的tag集合中
        canSerializable = _.includes(
          validatedNodeTags,
          node.getSource().getTag()
        );
      }
      return canSerializable;
    };

    if (this.HTModelEditor) {
      const validatedNodeSerializeLayout =
        this.getGraphViewDataModelSerialize(space);

      // 还原原有ht对象中的isSerializable
      window.ht.JSONSerializer.prototype.isSerializable = isSerializableCached;
      return validatedNodeSerializeLayout;
    }
    return null;
  };

  public initHT = (HTLayoutInfo: string) => {
    if (_.isNil(this.ContainerRef.current) || _.isEmpty(HTLayoutInfo)) {
      return;
    }
    this.HTModelEditor = new HTCanvas(this.ContainerRef.current, {
      title: '',
      onEventTypeChange: this.props.onEventTypeChange
    });
    this.HTModelEditor.initLayout(HTLayoutInfo);
  };

  public render() {
    return (
      <div
        key="publishEditor"
        className={classnames(styles.container, styles.publishConfig)}
        ref={this.ContainerRef}
      />
    );
  }
}
export default PublishEditor;
