import React from 'react';
import { Table, Form, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import classnames from 'classnames';

import { AddBtn, DelBtn } from '@components/Button';
import DialogModel from '@components/Modal/Dialog';
import TipsDelete from '@components/Modal/TipsDelete';
import Icon from '@components/Icon';

import VarName from './VarName';
import VarType from './VarType';
import VarValue from './VarValue';
import DateSetting from './DateSetting';

import uuid from '@utils/uuid';

import styles from './index.less';

interface IVariableConfigureProps extends FormComponentProps {
  variables: any[];
  loading: boolean;
  onOk: (formData: any) => void;
  toggleModalVisible: () => void;
}
class VarConfig extends React.Component<IVariableConfigureProps> {
  public state: any;
  public constructor(props: any) {
    super(props);

    this.state = {
      dataSource: _.cloneDeep(props.variables) || [],
      selectedRowKeys: [],
      dateSettingVisible: false,
      currentRecord: {}
    };
  }

  private onSelectChange = (selectedRowKeys: any) => {
    this.setState({ selectedRowKeys });
  };

  private handleAdd = () => {
    const { dataSource } = this.state;
    const newData = {
      id: uuid(6),
      name: '',
      constValue: '',
      dataType: 'String'
    };
    this.setState({
      dataSource: [...dataSource, newData]
    });
  };

  private handleUpdateRecord = (record: any) => {
    const { dataSource } = this.state;
    this.setState({
      dataSource: _.map(dataSource, item =>
        record.id === item.id
          ? {
              ...item,
              ...record
            }
          : item
      )
    });
  };

  private handleDelete = () => {
    const { selectedRowKeys, dataSource } = this.state;
    const config = {
      title: '是否删除该变量？',
      content: '删除变量确认后可能导致组态调试失败',
      onOk: () => {
        this.setState({
          dataSource: dataSource.filter(
            (item: any) => !_.includes(selectedRowKeys, item.id)
          ),
          selectedRowKeys: []
        });
      }
    };
    TipsDelete(config);
  };

  private handleOk = () => {
    const { onOk, form } = this.props;
    const { dataSource } = this.state;

    form.validateFields((err: any) => {
      if (err) {
        message.error('变量值不符合类型或者变量值为空');
        return;
      }
      const unionDataSource = _.unionBy(dataSource, 'name');
      const hasSameName = unionDataSource.length < dataSource.length;
      if (hasSameName) {
        message.warning('变量名不能相同!');
        return;
      }
      const newDateSource = _.map(dataSource, item => {
        if (item.dataType === 'Datetime') {
          item.constValue = JSON.stringify(item.constValue);
        }
        return item;
      });
      onOk(newDateSource);
    });
  };

  private onCancel = () => {
    this.props.toggleModalVisible();
  };

  private openDateSetting = (currentRecord: any) => {
    this.setState({
      currentRecord,
      dateSettingVisible: true
    });
  };

  private closeDateSetting = () => {
    this.setState({
      currentRecord: {},
      dateSettingVisible: false
    });
  };

  private updateDateSetting = (record: any) => {
    this.handleUpdateRecord(record);
    this.setState({
      dateSettingVisible: false
    });
  };

  private getColumns = (): any => {
    const { getFieldDecorator } = this.props.form;
    return [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 50,
        align: 'center',
        render: (text: any, _record: any, index: number) => (
          <span title={text}>{index + 1}</span>
        )
      },
      {
        key: 'name',
        title: '变量名',
        dataIndex: 'name',
        width: 150,
        render: (_text: string, record: any) => (
          <VarName
            getFieldDecorator={getFieldDecorator}
            record={record}
            dataSource={this.state.dataSource}
            onChange={this.handleUpdateRecord}
          />
        )
      },
      {
        key: 'dataType',
        title: '变量类型',
        dataIndex: 'dataType',
        width: 120,
        render: (_text: string, record: any) => (
          <VarType
            getFieldDecorator={getFieldDecorator}
            record={record}
            onChange={this.handleUpdateRecord}
          />
        )
      },
      {
        key: 'constValue',
        title: '变量值',
        dataIndex: 'constValue',
        width: 200,
        render: (_text: string, record: any) => (
          <VarValue
            getFieldDecorator={getFieldDecorator}
            record={record}
            onChange={this.handleUpdateRecord}
          />
        )
      },
      {
        key: 'timeSetting',
        title: '',
        dataIndex: 'timeSetting',
        textAlign: 'center',
        render: (_text: string, record: any) =>
          record.dataType === 'Datetime' && (
            <Icon
              type="setting"
              onClick={this.openDateSetting.bind(this, record)}
            />
          )
      }
    ];
  };

  public render() {
    const { dataSource, selectedRowKeys, currentRecord, dateSettingVisible } =
      this.state;
    const { loading } = this.props;

    const rowSelection = {
      selectedRowKeys,
      onChange: this.onSelectChange,
      hideDefaultSelections: true
    };

    return (
      <DialogModel
        title="变量配置"
        width={680}
        visible
        onOk={this.handleOk}
        onCancel={this.onCancel}
        disabled={loading}
        className={styles.dialogModalContainer}
      >
        <div className={styles.varHeaderEdit}>
          <AddBtn
            ghost
            onClick={this.handleAdd}
            style={{ marginRight: '10px' }}
          />
          <DelBtn
            disabled={!selectedRowKeys.length}
            onClick={this.handleDelete}
          />
          <p className={styles.tips}>
            注:如果修改变量名/类型,或者删除变量,可能会导致组态调试失败!
          </p>
        </div>
        <Form className={styles.formWrapper}>
          <Table
            className={classnames('mp-table-gray', 'mp-table-grow')}
            rowSelection={rowSelection}
            rowClassName={() => 'editable-row'}
            rowKey={(record: any) => record.id}
            dataSource={dataSource}
            columns={this.getColumns()}
            pagination={false}
            scroll={{ y: 'calc(100% - 50px)' }}
          />
        </Form>
        {dateSettingVisible && (
          <DateSetting
            record={currentRecord}
            onOk={this.updateDateSetting}
            onCancel={this.closeDateSetting}
          />
        )}
      </DialogModel>
    );
  }
}

export default Form.create<IVariableConfigureProps>({
  name: 'varConfig'
})(VarConfig);
