import React, { FunctionComponent, useState } from 'react';
import moment from 'moment';
import { Form, Select } from 'sup-ui';

import {
  DATATYPE_SETS,
  isNumericDataType,
  isBooleanDataType,
  isDatetimeDataType
} from '@utils/datatype';
import { getGMTimeZone } from '@utils/common';

const FormItem = Form.Item;
const { Option } = Select;

interface IVarTypeProps {
  record: any;
  getFieldDecorator: any;
  onChange: (value: any) => void;
}

const VarType: FunctionComponent<IVarTypeProps> = (props: IVarTypeProps) => {
  const { record, getFieldDecorator } = props;
  const [editing, setEdit] = useState(false);
  const dataType = _.get(record, 'dataType');
  return editing ? (
    <FormItem>
      {getFieldDecorator(`dataType_${record.id}`, {
        initialValue: _.get(record, 'dataType'),
        rules: [
          {
            required: true,
            message: '变量类型不能为空.'
          }
        ],
        validateTrigger: ['onChange', 'onBlur']
      })(
        <Select
          size="small"
          placeholder="-请选择-"
          dropdownMatchSelectWidth={false}
          defaultOpen
          onChange={(v: string) => {
            if (isDatetimeDataType(v)) {
              record.constValue = {
                type: 1,
                value: moment().format('YYYY'),
                datePattern: 1,
                offsetValue: 0,
                offsetType: 'year',
                timezone: getGMTimeZone()
              };
            } else if (isNumericDataType(v)) {
              record.constValue = undefined;
            } else if (isBooleanDataType(v)) {
              record.constValue = 1;
            } else {
              record.constValue = '';
            }
            record.dataType = v;
            props.onChange(record);
            setEdit(false);
          }}
          onBlur={() => {
            setEdit(false);
          }}
        >
          {_.map(DATATYPE_SETS, type => (
            <Option key={type} value={type}>
              {type}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  ) : (
    <div
      className="editable-cell-value-wrap ellipsis-1"
      style={{
        paddingRight: 24,
        height: '24px',
        lineHeight: '24px'
      }}
      onClick={() => {
        setEdit(true);
      }}
    >
      {dataType}
    </div>
  );
};

export default VarType;
