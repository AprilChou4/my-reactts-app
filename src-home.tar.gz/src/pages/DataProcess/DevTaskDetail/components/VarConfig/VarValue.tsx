import React, { FunctionComponent } from 'react';
import { Input, Form } from 'sup-ui';

import { NumericInput, BoolSelect } from '@components/Form';
import { mappingDateTimeType } from './varConfig.const';
import {
  isNumericDataType,
  isBooleanDataType,
  isDatetimeDataType
} from '@utils/datatype';

const FormItem = Form.Item;

interface IVarValueProps {
  record: any;
  getFieldDecorator: any;
  onChange: (value: any) => void;
}

const VarValue: FunctionComponent<IVarValueProps> = (props: IVarValueProps) => {
  const { record, getFieldDecorator, onChange } = props;
  if (isDatetimeDataType(record.dataType)) {
    const { value, type } = record.constValue;
    const dateValue = type === 1 ? value : mappingDateTimeType[type];
    return dateValue || '';
  } else if (isNumericDataType(record.dataType)) {
    return (
      <NumericInput
        formKey={`constValue_${record.id}_number`}
        size="small"
        dataType={record.dataType}
        initialValue={record.constValue}
        onChange={v => {
          record.constValue = v;
          onChange(record);
        }}
        getFieldDecorator={getFieldDecorator}
      />
    );
  } else if (isBooleanDataType(record.dataType)) {
    return (
      <BoolSelect
        formKey={`constValue_${record.id}_bool`}
        size="small"
        initialValue={record.constValue}
        getFieldDecorator={getFieldDecorator}
        onChange={v => {
          record.constValue = v;
          onChange(record);
        }}
      />
    );
  } else if (record.dataType === 'String') {
    return (
      <FormItem style={{ margin: 0 }}>
        {getFieldDecorator(`constValue_${record.id}_string`, {
          initialValue: record.constValue,
          rules: [{ required: true, message: '变量值不能为空' }],
          validateTrigger: ['onChange', 'onBlur']
        })(
          <Input
            placeholder="-请输入-"
            size="small"
            onBlur={(e: any) => {
              if (e.target.value) {
                record.constValue = e.target.value;
                onChange(record);
              }
            }}
            onPressEnter={(e: any) => {
              if (e.target.value) {
                record.constValue = e.target.value;
                onChange(record);
              }
            }}
          />
        )}
      </FormItem>
    );
  } else {
    return _.get(record, 'constValue', '');
  }
};

export default VarValue;
