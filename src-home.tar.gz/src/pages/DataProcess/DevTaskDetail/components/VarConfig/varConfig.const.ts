/**
 * @description 日期格式转换映射表
 */
export const transferDatePattern: {
  [propsName: string]: string;
} = {
  '1': 'YYYY',
  '2': 'YYYY-MM-DD',
  '3': 'YYYY/MM/DD',
  '4': 'YYYY-MM-DD HH:mm:ss',
  '5': 'YYYY/MM/DD HH:mm:ss',
  '6': 'HH:mm:ss'
};

/**
 * @description 时间类型选项
 */
export const dateTypeOptions = [
  {
    key: 'year',
    label: '年份'
  },
  {
    key: 'date',
    label: '日期'
  },
  {
    key: 'dateTime',
    label: '日期时间'
  },
  {
    key: 'time',
    label: '时间'
  },
  {
    key: 'day',
    label: '当天'
  },
  {
    key: 'recentThreeDays',
    label: '近三天'
  },
  {
    key: 'week',
    label: '当周'
  },
  {
    key: 'month',
    label: '当月'
  },
  {
    key: 'quarter',
    label: '当季度'
  },
  {
    key: 'thisYear',
    label: '当年'
  }
];

/**
 * @description: 当时间类型发生改变，根据时间类型匹配默认值
 * @param {string} dateType 时间类型
 * @return {object} 对应时间类型的配置信息
 * patterns: 日期格式
 * offsetType: 偏置时间类型
 * offsetValue: 偏置值
 * offsetTypes: 偏置类型可选项
 */
export const getDateSettingByDateType = (dateType: string) => {
  const offsetTypes = [
    {
      name: '年',
      value: 'year'
    },
    {
      name: '月',
      value: 'month'
    },
    {
      name: '日',
      value: 'day'
    },
    {
      name: '时',
      value: 'hour'
    },
    {
      name: '分',
      value: 'minute'
    }
  ];
  switch (dateType) {
    case 'year':
      return {
        patterns: [{ value: 'YYYY', datePattern: 1 }],
        offsetType: 'year',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['year', 'month', 'day', 'hour', 'minute'], item.value)
        )
      };
    case 'date':
      return {
        patterns: [
          { value: 'YYYY-MM-DD', datePattern: 2 },
          { value: 'YYYY/MM/DD', datePattern: 3 }
        ],
        offsetType: 'day',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['year', 'month', 'day'], item.value)
        )
      };
    case 'dateTime':
      return {
        patterns: [
          { value: 'YYYY-MM-DD HH:mm:ss', datePattern: 4 },
          { value: 'YYYY/MM/DD HH:mm:ss', datePattern: 5 }
        ],
        offsetType: 'year',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['year', 'month', 'day', 'hour', 'minute'], item.value)
        )
      };
    case 'time':
      return {
        patterns: [{ value: 'HH:mm:ss', datePattern: 6 }],
        offsetType: 'hour',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['hour', 'minute'], item.value)
        )
      };
    case 'day':
      return {
        offsetType: 'day',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['day', 'hour', 'minute'], item.value)
        )
      };
    case 'recentThreeDays':
      return {
        offsetType: 'day',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['day', 'hour', 'minute'], item.value)
        )
      };
    case 'week':
      return {
        offsetType: 'day',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['day', 'hour', 'minute'], item.value)
        )
      };
    case 'month':
      return {
        offsetType: 'month',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['month', 'day', 'hour', 'minute'], item.value)
        )
      };
    case 'quarter':
      return {
        offsetType: 'month',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['month', 'day', 'hour', 'minute'], item.value)
        )
      };
    case 'thisYear':
      return {
        offsetType: 'year',
        offsetValue: 0,
        offsetTypes: _.filter(offsetTypes, item =>
          _.includes(['year', 'month', 'day', 'hour', 'minute'], item.value)
        )
      };
    default:
      return {};
  }
};

// 范围型时间类型
export const rangeDateType = [
  'day',
  'recentThreeDays',
  'week',
  'month',
  'quarter',
  'thisYear'
];

/**
 * @description 时间类型转换
 * @param type
 */
export const transDateType = (type: string): number => {
  const map: any = {
    year: 1,
    dateTime: 1,
    date: 1,
    time: 1,
    day: 2,
    recentThreeDays: 3,
    week: 4,
    month: 5,
    quarter: 6,
    thisYear: 7
  };

  return map[type];
};

/**
 *@description 时间类型转换
 *@param type
 *@param value
 */
export const transDateTimeType = (type: number, value: string | number) => {
  const stringValue = _.toString(value);

  let dateType;
  if (type === 1) {
    const mapping: {
      [propsName: string]: string;
    } = {
      '4': 'year',
      '8': 'time',
      '10': 'date',
      '19': 'dateTime'
    };
    dateType = mapping[stringValue.length];
  } else {
    const mapping: {
      [propsName: string]: string;
    } = {
      '2': 'day',
      '3': 'recentThreeDays',
      '4': 'week',
      '5': 'month',
      '6': 'quarter',
      '7': 'thisYear'
    };
    dateType = mapping[type];
  }
  return dateType;
};

export const mappingDateTimeType: {
  [propsName: string]: string;
} = {
  '2': '当天',
  '3': '近三天',
  '4': '当周',
  '5': '当月',
  '6': '当季度',
  '7': '当年'
};
