import React, { Component, Suspense } from 'react';
import { Spin } from 'sup-ui';

import SaveTips from '../../SaveTips';
import ModuleErrorBoundary from '../../../../Modules/components/ModuleErrorBoundary';
import TaskModuleDrawer from '../../../../Modules/components/TaskModuleDrawer';
import PublishEditor from '../../Editor/PublishEditor';
import Modules from '../../../../Modules';
import { getModuleName } from '../../../lib/task.helper';
import styles from './index.less';

interface IProps {
  taskDetailStore: any;
}

class AdjustConfig extends Component<IProps> {
  public state: any;
  public HTEditorRef: any;
  private save: any;

  public constructor(props: any) {
    super(props);

    this.state = {
      isHTEditorInit: false,
      dataModuleAlias: '',
      dataModuleName: '',
      dataModuleTag: '',
      dataModuleConfig: null,
      dataModuleInputDatas: [],
      drawerVisible: false,
      tipsVisible: false,
      isConfigChanged: false
    };

    this.HTEditorRef = null;
  }

  public componentDidMount() {
    this.props.taskDetailStore.getInsightData(this.init);
  }

  public init = (debugLayout: string) => {
    if (this.HTEditorRef) {
      this.HTEditorRef.initHT(debugLayout);
    }
  };

  public initApi = (callback: any) => {
    this.save = callback;
  };

  public closeDrawer = () => {
    if (this.verifyConfigStatus()) this.cancelModuleConfig();
  };

  // *********************** 修改状态相关 ***************************
  public toggleChangedStatus = () => {
    this.setState({
      isConfigChanged: true
    });
  };

  // **************************  校验状态相关 ***********************
  /**
   * @description:校验算子模块的状态是否时已修改
   * 如果已修改 提示用户是否保存
   * @return {boolean} 返回布尔值
   */
  public verifyConfigStatus = () => {
    const { isConfigChanged } = this.state;
    if (isConfigChanged) {
      this.setState({
        tipsVisible: true
      });
      return false;
    }
    return true;
  };

  /**
   * @description: 保存配置区的配置项至HT-Node的Attrs
   * 保存配置成功之后将调试状态置为  '未调试' -> 2
   * @param {object} moduleConfig - 配置区域配置
   */
  public saveConfigToLayout = (moduleConfig: any) => {
    const { dataModuleTag } = this.state;
    if (!dataModuleTag) return;
    // 更新HT节点中attrs中的config
    this.HTEditorRef.updateGraphViewNodeAttrsByTag(
      dataModuleTag,
      'config',
      moduleConfig
    );
    // 对当前节点及下游节点递归检查
    this.HTEditorRef.checkNodeByModuleVerifier(dataModuleTag);
    this.props.taskDetailStore.updateDebugStatus(2);
    this.props.taskDetailStore.updateConfigStatus(false);
    this.setState({
      drawerVisible: false,
      tipsVisible: false,
      isConfigChanged: false
    });
  };

  public saveModuleConfig = () => {
    const config = this.save();
    if (config) this.saveConfigToLayout(config);
  };

  /**
   * @description: 取消是否保存修改提示框
   * 注: 提示框的取消事件 是 取消当前配置
   */
  private cancelModuleConfig = () => {
    this.setState({
      drawerVisible: false,
      tipsVisible: false,
      isConfigChanged: false
    });
    this.props.taskDetailStore.updateConfigStatus(false);
  };

  /**
   * @description: 关闭是否保存修改提示框
   * 注: 关闭弹框是 仅关闭提示框
   */
  private closeTipsModal = () => {
    this.setState({
      tipsVisible: false
    });
  };

  private handleHTEditorEventChange = (
    eventType: string,
    currentModuleInfo: any
  ) => {
    const { isConfigChanged, drawerVisible } = this.state;

    if (isConfigChanged) {
      return;
    }

    if (eventType === 'doubleClickData' || eventType === 'clickData') {
      const { dataModuleAlias } = currentModuleInfo;
      const isEditor =
        dataModuleAlias === 'DataInputModule' ||
        dataModuleAlias === 'DataOutputModule';

      // 只能调整输入/输出算子
      if (!isEditor) {
        return;
      }

      if (eventType === 'doubleClickData') {
        this.setState({
          drawerVisible: true
        });
      }

      if (eventType === 'clickData') {
        if (!drawerVisible) {
          return;
        }
      }

      this.setState({
        ...currentModuleInfo
      });
    }

    if (
      (eventType === 'clickBackground' ||
        eventType === 'doubleClickBackground') &&
      drawerVisible
    ) {
      this.setState({
        dataModuleAlias: '',
        dataModuleSubAlias: '',
        dataModuleName: '',
        dataModuleTag: '',
        dataModuleConfig: {},
        dataModuleInputDatas: [],
        drawerVisible: false
      });
    }
  };

  /**
   * @description: 根据tag号更新节点名称
   */
  private handleUpdateNodeNameByTag = (name: string) => {
    if (this.HTEditorRef) {
      const { dataModuleTag } = this.state;
      if (dataModuleTag) {
        const names = this.HTEditorRef.getGraphViewNodesName();
        const moduleName = getModuleName(names, name);
        this.HTEditorRef.updateGraphViewNodeAttrsByTag(
          dataModuleTag,
          'name',
          moduleName
        );
        this.setState({
          dataModuleName: name
        });
      }
    }
  };

  /**
   * @description:将Hightopo节点的attrs转换为服务端需要的数据结构
   * @param {Object} htNode - Hightopo的节点
   */
  private exchangeHtNodeData = (htNode: any) => {
    let data = null;
    if (!_.isNil(htNode) && htNode instanceof window.ht.Node) {
      const htNodePoints = htNode.a('points');
      const htNodeInPoints =
        htNodePoints && htNodePoints.in
          ? htNodePoints.in.filter((item: any) => !_.isNil(item.sourcePointID))
          : [];
      const htNodeOutPoints =
        htNodePoints && htNodePoints.out
          ? htNodePoints.out.filter((item: any) => !_.isNil(item.targetPointID))
          : [];
      data = {
        id: htNode.getTag(),
        name: htNode.a('name'),
        operator: htNode.a('alias'),
        config: _.omit(htNode.a('config'), ['struct']),
        status: htNode.a('status'),
        struct: _.get(htNode.a('config'), ['struct'], []),
        in:
          htNodeInPoints.length > 0
            ? htNodeInPoints.map(
                ({ type, id, sourceNodeTag, sourcePointID }: any) => ({
                  type,
                  pointId: id,
                  id: sourceNodeTag,
                  sourcePointID
                })
              )
            : null,
        out:
          htNodeOutPoints.length > 0
            ? htNodeOutPoints.map(
                ({ type, id, targetNodeTag, targetPointID }: any) => ({
                  type,
                  pointId: id,
                  id: targetNodeTag,
                  targetPointID
                })
              )
            : null
      };
    }
    return data;
  };

  public getReleaseLayoutInfos = () => {
    if (this.HTEditorRef === null) return;

    // 根据洞察返回的节点信息获取新的
    const verifiedProcessesNodes = _.map(
      this.props.taskDetailStore.nodeInfos,
      item => {
        return this.exchangeHtNodeData(
          this.HTEditorRef.getGraphViewNodeByTag(item.id)
        );
      }
    );
    // 已验证的组件对象序列化结果
    const verifiedProcessesLayout =
      this.HTEditorRef.getVerifiedProcessesSerialization(
        verifiedProcessesNodes.map(({ id }: any) => id),
        0
      );
    return {
      nodes: verifiedProcessesNodes,
      layout: verifiedProcessesLayout
    };
  };

  private renderComponent = () => {
    const {
      dataModuleConfig,
      dataModuleInputDatas,
      dataModuleTag,
      dataModuleName,
      dataModuleAlias: alias,
      dataModuleSubAlias
    } = this.state;

    let ModuleComponent = null;
    if (alias === 'DataInputModule' || alias === 'DataOutputModule') {
      ModuleComponent = Modules[dataModuleSubAlias || alias];
    }

    return (
      <ModuleErrorBoundary dataModuleTag={dataModuleTag}>
        <Suspense
          fallback={
            <div className={styles.spinWrapper}>
              <Spin className={styles.spin} />
            </div>
          }
        >
          {!_.isNil(ModuleComponent) ? (
            <ModuleComponent
              initApi={this.initApi}
              updateNodeNameByTag={this.handleUpdateNodeNameByTag}
              dataModuleConfig={dataModuleConfig}
              dataModuleTag={dataModuleTag}
              dataModuleName={dataModuleName}
              dataModuleInputDatas={dataModuleInputDatas}
              toggleChangedStatus={this.toggleChangedStatus}
            />
          ) : null}
        </Suspense>
      </ModuleErrorBoundary>
    );
  };

  public render() {
    const { isConfigChanged } = this.state;
    const { tipsVisible, dataModuleName, drawerVisible, dataModuleAlias } =
      this.state;
    return (
      <div className={styles.adjustWrapper}>
        <PublishEditor
          ref={ref => {
            if (this.HTEditorRef === null) {
              this.HTEditorRef = ref;
            }
          }}
          onEventTypeChange={this.handleHTEditorEventChange}
        />
        {drawerVisible ? (
          <TaskModuleDrawer
            dataModuleAlias={dataModuleAlias}
            dataModuleName={dataModuleName}
            drawerVisible={drawerVisible}
            isConfigChanged={isConfigChanged}
            onSave={this.saveModuleConfig}
            onCancel={this.closeDrawer}
          >
            {this.renderComponent()}
          </TaskModuleDrawer>
        ) : (
          <div className={styles.adjustContainer}>
            <p className={styles.placeholder}>
              请选择 数据输入 和 数据输出 组件进行配置调整
            </p>
          </div>
        )}
        <SaveTips
          visible={tipsVisible}
          dataModuleName={dataModuleName}
          onOk={this.saveModuleConfig}
          onCancel={this.cancelModuleConfig}
          onClose={this.closeTipsModal}
        />
      </div>
    );
  }
}

export default AdjustConfig;
