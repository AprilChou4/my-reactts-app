import React, { FunctionComponent } from 'react';
import classnames from 'classnames';
import { Button } from 'sup-ui';

import Dialog from '@components/Modal/Dialog';
import styles from './index.less';

interface IProps {
  visible: boolean;
  onChange: (value: string) => void;
  onCancel: () => void;
}

const ChoosePublishWay: FunctionComponent<IProps> = (props: IProps) => {
  const { onChange, visible, onCancel } = props;
  return (
    <Dialog
      visible={visible}
      footer={null}
      centered={true}
      className={styles.publishContainer}
      wrapClassName="filter-mask"
      width="auto"
      onCancel={onCancel}
    >
      <div className={styles.choosePublishContainer}>
        <h3 className={styles.title}>选择发布方式</h3>
        <div className={styles.publishMethod}>
          <Button
            className={classnames(styles.chooseBtn, styles.publishBtn)}
            onClick={() => {
              onChange('fastPublish');
            }}
          >
            快速发布
          </Button>
          <Button
            className={classnames(styles.chooseBtn, styles.adjustBtn)}
            onClick={() => {
              onChange('adjustPublish');
            }}
          >
            调整
          </Button>
          <div className={styles.tips}>修改数据输入/输出配置</div>
        </div>
      </div>
    </Dialog>
  );
};

export default ChoosePublishWay;
