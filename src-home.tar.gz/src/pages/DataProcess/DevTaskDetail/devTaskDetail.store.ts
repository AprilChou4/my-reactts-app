import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';

import {
  getTaskDataById,
  updateTaskData,
  getInsightDetailByTag,
  startDebug,
  getDebugInfo,
  stopDebug,
  getInsightData,
  quickReleaseTask,
  adjustReleaseTask,
  getCatalogue
} from './devTaskDetail.service';
import { getLayout, packLayout, trimNodes } from './lib/task.helper';
import { transJsonParse } from '@utils/common';

const initModule = {
  dataModuleAlias: '',
  dataModuleName: '',
  dataModuleTag: '',
  dataModuleDescription: '',
  dataModuleStatus: 'warning',
  dataModuleConfig: {},
  dataModuleInputDatas: []
};

class TaskModelStore {
  private readonly globalStore: any;
  // 建模 画布区 穿梭框 相关状态
  @observable public drawerVisible = false; // 模块配置区穿梭框状态
  @observable public publishVisible = false; //
  @observable public saveModuleConfigModalVisible = false; // 是否保存配置区修改的模太框状态
  @observable public isConfigChanged = false; // 配置信息是否改变
  @observable public isAdjustPublishConfig = false;
  @observable public isCloseSaveConfigModalByPublish = false; // 调整发布时 - 是否保存配置区修改的模太框是否为点击的关闭
  // 当前选择节点-右侧配置区信息
  // 当前选择的模块信息
  @observable public currentModule = _.cloneDeep(initModule);

  // 开发任务详情 后端相关数据
  @observable public taskInfo: any = {
    taskId: '',
    taskName: '',
    taskType: undefined,
    version: '',
    thoroughState: 0, // 调试状态 0:失败  1:成功  2:未调试 3:正在调试
    creatorName: '',
    createdTime: undefined,
    lastModifierName: '',
    lastModifiedTime: undefined,
    inputShowName: '',
    outputShowName: '',
    publishNum: undefined,
    lastTestId: ''
  };
  @observable public variables: any[] = []; // 变量信息
  @observable public schedule = {};
  @observable public detailLoading = false; // 保存画布信息 loading
  @observable public taskTabType = 'taskModel';
  @observable public layout = '';
  @observable public graphViewLayout = null;
  @observable public nodesNumber = -1;
  @observable public currentModuleInsightData = {};
  @observable public debugStatus = 2; // 调试状态 0:失败  1:成功  2:未调试 3:正在调试
  @observable public debugLogs: any[] = [];
  public debugIterator: any = null;
  @observable public insightLayout = '';
  @observable public insightInfo = {};
  public nodeInfos: [] = [];
  public publishFormData: any = {};
  @observable public catalog: any[] = [];

  public constructor(globalStore: any) {
    this.globalStore = globalStore;
  }

  //获取目录列表
  @action.bound
  public async getTaskCatalog() {
    const res = await getCatalogue();

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.catalog = res.list || [];
    });
  }

  /**
   * @description: 格式化变量配置信息
   * 当变量是 Datetime 类型时，变量值 constValue 为一个对象，而给后台时需要将对象转换为 JSON串
   * 因此在每次获取之后 需要将 Datatime 类型的变量值 constValue 转换为 JSON对象方便其他模块使用
   * @param {array} variables 变量配置数组
   * @return: 格式化后的 变量配置
   */
  public formateVariables = (variables: any[]) => {
    return _.map(variables, item => {
      if (item.dataType === 'Datetime') {
        item.constValue = transJsonParse(item.constValue);
      }
      return item;
    });
  };

  @action.bound
  public async getTaskDataById(taskId: number, callback: any) {
    if (!taskId) {
      return;
    }

    const res = await getTaskDataById(taskId);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const {
        variables = [],
        schedule = this.schedule,
        layout = '',
        ...taskInfo
      } = res.data;
      let graphViewLayout: any;

      try {
        graphViewLayout = JSON.parse(layout);
      } catch (error) {
        graphViewLayout = null;
      }

      this.taskInfo = _.assign(this.taskInfo, taskInfo);
      this.variables = this.formateVariables(variables);
      this.schedule = _.assign(this.schedule, schedule);
      this.graphViewLayout = graphViewLayout;
      this.debugStatus = taskInfo.thoroughState;
      this.layout = getLayout(layout);

      callback();
    });
  }

  /**
   * @description: 保存任务的信息 变量配置/任务信息/调度信息/保存
   * 保存任务信息走的时同一个接口，返回信息只有状态码，当返回 code===200 时，更新 taskDetailStore 里相应的数据信息
   * @param {string} updateType taskInfo:任务信息 schedule:调度信息 variables:变量配置 layout:画布信息
   * @param {object} data 相应类型的数据信息
   * @param {any} callback 相应类型的数据信息
   */
  @action.bound
  public async updateTaskData(
    updateType: string,
    data: any,
    callback?: (type: string) => void
  ) {
    const { taskId } = this.taskInfo;
    if (!taskId) {
      return;
    }

    data.taskId = taskId;

    if (data.layout) {
      data.layout = packLayout(data.layout);
    }

    this.detailLoading = true;

    const res = await updateTaskData(data);

    runInAction(() => {
      this.detailLoading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      if (updateType === 'taskInfo') {
        this.taskInfo = _.assign(this.taskInfo, data);
      }

      if (updateType === 'schedule') {
        this.schedule = data.schedule;
      }

      if (updateType === 'variables') {
        this.variables = this.formateVariables(data.variables);
      }

      if (updateType === 'layout') {
        this.layout = data; //???
      }

      message.success('信息保存成功!');
      this.globalStore.executeCacheMethod('/process/dev', 'refreshTaskList');
      callback && callback(updateType);
    });
  }

  @action.bound
  public async quickReleaseTask(params: any) {
    const { taskId } = this.taskInfo;

    if (!taskId) {
      return;
    }

    const res = await quickReleaseTask({
      ...params,
      taskId
    });

    if (res.code !== 200) {
      message.error(`${res.message}`);
      return;
    }

    message.success('发布成功');
  }

  @action.bound
  public async getInsightDetailByTag(params: any) {
    const { lastTestId: testId, taskId } = this.taskInfo;

    if (!testId || !taskId) {
      return;
    }

    const res = await getInsightDetailByTag({
      ...params,
      testId,
      taskId
    });

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.currentModuleInsightData = res.data;
    });
  }

  @action.bound
  public async startDebug(debugFormData: any, debugNodeStatus?: any) {
    const { taskId } = this.taskInfo;

    if (!taskId) {
      return;
    }

    debugFormData.taskId = taskId;
    debugFormData.debugLayout = packLayout(debugFormData.debugLayout);
    debugFormData.nodes = trimNodes(debugFormData.nodes);

    this.updateDebugStatus(3); //正在调试
    this.updateDebugLogs([]);

    const res = await startDebug(debugFormData);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const debugData = {
        taskId,
        testId: res.data,
        testType: debugFormData.testType,
        allLogs: 0
      };

      this.getDebugInfo(debugData, debugNodeStatus);
    });
  }

  @action.bound
  public adjustPublishDebug = (debugFormData: any, publishFormData: any) => {
    this.publishFormData = publishFormData;
    this.startDebug(debugFormData);
  };

  @action.bound
  public async modelDebug(
    debugFormData: any,
    layoutData: any,
    debugNodeStatus: any
  ) {
    const { taskId } = this.taskInfo;

    if (!taskId) {
      return;
    }

    layoutData.taskId = taskId;
    layoutData.layout = packLayout(layoutData.layout);
    this.updateLayout(debugFormData.debugLayout); //？？？不知何用
    this.detailLoading = true;

    // 先更新一下整个画布信息
    const res = await updateTaskData(layoutData);

    runInAction(() => {
      this.detailLoading = false;

      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      this.startDebug(debugFormData, debugNodeStatus);
    });
  }

  @action.bound
  public async stopDebug() {
    const { lastTestId } = this.taskInfo;

    if (!lastTestId) {
      return;
    }

    const res = await stopDebug(lastTestId);

    if (res.code !== 200) {
      message.error('停止调试失败');
      return;
    }

    message.success('停止调试成功');
    this.updateDebugStatus(2);
    this.cleanDebugIterator();
  }

  /**
   * @description: 执行轮询运行记录的迭代器
   * 根据 allLogs 参数不同 返回的数据信息不同;
   *  - 当 allLogs 传参为 1 时, 即显示为所有信息, 存在返回信息字段的 allLogs 中;
   * 	- 当 allLogs 传参为 0 时, 即显示单条信息, 存在返回信息字段的 logs 中
   * @param {any} debugData - formData
   * @param {any} debugNodeStatus - callback
   */
  @action.bound
  public async getDebugInfo(debugData: any, debugNodeStatus?: any) {
    const res = await getDebugInfo(debugData);

    if (res.code !== 200) {
      this.cleanDebugIterator();
      this.updateDebugStatus(0);
      message.error(res.message || '调试失败');
      return;
    }

    const {
      testId,
      successed,
      status,
      logs = [],
      allLogs: resAllLogs = [],
      nodeInfos = [],
      takenTime = 0
    } = res.data || {};

    if (!testId) {
      this.cleanDebugIterator();
      this.updateDebugStatus(0);
      message.error('调试失败');
      return;
    }

    // 根据返回节点信息更新节点状态
    const nodeInfosArr = _.isArray(nodeInfos) ? nodeInfos : [];

    if (debugData.testType === 1) {
      debugNodeStatus(nodeInfosArr);
    }

    runInAction(() => {
      // 更新 debug 日志 allLog 1:全部输出 0:单条输出
      if (debugData.allLogs === 1) {
        this.debugLogs = _.isArray(resAllLogs) ? resAllLogs : [];
      } else {
        // 单条输出，一条一条拼接
        const reslogs = _.isArray(logs) ? logs : [];

        this.debugLogs = _.concat(this.debugLogs, reslogs);
      }

      // 状态为1，调试完成，停止轮循
      if (status === 1) {
        this.cleanDebugIterator();
        this.updateDebugStatus(successed);

        if (successed === 1) {
          this.taskInfo = {
            ...this.taskInfo,
            lastTestId: testId,
            takenTime
          };

          if (debugData.allLogs === 0) {
            if (debugData.testType === 1) {
              // 切换至洞察页
              this.changeTaskTabType('taskView');
            } else {
              this.adjustPublishTask(this.publishFormData);
            }
          }
        }

        return;
      }

      // 继续轮循
      if (status === 0) {
        this.updateDebugStatus(3); //正在调试
        this.taskInfo.lastTestId = testId;
        this.debugIterator = setTimeout(() => {
          this.getDebugInfo(debugData, debugNodeStatus);
        }, 1000);
        return;
      }

      this.updateDebugStatus(0); //调试失败
    });
  }

  @action.bound
  public async getInsightData(callback?: any) {
    const { taskId, lastTestId } = this.taskInfo;
    if (!lastTestId || !taskId) return;
    const {
      code,
      data,
      message: msg
    } = await getInsightData({
      taskId,
      testId: lastTestId
    });
    if (code === 200) {
      if (_.isEmpty(data)) {
        throw new Error('TaskView must need insightDetailData');
      }
      const {
        debugLayout,
        nodeInfos = [],
        takenTime,
        status,
        successed
      } = data;
      runInAction(() => {
        this.insightLayout = getLayout(debugLayout);
        this.nodeInfos = nodeInfos;
        this.insightInfo = {
          successed,
          takenTime,
          status
        };
        if (callback) callback(this.insightLayout);
      });
    } else {
      message.error(msg);
    }
  }

  @action.bound
  public async adjustPublishTask(formData: any) {
    const { taskId } = this.taskInfo;
    if (!taskId) return;
    formData.taskId = taskId;
    const res = await adjustReleaseTask(formData);
    if (res.code === 200) {
      //success
    } else {
      this.updateDebugStatus(0);
      message.error(`${res.message}`);
    }
  }

  @action.bound
  public changeTaskTabType = (taskTabType: string) => {
    if (taskTabType === 'taskModel') {
      this.drawerVisible = false;
    }
    this.initCurrentModule();
    this.taskTabType = taskTabType;
  };

  @action.bound
  public updateCurrentModule = (currentModule: any) => {
    if (!currentModule) return;
    this.currentModule = _.cloneDeep(
      _.assign(this.currentModule, currentModule)
    );
  };

  @action.bound
  public initCurrentModule = () => {
    this.currentModule = _.cloneDeep(initModule);
    this.currentModuleInsightData = {};
  };

  @action.bound
  public updateLayout = (layout: string) => {
    this.layout = layout;
  };

  /**
   * @description: 更新画布中的节点数量，用于调试校验等
   */
  @action.bound
  public updateNodesNumber = (value: number) => {
    this.nodesNumber = value;
  };

  @action.bound
  public updateDebugStatus = (status: number) => {
    this.debugStatus = status;
    // 当更改调试状态为 2：未调试状态 将debugLogs 置空
    if (status === 2) {
      this.debugLogs = [];
    }
  };

  @action.bound
  public updateDebugLogs = (debugLogs: any[]) => {
    this.debugLogs = debugLogs;
  };

  /**
   * @description: 清除调试轮询计时器
   * 意味着调试结束，需要重新刷新任务列表
   */
  public cleanDebugIterator = () => {
    if (this.debugIterator) clearTimeout(this.debugIterator);
    this.globalStore.executeCacheMethod('/process/dev', 'refreshTaskList');
  };

  /**
   * @description: 当算子穿梭框关闭时，isConfigChanged 的状态也要修改为 false
   */
  @action.bound
  public updateDrawerVisible = (value: boolean) => {
    this.drawerVisible = value;
    if (value === false) {
      this.isConfigChanged = false;
    }
  };

  /**
   * @description: 当 value 为 true 时，必须在算子穿梭框开启时才有效
   */
  @action.bound
  public updateConfigStatus = (value: boolean) => {
    if (value === true) {
      if (this.drawerVisible) this.isConfigChanged = value;
    } else {
      this.isConfigChanged = value;
    }
  };

  @action.bound
  public updatePublishVisible = (value: boolean) => {
    this.publishVisible = value;
  };
}

export default TaskModelStore;
