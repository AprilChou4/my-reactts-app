import React, { Component } from 'react';
import classnames from 'classnames';
import { inject, observer } from 'mobx-react';
import { Button, Radio, message } from 'sup-ui';

import TaskDispatch from '../components/TaskDispatch';
import TaskInformation from '../components/TaskInformation';
import VariableConfigure from '../components/VarConfig';
import TaskDetailName from '../../components/TaskDetailName';
import Icon from '@components/Icon';
import styles from './index.less';

const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;
const ButtonGroup = Button.Group;

interface IProps {
  taskDetailStore?: any;
  onSave: () => void;
  onVerify: () => void;
}

interface IState {
  [propName: string]: boolean;
}

interface ITaskInfo {
  taskName: string;
  taskType: any;
  version: any;
  description: string;
}

const typeVisible: {
  [propName: string]: string;
} = {
  schedule: 'dispatchVisible',
  variables: 'varVisible',
  taskInfo: 'infoVisible',
  publishVisible: 'publishVisible'
};

@inject('taskDetailStore')
@observer
class TaskToolBar extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      dispatchVisible: false,
      infoVisible: false,
      varVisible: false
    };
  }

  private handleBack = () => {
    window.location.href = `#/process/dev?folderId=${this.props.taskDetailStore.taskInfo.folderId}`;
  };

  private changeTaskTabType = (e: any) => {
    this.props.taskDetailStore.changeTaskTabType(e.target.value);
  };

  private handlePublish = () => {
    const { debugStatus, schedule, updatePublishVisible } =
      this.props.taskDetailStore;
    if (_.isEmpty(schedule)) {
      message.warning('请先配置调度信息!');
      return;
    }
    if (debugStatus !== 1) {
      message.warning('请先调试成功!');
      return;
    }
    updatePublishVisible(true);
  };

  private openModal = (type: string): void => {
    if (!type) return;
    this.setState({
      [type]: true
    });
    if (type === 'infoVisible') {
      this.props.taskDetailStore.getTaskCatalog();
    }
  };

  public toggleModalVisible = (type: string): void => {
    if (!type) return;
    const visible = typeVisible[type];
    this.setState({
      [visible]: false
    });
  };

  // 保存 任务信息
  private handleSaveTaskInfo = (formData: ITaskInfo): void => {
    const {
      taskName = '',
      taskType = '',
      version = '',
      description = ''
    } = formData;
    const params = _.assign(formData, {
      taskName,
      taskType,
      version,
      description,
      modifyUnit: 2
    });
    this.props.taskDetailStore.updateTaskData('taskInfo', params, () => {
      this.setState({
        infoVisible: false
      });
    });
  };

  /**
   * @description: 保存全局变量，保存成功之后需要对所有使用到全局变量的算子进行校验
   * @param {function} onVerify 告知 taskModel 对算子进行校验
   */
  private handleSaveVariables = (formData: any): void => {
    const params = {
      variables: formData,
      modifyUnit: 3
    };
    this.props.taskDetailStore.updateTaskData(
      'variables',
      params,
      this.props.onVerify
    );
    this.setState({
      varVisible: false
    });
  };

  // 保存 调度信息
  private handleSaveSchedule = (formData: any): void => {
    const params = {
      schedule: formData,
      modifyUnit: 1
    };
    this.props.taskDetailStore.updateTaskData('schedule', params, () => {
      this.setState({
        dispatchVisible: false
      });
    });
  };

  public render() {
    const {
      variables,
      taskInfo,
      schedule,
      taskTabType,
      debugStatus,
      onOkLoading,
      catalog
    } = this.props.taskDetailStore;
    const { dispatchVisible, infoVisible, varVisible } = this.state;
    const btnDisabled = taskTabType === 'taskView';
    return (
      <div className={styles.header}>
        <TaskDetailName
          taskName={taskInfo.taskName}
          version={taskInfo.version}
          onBack={this.handleBack}
        />
        <div className={styles.toolbar}>
          <ButtonGroup>
            <Button
              onClick={this.props.onSave}
              disabled={btnDisabled}
              className={styles.save}
            >
              保存
            </Button>
            <Button
              className={classnames(_.isEmpty(schedule) && styles.dispatchBtn)}
              onClick={this.openModal.bind(this, 'dispatchVisible')}
            >
              调度
            </Button>
            <Button onClick={this.openModal.bind(this, 'infoVisible')}>
              任务信息
            </Button>
          </ButtonGroup>
          <ButtonGroup>
            <Button onClick={this.openModal.bind(this, 'varVisible')}>
              变量
            </Button>
            {/* <Button>
              <i className={(styles, helpIcon)}></i>
            </Button> */}
          </ButtonGroup>
          <div className={styles.headerTabs}>
            <RadioGroup
              size="large"
              value={taskTabType}
              onChange={this.changeTaskTabType}
            >
              <RadioButton value="taskModel" className={styles.headerTabItem}>
                <Icon
                  type="modeling"
                  className={styles.icon}
                  fill={taskTabType === 'taskModel' ? '#fff' : ''}
                />
                建模
              </RadioButton>
              <RadioButton
                value="taskView"
                disabled={debugStatus !== 1}
                className={styles.headerTabItem}
              >
                <Icon
                  type="viewing"
                  disabled={debugStatus !== 1}
                  className={classnames(
                    styles.icon,
                    taskTabType === 'taskView' && styles.viewActive
                  )}
                />
                洞察
              </RadioButton>
            </RadioGroup>
          </div>
          <div className={styles.publish}>
            <Button
              size="large"
              className={styles.publishBtn}
              onClick={this.handlePublish}
            >
              <span>发布</span>
              <span className={styles.publishIcon}>
                <Icon type="arrow" className={styles.arrowIcon} fill="#fff" />
              </span>
            </Button>
          </div>
        </div>
        {dispatchVisible && (
          <TaskDispatch
            visible={dispatchVisible}
            toggleModalVisible={this.toggleModalVisible.bind(this, 'schedule')}
            onSave={this.handleSaveSchedule}
            schedule={schedule}
            loading={onOkLoading}
          />
        )}
        {infoVisible && (
          <TaskInformation
            visible={infoVisible}
            loading={onOkLoading}
            taskInfo={taskInfo}
            catalog={catalog}
            toggleModalVisible={this.toggleModalVisible.bind(this, 'taskInfo')}
            onSave={this.handleSaveTaskInfo}
          />
        )}
        {varVisible && (
          <VariableConfigure
            toggleModalVisible={this.toggleModalVisible.bind(this, 'variables')}
            variables={variables}
            loading={onOkLoading}
            onOk={this.handleSaveVariables}
          />
        )}
      </div>
    );
  }
}

export default TaskToolBar;
