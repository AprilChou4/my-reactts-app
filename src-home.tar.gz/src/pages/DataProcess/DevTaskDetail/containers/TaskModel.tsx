import React from 'react';
import { message } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import { toJS } from 'mobx';
import TaskModuleDrawer from '../../Modules/components/TaskModuleDrawer';
import Modules from '../../Modules';
import ModelEditor from '../components/Editor/ModelEditor';
import DebugLogs from '../components/DebugLogs';
import SaveTips from '../components/SaveTips';
import { getSourceInfo, getModuleName } from '../lib/task.helper';
import { modulesMenu } from '../../devTask.const';
import styles from './index.less';

interface IProps {
  taskId: any;
  drawerVisible: boolean;
  collapsedSider: boolean;
  onPageStatusChange: any;
  global?: any;
  taskDetailStore?: any;
}

interface IState {
  debugSuccessNodes: any[];
  tipsVisible: boolean;
}

@inject('taskDetailStore', 'global')
@observer
class TaskModel extends React.Component<IProps, IState> {
  public HTEditorRef: any;
  private currentModuleSaveFn: any;
  private readonly resize: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      debugSuccessNodes: [], // 调试成功时保存的nodes节点
      tipsVisible: false
    };
    this.HTEditorRef = null;
    this.resize = _.debounce(this.resizeLayout, 400);
  }

  public componentDidMount() {
    const { taskId, taskDetailStore } = this.props;

    taskDetailStore.getTaskDataById(taskId, this.initTaskModeling);
  }

  public componentDidUpdate(prevProps: IProps) {
    const {
      // taskDetailStore: { dataModuleConfig, dataModuleTag },
      collapsedSider,
      drawerVisible
    } = this.props;

    // 判断是否为当前算法的配置区信息有修改,并保存到store中
    // 无用代码，store中不存在此变量
    // if (
    //   !_.isEqual(
    //     prevProps.taskDetailStore.dataModuleConfig,
    //     dataModuleConfig
    //   ) &&
    //   prevProps.taskDetailStore.dataModuleTag === dataModuleTag
    // ) {
    //   this.saveConfigToLayout(dataModuleConfig);
    // }

    if (
      !_.isEqual(prevProps.collapsedSider, collapsedSider) ||
      !_.isEqual(prevProps.drawerVisible, drawerVisible)
    ) {
      //菜单列、drawer折叠/打开时重绘一次布局
      //第一次collapsedSider、drawerVisible会依次变化，debounce避免重复触发
      this.resize();
    }
  }

  public componentWillUnmount() {
    this.props.taskDetailStore.cleanDebugIterator();
  }

  public resizeLayout = () => {
    this.HTEditorRef.resizeLayout();
  };

  private initTaskModeling = () => {
    const { debugStatus, taskInfo, layout } = this.props.taskDetailStore;

    // 若上次调试过，取上次的所有logs信息渲染，轮循接口，处理逻辑
    if (taskInfo.lastTestId) {
      const debugData = {
        taskId: taskInfo.taskId,
        testId: taskInfo.lastTestId,
        allLogs: 1,
        testType: 1
      };

      this.props.taskDetailStore.getDebugInfo(
        debugData,
        this.updateNodeStatusByDebugInfo
      );
    }

    if (this.HTEditorRef) {
      this.HTEditorRef.initHT(layout); //创建画布，初始化layout，更新nodesNumber
      this.HTEditorRef.checkGraphViewAllNodes(); //校验所有节点，同时更新节点status等信息

      if (debugStatus === 1) {
        const verifiedProcessNodes = this.getTaskValidatedNodes();
        this.setState({
          debugSuccessNodes: _.map(verifiedProcessNodes, (item: any) => ({
            ...item,
            status: ''
          }))
        });
      }
    }
  };

  private closeDrawer = () => {
    if (this.verifyConfigStatus()) this.cancelModuleConfig();
  };

  /**
   * @description: 当组态信息发生更改之后，触发算子状态开关
   * 同时告知全局缓存页面，页面发生更改，当组态界面发生改变，用户关闭缓存标签页时，二次确认提示
   */
  private toggleChangedStatus = () => {
    const {
      onPageStatusChange,
      taskDetailStore: { updateConfigStatus }
    } = this.props;

    onPageStatusChange(true);
    updateConfigStatus(true);
  };

  // **************************  校验状态相关 ***********************
  /**
   * @description:校验算子模块的状态是否时已修改
   * 如果已修改 提示用户是否保存
   * @return {boolean} 返回布尔值
   */
  private verifyConfigStatus = () => {
    const { isConfigChanged } = this.props.taskDetailStore;
    if (isConfigChanged) {
      this.toggleTipsModal(true);
      return false;
    }
    return true;
  };

  /**
   * @description: 校验调试任务信息状态
   * 如果调试任务正在继续,请用户稍后重试
   * @return {boolean} 返回布尔值
   */
  private verifyDebugStatus = () => {
    const { debugStatus } = this.props.taskDetailStore;
    if (debugStatus === 3) {
      message.warning('任务正在调试, 请稍候再试!');
      return false;
    }
    return true;
  };

  // ***************************** 保存相关 ***********************************
  /**
   * @description: 保存配置区的配置项至HT-Node的Attrs
   * 保存配置成功之后将调试状态置为  '未调试' -> 2
   * @param {object} moduleConfig - 配置区域配置
   */
  private saveConfigToLayout = (moduleConfig: any) => {
    const tag = this.props.taskDetailStore.currentModule.dataModuleTag;
    if (!tag) return;
    // 更新HT节点中attrs中的config
    this.HTEditorRef.updateGraphViewNodeAttrsByTag(tag, 'config', moduleConfig);
    // 对当前节点及下游节点递归检查
    this.HTEditorRef.checkNodeByModuleVerifier(tag);
    this.props.taskDetailStore.updateDebugStatus(2);
    this.props.taskDetailStore.initCurrentModule();
    this.props.taskDetailStore.updateDrawerVisible(false);
    this.toggleTipsModal(false);
  };

  private saveModuleConfig = () => {
    if (_.isFunction(this.currentModuleSaveFn)) {
      const config = this.currentModuleSaveFn();
      console.log('config', config);
      if (config) {
        this.saveConfigToLayout(config);
      }
    }
  };

  /**
   * @description: 取消是否保存修改提示框
   * 注: 提示框的取消事件 是 取消当前配置
   */
  private cancelModuleConfig = () => {
    this.setState({
      tipsVisible: false
    });
    this.props.taskDetailStore.updateDrawerVisible(false);
    this.props.taskDetailStore.initCurrentModule();
  };

  /**
   * @description: 打开/关闭是否保存修改提示框
   */
  private toggleTipsModal = (value: boolean) => {
    this.setState({
      tipsVisible: value
    });
  };

  // 全局保存,将 HT layout 信息经过校验传输给后台
  public saveTaskData = () => {
    const { debugSuccessNodes } = this.state;
    const {
      onPageStatusChange,
      taskDetailStore: { updateTaskData, updateDebugStatus }
    } = this.props;

    if (!this.verifyConfigStatus() || !this.verifyDebugStatus()) {
      return;
    }

    // 获取有效的输入输出节点
    let verifiedProcessNodes = this.getTaskValidatedNodes();
    const sourceInfo = getSourceInfo(verifiedProcessNodes);
    // 调试成功后 各节点配置项 是否有修改
    // 重置组件状态
    verifiedProcessNodes = _.map(verifiedProcessNodes, (item: any) => ({
      ...item,
      status: ''
    }));

    const isConfigModify = !_.isEqual(debugSuccessNodes, verifiedProcessNodes)
      ? 1
      : 0;

    if (isConfigModify === 1) {
      updateDebugStatus(2);
    }

    const layout = this.getTaskLayout();

    if (!layout) {
      return;
    }

    const formData: any = {
      layout,
      isConfigModify,
      modifyUnit: 0,
      sourceInfo
    };

    updateTaskData('layout', formData);
    onPageStatusChange(false); //保存后，可以安全的关闭当前页
  };

  // *********************** HT 画布相关 *************************
  // HT画布被清空时的触发事件
  // private handleHTEditorCleanAll = () => {
  //   this.props.taskDetailStore.initCurrentModule();
  // };

  // 获取layout序列化后的数据
  private getTaskLayout = () => {
    return this.HTEditorRef
      ? this.HTEditorRef.getGraphViewDataModelSerialize()
      : '';
  };

  /**
   * @description: 获取已经验证过的Node节点集合
   * 检测通过的链路上的所有算法节点的配置信息
   * @return {array}  验证通过的Node节点集合
   */
  private getTaskValidatedNodes = (): any[] => {
    return this.HTEditorRef
      ? this.HTEditorRef.getValidatedGraphViewNodeData()
      : [];
  };

  // 处理画布事件
  private handleHTEditorEventChange = (
    eventType: string,
    currentModuleInfo: any
  ) => {
    const {
      taskDetailStore: {
        drawerVisible,
        isConfigChanged,
        updateDrawerVisible,
        updateCurrentModule,
        initCurrentModule,
        currentModule
      },
      global
    } = this.props;

    //drawer框有更改时，不处理后续逻辑
    if (isConfigChanged) {
      return;
    }

    if (eventType === 'doubleClickData' && currentModuleInfo) {
      //打开drawer的同时折叠菜单列
      global.changeCollapsed(true);

      setTimeout(() => {
        updateDrawerVisible(true);
        updateCurrentModule(currentModuleInfo);
      }, 100);
    }

    if (eventType === 'clickData') {
      if (!drawerVisible) {
        return;
      }

      // TODO: bug: 切换相同输入/输出算子时，数据未更新
      if (
        currentModule.dataModuleTag !== currentModuleInfo.dataModuleTag &&
        currentModuleInfo
      ) {
        updateCurrentModule(currentModuleInfo);
      }
    }

    if (
      eventType === 'clickBackground' ||
      eventType === 'doubleClickBackground'
    ) {
      initCurrentModule();
      updateDrawerVisible(false);
    }
  };

  /**
   * @description: HT的GraphView中事件类型切换的触发事件
   * doubleClick 显示算子配置区信息
   * @param {string} eventType - 当前类型
   * @param {boolean} isHtNode - 当前事件源是不是htNode
   */
  // private handleHTEditorEventChange = (
  //   eventType: string,
  //   currentModuleInfo: any,
  //   event?: MouseEvent
  // ) => {
  //   const { taskDetailStore, global } = this.props;
  //
  //   if (!taskDetailStore.isConfigChanged) {
  //     if (eventType === 'doubleClickData' && currentModuleInfo) {
  //       //打开drawer的同时折叠菜单列
  //       global.changeCollapsed(true);
  //
  //       setTimeout(() => {
  //         taskDetailStore.updateDrawerVisible(true);
  //         taskDetailStore.updateCurrentModule(currentModuleInfo);
  //       }, 100);
  //     }
  //     if (eventType === 'clickData') {
  //       if (currentModuleInfo.dataModuleStatus === 'warn') {
  //         const tipsDom = $(`#warningTips-${taskDetailStore.taskInfo.taskId}`);
  //         event &&
  //           renderWarningTips(event, tipsDom, currentModuleInfo.verifyInfo);
  //       }
  //       this.handleSelectionNode(currentModuleInfo.dataModuleTag);
  //     }
  //   }
  // };

  /**
   * @description: HT的GraphView中Node切换焦点的触发事件
   * @param {string} kind - 图元操作类型
   * @param {string} eleType - 图元的类型 Node Edge
   * @param {object} currentModuleInfo - 当前选中节点的信息
   */
  // private handleHTEditorSelectChange = (
  //   kind: string,
  //   eleType: string,
  //   currentModuleInfo: any
  // ) => {
  //   const { isCloseSaveConfigModal } = this.state;
  //   const {
  //     isConfigChanged,
  //     drawerVisible,
  //     updateConfigStatus,
  //     initCurrentModule,
  //     currentModule: preModuleInfo
  //   } = this.props.taskDetailStore;
  //
  //   // 配置信息是否修改
  //   if (kind === 'remove' && eleType === 'Node') {
  //     if (eleType === 'Node') {
  //       updateConfigStatus(false);
  //     }
  //     if (drawerVisible && isConfigChanged && !isCloseSaveConfigModal) {
  //       this.toggleTipsModal(false);
  //     }
  //   }
  //   // 如果穿梭层未打开,则不更新当前节点数据
  //   if (!drawerVisible) return;
  //   if (!this.props.taskDetailStore.isConfigChanged) {
  //     if (!currentModuleInfo) {
  //       initCurrentModule();
  //       this.props.taskDetailStore.updateDrawerVisible(false);
  //     } else {
  //       if (
  //         preModuleInfo.dataModuleAlias !== currentModuleInfo.alias &&
  //         currentModuleInfo
  //       ) {
  //         this.props.taskDetailStore.updateCurrentModule(currentModuleInfo);
  //       }
  //     }
  //   }
  // };

  private handleNodeDelete = (moduleInfo: any) => {
    const { currentModule } = this.props.taskDetailStore;
    if (currentModule.dataModuleTag === moduleInfo.dataModuleTag) {
      this.props.taskDetailStore.updateDrawerVisible(false);
      this.props.taskDetailStore.initCurrentModule();
    }
  };

  /**
   * @description: 根据tag号更新节点名称
   */
  private handleUpdateNodeNameByTag = (name: string) => {
    if (this.HTEditorRef) {
      const { currentModule } = this.props.taskDetailStore;
      if (currentModule.dataModuleTag) {
        const names = this.HTEditorRef.getGraphViewNodesName();
        const moduleName = getModuleName(names, name);
        this.HTEditorRef.updateGraphViewNodeAttrsByTag(
          currentModule.dataModuleTag,
          'name',
          moduleName
        );
        const newCurrentModule = toJS(currentModule);
        newCurrentModule.dataModuleName = moduleName;
        this.props.taskDetailStore.updateCurrentModule(newCurrentModule);
      }
    }
  };

  /**
   * @description: HT节点状态检查后的回调函数
   * 参数由<ModelEditor/> => checkNodeByModuleVerifier 定义
   * 选中单个的图元时，切换左侧配置区的参数
   */
  private handleAfterHTNodeStatusChecking = ({
    tag = '',
    dataModuleConfig,
    dataModuleInputDatas
  }: any) => {
    const { dataModuleTag } = this.props.taskDetailStore.currentModule;
    if (dataModuleTag && dataModuleTag === tag) {
      const newModuleConfig = {
        dataModuleConfig,
        dataModuleInputDatas
      };
      this.props.taskDetailStore.updateCurrentModule(newModuleConfig);
    }
  };

  // 开始调试/停止按钮
  private onDebug = () => {
    const {
      onPageStatusChange,
      taskDetailStore: { debugStatus, modelDebug, stopDebug }
    } = this.props;

    if (debugStatus === 3) {
      stopDebug();
      return;
    }

    if (!this.verifyConfigStatus() || !this.HTEditorRef) {
      return;
    }

    // 强制从所有输入节点校验一次
    this.HTEditorRef.checkGraphViewAllNodes(true);
    // 获取从“数据输入/变量设置”开始至“数据输出”全检测通过的链路上的所有算法节点的配置信息
    const verifiedProcessNodes = this.getTaskValidatedNodes();
    const sourceInfo = getSourceInfo(verifiedProcessNodes);

    // 判断流程节点是否正确，并且所有节点无 warning 状态
    if (
      _.isEmpty(verifiedProcessNodes) ||
      _.some(verifiedProcessNodes, ['status', 'warning'])
    ) {
      message.warning('组件配置未完成');
      return;
    }

    // 重置待运行的组件状态
    verifiedProcessNodes.forEach(({ id }: any) => {
      this.updateNodeStatus(id, '');
    });

    // 已验证的组件对象序列化结果，已验证节点布局
    const verifiedProcessLayout =
      this.HTEditorRef.getVerifiedProcessLayout(verifiedProcessNodes);

    if (!verifiedProcessLayout) {
      message.warning('画布信息有误！');
      return;
    }

    // 获取画布所有节点布局序列
    const layout = this.getTaskLayout();

    if (!layout) {
      return;
    }

    // 调试之前保存画布信息
    const layoutData: any = {
      layout,
      isConfigModify: 0,
      modifyUnit: 0,
      sourceInfo
    };
    const debugFormData = {
      debugLayout: verifiedProcessLayout,
      nodes: verifiedProcessNodes,
      testType: 1
    };

    // 先保存画布信息, 再调试
    modelDebug(debugFormData, layoutData, this.updateNodeStatusByDebugInfo);
    onPageStatusChange(false); //保存后，可以安全的关闭当前页
  };

  /**
   * @description: 更新指定tag的Node的状态值
   * @param {string} nodeTag - 节点的tag
   * @param {string} status - 状态值
   */
  private updateNodeStatus = (nodeTag: string, status: string) => {
    if (this.HTEditorRef && nodeTag) {
      this.HTEditorRef.updateGraphViewNodeAttrsByTag(nodeTag, 'status', status);
    }
  };

  private updateNodeStatusByDebugInfo = (nodeInfosArr: any[]) => {
    _.forEach(nodeInfosArr, ({ id, success }: any) => {
      const htNode = this.HTEditorRef.getGraphViewNodeByTag(id);

      if (!_.isNil(htNode)) {
        const oldCheckStatus = htNode.a('status');

        if (oldCheckStatus !== 'warning') {
          const caseType = parseInt(success, 10);

          this.updateNodeStatus(
            id,
            caseType === 1 ? 'success' : caseType === 2 ? 'loading' : 'error'
          );
        }
      }
    });
  };

  private renderComponent = () => {
    const {
      currentModule,
      currentModule: { dataModuleAlias, dataModuleSubAlias },
      taskInfo: { taskId },
      variables
    } = this.props.taskDetailStore;
    if (dataModuleAlias) {
      const ModuleComponent = Modules[dataModuleSubAlias || dataModuleAlias];
      return (
        <ModuleComponent
          {...currentModule}
          taskId={taskId}
          initApi={(saveFn: () => any) => {
            this.currentModuleSaveFn = saveFn;
          }}
          variables={variables}
          toggleChangedStatus={this.toggleChangedStatus}
          updateNodeNameByTag={this.handleUpdateNodeNameByTag}
        />
      );
    } else {
      return null;
    }
  };

  public render() {
    const { tipsVisible } = this.state;
    const {
      isConfigChanged,
      updateNodesNumber,
      drawerVisible,
      debugStatus,
      debugLogs,
      nodesNumber,
      detailLoading,
      currentModule: { dataModuleName, dataModuleAlias }
    } = this.props.taskDetailStore;

    return (
      <div className={styles.taskModelContainer}>
        <ModelEditor
          ref={ref => {
            if (!this.HTEditorRef) {
              this.HTEditorRef = ref;
            }
          }}
          nodesNumber={nodesNumber}
          modulesMenu={modulesMenu}
          updateNodesNumber={updateNodesNumber}
          // afterGraphViewCleanAll={this.handleHTEditorCleanAll}
          afterNodeDeleted={this.handleNodeDelete}
          // onSelectChange={this.handleHTEditorSelectChange}
          onEventTypeChange={this.handleHTEditorEventChange}
          afterNodeStatusChecking={this.handleAfterHTNodeStatusChecking}
        />
        <DebugLogs
          loading={detailLoading}
          nodesNumber={nodesNumber}
          isOpenConfigDrawer={drawerVisible}
          onDebug={this.onDebug}
          debugStatus={debugStatus}
          logs={debugLogs}
        />
        <TaskModuleDrawer
          dataModuleName={dataModuleName}
          dataModuleAlias={dataModuleAlias}
          drawerVisible={drawerVisible}
          isConfigChanged={isConfigChanged}
          onSave={this.saveModuleConfig}
          onCancel={this.closeDrawer}
          updateNodeNameByTag={this.handleUpdateNodeNameByTag}
        >
          {drawerVisible && this.renderComponent()}
        </TaskModuleDrawer>
        <SaveTips
          visible={tipsVisible}
          dataModuleName={dataModuleName}
          onClose={() => {
            this.toggleTipsModal(false);
          }}
          onCancel={this.cancelModuleConfig}
          onOk={this.saveModuleConfig}
        />
      </div>
    );
  }
}

export default TaskModel;
