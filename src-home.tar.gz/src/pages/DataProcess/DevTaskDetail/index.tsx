import React, { Component, createRef } from 'react';
import { observer, Provider, inject } from 'mobx-react';
import { message } from 'sup-ui';
import { RouteComponentProps } from 'react-router-dom';
import ErrorBoundary from '@components/ErrorBoundary';
import TaskToolBar from './containers/TaskToolBar';
import TaskModel from './containers/TaskModel';
import TaskView from './containers/TaskView';
import TaskPublish from './containers/TaskPublish';
import TaskModelStore from './devTaskDetail.store';

import '@assets/css/devTask.global.less';
import styles from './index.less';

interface IProps extends RouteComponentProps {
  taskDetailStore?: any;
  global?: any;
}

interface IState {
  [propName: string]: boolean;
}

@inject('global')
@observer
class DevTaskDetail extends Component<IProps, IState> {
  private taskDetailStore: TaskModelStore;
  public taskModelRef: any;
  public constructor(props: IProps) {
    super(props);
    this.taskDetailStore = new TaskModelStore(props.global);
    this.taskModelRef = createRef();
  }

  public componentWillUnmount() {
    message.destroy();
  }

  private handleSave = () => {
    if (this.taskModelRef.current) {
      this.taskModelRef.current.saveTaskData();
    }
  };

  private handleModuleVerify = () => {
    if (this.taskModelRef.current) {
      this.taskModelRef.current.HTEditorRef.checkGraphViewAllNodes(true);
    }
  };

  private handleChangePageStatus = (status: boolean) => {
    const {
      global: { changePromptMap },
      location: { pathname }
    } = this.props;

    changePromptMap(pathname, status);
  };

  public render() {
    const { taskTabType, drawerVisible } = this.taskDetailStore;
    const {
      match,
      global: { collapsedSider }
    } = this.props;
    const taskId = (match as any).params.id;

    return (
      <ErrorBoundary>
        <Provider taskDetailStore={this.taskDetailStore}>
          <div className={styles.wrapper}>
            <TaskToolBar
              onSave={this.handleSave}
              onVerify={this.handleModuleVerify}
            />
            {taskTabType === 'taskModel' ? (
              <TaskModel
                ref={this.taskModelRef}
                taskId={taskId}
                collapsedSider={collapsedSider}
                drawerVisible={drawerVisible}
                onPageStatusChange={this.handleChangePageStatus}
              />
            ) : (
              <TaskView collapsedSider={collapsedSider} />
            )}
          </div>
          <TaskPublish />
        </Provider>
      </ErrorBoundary>
    );
  }
}

export default DevTaskDetail;
