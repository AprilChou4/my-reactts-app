const isWin = process.env.SYSTEM === 'WIN';

export const systemDefaultProps = [
  {
    key: 0,
    type: 'ENTITY_FORM',
    initialValue: ['system_id', 'id'],
    required: false,
    showName: 'id',
    dataType: 'Long'
  },
  {
    key: 1,
    type: 'ENTITY',
    initialValue: ['system_en_name', 'en_name'],
    required: false,
    showName: '别名',
    dataType: 'String'
  },
  {
    key: 2,
    type: 'ENTITY',
    initialValue: ['system_display_name', 'display_name'],
    required: false,
    showName: '名称',
    dataType: 'String'
  },
  {
    key: 3,
    type: 'ENTITY',
    initialValue: ['system_comment', 'comment'],
    required: false,
    showName: '描述',
    dataType: 'String'
  },
  {
    key: 4,
    type: 'ENTITY',
    initialValue: ['system_code', 'code'],
    required: false,
    showName: '编码',
    dataType: 'String'
  },
  {
    key: 5,
    type: 'ENTITY',
    initialValue: ['system_icon_path', 'icon_path'],
    required: false,
    showName: '图标',
    dataType: 'String'
  },
  {
    key: 6,
    type: 'ENTITY_FORM',
    initialValue: ['system_app_name', 'app_name'],
    required: false,
    showName: '所属APP名称',
    dataType: 'String'
  },
  {
    key: 7,
    type: 'ENTITY_FORM',
    initialValue: ['system_app_access_mode', 'app_access_mode'],
    required: false,
    showName: '其他APP是否可见',
    dataType: 'String'
  },
  {
    key: 8,
    type: 'ENTITY_FORM',
    initialValue: ['system_created_time', 'created_time'],
    required: false,
    showName: '创建时间',
    dataType: 'Timestamp'
  },
  {
    key: 9,
    type: 'ENTITY_FORM',
    initialValue: ['system_last_modified_time', 'last_modified_time'],
    required: false,
    showName: '最后修改时间',
    dataType: 'Timestamp'
  },
  {
    key: 10,
    type: 'ENTITY_FORM',
    initialValue: ['system_creator_id', 'creator_id'],
    required: false,
    showName: '创建人',
    dataType: 'String'
  },
  {
    key: 11,
    type: 'ENTITY_FORM',
    initialValue: ['system_last_modifier_id', 'last_modifier_id'],
    required: false,
    showName: '最后修改人',
    dataType: 'String'
  }
];

// 前后端约定的基础数据类型
export const baseTypes = [
  'String',
  'Boolean',
  'Float',
  'Double',
  'Long',
  'Integer',
  'BigInteger',
  'BigDecimal',
  'Time',
  'Date',
  'Timestamp'
];

// 前后端约定的所有数据源类型
export const dataTypes = _.concat(baseTypes, ['Bytes']);

export const sourceTypeEnum = {
  1: {
    name: 'My SQL'
  },
  2: {
    name: 'Oracle'
  },
  3: {
    name: 'SQL Server'
  },
  4: {
    name: '本地文件'
  },
  6: {
    name: 'WebService'
  },
  7: {
    name: 'Restful'
  },
  9: {
    name: 'HBase'
  },
  15: {
    name: 'Hive'
  },
  16: {
    name: 'Access'
  },
  17: {
    name: 'Paradox'
  },
  18: {
    name: 'JDBC'
  },
  19: {
    name: 'HANA'
  },
  20: {
    name: 'PostgreSQL'
  },
  21: {
    name: '达梦数据库'
  },
  31: {
    name: '对象模型'
  },
  42: {
    name: 'SMB'
  },
  43: {
    name: 'HDFS'
  },
  44: {
    name: 'FTP'
  },
  61: {
    name: 'ODS'
  },
  62: {
    name: '数仓DWD模型'
  },
  51: {
    name: 'Kafka'
  },
  52: {
    name: 'MQTT'
  },
  53: {
    name: 'RocketMQ'
  }
};

// 为了和原先数据结构保持一致
const defaultMenuConfig: any = {
  points: { in: [{ type: 'data' }], out: [{ type: 'data' }] }
};

export const modulesMenu: any[] = [
  {
    name: '数据输入',
    alias: 'DataIn',
    children: [
      {
        name: '数据输入',
        alias: 'DataInputModule',
        defaultConfig: defaultMenuConfig,
        pointType: 'start',
        maxOutput: 100,
        maxInput: 1,
        description:
          '数据来源组件，支持从关系型数据源、supOS实例、文件数据源、API数据源接入数据，也支持通过SQL抽取数据'
      },
      {
        name: '消息队列输入',
        alias: 'DataInputModule',
        subAlias: 'MsgQueueInputModule',
        defaultConfig: defaultMenuConfig,
        pointType: 'start',
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持读取消息队列中的数据，将消息数据映射成一张虚拟的"二维表”，供下游算子处理，支持Kafka、RocketMQ两种 '
      }
    ]
  },
  {
    name: '数据输出',
    alias: 'DataOut',
    children: [
      {
        name: '数据输出',
        alias: 'DataOutputModule',
        defaultConfig: {
          points: {
            in: [{ type: 'data' }]
          }
        },
        maxOutput: 100,
        maxInput: 1,
        description:
          '将处理后的数据输出到关系型数据源、supOS实例、文件数据源、API数据源中'
      },
      {
        name: '消息队列输出',
        alias: 'DataOutputModule',
        subAlias: 'MsgQueueOutputModule',
        defaultConfig: {
          points: {
            in: [{ type: 'data' }]
          }
        },
        maxOutput: 0,
        maxInput: 1,
        description:
          '支持将处理后的数据发送到消息队列，支持Kafka、MQTT、RocketMQ三种'
      },
      !isWin && {
        name: 'HBASE输出',
        alias: 'DataOutputModule',
        subAlias: 'HBASEOutputModule',
        defaultConfig: {
          points: {
            in: [{ type: 'data' }]
          }
        },
        maxOutput: 0,
        maxInput: 1,
        description: '将处理后的数据输出到HABSE数据源中'
      }
    ].filter(Boolean)
  },
  {
    name: '数据处理',
    alias: 'DataClean',
    children: [
      {
        name: '数据质量',
        alias: 'DataQualityModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持数据质量检测，支持按照一定策略检测数据，对错误记录执行丢弃、忽略、修复等操作'
      },
      {
        name: 'SQL执行',
        alias: 'SqlScriptModule',
        defaultConfig: defaultMenuConfig,
        pointType: 'start',
        maxOutput: 100,
        maxInput: 1,
        description:
          '通过编写SQL语句实现对关系型数据源的增删改查等操作，实现对目标数据的操作'
      },
      {
        name: '数据集',
        alias: 'DataSampleModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description: '通过修改数据字段的字段名和描述信息实现数据结构的重新定义'
      },
      {
        name: '数据过滤',
        alias: 'DataFilterModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '对若干个数据字段设置过滤条件，支持字段按照常量、变量进行过滤，类似数据库的where条件'
      },
      {
        name: '数据连接',
        alias: 'DataJoinModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 100,
        description:
          '利用内联、左联、右连、全连的方式对多个数据库表进行连接，支持跨源数据库的表连接'
      },
      {
        name: '数据排序',
        alias: 'DataSortModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持对指定字段升序或降序，实现数据的重新排列。若指定多个字段进行排序，则按先后顺序排优先级'
      },
      {
        name: '数据合并',
        alias: 'MergeModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 100,
        description: '支持对多个表的数据按列合并，组成新表'
      },
      {
        name: '缺失值处理',
        alias: 'MissingValueFillModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持以最大值、最小值、平均值、常量、变量、拟合、自定义公式对数据中的NULL值和空字符串进行填充'
      },
      {
        name: '数据类型转换',
        alias: 'DataTypeConversionModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持对数值型、布尔型、字符型和日期型相互转换，同时支持字符串处理、字符替换、数据替换、字段处理等操作'
      },
      {
        name: '数据补齐',
        alias: 'DataFillModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '补齐时间上不连续的数据，获得连续、完整的数据，减小后续数据处理的难度'
      },
      {
        name: '变量设置',
        alias: 'VariableSetModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description: '对已初始化的变量重新赋值，主要用于数据增量同步场景'
      },
      {
        name: '数据聚合',
        alias: 'AggregationModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持对数据进行各种聚合运算，包括求和、最大值、最小值、平均值'
      },
      {
        name: '表转置',
        alias: 'TableTransposeModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 100,
        maxInput: 1,
        description:
          '支持对关系型数据源和文件数据进行表转置，即改变表的横纵方向，处理后的数据结果只能输出到文件中'
      },
      {
        name: '自定义算子',
        alias: 'CustomModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 1,
        maxInput: 1,
        description:
          '通过编写脚本实现对数据源的自定义提取与分析，使得数据处理更加灵活'
      }
    ]
  },
  !isWin && {
    name: '大数据模型',
    alias: 'BigDataModel',
    children: [
      {
        name: '模型运行',
        alias: 'BigDataModelRuntimeModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 1,
        maxInput: 1,
        description:
          '支持将supBD算法模型编排在任务中，接入外部数据作为模型运算数据来源，支持将模型运行的结果输出到对象模型在内的各类数据源中'
      },
      {
        name: '模型更新',
        alias: 'BigDataModelUpdateModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 1,
        maxInput: 1,
        description: '提供supBD算法模型的在线更新服务'
      }
    ]
  },
  {
    name: '过程控制',
    alias: 'ProcessControl',
    children: [
      {
        name: '分支任务',
        alias: 'BranchModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 5,
        maxInput: 1,
        description:
          '分支任务中算子根据设置的分支条件表达式将数据过滤、分流到至多5个的下游算子，其中条件表达式可由函数、变量、字段生成，以此根据不同的数据特征进行不同的数据处理'
      }
    ]
  },
  {
    name: '安全脱敏',
    alias: 'Desensitization',
    children: [
      {
        name: '数据脱敏',
        alias: 'DataMaskModule',
        defaultConfig: defaultMenuConfig,
        maxOutput: 5,
        maxInput: 1,
        description:
          '通过数据模糊处理对若干字段进行脱敏，支持选定脱敏字段的起始位置和长度，脱敏后的数据将覆盖原数据并流转到下游算子。'
      }
    ]
  }
].filter(Boolean);

const moduleNameMap: {
  [key: string]: string;
} = {};

const getModuleNameMap = () => {
  _.forEach(modulesMenu, (menu: any) => {
    _.forEach(menu.children, (menuItem: any) => {
      moduleNameMap[menuItem.subAlias || menuItem.alias] = menuItem.name;
    });
  });
};
getModuleNameMap();
export const moduleNameMapping = moduleNameMap;

export const taskTypes = [
  { value: 3, name: '数据加工' },
  { value: 1, name: '数据同步' },
  { value: 2, name: '数据清洗' }
];
