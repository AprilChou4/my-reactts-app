import http from '@services/http';
import { TASK_URL } from '@config/env';

//开发/已发布任务统计**
export function getTaskList(): Promise<any> {
  return http.get(`${TASK_URL}/panel/tasksByType`);
}

// 已发布任务的运行/停止统计**
export function getTaskStatus(): Promise<any> {
  return http.get(`${TASK_URL}/panel/tasksByState`);
}

//已发布任务执行成功/失败统计**
export function getTaskResult(): Promise<any> {
  return http.get(`${TASK_URL}/panel/tasksByExecState`);
}

//已发布任务按时刻执行次数统计**
export function getTasksExecRate(): Promise<any> {
  return http.get(`${TASK_URL}/panel/tasksExecRate`);
}

//已发布任务按时刻执行次数统计**
export function getTasksFailedlist(params: any): Promise<any> {
  return http.post(`${TASK_URL}/panel/tasksFailedlist`, params);
}

export function getTasksNum(): Promise<any> {
  return http.get(`${TASK_URL}/panel/taskExecCase`);
}
