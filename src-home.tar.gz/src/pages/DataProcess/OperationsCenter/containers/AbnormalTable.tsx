import React, { Component } from 'react';
import { Table, message } from 'sup-ui';
import { getTasksFailedlist } from '../operations.service';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import styles from './AbnormalTable.less';
interface IProps {}

class AbnormalTable extends Component<IProps> {
  public interval: any;

  public state = {
    tablePage: {
      pageNum: 1,
      pageSize: 10
    },
    total: {
      current: 1,
      pageSize: 10,
      total: 0
    },
    dataSource: []
  };

  public handlePageChange = (value: any) => {
    this.setState(
      {
        tablePage: {
          pageNum: value,
          pageSize: 10
        }
      },
      () => {
        this.getTasksFailedlist();
      }
    );
  };

  public getTasksFailedlist = async () => {
    const res = await getTasksFailedlist(this.state.tablePage);

    if (res.code !== 200) {
      message.error(res.message);
      return;
    }

    this.setState({
      total: res.pagination,
      dataSource: res.list
    });
  };

  public componentDidMount() {
    this.getTasksFailedlist();

    this.interval = setInterval(() => {
      this.getTasksFailedlist();
    }, 60000);
  }

  public componentWillUnmount() {
    clearInterval(this.interval);
  }

  public render() {
    const { total, dataSource } = this.state;

    const columns: any = [
      {
        key: 'sequence',
        dataIndex: 'sequence',
        title: '序号',
        align: 'center',
        width: 60,
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      },
      {
        key: 'taskName',
        dataIndex: 'taskName',
        title: '任务名称',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      },
      {
        key: 'execTime',
        dataIndex: 'execTime',
        title: '执行时间',
        width: 150,
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      },
      {
        key: 'execCondition',
        dataIndex: 'execCondition',
        title: '执行失败原因',
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      }
    ];

    return (
      <div className={styles.abnormalContainer}>
        <header className={styles.abnormalTitle}>运行任务异常追踪</header>
        <Table
          columns={columns}
          dataSource={dataSource}
          scroll={{ x: 500, y: 'calc(100vh - 31px)' }}
          pagination={{
            ...total,
            showTotal: (count: number) => `共${count}条`,
            itemRender: CustomPaging,
            hideOnSinglePage: true,
            onChange: this.handlePageChange
          }}
          rowKey="sequence"
        />
      </div>
    );
  }
}

export default AbnormalTable;
