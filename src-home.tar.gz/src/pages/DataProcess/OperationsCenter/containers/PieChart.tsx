import React, { Component } from 'react';
import { message, Divider } from 'sup-ui';

import Highcharts from 'highcharts';

import { getTaskResult } from '../operations.service';

import styles from './Operation.less';

interface IProps {}

interface IState {
  taskNum: {
    tasksSuccess: number;
    tasksFail: number;
  };
}

class PieChart extends Component<IProps, IState> {
  public interval: any;
  public chart: any;
  public container: any;

  public state = {
    taskNum: {
      tasksSuccess: 0,
      tasksFail: 0
    }
  };

  public options = {
    title: {
      text: null
    },
    tooltip: {
      headerFormat: '{series.name}<br>',
      pointFormat: '{point.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
      pie: {},
      series: {
        dataLabels: {
          enabled: false
        }
      }
    },
    series: [
      {
        type: 'pie',
        innerSize: '60%',
        allowPointSelect: true,
        showInLegend: false,
        data: [
          {
            name: '成功',
            y: this.state.taskNum.tasksSuccess,
            color: '#0263ff'
          },
          {
            name: '失败',
            y: this.state.taskNum.tasksFail,
            color: '#ff5d5d'
          }
        ]
      }
    ],
    credits: {
      //去除版权信息
      enabled: false
    }
  };

  public getTaskResult = async () => {
    const res = await getTaskResult();

    const { code, data } = res;

    if (code !== 200) {
      message.error(res.message);
      return;
    }

    this.setState({
      taskNum: data
    });

    const item = [
      {
        name: '成功',
        y: data.tasksSuccess,
        color: '#0263ff'
      },
      {
        name: '失败',
        y: data.tasksFail,
        color: '#ff5d5d'
      }
    ];

    this.chart.series[0].setData(item);
  };

  public componentDidMount() {
    this.chart = Highcharts.chart(this.container, this.options);

    this.getTaskResult();

    this.interval = setInterval(() => {
      this.getTaskResult();
    }, 300000);
  }

  public componentWillUnmount() {
    clearInterval(this.interval);
  }

  public render() {
    const { taskNum } = this.state;

    return (
      <div className={styles.container}>
        <div className={styles.chartTitle}>
          <div className={styles.chartHeader}>任务执行结果分布</div>
          <div
            className={styles.picChartSvg}
            ref={ref => (this.container = ref)}
          />
        </div>
        <div className={styles.chartsContent}>
          <div className={styles.pieSuccess}>
            <div className={styles.chartsNumber}>{taskNum.tasksSuccess}</div>
            <div className={styles.chartsText}>
              <span />
              成功
            </div>
          </div>
          <Divider type="vertical" />
          <div className={styles.pieError}>
            <div className={styles.chartsNumber}>{taskNum.tasksFail}</div>
            <div className={styles.chartsText}>
              <span />
              失败
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default PieChart;
