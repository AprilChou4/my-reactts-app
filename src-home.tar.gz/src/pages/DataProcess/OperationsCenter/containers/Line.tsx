import React, { Component, Fragment } from 'react';
import { message } from 'sup-ui';

import Highcharts from 'highcharts';
import HighchartsMore from 'highcharts/highcharts-more';

import { getTasksExecRate } from '../operations.service';

import styles from './Operation.less';

HighchartsMore(Highcharts);

interface IProps {}

class Line extends Component<IProps> {
  public interval: any;
  public chart: any;
  public container: any;
  public options = {
    chart: {
      type: 'spline'
    },
    title: {
      text: '任务执行趋势',
      align: 'left',
      x: -10,
      style: {
        fontSize: '14px',
        fontWeight: 600,
        color: '#3b4859'
      }
    },
    xAxis: {
      categories: []
    },
    yAxis: {
      title: {
        text: '次数'
      }
    },
    tooltip: {
      crosshairs: true,
      shared: true
    },
    plotOptions: {
      spline: {
        marker: {
          radius: 4,
          lineWidth: 1
        },

        lineWidth: 4,
        states: {
          hover: {
            lineWidth: 5
          }
        }
      },
      series: {
        color: '#0364FF'
      }
    },
    series: [
      {
        name: '每小时累计执行任务次数',
        marker: {
          symbol: 'square'
        },
        data: []
      }
    ],
    lineWidth: 2,

    credits: {
      //去除版权信息
      enabled: false
    }
  };

  public state = {
    maskVisible: false
  };

  public getTasksExecRate = async () => {
    const res = await getTasksExecRate();

    const { code, data } = res;

    if (code !== 200) {
      message.error(res.message);
      return;
    }

    const highChartY: any[] = [];
    const highChartX: any[] = [];

    if (!data.listVO.length) {
      this.setState({
        maskVisible: true
      });
    }

    _.forEach(data.listVO, (item: any) => {
      highChartY.push(item.tasks);
      highChartX.push(item.hours);
    });

    this.chart.series[0].setData(highChartY);
    this.chart.xAxis[0].update({
      categories: highChartX
    });
  };

  public componentDidMount() {
    this.chart = Highcharts.chart(this.container, this.options);

    this.getTasksExecRate();

    this.interval = setInterval(() => {
      this.getTasksExecRate();
    }, 3600000);
  }

  public componentWillUnmount() {
    clearInterval(this.interval);
  }

  public render() {
    const { maskVisible } = this.state;

    return (
      <Fragment>
        <div
          className={styles.container}
          style={{ height: '100%' }}
          ref={ref => (this.container = ref)}
        />
        <div className={maskVisible ? styles.mask : styles.none}>
          <div className={styles.dataMask}>
            <div className={styles.noData} />
            <div className={styles.description}>暂无数据</div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Line;
