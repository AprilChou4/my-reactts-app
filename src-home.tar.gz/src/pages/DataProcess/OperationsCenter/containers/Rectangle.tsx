import React, { Component } from 'react';
import { message, Divider } from 'sup-ui';

import { TableCellText } from '@components/Table';

import { getTaskList } from '../operations.service';

import styles from './Operation.less';

interface IProps {}

class Rectangle extends Component<IProps> {
  public interval: any;
  public state = {
    taskNum: {
      developerTasks: 0,
      releaseTasks: 0
    }
  };

  public getTaskList = async () => {
    const res = await getTaskList();
    const { code, data } = res;
    if (code === 200) {
      this.setState({
        taskNum: data
      });

      return;
    }

    message.error(res.message);
  };

  public componentDidMount() {
    this.getTaskList();

    this.interval = setInterval(() => {
      this.getTaskList();
    }, 300000);
  }

  public componentWillUnmount() {
    clearInterval(this.interval);
  }

  public render() {
    const { taskNum } = this.state;

    return (
      <div className={`${styles.container} ${styles.rectContainer}`}>
        <div className={styles.chartHeader}>
          <TableCellText text={`任务开发&任务运维分布`} />
        </div>

        <div className={styles.rectContent}>
          <div className={styles.rectTask}>
            <div className={styles.chartsText}>任务开发</div>
            <div className={styles.chartsNumber}>
              {_.get(taskNum, 'developerTasks', 0)}
            </div>
          </div>
          <Divider type="vertical" className={styles.vertical} />
          <div className={styles.rectRel}>
            <div className={styles.chartsText}>任务运维</div>
            <div className={styles.chartsNumber}>
              {_.get(taskNum, 'releaseTasks', 0)}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Rectangle;
