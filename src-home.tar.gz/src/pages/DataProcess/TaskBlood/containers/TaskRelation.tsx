import React, { Component } from 'react';
import * as echarts from 'echarts';
import { observer, inject } from 'mobx-react';
import { Button, Spin } from 'sup-ui';

import Header from '@components/Header';
import CanvasToolBar from '@components/CanvasToolBar';
import KeywordSearch from '@components/KeywordSearch';
import {
  nodeTooltip,
  edgeTooltip,
  formatterNodeInfo,
  extraEllipsis
} from '../blood.helper';
import { bloodStyle } from '../taskBlood.const';
import Icon from '@components/Icon';
import RelationTabs from '../component/RelationTabs';
import styles from '../index.less';

interface IProps {
  global?: any;
  bloodStore?: any;
}

interface IState {
  searchValue: string;
  sideDrawer: boolean;
  sourceList: any[];
  taskList: any[];
  selectedItem: any;
}

@inject('global', 'bloodStore')
@observer
class TaskRelation extends Component<IProps, IState> {
  private pointId2NodeId: any;
  private nodeId2Info: any;
  private chartRef: any;
  private chart: any;
  private renderChartFn: any;
  public constructor(props: IProps) {
    super(props);
    this.state = {
      searchValue: '',
      sideDrawer: true,
      sourceList: [],
      taskList: [],
      selectedItem: null
    };
    this.pointId2NodeId = {};
    this.nodeId2Info = {};
    this.renderChartFn = _.debounce(this.renderChart, 600);
  }

  public componentDidMount() {
    this.chart = echarts.init(this.chartRef);
    const options = {
      ...bloodStyle.defaultConfig,
      series: [
        {
          ...bloodStyle.defaultSeriesConfig,
          nodes: [],
          links: []
        }
      ]
    };
    this.chart.setOption(options);
    this.renderChart();
  }

  public componentWillUnmount() {
    this.chart.dispose();
  }

  private init = () => {
    this.setState(
      {
        searchValue: ''
      },
      () => {
        this.renderChart();
      }
    );
  };

  private renderChart = () => {
    const nodes = this.getNodes();
    const links = this.getLinks();
    this.setState({
      sourceList: nodes,
      taskList: links
    });
    const options = this.chart.getOption();
    options.series[0].nodes = nodes;
    options.series[0].links = links;
    if (nodes.length > 10) options.series[0].zoom = 0.8;
    if (nodes.length > 15) options.series[0].zoom = 0.6;
    if (nodes.length > 22) options.series[0].zoom = 0.5;
    this.chart.on('dblclick', { dataType: 'node' }, (node: any) => {
      const { id } = node.data;
      const targetNodePoint = _.findKey(this.pointId2NodeId, v => v === id);
      if (!_.isNil(targetNodePoint)) {
        this.props.bloodStore.changeViewType(targetNodePoint);
      }
    });
    this.chart.on('mouseover', () => {
      if (this.state.selectedItem !== null) {
        this.setState({ selectedItem: null });
      }
    });
    this.chart.setOption(options);
  };

  private getNodes = () => {
    const { inSupos } = this.props.global;
    const { hasMetaData, points, edges } = this.props.bloodStore;
    const { searchValue } = this.state;
    const nodes: any[] = [];
    _.forEach(points, item => {
      const nodeInfo = formatterNodeInfo(item.sourceInfo);
      const { nodeId, nodeName } = nodeInfo;
      this.pointId2NodeId[item.pointId] = nodeId;
      this.nodeId2Info[nodeId] = nodeInfo;
      if (_.includes(nodeName, searchValue)) {
        nodes.push({
          id: nodeId,
          name: extraEllipsis(nodeName),
          itemStyle: bloodStyle.nodeItemStyle,
          emphasis: {
            itemStyle: {
              ...bloodStyle.nodeActiveStyle
            }
          },
          tooltip: {
            position: 'bottom',
            formatter: nodeTooltip(nodeInfo.sourceInfo, hasMetaData, inSupos)
          }
        });
      }
    });
    _.forEach(edges, edgeItem => {
      const { taskName, nextPointId, prePointId } = edgeItem;
      if (_.includes(taskName, searchValue)) {
        const nextId = this.pointId2NodeId[nextPointId];
        const nextNodeInfo = _.get(this.nodeId2Info, nextId, {});
        const preId = this.pointId2NodeId[prePointId];
        const preNodeInfo = _.get(this.nodeId2Info, preId, {});
        nodes.push(
          {
            id: nextId,
            name: nextNodeInfo.name,
            itemStyle: bloodStyle.nodeItemStyle,
            emphasis: {
              itemStyle: {
                ...bloodStyle.nodeActiveStyle
              }
            },
            tooltip: {
              position: 'bottom',
              formatter: nodeTooltip(
                nextNodeInfo.sourceInfo,
                hasMetaData,
                inSupos
              )
            }
          },
          {
            id: preId,
            name: preNodeInfo.name,
            itemStyle: bloodStyle.nodeItemStyle,
            emphasis: {
              itemStyle: {
                ...bloodStyle.nodeActiveStyle
              }
            },
            tooltip: {
              position: 'bottom',
              formatter: nodeTooltip(
                preNodeInfo.sourceInfo,
                hasMetaData,
                inSupos
              )
            }
          }
        );
      }
    });
    return _.unionBy(nodes, 'id');
  };

  private getLinks = () => {
    const { edges } = this.props.bloodStore;
    const { searchValue } = this.state;
    const edgeCount: any = {};
    const links: any[] = [];
    _.forEach(edges, item => {
      if (_.includes(item.taskName, searchValue)) {
        const source = `${this.pointId2NodeId[item.prePointId]}`;
        const target = `${this.pointId2NodeId[item.nextPointId]}`;
        const countId = [source, target].sort().join('-');
        edgeCount[countId] = _.isNil(edgeCount[countId])
          ? 0
          : edgeCount[countId] + 1;
        const curveness =
          0.3 *
          Math.ceil(edgeCount[countId] / 2) *
          (edgeCount[countId] % 2 === 0 ? -1 : 1);
        links.push({
          taskId: item.taskId,
          source,
          target,
          taskName: extraEllipsis(`${item.taskName}`),
          lineStyle: {
            normal: {
              ...bloodStyle.lineNormalStyle,
              curveness
            }
          },
          emphasis: {
            itemStyle: {
              ...bloodStyle.lineActiveStyle
            }
          },
          tooltip: {
            position: 'bottom',
            formatter: () => {
              const sourceName = _.get(
                this.nodeId2Info,
                [source, 'nodeName'],
                ''
              );
              const targetName = _.get(
                this.nodeId2Info,
                [target, 'nodeName'],
                ''
              );
              return edgeTooltip({
                taskName: item.taskName,
                taskId: item.taskId,
                sourceName,
                targetName
              });
            }
          }
        });
      }
    });
    return links;
  };

  private handleSearch = (value: string) => {
    this.setState({
      searchValue: value
    });
    this.renderChartFn();
  };

  private handleZoomIn = () => {
    const options = this.chart.getOption();
    const zoom = options.series[0].zoom;
    if (zoom < 5) {
      options.series[0].zoom += 0.2;
      this.chart.setOption(options);
    }
  };

  private handleZoomOut = () => {
    const options = this.chart.getOption();
    const zoom = options.series[0].zoom;
    if (zoom > 0.5) {
      options.series[0].zoom -= 0.2;
      this.chart.setOption(options);
    }
  };

  private handleToggleMovable = (removable: boolean) => {
    const options = this.chart.getOption();
    if (removable) {
      options.series[0].roam = true;
    } else {
      options.series[0].roam = 'scale';
    }
    this.chart.setOption(options);
  };

  private handleCollapse = () => {
    this.setState({ sideDrawer: false });
    setTimeout(() => {
      this.chart.resize();
    });
  };
  private handleExpand = () => {
    this.setState({ sideDrawer: true });
    setTimeout(() => {
      this.chart.resize();
    });
  };
  private handleSelectChange = (param: any) => {
    this.setState({
      selectedItem: param
    });
    if (param?.id) {
      //选中数据源
      const dataIndex = this.state.sourceList.findIndex(
        item => item.id === param?.id
      );
      const options = this.chart.getOption();
      if (Array.isArray(options.series[0].nodes)) {
        options.series[0].nodes.forEach((item: any, index: number) => {
          if (index === dataIndex) {
            item.x = +(this.chart.getWidth() / 2).toFixed();
            item.y = +(this.chart.getHeight() / 2).toFixed();
          } else {
            delete item.x;
            delete item.y;
          }
        });
      }

      this.chart.setOption(options);

      this.chart.dispatchAction({
        type: 'highlight',
        dataIndex
      });
    } else {
      //选中任务
      const taskndex = this.state.taskList.findIndex(
        item => item.taskId === param?.taskId
      );
      const dataIndex = this.state.sourceList.findIndex(
        item => item.id === this.state.taskList[taskndex].source
      );
      const options = this.chart.getOption();
      if (Array.isArray(options.series[0].nodes)) {
        options.series[0].nodes.forEach((item: any, index: number) => {
          if (index === dataIndex) {
            item.x = +(this.chart.getWidth() / 2).toFixed();
            item.y = +(this.chart.getHeight() / 2).toFixed();
          } else {
            delete item.x;
            delete item.y;
          }
        });
      }

      this.chart.setOption(options);
      this.chart.dispatchAction({
        type: 'highlight',
        dataIndex
      });
    }
  };
  private handleSelectClear = () => {
    const selected = this.state.selectedItem;
    if (this.state.selectedItem) {
      if (selected?.id) {
        //选中数据源
        const dataIndex = this.state.sourceList.findIndex(
          item => item.id === selected?.id
        );
        this.chart.dispatchAction({
          type: 'downplay',
          dataIndex
        });
      } else {
        //选中任务
        const taskndex = this.state.taskList.findIndex(
          item => item.taskId === selected?.taskId
        );
        const dataIndex = this.state.sourceList.findIndex(
          item => item.id === this.state.taskList[taskndex].source
        );
        this.chart.dispatchAction({
          type: 'downplay',
          dataIndex
        });
      }
      this.setState({ selectedItem: null });
    }
  };
  public render() {
    const { sideDrawer } = this.state;
    const { loading, taskName } = this.props.bloodStore;
    const title = `${taskName ? `${taskName}-` : ''}数据血缘`;
    return (
      <div className={styles.wrapper}>
        <Header
          left={title}
          right={
            <div className={styles.search}>
              <KeywordSearch
                size="large"
                placeholder="请输入关键字搜索"
                disabled={loading}
                value={this.state.searchValue}
                onSearch={this.handleSearch}
              />
              <Button ghost disabled={loading} size="large" onClick={this.init}>
                初始化
              </Button>
            </div>
          }
        />
        <div className={styles.relationcontent}>
          <div className={styles.relationcontainer}>
            <Spin spinning={loading} />
            <div
              className={styles.relationeditorWrapper}
              ref={ref => {
                this.chartRef = ref;
              }}
            />
            <CanvasToolBar
              onZoomIn={this.handleZoomIn}
              onZoomOut={this.handleZoomOut}
              toggleMovable={this.handleToggleMovable}
            />
          </div>
          {sideDrawer ? (
            <div className={styles.sideExpand}>
              <div className={styles.sideExpandTabs}>
                <RelationTabs
                  datasourceList={this.state.sourceList}
                  taskList={this.state.taskList}
                  selected={this.state.selectedItem}
                  onChange={this.handleSelectChange}
                  onClear={this.handleSelectClear}
                />
              </div>
              <div
                style={{
                  flexBasis: '20px',
                  height: '20px',
                  paddingLeft: '12px'
                }}
                onClick={this.handleCollapse}
              >
                <Icon type="collapse" width={16} height={16} />
              </div>
            </div>
          ) : (
            <div className={styles.sideCollapse} onClick={this.handleExpand}>
              <Icon
                type="comment"
                fill="#354052"
                width={16}
                height={16}
                style={{ position: 'absolute', top: '5px', right: '10px' }}
              />
              <Icon
                type="expand"
                width={16}
                height={16}
                style={{ position: 'absolute', bottom: '5px', right: '10px' }}
              />
            </div>
          )}
        </div>
      </div>
    );
  }
}

export default TaskRelation;
