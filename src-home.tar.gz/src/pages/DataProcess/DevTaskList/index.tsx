import React, { Component, Fragment } from 'react';
import { inject, observer, Provider } from 'mobx-react';
import { RouteComponentProps } from 'react-router-dom';
import ListHeader from './containers/ListHeader';
import ListTable from './containers/ListTable';
import TaskForm from './containers/TaskForm';
import Catalogue from '../Catalogue';
import DevStore from './stores/dev.store';
import styles from './index.less';

interface IProps extends RouteComponentProps {
  global?: any;
}
interface IState {}

@inject('global')
@observer
class DevTaskList extends Component<IProps, IState> {
  private readonly store: DevStore;
  public constructor(props: IProps) {
    super(props);
    this.store = new DevStore(props.global, props.history);
  }

  public render() {
    const { history } = this.props;
    const {
      handleCatalogueChange,
      updateCatalogueList,
      selectedCatalogue,
      formModalVisible
    } = this.store;

    return (
      <Provider store={this.store}>
        <div className={styles.wrapper}>
          <div className={styles.sider}>
            <Catalogue
              type="dev"
              readOnly={false}
              history={history}
              onChange={handleCatalogueChange}
              updateCatalogue={updateCatalogueList}
            />
          </div>
          <div className={styles.container}>
            {_.isEmpty(selectedCatalogue) ? (
              <div className={styles.noCont}>
                <p>请选择左侧目录</p>
              </div>
            ) : (
              <Fragment>
                <ListHeader />
                <ListTable />
              </Fragment>
            )}
          </div>
          {formModalVisible && <TaskForm />}
        </div>
      </Provider>
    );
  }
}

export default DevTaskList;
