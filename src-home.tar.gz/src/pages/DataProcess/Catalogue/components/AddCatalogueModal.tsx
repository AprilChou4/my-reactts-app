import React, { FunctionComponent } from 'react';
import { Form, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import DialogModal from '@components/Modal/Dialog';
import CatalogSelect from '../../components/CatalogSelect';
const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  loading: boolean;
  values: any;
  catalog: any[];
  onOk: (params: any) => void;
  onCancel: () => void;
}

const CatalogueModal: FunctionComponent<IProps> = (props: IProps) => {
  const { loading, values, catalog, onCancel, form, onOk } = props;
  const isEdit = !_.isEmpty(values);
  const handleOK = () => {
    form.validateFields((error: any, formValues: any) => {
      if (error) return;
      const name = formValues.name;
      let { parentId } = formValues;
      parentId = parentId === 'root' ? '' : parentId;
      if (_.isEmpty(values)) {
        onOk({
          name,
          parentId
        });
      } else {
        if (parentId !== values.parentId) {
          const params = {
            folderId: values.id,
            move: true,
            name,
            pos: 3,
            targetFolderId: parentId
          };
          onOk(params);
        } else {
          const params = {
            folderId: values.id,
            move: false,
            name
          };
          onOk(params);
        }
      }
    });
  };

  const initParentId = _.get(values, 'parentId', 'root');

  return (
    <DialogModal
      width={460}
      title={isEdit ? '编辑目录' : '新增目录'}
      bodyStyle={{ padding: '20px 30px 6px' }}
      visible
      loading={loading}
      maskClosable={false}
      onOk={handleOK}
      onCancel={onCancel}
    >
      <Form>
        <FormItem label="文件夹名称" colon={false}>
          {form.getFieldDecorator('name', {
            initialValue: values.name,
            rules: [
              { required: true, message: `请输入目录名称` },
              { max: 50, message: `目录名称长度不能超过50!` }
            ]
          })(<Input size="large" placeholder="请输入目录名称" />)}
        </FormItem>
        <CatalogSelect
          formKey="parentId"
          required
          label="上级文件夹"
          catalog={[
            {
              id: 'root',
              name: '根目录',
              folders: catalog
            }
          ]}
          initialValue={initParentId || 'root'}
          disabledItem={values.id}
          getFieldDecorator={form.getFieldDecorator}
        />
      </Form>
    </DialogModal>
  );
};

export default Form.create<IProps>({
  name: 'CatalogueModal'
})(CatalogueModal);
