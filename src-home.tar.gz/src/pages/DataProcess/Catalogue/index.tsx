import React, { Component } from 'react';
import { Spin, Tree, Empty, Input } from 'sup-ui';
import { observer, inject } from 'mobx-react';
import classnames from 'classnames';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import CatalogueModal from './components/AddCatalogueModal';
import CatalogueStore from './stores/catalogue.store';
import styles from './index.less';

const { TreeNode, DirectoryTree } = Tree;

interface IProps {
  global?: any;
  history: any;
  onChange: any;
  updateCatalogue?: any; //传出树结构
  type: 'dev' | 'release';
  readOnly?: boolean;
}
interface IState {
  expandedKeys: any[];
  inputValue: string;
}

@inject('global')
@observer
class Catalogue extends Component<IProps, IState> {
  private containerRef: any;
  private readonly handleSearch: any;
  private readonly store: CatalogueStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new CatalogueStore(
      props.global,
      props.type,
      props.history,
      props.onChange,
      props.updateCatalogue
    );
    this.state = {
      expandedKeys: [],
      inputValue: ''
    };

    this.handleSearch = _.debounce(this.store.handleSearch, 500);
  }

  private handleInputChange = (e: any) => {
    const inputValue = e.target.value;

    this.setState({
      inputValue
    });

    this.handleSearch(inputValue);
  };

  private handleAddDir = () => {
    this.store.changeModalVisible(true);
  };

  private deleteNode = (e: any, item: any) => {
    e.stopPropagation();

    const { deleteNode } = this.store;
    const config = {
      title: '提示',
      content: `确定删除 ${item.name} 目录？`,
      onOk: () => {
        deleteNode(item);
      }
    };

    TipsDelete(config);
  };

  //自定义节点title
  private treeTitle = (item: any) => {
    const { editNode } = this.store;
    const { readOnly } = this.props;

    return (
      <div className={styles.customerTitle}>
        <div className={styles.edit}>
          <span title={item.name}>{item.name}</span>
        </div>
        {!readOnly && (
          <div className="operator">
            <Icon
              onClick={(e: any) => {
                e.stopPropagation();
                editNode(item);
              }}
              type="edit"
              fill="white"
              height={24}
              width={20}
            />
            <Icon
              onClick={(e: any) => {
                this.deleteNode(e, item);
              }}
              type="remove"
              fill="white"
              height={24}
              width={20}
            />
          </div>
        )}
      </div>
    );
  };

  //递归节点树结构
  private loopTreeNode = (data: any) => {
    return data.map((item: any) => {
      if (item.folders) {
        return (
          <TreeNode
            key={item.id}
            dataRef={item}
            title={this.treeTitle(item)}
            selectable={item.selectable}
          >
            {this.loopTreeNode(item.folders)}
          </TreeNode>
        );
      }
      return (
        <TreeNode
          key={item.id}
          isLeaf={item.isLeaf}
          selectable
          title={this.treeTitle(item)}
          dataRef={item}
        />
      );
    });
  };

  private handleDrop = (info: any) => {
    const { moveNode } = this.store;
    const { eventKey: dragId } = info.dragNode.props;
    const {
      eventKey: dropId,
      dataRef,
      dragOverGapTop,
      dragOverGapBottom
    } = info.node.props;
    let params: any;

    if (dragOverGapTop) {
      params = {
        pos: 1,
        targetFolderId: dataRef.parentId,
        childFolderId: dropId
      };
    } else if (dragOverGapBottom) {
      params = {
        pos: 2,
        targetFolderId: dataRef.parentId,
        childFolderId: dropId
      };
    } else if (dragOverGapTop === false && dragOverGapBottom === false) {
      params = {
        pos: 3,
        targetFolderId: dropId
      };
    } else {
      return;
    }

    params.folderId = dragId;

    moveNode(params);
  };

  public componentDidMount() {
    this.store.getDefaultTreeNodes(true);
    this.store.bindTreeDirectoryRef(this.containerRef);
  }

  public render() {
    const {
      changeModalVisible,
      formData,
      loading,
      visible,
      modifyCatalogue,
      searchValue,
      treeLoading,
      treeData,
      fuzzyData,
      selectedKeys,
      selectedItem,
      expandedKeys,
      updateExpandedKeys,
      handleTreeNodeSelect,
      handleSelectAll
    } = this.store;
    const { readOnly } = this.props;
    const { inputValue } = this.state;
    const catalog = searchValue ? fuzzyData : treeData;

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <p>任务目录</p>
          {!readOnly && <Icon primary type="add" onClick={this.handleAddDir} />}
        </div>
        <div className={styles.treeContainer}>
          <Input
            className={styles.searchBox}
            value={inputValue}
            placeholder="请输入目录名搜索"
            onChange={this.handleInputChange}
          />
          <div
            className={styles.directoryTree}
            ref={ref => (this.containerRef = ref)}
          >
            <Spin spinning={treeLoading}>
              <div
                className={classnames(
                  styles.all,
                  selectedItem === 'all' && styles.allChecked
                )}
                onClick={handleSelectAll}
              >
                全部
              </div>
              {!_.isEmpty(catalog) ? (
                <DirectoryTree
                  expandAction={false}
                  selectedKeys={selectedKeys}
                  onSelect={handleTreeNodeSelect}
                  autoExpandParent
                  expandedKeys={expandedKeys}
                  onExpand={updateExpandedKeys}
                  draggable={!readOnly}
                  onDrop={this.handleDrop}
                >
                  {this.loopTreeNode(catalog)}
                </DirectoryTree>
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </Spin>
          </div>
        </div>
        {visible && (
          <CatalogueModal
            loading={loading}
            values={formData}
            catalog={treeData}
            onOk={modifyCatalogue}
            onCancel={() => {
              changeModalVisible(false);
            }}
          />
        )}
      </div>
    );
  }
}

export default Catalogue;
