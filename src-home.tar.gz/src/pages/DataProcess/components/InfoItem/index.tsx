import React, { FunctionComponent, ReactNode } from 'react';

import styles from './index.less';

interface IProps {
  label: string;
  value: string | ReactNode;
}

const InfoItem: FunctionComponent<IProps> = (props: IProps) => {
  return (
    <div className={styles.wrapper}>
      <label className={styles.label}>{props.label}：</label>
      <span className={styles.value}>{props.value}</span>
    </div>
  );
};

export default InfoItem;
