import React, { FunctionComponent } from 'react';
import { Form, Select } from 'sup-ui';

import { taskTypes } from '../devTask.const';
const FormItem = Form.Item;
const { Option } = Select;
interface IProps {
  formKey: string;
  initialValue?: string | undefined;
  getFieldDecorator: any;
}

const TaskType: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, formKey, initialValue = 3 } = props;
  return (
    <FormItem label="任务类型" colon={false}>
      {getFieldDecorator(formKey, {
        initialValue,
        rules: [{ required: true, message: '-请选择任务类型-' }]
      })(
        <Select placeholder="-请选择-" size="large">
          {_.map(taskTypes, item => (
            <Option key={item.value} value={item.value}>
              {item.name}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default TaskType;
