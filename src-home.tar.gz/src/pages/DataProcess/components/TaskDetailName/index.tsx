import React, { FunctionComponent } from 'react';
import { Tooltip } from 'sup-ui';
import Icon from '@components/Icon';

import styles from './index.less';

interface IProps {
  taskName: string;
  version: string;
  onBack: () => void;
}

const TaskDetailName: FunctionComponent<IProps> = (props: IProps) => {
  const { taskName, version, onBack } = props;
  return (
    <div className={styles.title}>
      <Icon type="arrow" onClick={onBack} />
      <Tooltip placement="bottom" title={taskName}>
        <span className={`ellipsis-1 ${styles.taskName}`}>{taskName}</span>
      </Tooltip>
      <Tooltip placement="bottom" title={version}>
        <span className={`ellipsis-1 ${styles.version}`}>{version}</span>
      </Tooltip>
    </div>
  );
};

export default TaskDetailName;
