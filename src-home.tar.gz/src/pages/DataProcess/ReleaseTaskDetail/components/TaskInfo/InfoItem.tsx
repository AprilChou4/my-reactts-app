import React, { FunctionComponent } from 'react';
import styles from './InfoItem.less';

interface IProps {
  label: string;
  children?: any;
}

const InfoItem: FunctionComponent<IProps> = (props: IProps) => {
  const { label, children } = props;
  return (
    <span className={styles.infoItemWrapper}>
      <label htmlFor={label} className={styles.infoItemLabel}>
        {label}
      </label>
      <span className={styles.infoItemContent}>{children}</span>
    </span>
  );
};

export default InfoItem;
