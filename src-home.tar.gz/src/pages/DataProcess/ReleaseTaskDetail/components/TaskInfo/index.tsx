import React, { Component, Fragment } from 'react';
import { Row, Col } from 'sup-ui';
import { Link } from 'react-router-dom';
import moment from 'moment';
import { observer } from 'mobx-react';
import classnames from 'classnames';
import Icon from '@components/Icon';
import InfoItem from './InfoItem';
import styles from './index.less';

const type = ['数据加工', '数据同步', '数据清洗'];

interface IProps {
  toggleTaskState: any;
  releaseDetailInfo: any;
}
interface IState {}

@observer
class ProjectInfo extends Component<IProps, IState> {
  /**
   *
   * @param cycle  后台返回调度周期
   */
  private getTimeCycle = (cycle: string): string => {
    switch (cycle) {
      case 'minute':
        return '分';
      case 'hour':
        return '时';
      case 'day':
        return '日';
      case 'week':
        return '周';
      case 'month':
        return '月';
      case 'customize':
        return '自定义';
      default:
        return '';
    }
  };

  private getTaskStatus = (status: string): string => {
    switch (status) {
      case '0':
        return '任务执行成功';
      case '1':
        return '任务执行失败';
      default:
        return '任务执行结束';
    }
  };

  public showLastExec = (time: any, state: any) => {
    if (_.isNil(time) || _.isNil(state)) {
      return <span>无上次执行记录</span>;
    } else {
      return (
        <InfoItem label={moment(time).format('YYYY-MM-DD HH:mm:ss')}>
          {state === 0 ? (
            <div className={styles.close}>
              <Icon type="close" />
              失败
            </div>
          ) : (
            <div className={styles.checked}>
              <Icon type="success" />
              成功
            </div>
          )}
        </InfoItem>
      );
    }
  };

  public taskInfoRender = () => {
    const { version, endTime, startTime, scheduleDetail, cronExpress } =
      this.props.releaseDetailInfo;

    const schedule: any = scheduleDetail ? JSON.parse(scheduleDetail) : '';
    const { triggerMode } = schedule;

    const taskStartTime: string = !startTime
      ? ''
      : moment(startTime).format('YYYY-MM-DD HH:mm:ss');
    const taskEndTime: string = !endTime
      ? ''
      : moment(endTime).format('YYYY-MM-DD HH:mm:ss');

    if (triggerMode === '1') {
      return (
        <Fragment>
          <InfoItem label="上游任务">{schedule.triggerTaskName}</InfoItem>
          <InfoItem label="触发消息任务状态">
            {this.getTaskStatus(schedule.triggerType)}
          </InfoItem>
        </Fragment>
      );
    } else if (triggerMode === '2') {
      return (
        <Fragment>
          <Row>
            <Col span={8}>
              <InfoItem label="对象模板">
                {schedule.templateDisplayName}
              </InfoItem>
            </Col>
            <Col span={8}>
              <InfoItem label="对象实例">
                {schedule.instanceDisplayName}
              </InfoItem>
            </Col>
            <Col span={8}>
              <InfoItem label="对象属性">{schedule.attributeShowName}</InfoItem>
            </Col>
          </Row>
          <InfoItem label="触发事件">{schedule.eventDisplayName}</InfoItem>
        </Fragment>
      );
    } else {
      return (
        <Fragment>
          <Row>
            <Col span={4}>
              <InfoItem label="版本号">{version}</InfoItem>
            </Col>
            <Col span={10}>
              <InfoItem label="任务开始执行时间">{taskStartTime}</InfoItem>
            </Col>
            <Col span={10}>
              <InfoItem label="任务结束执行时间">{taskEndTime}</InfoItem>
            </Col>
          </Row>
          <Row>
            <Col span={4}>
              <InfoItem label="调度周期">
                {this.getTimeCycle(schedule.radioTimeChange)}
              </InfoItem>
            </Col>
            {schedule.radioTimeChange !== 'customize' && (
              <Col span={4}>
                <InfoItem label="时间间隔">{schedule.timeGap}</InfoItem>
              </Col>
            )}
            <Col span={10}>
              <InfoItem label="Cron表达式">{cronExpress}</InfoItem>
            </Col>
          </Row>
        </Fragment>
      );
    }
  };

  public render() {
    const {
      toggleTaskState,
      releaseDetailInfo: {
        state,
        taskName,
        taskType,
        description,
        lastExecTime,
        lastExecState,
        developTaskId
      }
    } = this.props;

    return (
      <div className={styles.planContainer}>
        <div className={styles.planTitle}>
          <h3 className={styles.infoTitle}>{taskName}</h3>
          <InfoItem label="任务类型">{type[taskType - 1]}</InfoItem>
          <InfoItem label="任务描述">{description}</InfoItem>
          <h3 className={styles.infoTitle}>任务信息</h3>
          {this.taskInfoRender()}
        </div>
        <div className={styles.planSection}>
          <h3 className={styles.infoTitle}>上次执行</h3>
          {this.showLastExec(lastExecTime, lastExecState)}
        </div>
        <div className={styles.planFooter}>
          <div
            className={classnames(
              styles.circleBtn,
              state === 0 ? styles.stop : styles.start
            )}
            onClick={toggleTaskState}
          />
          {state === 0 ? (
            <div className={classnames(styles.circleBtn, styles.editCircle)}>
              <Link
                to={`/process/dev/modeling/${developTaskId}`}
                style={{ color: '#354035' }}
              >
                编辑
              </Link>
            </div>
          ) : null}
        </div>
      </div>
    );
  }
}

export default ProjectInfo;
