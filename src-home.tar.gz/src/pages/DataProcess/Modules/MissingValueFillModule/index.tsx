import React, { Component } from 'react';

import uuid from '@utils/uuid';
import { getDerivedStateFromProps } from '../module.helper';
import TransferTable from '../components/TransferTable';
import MissFillTable from './MissFillTable';
import { IModuleProps } from '../module';

interface IState {
  dataModuleTag: string;
  dataModuleInputDatas: [];
  rules: any[];
  targetKeys: [];
  variables: [];
  dateTimeKey: number;
}

class MissingValueFillModule extends Component<IModuleProps, IState> {
  private fillRef: any;
  public constructor(props: IModuleProps) {
    super(props);

    this.state = {
      dataModuleTag: '', // 模块tag
      dataModuleInputDatas: [], // 输入数据
      rules: _.cloneDeep(_.get(props, 'dataModuleConfig.rules', [])), // 输出数据
      targetKeys: [], // 输出数据的keys
      variables: [],
      dateTimeKey: 11
    };
    props.initApi(this.saveConfig);
  }

  public static getDerivedStateFromProps(nextProps: any, state: IState) {
    return getDerivedStateFromProps(nextProps, state);
  }

  /**
   * @description: 保存配置信息
   * @return: object config
   */
  public saveConfig = () => {
    const verifyRes = this.fillRef.verifyRules();
    if (!verifyRes) return;
    return {
      struct: this.state.dataModuleInputDatas,
      rules: this.state.rules
    };
  };

  /**
   * @description: 配置信息发生改变后触发函数,修改算子是否更改状态
   */
  private handleConfigChange = () => {
    this.props.toggleChangedStatus();
  };

  // 设置角色穿梭层数据变化的回调事件
  private handleTransferChange = (moveKeys: any) => {
    this.setState(({ dataModuleInputDatas, rules }: any) => {
      const newRules = _.unionBy(
        rules,
        dataModuleInputDatas
          .filter(({ name }: any) => _.includes(moveKeys, name))
          .map((record: any) =>
            Object.assign({}, record, {
              key: uuid(6),
              type: undefined,
              value: ''
            })
          ),
        'name'
      );
      return {
        rules: newRules
      };
    });
    this.handleConfigChange();
  };

  private updateRules = (rules: any[]) => {
    this.setState({
      rules
    });
    this.handleConfigChange();
  };

  public render() {
    const { dataModuleTag } = this.props;
    const { rules, dataModuleInputDatas, variables } = this.state;
    return (
      <TransferTable
        dataModuleTag={dataModuleTag}
        leftTitle="选择缺失字段"
        rightTitle="缺失值处理"
        sourceDataStructure={dataModuleInputDatas}
        verifyKeys={['name', 'dataType']}
        targetKeys={rules.map(({ name }: any) => name)}
        selectedKeyName="name"
        onChange={this.handleTransferChange}
        getCheckboxProps={(record: any): any => {
          if (record.dataType === 'Bytes') return { disabled: true };
        }}
        rightComponent={
          <MissFillTable
            wrappedComponentRef={(ref: any) => {
              if (!this.fillRef) {
                this.fillRef = ref;
              }
            }}
            sourceDataStructure={dataModuleInputDatas}
            dataSource={rules}
            variables={variables}
            updateRules={this.updateRules}
          />
        }
      />
    );
  }
}
export default MissingValueFillModule;
