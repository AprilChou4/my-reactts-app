/*
 * @Description: 数据加工 缺失值处理算子 主体逻辑组件
 * @Author: liyongshuai
 */
import React, { Component } from 'react';
import { Table, Form, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import SetValueByDataType from '../../components/SetValueByDataType';
import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import { getTimeTypeByValue } from '@utils/timeUtil';
import ProcessMode from './lib/ProcessMode';
import Fitting from './lib/Fitting';
import Formula from './lib/Formula';
import { isNumericDataType } from '@utils/datatype';

interface IProps extends FormComponentProps {
  variables: [];
  dataSource: any[];
  sourceDataStructure: any[];
  updateRules: (newRules: any[]) => void;
}

class MissFillTable extends Component<IProps> {
  public constructor(props: IProps) {
    super(props);
  }
  public verifyRules = () => {
    let params;
    this.props.form.validateFields((errors: any) => {
      if (!errors) {
        params = true;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 根据行 key 值，更新dataSource
   */
  private updateRulesByKey = (newRecord: any) => {
    const { key } = newRecord;
    const newDataSource: any[] = _.map(this.props.dataSource, (item: any) =>
      item.key === key ? newRecord : item
    );
    this.props.updateRules(newDataSource);
  };

  /**
   * @description: 处理方式更改
   */
  private handleTypeChange = (value: number, record: any) => {
    const newRecord = {
      ...record,
      type: value,
      value: undefined
    };
    this.updateRulesByKey(newRecord);
  };

  private handleValueChange = (value: any, record: any) => {
    const newRecord = {
      ...record
    };
    if (_.isObject(value as any)) {
      const { variableName } = value;
      const selectedVb: any =
        _.find(
          this.props.variables,
          (item: any) => variableName === item.name
        ) || {};
      const constType = _.get(selectedVb, ['constValue', 'type'], null);
      value.constType = constType;
    }
    newRecord.value = value;
    this.updateRulesByKey(newRecord);
  };

  private handleDelete = (record: any): void => {
    const { dataSource } = this.props;
    const { key } = record;
    _.remove(dataSource, (o: any) => o.key === key);
    this.props.updateRules(dataSource);
  };

  private getColumns = () => {
    const {
      form: { getFieldDecorator },
      variables
    } = this.props;
    return [
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: 90
      },
      {
        title: '处理方式',
        dataIndex: 'type',
        key: 'type',
        width: 120,
        render: (_text: any, record: any) => {
          const { key, dataType } = record;
          return (
            <ProcessMode
              formKey={`${key}_type`}
              getFieldDecorator={getFieldDecorator}
              initialValue={_.get(record, 'type', undefined)}
              dataType={dataType}
              onChange={(value: number) => {
                this.handleTypeChange(value, record);
              }}
            />
          );
        }
      },
      {
        title: '值',
        dataIndex: 'value',
        key: 'value',
        render: (value: any, record: any) => {
          const { key, type, dataType } = record;
          if (type === 3) {
            return (
              <SetValueByDataType
                size="small"
                formKey={`${key}_const_value`}
                value={value}
                dataType={record.dataType}
                varType="const"
                getFieldDecorator={getFieldDecorator}
                variables={[]}
                onChange={(v: any) => {
                  this.handleValueChange(v, record);
                }}
              />
            );
          } else if (type === 4) {
            // 当变量是确定值且变量的类型与字段的数据类型一致时才允许选择
            const newVariables = _.filter(variables, (item: any) => {
              if (item.dataType === 'Datetime') {
                const { type: iType, value: iValue } = item.constValue;
                if (iType === 1) {
                  const valueDataType = getTimeTypeByValue(iValue);
                  return valueDataType === dataType;
                } else {
                  return false;
                }
              } else {
                return item.dataType === dataType;
              }
            });
            return (
              <SetValueByDataType
                size="small"
                formKey={`${key}_let_value`}
                value={value}
                dataType={record.dataType}
                varType="let"
                getFieldDecorator={getFieldDecorator}
                variables={newVariables}
                onChange={(v: any) => {
                  this.handleValueChange(v, record);
                }}
              />
            );
          } else if (type === 8) {
            return (
              <Fitting
                formKey={`${key}_fit_value`}
                getFieldDecorator={getFieldDecorator}
                initialValue={_.get(record, 'value', undefined)}
                options={_.filter(
                  this.props.sourceDataStructure,
                  field =>
                    isNumericDataType(field.dataType) &&
                    field.name !== record.name
                )}
                onChange={v => {
                  this.handleValueChange(v, record);
                }}
              />
            );
          } else if (type === 9) {
            return (
              <Formula
                initialValue={_.get(record, 'value', undefined)}
                options={this.props.sourceDataStructure}
                onChange={v => {
                  this.handleValueChange(v, record);
                }}
              />
            );
          } else {
            return null;
          }
        }
      },
      {
        title: '移除',
        align: 'center',
        width: 50,
        render: (_text: any, record: any) => (
          <Icon type="remove" onClick={this.handleDelete.bind(this, record)} />
        )
      }
    ];
  };

  public render() {
    const { dataSource } = this.props;
    const columns: any = this.getColumns();
    return (
      <Table
        size="small"
        className="task-base-table task-edit-table"
        rowKey="key"
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({
  name: 'missFill'
})(MissFillTable);
