/*
 * @Description: 缺失值处理 处理方式交互
 * @Author: liyongshuai
 */
import React, { FunctionComponent } from 'react';
import { Select, Form } from 'sup-ui';

import { popupContainer } from '@utils/propUtil';
import {
  isDatetimeDataType,
  isNumericDataType,
  isBooleanDataType
} from '@utils/datatype';
import {
  stringOP,
  numericalOP,
  booleanOP,
  datetimeOP
} from '../missFill.const';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  formKey: string;
  initialValue: any;
  dataType: string;
  getFieldDecorator: any;
  onChange: (value: number) => void;
}

const ProcessMode: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, formKey, dataType, initialValue } = props;

  let options = [];
  if (isNumericDataType(dataType)) {
    options = numericalOP;
  } else if (isDatetimeDataType(dataType)) {
    options = datetimeOP;
  } else if (isBooleanDataType(dataType)) {
    options = booleanOP;
  } else {
    options = stringOP;
  }

  return (
    <FormItem>
      {getFieldDecorator(`${formKey}`, {
        initialValue,
        rules: [
          {
            required: true,
            message: '-请选择-'
          }
        ]
      })(
        <Select
          size="small"
          placeholder="-请选择-"
          dropdownMatchSelectWidth={false}
          onChange={props.onChange}
          getPopupContainer={popupContainer}
        >
          {_.map(options, (item: any) => (
            <Option key={item.key} value={item.key}>
              {item.label}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default ProcessMode;
