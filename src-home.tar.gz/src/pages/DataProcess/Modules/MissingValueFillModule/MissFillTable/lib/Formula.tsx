import React, { Component, Fragment } from 'react';
import { Select, Input, message, Tooltip } from 'sup-ui';
import classnames from 'classnames';
import $ from 'jquery';

import Icon from '@components/Icon';
import Dialog from '@components/Modal/Dialog';
import { popupContainer } from '@utils/propUtil';
import { TableCellText } from '@components/Table';
import styles from './Formula.less';

const { Option } = Select;
const { TextArea } = Input;

interface IProps {
  initialValue: string;
  options: any[];
  onChange: (expr: string) => void;
}

interface IState {
  edit: boolean;
}

class Formula extends Component<IProps, IState> {
  private expressionEditorRef: any;
  private exprShowRef: any;
  public constructor(props: IProps) {
    super(props);
    this.state = {
      edit: false
    };
  }

  private cancelEdit = () => {
    this.setState({
      edit: false
    });
  };

  private editExpr = () => {
    this.setState({
      edit: true
    });
  };

  private handleOk = () => {
    const value = $(this.expressionEditorRef)[0].value;
    if (_.isEmpty(_.trim(value))) {
      message.warning('请输入公式！');
    } else if ($(this.exprShowRef).find('.field-error').length) {
      message.warning('公式包含未知字段，请核对！');
    } else {
      this.props.onChange(value);
      this.setState({
        edit: false
      });
    }
  };

  private handleAttrChoose = (value: string) => {
    const targetItem = _.find(this.props.options, i => i.name === value);
    const expr = `[${targetItem.name}]`;
    this.expressionEditorRef.focus();
    document.execCommand('insertText', false, expr);
    this.renderExpression($(this.expressionEditorRef)[0].value, expr.length);
  };

  private handleChangeExpr = (e: any) => {
    this.renderExpression(e.target.value);
  };

  private renderExpression = (expr: string, insertPos = 0) => {
    if (
      _.isString(expr) &&
      !_.isNil(this.expressionEditorRef) &&
      !_.isNil(this.exprShowRef)
    ) {
      const { options } = this.props;
      const htmlText = expr
        .replace(
          /[~!%^&*()\-+=<>?:,]/g,
          v1 => `<span class='special'>${v1}</span>`
        )
        .replace(/(\[[A-Za-z0-9_\u4E00-\u9FA5]+\])/g, (_v1, v2) => {
          const target = _.find(options, i => i.name === v2.slice(1, -1));
          return `<span class=${target ? 'field' : 'field-error'}>${v2}</span>`;
        })
        .replace(
          /(\n+)/g,
          v1 => `<span class="spaces">${'&#10;'.repeat(v1.length)}</span>`
        );

      $(this.exprShowRef).html(htmlText);
      if (insertPos) {
        const { selectionStart } = this.expressionEditorRef;
        this.expressionEditorRef.selectionEnd = selectionStart + insertPos;
      }
      const { scrollHeight } = this.expressionEditorRef;
      if (scrollHeight > 200) {
        this.expressionEditorRef.style.height = `${scrollHeight}px`;
        this.exprShowRef.style.height = `${scrollHeight}px`;
      }
    }
  };

  public render() {
    const { initialValue, options = [] } = this.props;
    const { edit } = this.state;
    return (
      <Fragment>
        <TableCellText
          text={initialValue}
          className={classnames(
            'ellipsis-1',
            styles.text,
            !initialValue && styles.noValue
          )}
          onClick={this.editExpr}
        />
        <Dialog
          visible={edit}
          title={
            <Fragment>
              自定义公式
              <Tooltip
                placement="top"
                overlayClassName={styles.tipsWrapper}
                title={
                  <Fragment>
                    <p>字符型：只支持字符串拼接，如[string]+&quot;test&quot;</p>
                    <p>数值型：支持字段的四则运算[double]+[float];</p>
                    <p>注：字段使用 [字段名] 匹配；。</p>
                  </Fragment>
                }
              >
                <Icon
                  type="circle-help"
                  style={{ verticalAlign: '-4px', marginLeft: '4px' }}
                />
              </Tooltip>
            </Fragment>
          }
          centered={true}
          wrapClassName="filter-mask"
          width="auto"
          destroyOnClose
          onOk={this.handleOk}
          onCancel={this.cancelEdit}
        >
          <Select
            value="插入字段"
            className={styles.selectItem}
            showSearch
            optionFilterProp="children"
            getPopupContainer={popupContainer}
            onSelect={this.handleAttrChoose}
          >
            {_.map(options, (item: any) => (
              <Option key={`${item.name}`} value={item.name}>
                {item.name}
              </Option>
            ))}
          </Select>
          <div className={styles.wrapper}>
            <TextArea
              rows={5}
              className={styles.textArea}
              onChange={this.handleChangeExpr}
              defaultValue={initialValue}
              style={{ height: '200px' }}
              ref={(ref: any) => {
                this.expressionEditorRef = ref && ref.textAreaRef;
              }}
            />
            <div
              className={styles.exprShow}
              ref={(ref: any) => {
                this.exprShowRef = ref;
                this.renderExpression(initialValue);
              }}
            />
          </div>
        </Dialog>
      </Fragment>
    );
  }
}

export default Formula;
