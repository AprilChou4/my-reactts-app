/*
 * @Description: 缺失值处理拟合类型交互
 * @Author: liyongshuai
 */

import React, { FunctionComponent } from 'react';
import { Select, Form } from 'sup-ui';

import { popupContainer } from '@utils/propUtil';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  formKey: string;
  initialValue: any;
  getFieldDecorator: any;
  options: any[];
  onChange: (value: number) => void;
}

const Fitting: FunctionComponent<IProps> = (props: IProps) => {
  const {
    formKey,
    initialValue,
    getFieldDecorator,
    options = [],
    onChange
  } = props;

  return (
    <FormItem>
      {getFieldDecorator(`${formKey}`, {
        initialValue,
        rules: [
          {
            required: true,
            message: '请选择'
          }
        ]
      })(
        <Select
          size="small"
          placeholder="-请选择-"
          dropdownMatchSelectWidth={false}
          onChange={onChange}
          getPopupContainer={popupContainer}
        >
          {_.map(options, (item: any) => (
            <Option key={item.name} value={item.name}>
              {item.name}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default Fitting;
