/**
 * 消息队列输入
 */
import React, { Component } from 'react';

import ShinePopover from '@components/ShinePopover';
import ModuleTab from '../components/ModuleTab';
import TaskTitle from '../components/TaskTitle';
import LineTable from '../components/LineTable';
import MsgQueueOuput from './container';
import { IModuleProps } from '../module';
import { getDerivedStateFromProps, getMappingStruct } from '../module.helper';

interface IProps extends IModuleProps {
  updateNodeNameByTag: (name: string) => void;
}
interface IState {
  dataModuleTag: string;
  variables: any[];
}

class MsgQueueInputModule extends Component<IProps, IState> {
  private sqlInputRef: any;
  private mappingRef: any;
  public static defaultProps = {
    dataModuleInputDatas: null,
    variables: []
  };

  public constructor(props: IProps) {
    super(props);
    this.state = {
      dataModuleTag: '',
      variables: []
    };
    props.initApi(this.saveConfig);
  }

  public static getDerivedStateFromProps(nextProps: any, state: any) {
    return getDerivedStateFromProps(nextProps, state);
  }

  public componentDidMount() {
    // if (this.mappingRef) {
    //   const { originStruct, targetStruct, mapping } =
    //     this.props.dataModuleConfig;
    //   this.initMapping({ originStruct, targetStruct, mapping });
    // }

    if (this.mappingRef) {
      const { dataModuleConfig, dataModuleInputDatas } = this.props;
      const originStruct = dataModuleInputDatas[0]
        ? _.cloneDeep(dataModuleInputDatas[0].dataStructure || [])
        : [];

      const { targetStruct, mapping } = dataModuleConfig;
      this.initMapping({ originStruct, targetStruct, mapping });
    }
    if (this.props.dataModuleStatus) {
      this.handleConfigChange();
    }
  }

  /**
   * @description: 触发配置信息改变状态的函数
   */
  public handleConfigChange = () => {
    this.props.toggleChangedStatus();
  };

  /**
   * @description: 保存配置信息
   * 根据输出类型，获取该类型下的 Form组件，保存时走该 Form组件下的保存校验
   * 当且仅当校验通过才会有数据信息返回，反之返回 undefined
   * 校验逻辑由各个 Form组件负责
   * Form 组件校验完毕之后，校验映射表格信息
   * @return {object|undefined} 当返回 undefined 时，表明该算子有配置信息未填写完整，不能保存
   */
  public saveConfig = () => {
    let config;
    const formData = this.sqlInputRef.saveVerify();
    if (!formData) return;
    const inputDatas = this.sqlInputRef.msgQueueOuputStore.originStruct;
    config = Object.assign({}, formData);
    const mappingData = this.mappingRef.saveVerify();
    if (!mappingData) return;
    const { mapping, targetStruct } = mappingData;
    const struct = getMappingStruct({
      mapping,
      inputDatas,
      targetStruct
    });
    config = Object.assign(config, {
      mapping,
      struct,
      originStruct: inputDatas,
      targetStruct
    });
    return config;
    // return _.assign({ struct }, formData, mappingData);
  };

  public initMapping = (mappingParams: any) => {
    this.mappingRef.init(mappingParams);
  };

  public renderLeftNode = () => {
    const { updateNodeNameByTag } = this.props;
    return (
      <MsgQueueOuput
        ref={ref => {
          this.sqlInputRef = ref;
        }}
        {...this.props}
        initMapping={this.initMapping}
        handleConfigChange={this.handleConfigChange}
        updateNodeNameByTag={updateNodeNameByTag}
      />
    );
  };

  public render() {
    const { taskId, dataModuleTag } = this.props;
    const lineProps: any = {
      mappingId: `${taskId}-${dataModuleTag}`,
      type: 'dataOutput'
    };
    return (
      <ModuleTab
        tabs={['输出选择', '映射配置']}
        leftNode={
          <>
            <TaskTitle index={1} subTitle="选择数据源" />
            {this.renderLeftNode()}
          </>
        }
        rightNode={
          <>
            <TaskTitle
              index={2}
              subTitle={
                <span>
                  字段信息映射
                  <ShinePopover />
                </span>
              }
            />
            <LineTable
              ref={(ref: any) => {
                if (!this.mappingRef) {
                  this.mappingRef = ref;
                }
              }}
              {...lineProps}
              handleConfigChange={this.handleConfigChange}
            />
          </>
        }
      />
    );
  }
}
export default MsgQueueInputModule;
