import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';

import {
  getDataSourceListByType,
  getMqTopicList,
  getMqDataPreview
} from '../../module.service';

class InputStore {
  private readonly initMapping: (params: any) => void;
  private readonly handleConfigChange: any;
  @observable public formLoading = false;
  @observable public previewVisible = false; // 数据预览弹窗是否显示
  @observable public previewDataLoading = false;
  @observable public previewData: any[] = []; // 数据预览数据
  public mapping: any[] = [];
  @observable public originStruct: any[] = []; // 字段设置列表
  @observable public targetStruct: any[] = [];
  @observable public formData: any = {};
  @observable public sourceTypes: any[] = []; // 数据源类型--1
  @observable public sourceNames: any[] = []; // 数据源名称--1
  @observable public topicList: any[] = []; // topic列表--1
  @observable public sourceNameGroup: { [propName: string]: any[] } = {};

  public constructor({
    originStruct,
    dataModuleConfig,
    initMapping,
    handleConfigChange
  }: any) {
    const {
      mapping = [],
      targetStruct = [],
      extendConfig = {},
      ...restProps
    } = _.cloneDeep(dataModuleConfig);
    runInAction(() => {
      this.formData = {
        inputType: 5,
        ...restProps,
        ...extendConfig
      };
      this.mapping = mapping;
      this.targetStruct = targetStruct;
      this.originStruct = originStruct;
    });
    this.initMapping = initMapping;
    this.handleConfigChange = handleConfigChange;
    this.getDataSourceListByType();
  }

  /**
   * @description: 根据不同的输入类型获取数据源列表
   * @param {string} type 默认为 mq  消息队列数据源
   */
  @action.bound
  public async getDataSourceListByType() {
    this.formLoading = true;
    const res = await getDataSourceListByType({ dataType: 'mq' });
    const { code, data, message: mes } = res;
    runInAction(() => {
      if (code !== 200) {
        message.error(mes);
        this.formLoading = false;
        return;
      }
      const { table } = data?.map || {};
      this.formLoading = false;
      // 数据源类型
      const sqlTypeList = _.get(data.map, 'sqlTypeList', []);
      this.sourceTypes = sqlTypeList;
      // 默认kafka51 先判断是否有kafka
      const kafka = _.find(sqlTypeList, { sqlType: 51 }) || {};
      this.formData = {
        ...this.formData,
        sourceType: this.formData.sourceType || kafka.sqlType
      };

      // 根据sqlType分组{1:[],2:[]}
      this.sourceNameGroup = _.groupBy(table, 'sqlType');
      const { topic, sourceType, sourceId } = this.formData;

      this.sourceNames = _.isNil(sourceType)
        ? table
        : this.sourceNameGroup[sourceType];

      const { url } = _.find(this.sourceNames, ['id', sourceId]) || {};
      if (topic) {
        this.getTopicListBySourceName({ endpoint: url });
      }
    });
  }

  /**
   * @description: 数据源类型切换
   * @param {type}
   */
  @action.bound
  public handleSourceTypeChange = (value: string) => {
    if (!value) return;
    runInAction(() => {
      this.sourceNames = this.sourceNameGroup[value];
      this.topicList = [];
      this.updateFormData({ sourceType: value });
    });
  };

  /**
   * @description: 根据选择数据源名称拉取对应kafka的Topic的列表
   * @param {string} endpoint endpoint 数据源ip和端口，对应url字段
   */
  @action.bound
  public async getTopicListBySourceName(params: any) {
    const { sourceType } = this.formData;
    if (sourceType === 53) {
      return;
    }
    const { sqlName: mqType } =
      _.find(this.sourceTypes, ['sqlType', sourceType]) || {};
    this.formLoading = true;

    const res = await getMqTopicList({ mqType, ...params });
    const { code, data, message: mes } = res;
    runInAction(() => {
      if (code !== 200) {
        message.error(mes);
        this.formLoading = false;
        return;
      } else {
        this.formLoading = false;
        this.topicList = data;
      }
    });
  }

  @action.bound
  public updateFormData = (updateItem: any) => {
    this.formData = Object.assign(this.formData, updateItem);
    this.handleConfigChange();
  };

  @action.bound
  public updateOriginStruct = (struct: any[]) => {
    this.originStruct = struct;
    this.handleConfigChange();
  };

  @action.bound
  public showPreview = async () => {
    this.previewVisible = true;
    const { topic, sourceName, sourceType } = this.formData;
    const { url, id } = _.find(this.sourceNames, ['name', sourceName]) || {};
    const { sqlName: mqType } =
      _.find(this.sourceTypes, ['sqlType', sourceType]) || {};
    this.previewDataLoading = true;
    const res = await getMqDataPreview({
      mqType,
      endpoint: url,
      id,
      topic
    });
    const { code, data, message: mes } = res;
    runInAction(() => {
      if (code !== 200) {
        message.error(mes);
        this.previewData = [];
        this.previewDataLoading = false;
      } else {
        this.previewData = data || [];
        this.previewDataLoading = false;
      }
    });
  };

  @action.bound
  public cancelPreview = () => {
    this.previewVisible = false;
    this.previewData = [];
  };

  @action.bound
  public initTargetStruct = (struct: [] = []) => {
    this.targetStruct = struct;
    this.initMapping({
      targetStruct: struct,
      mapping: []
    });
    this.handleConfigChange();
  };

  /**
   * 更新字段list
   */
  @action.bound
  public updateFieldList = (list: any[]) => {
    this.targetStruct = list;
    this.mapping = [];
    this.initMapping({
      mapping: this.mapping,
      targetStruct: list
    });
    this.handleConfigChange();
  };
}

export default InputStore;
