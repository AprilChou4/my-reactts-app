import { action, computed, observable } from 'mobx';

class TransposeStore {
  private readonly sourceList: any[] = []; //源数据
  private readonly toggleChangedStatus: (status: boolean) => void;
  private hasDirty = false;
  @observable public keyword = ''; //搜索字段
  @observable.struct public selectedRowKeys: string[] = []; //选中的行
  @observable public transFormValues = {}; //表单初始值

  public constructor(config: any, sourceData: any[], toggleChangedStatus: any) {
    this.sourceList = sourceData;
    this.toggleChangedStatus = toggleChangedStatus;
    this.initData(config);
  }

  @action.bound
  public initData(config: any) {
    if (!_.isEmpty(config)) {
      this.transFormValues = config;
    }
  }

  /*总列表模块*/
  /*过滤列表项*/
  @computed
  public get filterSourceList() {
    const filterFields = ['name'];
    return _.filter(this.sourceList, item =>
      _.some(filterFields, field => item[field].indexOf(this.keyword) !== -1)
    );
  }
  /*更改搜索字段*/
  @action.bound
  public changeKeyword(keyword: string) {
    this.keyword = keyword;
  }
  /*更新列表选择行*/
  @action.bound
  public updateSelectedRowKeys(selectedKeys: string[]) {
    this.selectedRowKeys = selectedKeys;
  }

  /*触发了config修改*/
  @action.bound
  public markConfigAsDirty() {
    if (this.hasDirty || this.sourceList.length === 0) return;
    this.hasDirty = true;
    this.toggleChangedStatus(true);
  }
}

export default TransposeStore;
