import React, { Component, Fragment } from 'react';
import { Row, Col, Button, Table, Form, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import { ColumnProps } from 'sup-ui/lib/table';

import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import EditableCell from './EditableCell';

import styles from './index.less';

interface IProps extends FormComponentProps {
  dataSource: any[];
  currentLinkedKey: string;
  onUpdate: (record: any) => void;
  onSort: (type: string) => void;
  getTargetStatus: (key: string) => boolean;
  checkCurrentRecord: (type: 'end', record: any) => void;
  isEdit?: boolean;
  onAdd?: any;
  onDelete?: any;
  columns?: ColumnProps<any>[];
}

interface IState {
  selectedRowKeys: [];
}

class LineTargetTable extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      selectedRowKeys: []
    };
  }

  public verify = () => {
    let verifyRes = true;
    this.props.form.validateFieldsAndScroll(errors => {
      if (errors) {
        message.warning('映射配置有误，请核对！');
        verifyRes = false;
        return;
      }
    });
    return verifyRes;
  };

  private getColumns = () => {
    const { isEdit, form, onUpdate, dataSource, getTargetStatus } = this.props;
    let columns = [
      {
        key: 'name',
        title: '字段',
        width: 130,
        dataIndex: 'name',
        className: 'ellipsis-hide'
      },
      {
        key: 'showName',
        title: '字段含义',
        width: 130,
        dataIndex: 'showName',
        className: 'ellipsis-hide'
      },
      {
        key: 'dataType',
        title: '数据类型',
        width: 80,
        dataIndex: 'dataType'
      }
    ];
    if (isEdit) {
      columns = _.map(columns, (col: any) => {
        return {
          ...col,
          render: (_text: string, record: any) => (
            <EditableCell
              record={record}
              dataIndex={col.dataIndex}
              form={form}
              onUpdate={onUpdate}
              dataSource={dataSource}
              getTargetStatus={getTargetStatus}
            />
          )
        };
      });
    } else {
      columns = _.map(columns, (col: any) => {
        col.render = (text: string) => <TableCellText text={text} />;
        return col;
      });
    }
    return columns;
  };

  private onSelectChange = (selectedRowKeys: []): void => {
    this.setState({ selectedRowKeys });
  };

  private onDelete = () => {
    const { selectedRowKeys } = this.state;
    if (!selectedRowKeys.length) return;
    this.props.onDelete(selectedRowKeys);
    this.setState({
      selectedRowKeys: []
    });
  };

  public render() {
    const { selectedRowKeys } = this.state;
    const {
      onDelete,
      dataSource,
      onAdd,
      onSort,
      checkCurrentRecord,
      currentLinkedKey
    } = this.props;
    const rowSelection: any = {
      columnWidth: 40,
      selectedRowKeys,
      onChange: this.onSelectChange
    };
    return (
      <Fragment>
        <Row className={styles.headerRow}>
          <Col
            span={4}
            className={styles.operaText}
            onClick={onSort.bind(this, 'auto')}
          >
            自动排序
          </Col>
          <Col span={20} className={styles.otherNode}>
            {_.isFunction(onAdd) && (
              <Button
                className={styles.operaBtn}
                size="small"
                type="primary"
                onClick={onAdd}
              >
                新增
              </Button>
            )}
            {_.isFunction(onDelete) && (
              <Button
                size="small"
                className={`${styles.operaBtn} ${styles.delBtn}`}
                disabled={!selectedRowKeys.length}
                onClick={this.onDelete}
              >
                <Icon type="remove" />
              </Button>
            )}
          </Col>
        </Row>
        <Form>
          <Table
            size="small"
            className="task-edit-table"
            rowClassName={record =>
              record.DAM_line_key === currentLinkedKey
                ? styles.activeRecord
                : ''
            }
            rowKey="DAM_line_key"
            rowSelection={rowSelection}
            columns={this.getColumns()}
            dataSource={dataSource}
            onRow={(_record, index) => ({
              onClick: () => {
                checkCurrentRecord('end', index);
              }
            })}
            pagination={false}
          />
        </Form>
      </Fragment>
    );
  }
}

export default Form.create<IProps>({
  name: 'lineTargetTable'
})(LineTargetTable);
