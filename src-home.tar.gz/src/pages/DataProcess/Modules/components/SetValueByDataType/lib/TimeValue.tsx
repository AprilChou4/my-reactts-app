import React, { FunctionComponent } from 'react';
import { Form, TimePicker } from 'sup-ui';
import moment from 'moment';

import { ISetValueProps } from '../setValueByDataType';
const FormItem = Form.Item;

interface IProps extends ISetValueProps {
  showTime: boolean;
}

const TimeValue: FunctionComponent<IProps> = (props: IProps) => {
  const { formKey, size, initialValue, required, getFieldDecorator, onChange } =
    props;
  return (
    <FormItem>
      {getFieldDecorator(`${formKey}_time`, {
        initialValue: initialValue
          ? moment(initialValue, 'HH:mm:ss')
          : undefined,
        rules: [
          {
            required,
            message: '请选择'
          }
        ]
      })(
        <TimePicker
          size={size}
          style={{
            width: '100%'
          }}
          placeholder="-请选择-"
          onChange={v => {
            const value = _.isNil(v) ? undefined : moment(v).format('HH:mm:ss');
            onChange(value);
          }}
        />
      )}
    </FormItem>
  );
};

export default TimeValue;
