export interface ISetValueProps {
  formKey: string;
  initialValue: string;
  dataType: string;
  getFieldDecorator: any;
  onChange: (value: string | undefined) => void;
  required?: boolean;
  size?: 'default' | 'small' | 'large' | undefined;
}
