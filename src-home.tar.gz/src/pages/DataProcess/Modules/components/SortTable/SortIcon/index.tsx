/*
 * @Description: 排序算子顶部上移 下移 置顶 置底 操作
 * @Author: liyongshuai
 */
import React, { FunctionComponent } from 'react';
import { Tooltip } from 'sup-ui';

import Icon from '@components/Icon';
import styles from './index.less';

interface IProps {
  disabled: boolean;
  onSort: (v: string) => void;
}

const icons = [
  {
    title: '置顶',
    type: 'move-top'
  },
  {
    title: '上移',
    type: 'move-up'
  },
  {
    title: '下移',
    type: 'move-down'
  },
  {
    title: '置底',
    type: 'move-bottom'
  },
  {
    title: '删除',
    type: 'remove',
    className: 'iconRemove'
  }
];

const SortIcon: FunctionComponent<IProps> = (props: IProps) => {
  return (
    <div className={styles.wrapper}>
      {_.map(icons, item => (
        <Tooltip title={item.title} key={item.type}>
          <Icon
            disabled={props.disabled}
            type={item.type}
            className={item.className ? styles[item.className] : ''}
            onClick={() => {
              props.onSort(item.type);
            }}
          />
        </Tooltip>
      ))}
    </div>
  );
};

export default SortIcon;
