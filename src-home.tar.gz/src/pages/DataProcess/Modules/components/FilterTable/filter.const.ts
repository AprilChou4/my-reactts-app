import { dataTypes } from '../../../devTask.const';
import { DATETIME_DATATYPE } from '@utils/datatype';
/*
 * @Description: 数据加工 过滤算子 过滤选项
 * V2.6京博定制版本将 大于/大于等于/小于/小于等于  对 String 类型的限制取消
 * @Author: liyongshuai
 */
export const filterOptions = [
  {
    key: 'eq',
    label: '=',
    disableDataType: ['Bytes']
  },
  {
    key: 'neq',
    label: '!=',
    disableDataType: ['Bytes']
  },
  {
    key: 'gt',
    label: '>',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'gte',
    label: '>=',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'lt',
    label: '<',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'lte',
    label: '<=',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'in',
    label: 'in',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'nin',
    label: 'not in',
    disableDataType: ['Bytes', 'Boolean']
  },
  {
    key: 'like',
    label: 'like',
    disableDataType: _.filter(dataTypes, i => i !== 'String')
  },
  {
    key: 'nlike',
    label: 'not like',
    disableDataType: _.filter(dataTypes, i => i !== 'String')
  },
  {
    key: 'between', // 当且仅当在处理类型为变量时，且为时间范围时有效
    label: 'between',
    disableDataType: _.filter(dataTypes, i => !_.includes(DATETIME_DATATYPE, i))
  },
  {
    key: 'nbetween', // 同between
    label: 'not between',
    disableDataType: _.filter(dataTypes, i => !_.includes(DATETIME_DATATYPE, i))
  },
  {
    key: 'min',
    label: '最小值',
    disableDataType: ['Bytes']
  },
  {
    key: 'max',
    label: '最大值',
    disableDataType: ['Bytes']
  },
  {
    key: 'null',
    label: '为空',
    disableDataType: ['Bytes']
  },
  {
    key: 'nnull',
    label: '不为空',
    disableDataType: ['Bytes']
  }
];
