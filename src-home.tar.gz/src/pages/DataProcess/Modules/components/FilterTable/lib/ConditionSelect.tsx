import React, { FunctionComponent } from 'react';
import { Select, Form } from 'sup-ui';

import { popupContainer } from '@utils/propUtil';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  formKey: string;
  initialValue: any;
  options: any[];
  getFieldDecorator: any;
  onChange: (value: string) => void;
}

const ConditionSelect: FunctionComponent<IProps> = (props: IProps) => {
  const { formKey, options, initialValue, onChange, getFieldDecorator } = props;
  return (
    <FormItem>
      {getFieldDecorator(`condition_${formKey}`, {
        initialValue,
        rules: [
          {
            required: true,
            message: '-请选择-'
          },
          {
            validator: (
              _rule: any,
              value: string,
              callback: (v?: any) => void
            ) => {
              const target = _.find(options, i => i.key === value);
              if (_.get(target, 'disabled')) {
                callback('请重新选择！');
              } else {
                callback();
              }
            }
          }
        ],
        validateTrigger: ['onBlur']
      })(
        <Select
          style={{ width: '100%' }}
          size="small"
          placeholder="-请选择-"
          dropdownMatchSelectWidth={false}
          getPopupContainer={popupContainer}
          onChange={onChange}
        >
          {_.map(options, (item: any) => (
            <Option key={item.key} value={item.key} disabled={item.disabled}>
              {item.label}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default ConditionSelect;
