/*
 * @Description: 数据加工 过滤算子 主体逻辑组件
 * 不同数据源类型所支持的过滤条件不同，过滤条件待数据输入算子拆分之后优化，2022-02-16
 * @Author: liyongshuai
 */
import React, { Component } from 'react';
import { Table, Form, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import SetValueByDataType from '../SetValueByDataType';
import ConditionSelect from './lib/ConditionSelect';
import DataValueType from './lib/DataValueType';
import { getTimeTypeByValue } from '@utils/timeUtil';
import { DATETIME_DATATYPE } from '@utils/datatype';
import { filterOptions } from './filter.const';

interface IProps extends FormComponentProps {
  dataSource: any[];
  variables: any[];
  updateRules: (newRules: any[]) => void;
  moduleType?: string;
  onSelectChange?: any;
}

class FilterTable extends Component<IProps> {
  public constructor(props: IProps) {
    super(props);
  }

  /**
   * @description: 校验配置信息是否正确
   * @return {boolean} 返回校验结果信息 true 标识配置信息正确 反之有误
   */
  public verifyRules = (): boolean => {
    let params = false;
    this.props.form.validateFields((errors: any) => {
      if (!errors) {
        params = true;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 根据行 key 值，更新dataSource
   */
  private updateRulesByKey = (newRecord: any) => {
    const { key } = newRecord;
    const newDataSource: any[] = _.map(this.props.dataSource, (item: any) =>
      item.key === key ? newRecord : item
    );
    this.props.updateRules(newDataSource);
  };

  /**
   * @description: 更改过滤条件
   * 如果修改过滤条件为 '为空'或者 '不为空' , 则清空输入的值
   */
  private handleTypeChange = (value: string, record: any) => {
    const newRecord = { ...record, type: value };
    if (_.includes(['null', 'nnull', 'min', 'max'], value)) {
      newRecord.value = undefined;
      newRecord.filterValueType = undefined;
    } else if (
      (!_.includes(['in', 'nin'], record.type) &&
        _.includes(['in', 'nin'], value)) ||
      (_.includes(['in', 'nin'], record.type) &&
        !_.includes(['in', 'nin'], value))
    ) {
      newRecord.value = undefined;
    }
    this.updateRulesByKey(newRecord);
  };

  /**
   * @description: 更改数值处理类型
   */
  private handleFilterValueTypeChange = (value: number, record: any) => {
    const newRecord = {
      ...record,
      filterValueType: value,
      value: undefined
    };
    this.updateRulesByKey(newRecord);
  };

  private handleValueChange = (v: any, record: any) => {
    const newRecord = {
      ...record
    };
    if (record.filterValueType === 2) {
      const selectedVb: any =
        _.find(this.props.variables, (item: any) => v === item.name) || {};
      const constType = _.get(selectedVb, ['constValue', 'type'], null);
      const value = {
        constType,
        variableName: v
      };
      newRecord.value = value;
    } else {
      newRecord.value = v;
    }
    this.updateRulesByKey(newRecord);
  };

  /**
   * @description: 移除元素
   * @param {object} record 每一个单元行
   */
  private handleDelete = (record: any): void => {
    const { dataSource, updateRules } = this.props;
    const { key } = record;
    const newDataSource = _.cloneDeep(dataSource);
    _.remove(newDataSource, (o: any) => o.key === key);
    updateRules(newDataSource);
  };

  private getColumns = () => {
    const {
      form: { getFieldDecorator },
      variables,
      moduleType
    } = this.props;
    return [
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 110,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '过滤条件',
        dataIndex: 'type',
        key: 'type',
        width: 120,
        render: (_value: any, record: any) => {
          const { type, key, dataType, filterValueType } = record;
          // 当选择的类型为常量，并且是时间类型，那么between nbetween 不能选择
          let typeOptions;
          if (moduleType !== 'inputSupos') {
            typeOptions = _.filter(
              filterOptions,
              o => !_.includes(['min', 'max'], o.key)
            );
          } else {
            typeOptions = _.filter(
              filterOptions,
              o =>
                !_.includes(
                  [
                    'in',
                    'nin',
                    'like',
                    'nlike',
                    'between',
                    'nbetween',
                    'null',
                    'nnull'
                  ],
                  o.key
                )
            );
          }
          const options = _.map(typeOptions, item => {
            if (_.includes(_.get(item, 'disableDataType', []), dataType)) {
              return { ...item, disabled: true };
            } else if (
              filterValueType === 1 &&
              _.includes(DATETIME_DATATYPE, dataType) &&
              (item.key === 'between' || item.key === 'nbetween')
            ) {
              return { ...item, disabled: true };
            } else if (
              filterValueType === 2 &&
              (item.key === 'in' || item.key === 'nin')
            ) {
              return { ...item, disabled: true };
            } else {
              return item;
            }
          });
          return (
            <ConditionSelect
              formKey={key}
              options={options}
              initialValue={type}
              getFieldDecorator={getFieldDecorator}
              onChange={v => {
                this.handleTypeChange(v, record);
              }}
            />
          );
        }
      },
      {
        title: '数值类型',
        dataIndex: 'filterValueType',
        key: 'filterValueType',
        width: 80,
        render: (_text: any, record: any) => {
          const { type, key, filterValueType } = record;
          if (_.includes(['null', 'nnull', 'min', 'max'], type)) {
            return;
          } else {
            let disabledValue: 'const' | 'let' | undefined;
            if (type === 'between' || type === 'nbetween') {
              disabledValue = 'const';
            } else if (type === 'in' || type === 'nin') {
              disabledValue = 'let';
            }
            return (
              <DataValueType
                formKey={key}
                initialValue={filterValueType}
                disableValue={disabledValue}
                getFieldDecorator={getFieldDecorator}
                onChange={value => {
                  this.handleFilterValueTypeChange(value, record);
                }}
              />
            );
          }
        }
      },
      {
        title: '值',
        dataIndex: 'value',
        key: 'value',
        render: (value: any, record: any): any => {
          const { filterValueType, type } = record;
          let dataType = record.dataType;
          if (_.includes(['null', 'nnull', 'min', 'max'], type)) {
            return;
          } else {
            let varType: string;
            let newVariables: any[] = [];
            if (filterValueType === 2) {
              varType = 'let';
              newVariables = _.filter(variables, (vb: any) => {
                const { dataType: vDataType, constValue } = vb;
                // 当变量类型为 Datetime 时,需要区分 年份/日期/日期时间/时间  时间范围(当天/近三天...)
                if (vDataType === 'Datetime') {
                  const { type: timeType, value: timeValue } = constValue;
                  if (timeType === 1) {
                    const valueDataType = getTimeTypeByValue(timeValue);
                    return (
                      valueDataType === dataType &&
                      type !== 'between' &&
                      type !== 'nbetween'
                    );
                  } else {
                    return (
                      dataType !== 'Time' &&
                      (type === 'between' || type === 'nbetween')
                    );
                  }
                } else {
                  return vDataType === dataType;
                }
              });
              value = _.get(value, 'variableName');
            } else {
              varType = 'const';
            }
            if (varType === 'const' && (type === 'in' || type === 'nin')) {
              dataType = 'String';
            }
            return (
              <SetValueByDataType
                formKey={`${record.key}_value`}
                size="small"
                value={value}
                dataType={dataType}
                varType={varType}
                getFieldDecorator={getFieldDecorator}
                variables={newVariables}
                onChange={(v: any) => this.handleValueChange(v, record)}
              />
            );
          }
        }
      },
      {
        title: '移除',
        align: 'center',
        width: 50,
        render: (_text: any, record: any) => (
          <Icon type="remove" onClick={this.handleDelete.bind(this, record)} />
        )
      }
    ];
  };

  public render() {
    const { dataSource } = this.props;
    const columns: any = this.getColumns();
    return (
      <Table
        size="small"
        className="task-base-table task-edit-table"
        rowKey="key"
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({ name: 'filterTable' })(FilterTable);
