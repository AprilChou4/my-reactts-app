/*
 * @Description: 数据加工 API 数据源输入列表模式
 * @Author: liyongshuai
 */
import React, { Component } from 'react';
import classnames from 'classnames';
import { Table, Form, Select, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import SetValueByDataType from '../SetValueByDataType';
import { TableCellText } from '@components/Table';
import { popupContainer } from '@utils/propUtil';
import { getTimeTypeByValue, transVarType2DataType } from '@utils/timeUtil';
import { baseTypes } from '../../../devTask.const';
import styles from './index.less';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps extends FormComponentProps {
  variables: any[];
  dataSource: any[];
  updateDataSource: (newDataSource: any[]) => void;
  editType?: boolean;
}

class ParamsTable extends Component<IProps> {
  public static defaultProps = {
    editType: false
  };

  public constructor(props: IProps) {
    super(props);
  }
  public verifyRules = () => {
    let params;
    const { form, dataSource } = this.props;
    form.validateFields((errors: any) => {
      if (!errors) {
        params = dataSource;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 根据索引，更新dataSource
   */
  private updateRulesByIndex = (index: number, newRecord: any) => {
    const newDataSource = _.cloneDeep(this.props.dataSource);
    newDataSource[index] = newRecord;
    this.props.updateDataSource(newDataSource);
  };

  private handleTypeChange = (value: number, record: any, index: number) => {
    const newRecord = { ...record, type: value, value: undefined };
    this.updateRulesByIndex(index, newRecord);
  };

  private handleDataTypeChange = (
    value: string,
    record: any,
    index: number
  ) => {
    const newRecord = { ...record, dataType: value, value: undefined };
    this.updateRulesByIndex(index, newRecord);
  };

  private handleValueChange = (v: any, record: any, index: number) => {
    const newRecord = {
      ...record
    };
    if (record.type === 1) {
      newRecord.value = v;
    } else if (record.type === 2) {
      const selectVB =
        _.find(this.props.variables, (item: any) => v === item.name) || {};
      newRecord.dataType = transVarType2DataType(selectVB);
      newRecord.value = v;
    }

    this.updateRulesByIndex(index, newRecord);
  };

  public getColumns = () => {
    const {
      form: { getFieldDecorator },
      variables,
      editType
    } = this.props;
    return [
      {
        title: '',
        dataIndex: 'required',
        key: 'required',
        width: 20,
        render: (text: number) => (
          <span className={text === 1 ? styles.formRequire : ''} />
        )
      },
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: 120,
        render: (text: string, record: any, index: number) => {
          if (editType) {
            return (
              <FormItem>
                {getFieldDecorator(`dataType_${record.name}`, {
                  initialValue: _.get(record, 'dataType', undefined),
                  rules: [
                    {
                      required: true,
                      message: '-请选择-'
                    }
                  ]
                })(
                  <Select
                    placeholder="-请选择-"
                    dropdownMatchSelectWidth={false}
                    onChange={(v: string) => {
                      this.handleDataTypeChange(v, record, index);
                    }}
                    getPopupContainer={popupContainer}
                  >
                    {_.map(baseTypes, item => (
                      <Option key={item} value={item}>
                        {item}
                      </Option>
                    ))}
                  </Select>
                )}
              </FormItem>
            );
          } else {
            return text;
          }
        }
      },
      {
        title: '处理方式',
        dataIndex: 'type',
        key: 'type',
        width: 120,
        render: (_text: any, record: any, index: number) => {
          return (
            <FormItem>
              {getFieldDecorator(`handle_type_${record.name}`, {
                initialValue: _.get(record, 'type', undefined),
                rules: [
                  {
                    required: true,
                    message: '-请选择-'
                  }
                ]
              })(
                <Select
                  placeholder="-请选择-"
                  size="small"
                  dropdownMatchSelectWidth={false}
                  onChange={(v: number) => {
                    this.handleTypeChange(v, record, index);
                  }}
                  getPopupContainer={popupContainer}
                >
                  <Option key={1} value={1}>
                    常量
                  </Option>
                  <Option key={2} value={2}>
                    变量
                  </Option>
                </Select>
              )}
            </FormItem>
          );
        }
      },
      {
        title: '值',
        dataIndex: 'value',
        key: 'value',
        render: (value: any, record: any, index: number) => {
          const { type, dataType } = record;
          let varType = '';
          if (type === 1) {
            varType = 'const';
          } else if (type === 2) {
            varType = 'let';
          }
          let newVariables: any[] = [];
          if (varType === 'let') {
            // 当变量是确定值且变量的类型与字段的数据类型一致时才允许选择
            newVariables = _.filter(variables, (item: any) => {
              if (item.dataType === 'Datetime') {
                const { type: iType, value: iValue } = item.constValue;
                if (iType === 1) {
                  const valueDataType = getTimeTypeByValue(iValue);
                  return valueDataType === dataType;
                } else {
                  return false;
                }
              } else {
                return item.dataType === dataType;
              }
            });
          }
          return (
            <SetValueByDataType
              formKey={`value_${index}_`}
              size="small"
              value={value}
              dataType={record.dataType}
              required={!!record.required}
              varType={varType}
              variables={newVariables}
              getFieldDecorator={getFieldDecorator}
              onChange={(v: any) => {
                this.handleValueChange(v, record, index);
              }}
            />
          );
        }
      }
    ];
  };

  public render() {
    const columns: any = this.getColumns();
    const { dataSource } = this.props;
    return (
      <Table
        size="small"
        className={classnames(
          'task-edit-table',
          dataSource.length && styles.inputParamsTable
        )}
        style={{
          marginBottom: '10px'
        }}
        rowKey={(_record, index) => `params_${index}`}
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({ name: 'ParamsTable' })(ParamsTable);
