import React, { Component } from 'react';
import { Tree, Button } from 'sup-ui';

import Icon from '@components/Icon';
import { isDefinedVar } from '../../module.helper';
import EditorNode from './EditorNode';
import VarSelect from './VarSelect';
import styles from './index.less';

const { TreeNode } = Tree;

interface IProps {
  json: any;
  originJson: any;
  variables: any[];
  onChange: (
    type: 'replace' | 'update' | 'delete',
    value: any,
    path: any[]
  ) => void;
  defaultSelectPath?: string;
}

interface IState {}

class JsonTree extends Component<IProps, IState> {
  /**
   * @description: 根据值获取具体的基本类型
   * @param {any} value JSON对象中key值对应的value
   * @return {string} 数据的基本类型
   */
  private getOriginValueType = (value: any) => {
    const valueType = typeof value;
    if (valueType === 'object') {
      const objectType = Object.prototype.toString.call(value);
      if (objectType === '[object Array]') {
        return 'Array';
      } else if (objectType === '[object Object]') {
        return 'Object';
      } else {
        return 'string';
      }
    } else {
      return valueType;
    }
  };

  /**
   * @description: 根据值的类型来判断具体的操作关系
   * 具体表现为当一个 key 对应的 value 是一个变量（#{VAR}）时
   * 将当前值替换为变量，当用户删除变量绑定的时候，那么将原始JSON对应的值再回退到当前JSON对象中
   * @param {any} path json 层级路径
   * @param {string} value 需要更改的值
   */
  private handleChangeMapping = (path: any[], value: string) => {
    this.props.onChange(value ? 'replace' : 'delete', value, path);
  };

  private handleDelete = (path: any[]) => {
    const { json } = this.props;
    const prePath = _.slice(path, 0, -1);
    const targetIndex = _.last(path);
    const targetArr = _.cloneDeep(
      _.isEmpty(prePath) ? json : _.get(json, prePath)
    );
    if (targetArr.length > 1) {
      _.remove(targetArr, (_item, index) => `${index}` === `${targetIndex}`);
      this.props.onChange('update', targetArr, prePath);
    }
  };

  /**
   * @description: 渲染对象类型的节点
   * @param {string} objKey 待循环处理的对象所对应的 key
   * @param {object} obj  待循环处理对象本身
   * @param {object} originObj 待循环处理对象的原始值，用于替换之后回退原始结构
   * @param {array} path 待循环处理对象在JSON中的路径信息
   * @param {boolean} isRemove 该对象是否可以删除的标识
   * @return: TreeNode
   */
  private renderObjectNode = (
    objKey: string | number,
    obj: any,
    originObj: any,
    path: string[] = [],
    isRemove = false
  ) => {
    const { variables, onChange } = this.props;
    const varValue = isDefinedVar(obj) ? obj : '';
    const parentNodePath = path.join('/');
    return (
      <TreeNode
        key={`${parentNodePath}`}
        title={
          <div
            className={styles.keyWrapper}
            // onClick={this.handleSelect.bind(this, nodePath, 'Object')}
          >
            <span className={styles.key}>
              {`${objKey} {} -${_.keys(originObj).length} keys`}
            </span>
            {isRemove && (
              <Icon
                type="remove"
                className={styles.icon}
                onClick={() => {
                  this.handleDelete(path);
                }}
              />
            )}
            <VarSelect
              value={varValue}
              options={_.filter(
                variables,
                item => item.type === 4 || item.type === 3
              )}
              onChange={this.handleChangeMapping.bind(this, path)}
            />
          </div>
        }
      >
        {!varValue &&
          _.map(obj, (oValue: any, oKey: string) => {
            const nodePathArray = _.concat(path, oKey);
            const originValue = _.get(originObj, oKey);
            const valueType = this.getOriginValueType(originValue);
            const nodePath = nodePathArray.join('/');
            if (valueType === 'Object') {
              return this.renderObjectNode(
                oKey,
                oValue,
                originValue,
                nodePathArray
              );
            } else if (valueType === 'Array') {
              if (this.getOriginValueType(originValue[0]) === 'Object') {
                return this.renderObjectArrayNode(
                  oKey,
                  oValue,
                  originValue,
                  nodePathArray
                );
              } else {
                return this.renderArrayNode(
                  oKey,
                  oValue,
                  originValue,
                  nodePathArray
                );
              }
            } else {
              return (
                <TreeNode
                  key={`${nodePath}`}
                  selectable={false}
                  title={
                    <EditorNode
                      itemKey={oKey}
                      value={oValue}
                      variables={variables}
                      onChange={(value: any) => {
                        onChange('update', value, nodePathArray);
                      }}
                    />
                  }
                />
              );
            }
          })}
      </TreeNode>
    );
  };

  /**
   * @description: 渲染数组对象接节点
   * 数组中的每个元素即为一个对象，只需要走渲染对象节点逻辑即可
   */
  private renderObjectArrayNode = (
    objKey: string,
    nowValue: any,
    originValue: any[],
    path: string[]
  ) => {
    const varValue = isDefinedVar(nowValue) ? nowValue : '';
    const { variables, onChange } = this.props;
    const nodePath = path.join('/');
    let nodes;
    if (!varValue) {
      nodes = _.map(nowValue, (item, index: number) =>
        this.renderObjectNode(
          index,
          item,
          _.get(originValue, index),
          _.concat(path, `${index}`),
          nowValue.length > 1
        )
      );
      nodes.push(
        <TreeNode
          key={`${nodePath}/${nowValue.length}`}
          className={styles.addNode}
          selectable={false}
          title={
            <Button
              size="small"
              onClick={() => {
                onChange(
                  'update',
                  _.cloneDeep(originValue[originValue.length - 1]),
                  _.concat(path, nowValue.length)
                );
              }}
            >
              添加
            </Button>
          }
        />
      );
    }

    return (
      <TreeNode
        key={`${nodePath}`}
        title={
          <div
            className={styles.keyWrapper}
            // onClick={this.handleSelect.bind(this, nodePath, 'Array')}
          >
            <span className={styles.key}>
              {`${objKey} [] -${originValue.length} objectItems`}
            </span>
            <VarSelect
              value={varValue}
              options={_.filter(variables, item => item.type === 3)}
              onChange={this.handleChangeMapping.bind(this, path)}
            />
          </div>
        }
      >
        {nodes}
      </TreeNode>
    );
  };

  /**
   * @description: 渲染纯数组节点
   * @param {string} objKey 该数组在所JSON中所对应的key值
   * @param {array} nowValue 待处理数组本身
   * @param {array} originValue 待处理数组在原始JSON中对应的值
   * @param {array} path 待处理数据在JSON 中的路径信息
   * @return: TreeNode
   */
  private renderArrayNode = (
    objKey: string,
    nowValue: any,
    originValue: any[],
    path: string[] = []
  ) => {
    const nodePath = path.join('/');
    const { variables, onChange } = this.props;
    nowValue = _.cloneDeep(nowValue);
    const varValue = isDefinedVar(nowValue) ? nowValue : '';
    let nodes: any[] = [];
    if (!varValue) {
      nodes = _.map(nowValue, (item, index) => (
        <TreeNode
          key={`${nodePath}/${index}`}
          selectable={false}
          title={
            <div className={styles.keyWrapper}>
              <EditorNode
                itemKey={`${index}`}
                value={item}
                onChange={value => {
                  nowValue[index] = value;
                  onChange('update', nowValue, path);
                }}
              />
              <Icon
                type="remove"
                className={styles.icon}
                onClick={() => {
                  nowValue.splice(index, 1);
                  onChange('update', nowValue, path);
                }}
              />
            </div>
          }
        />
      ));
      nodes.push(
        <TreeNode
          key={`${nodePath}/add`}
          selectable={false}
          title={
            <Button
              size="small"
              onClick={() => {
                nowValue.push('');
                onChange('update', nowValue, path);
              }}
            >
              添加
            </Button>
          }
        />
      );
    }
    return (
      <TreeNode
        key={`${nodePath}`}
        selectable={false}
        title={
          <div className={styles.keyWrapper}>
            <span className={styles.key}>
              {`${objKey} [] -${originValue.length} items`}:
            </span>
            <VarSelect
              value={varValue}
              options={_.filter(variables, item => item.type === 5)}
              onChange={this.handleChangeMapping.bind(this, path)}
            />
          </div>
        }
      >
        {nodes}
      </TreeNode>
    );
  };

  public render() {
    const { json, originJson, defaultSelectPath = '', variables } = this.props;
    const valueType = this.getOriginValueType(json);
    let isNoData = false;
    let nodes: any;
    // 判断JSON是object模式 还是 array模式
    if (valueType === 'Object') {
      isNoData = !_.keys(originJson).length;
      nodes = this.renderObjectNode('root', json, originJson, []);
    } else if (valueType === 'Array') {
      const [arrItem] = json;
      const arrItemType = this.getOriginValueType(arrItem);
      if (arrItemType === 'Object') {
        nodes = this.renderObjectArrayNode('root', json, originJson, []);
      } else {
        nodes = this.renderArrayNode('root', json, originJson, []);
      }
    } else {
      nodes = (
        <TreeNode
          key="root"
          title={
            <div
              className={styles.keyWrapper}
              // onClick={this.handleSelect.bind(this, nodePath, 'Object')}
            >
              <span className={styles.key}>
                {`root {} -${_.keys(originJson).length} keys`}
              </span>
              <VarSelect
                value={json}
                options={_.filter(
                  variables,
                  item => item.type === 4 || item.type === 3
                )}
                onChange={this.handleChangeMapping.bind(this, [])}
              />
            </div>
          }
        />
      );
    }
    return (
      <div className={styles.treeWrapper}>
        {!isNoData ? (
          <Tree
            defaultExpandAll
            blockNode
            defaultSelectedKeys={[defaultSelectPath]}
          >
            {nodes}
          </Tree>
        ) : (
          <div className={styles.empty}>
            <div className={styles.emptyImage} />
            <p>暂无数据</p>
          </div>
        )}
      </div>
    );
  }
}

export default JsonTree;
