import React, { FunctionComponent } from 'react';
import { Radio } from 'sup-ui';

import styles from './index.less';
const RadioGroup = Radio.Group;
const RadioButton = Radio.Button;

interface IProps {
  value: string;
  tabs: string[];
  handleChange: any;
}

const HeaderTab: FunctionComponent<IProps> = (props: IProps) => {
  const { tabs, value, handleChange } = props;
  return (
    <RadioGroup
      className={styles.headerTab}
      defaultValue="0"
      value={value}
      onChange={e => {
        handleChange(e.target.value);
      }}
    >
      {_.map(tabs, (item, index) => (
        <RadioButton key={index} value={`${index}`}>
          {item}
        </RadioButton>
      ))}
    </RadioGroup>
  );
};

export default HeaderTab;
