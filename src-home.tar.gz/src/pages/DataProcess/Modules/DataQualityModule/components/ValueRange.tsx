import React, { FC } from 'react';
import { QualityType } from '../index';
import RangeSelector from './RangeSelector';
import { Form } from 'sup-ui';
const FormItem = Form.Item;
interface IProps {
  form: any;
  values: QualityType;
  id: string;
  onChange: (type: string, value: any) => void;
}
/**
 * 值域范围检查组件
 * @param props
 * @returns
 */
const ValueRange: FC<IProps> = props => {
  const {
    id,
    form: { getFieldDecorator },
    values,
    onChange
  } = props;
  return (
    <FormItem label="值域" required>
      {getFieldDecorator(`ranges_${id}`, {
        initialValue: values.ranges || []
      })(
        <RangeSelector onChange={(range: any) => onChange('ranges', range)} />
      )}
    </FormItem>
  );
};

export default ValueRange;
