import React, { FC } from 'react';
import { Form, Row, Col, Select } from 'sup-ui';
import SetValueByDataType from '../../components/SetValueByDataType';
import {
  Actions,
  stringOP,
  datetimeOP,
  booleanOP,
  numericalOP
} from '../const/enum';
import {
  isDatetimeDataType,
  isNumericDataType,
  isBooleanDataType
} from '@utils/datatype';
import { getTimeTypeByValue } from '@utils/timeUtil';
import Fitting from '../../MissingValueFillModule/MissFillTable/lib/Fitting';
import Formula from '../../MissingValueFillModule/MissFillTable/lib/Formula';
const FormItem = Form.Item;
const { Option } = Select;
interface IProps {
  values: any;
  form: any;
  variables: any[];
  fields: any[];
  onChange: (type: string, data: any) => void;
}
const ExecuteAction: FC<IProps> = props => {
  const {
    form: { getFieldDecorator },
    values,
    values: { extendConfig, key },
    variables,
    fields,
    onChange
  } = props;

  let options = [];
  if (isNumericDataType(values.dataType)) {
    options = numericalOP;
  } else if (isDatetimeDataType(values.dataType)) {
    options = datetimeOP;
  } else if (isBooleanDataType(values.dataType)) {
    options = booleanOP;
  } else {
    options = stringOP;
  }

  const handleChange = (type: string, value: any) => {
    //TODO
    onChange(type, value);
  };

  const renderValue = (actionType: number) => {
    switch (actionType) {
      case 3: {
        //常量
        return (
          <SetValueByDataType
            size="small"
            formKey={`actionValue_${key}`}
            value={extendConfig.actionValue}
            dataType={values.dataType}
            varType="const"
            getFieldDecorator={getFieldDecorator}
            variables={[]}
            onChange={(val: any) => {
              handleChange('actionValue', val);
            }}
          />
        );
      }
      case 4: {
        //变量
        // 当变量是确定值且变量的类型与字段的数据类型一致时才允许选择
        const newVariables = _.filter(variables, (item: any) => {
          if (item.dataType === 'Datetime') {
            const { type: iType, value: iValue } = item.constValue;
            if (iType === 1) {
              const valueDataType = getTimeTypeByValue(iValue);
              return valueDataType === values.dataType;
            } else {
              return false;
            }
          } else {
            return item.dataType === values.dataType;
          }
        });
        return (
          <SetValueByDataType
            size="small"
            formKey={`actionValue_${key}`}
            value={extendConfig.actionValue}
            dataType={values.dataType}
            varType="let"
            getFieldDecorator={getFieldDecorator}
            variables={newVariables}
            onChange={(val: any) => {
              handleChange('actionValue', val);
            }}
          />
        );
      }
      case 8: {
        //拟合
        return (
          <Fitting
            formKey={`actionValue_${key}`}
            getFieldDecorator={getFieldDecorator}
            initialValue={_.get(extendConfig, 'actionValue', undefined)}
            options={_.filter(
              fields,
              field =>
                isNumericDataType(field.dataType) && field.name !== values.name
            )}
            onChange={val => {
              handleChange('actionValue', val);
            }}
          />
        );
      }
      case 9: {
        // 自定义
        return (
          <Formula
            initialValue={_.get(extendConfig, 'actionValue', undefined)}
            options={fields}
            onChange={val => {
              handleChange('actionValue', val);
            }}
          />
        );
      }
      default:
        return null;
    }
  };

  return (
    <div>
      <FormItem label="执行动作">
        {getFieldDecorator(`action_${key}`, {
          initialValue: extendConfig?.action,
          rules: [
            {
              required: true,
              message: `请选择执行动作`
            }
          ]
        })(
          <Select
            placeholder="-请选择-"
            onChange={val => handleChange('action', val)}
          >
            {Actions.map(item => (
              <Option key={item.key} value={item.key}>
                {item.showName}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      {extendConfig?.action === 1 && (
        // 处理方式
        <FormItem>
          {getFieldDecorator(`actionType_${key}`, {
            initialValue: extendConfig?.actionType,
            rules: [
              {
                required: true,
                message: '-请选择-'
              }
            ]
          })(
            <Select
              size="small"
              placeholder="-请选择-"
              onChange={val => handleChange('actionType', val)}
            >
              {_.map(options, (item: any) => (
                <Option key={item.key} value={item.key}>
                  {item.label}
                </Option>
              ))}
            </Select>
          )}
        </FormItem>
      )}
      {extendConfig?.action === 1 &&
        extendConfig?.actionType &&
        renderValue(extendConfig?.actionType)}
    </div>
  );
};

export default ExecuteAction;
