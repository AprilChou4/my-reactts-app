import React, { Component } from 'react';
import { Select, Input } from 'sup-ui';
import { leftRange, rightRange } from '../const/enum';
import styles from './index.less';

const Option = Select.Option;

interface IProps {
  value: any;
  onChange: any;
  disable: boolean;
}

interface IState {}

class Ranger extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public handleValueChange = (key: string, value: any) => {
    const {
      onChange,
      value: { key: id }
    } = this.props;

    onChange(id, key, value);
  };

  public render() {
    const {
      disable,
      value: { leftOper, leftVal, rightOper, rightVal }
    } = this.props;
    const cssText = leftOper === '3' && rightOper === '3' ? { flex: 1 } : {};

    return (
      <div className={styles.ranger}>
        <Select
          disabled={disable}
          value={leftOper}
          onChange={(val: any) => this.handleValueChange('leftOper', val)}
          style={cssText}
        >
          {leftRange.map(r => (
            <Option
              value={r.key}
              key={r.key}
              disabled={r.key === '3' && rightOper === '3'}
            >
              {r.showName}
            </Option>
          ))}
        </Select>
        {leftOper !== '3' && (
          <Input
            disabled={disable}
            value={leftVal}
            onChange={(e: any) =>
              this.handleValueChange('leftVal', e.target.value)
            }
            placeholder="请输入数值"
            style={{ borderLeft: '1px solid #dfe3e9' }}
          />
        )}
        <div className={styles.separate}>,</div>
        {rightOper !== '3' && (
          <Input
            disabled={disable}
            value={rightVal}
            onChange={(e: any) =>
              this.handleValueChange('rightVal', e.target.value)
            }
            placeholder="请输入数值"
            style={{ borderRight: '1px solid #dfe3e9' }}
          />
        )}
        <Select
          disabled={disable}
          value={rightOper}
          onChange={(val: any) => this.handleValueChange('rightOper', val)}
          style={cssText}
        >
          {rightRange.map(r => (
            <Option
              value={r.key}
              key={r.key}
              disabled={r.key === '3' && leftOper === '3'}
            >
              {r.showName}
            </Option>
          ))}
        </Select>
      </div>
    );
  }
}

export default Ranger;
