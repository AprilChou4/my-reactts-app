import React, { FC } from 'react';
import { Form, Select, Input } from 'sup-ui';
import { QualityRuleEnum } from '../const/enum';
import DataFormat from '../components/DataFormat';
import Empty from '../components/Empty';
import ValueRange from '../components/ValueRange';
import ExecuteAction from '../components/ExecuteAction';
import Icon from '@components/Icon';
import { QualityRuleType } from '../index';
import styles from './index.less';
const FormItem = Form.Item;
const TextArea = Input.TextArea;
const { Option } = Select;

interface IProps {
  index: number;
  ruleInfo: QualityRuleType;
  fields: any[];
  variables: any[];
  form: any;
  onChange: (i: number, data: any) => void;
  onDelete: (i: number) => void;
}

const QualityRule: FC<IProps> = props => {
  const { ruleInfo, fields, form, index, onChange, onDelete, variables } =
    props;
  const { getFieldDecorator } = form;
  const { key } = ruleInfo;
  const handleChange = (type: string, data: any) => {
    let newD: any = {};
    if (type === 'ruleField') {
      const field = _.find(fields, val => val.name === data);
      if (field) {
        newD = {
          ...field
        };
      }
    }
    newD = {
      ...newD,
      ...ruleInfo,
      extendConfig: { ...ruleInfo.extendConfig, [type]: data }
    };

    onChange(index, newD);
  };

  const renderDataComp = () => {
    const { extendConfig } = ruleInfo;

    switch (extendConfig?.ruleType) {
      case 1:
        return <Empty values={extendConfig} onChange={handleChange} />;
      case 2:
        return null; //重复值检查无需其他
      case 3:
        return (
          <ValueRange
            form={form}
            values={extendConfig}
            id={key}
            onChange={handleChange}
          />
        );
      case 4:
        return (
          <DataFormat
            form={form}
            values={extendConfig}
            id={key}
            onChange={handleChange}
          />
        );
      case 5:
        return (
          <FormItem label="枚举值" required>
            {getFieldDecorator(`enums_${key}`, {
              initialValue: extendConfig?.enums,
              rules: [{ required: true, message: `请填写枚举值` }]
            })(
              <TextArea
                autosize={{ minRows: 3, maxRows: 6 }}
                placeholder="如: 昨天,今天,明天 请用英文逗号分隔"
                onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) =>
                  handleChange('enums', event.target.value)
                }
              />
            )}
          </FormItem>
        );
    }

    return null;
  };

  return (
    <div className={styles.qualityRuleContainer}>
      <div className={styles.title}>
        <h3>质检规则{index + 1}</h3>
        <Icon type="remove" onClick={() => onDelete(index)} />
      </div>
      <FormItem label={'规则类型'}>
        {getFieldDecorator(`ruleType_${key}`, {
          initialValue: ruleInfo?.extendConfig?.ruleType,
          rules: [
            {
              required: true,
              message: '请选择'
            }
          ]
        })(
          <Select
            size="small"
            placeholder="-请选择-"
            onChange={value => handleChange('ruleType', value)}
          >
            {_.map(QualityRuleEnum, (item: any) => (
              <Option key={item.key} value={item.key}>
                {item.showName}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      <FormItem label={'检查字段'}>
        {getFieldDecorator(`ruleField_${key}`, {
          initialValue: ruleInfo?.extendConfig?.ruleField,
          rules: [
            {
              required: true,
              message: '请选择'
            }
          ]
        })(
          <Select
            size="small"
            placeholder="-请选择-"
            onChange={value => handleChange('ruleField', value)}
          >
            {_.map(fields, (item: any) => (
              <Option key={item.name} value={item.name}>
                {item.name}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      {renderDataComp()}
      {ruleInfo?.extendConfig?.ruleType && (
        <ExecuteAction
          form={form}
          values={ruleInfo}
          variables={variables}
          fields={fields}
          onChange={handleChange}
        />
      )}
    </div>
  );
};

export default QualityRule;
