import React, { Component } from 'react';
import { Provider } from 'mobx-react';

import MsgQueueInputForm from './MsgQueueInputForm';
import Fieldset from './Fieldset';
import { IModuleProps } from '../../module';
import MsgQueueInputStore from '../stores/msgQueueInputStore';
import MoreSet from './MoreSet';
import { message } from 'sup-ui';

interface IProps extends IModuleProps {
  initMapping: (mappingParams: any) => void;
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
}

interface IState {
  previewVisible: boolean;
}

class MsgQueueInput extends Component<IProps, IState> {
  private msgQueueInputStore: any;
  private msgQueueRef: any;
  private fieldRef: any;
  private moreSetRef: any;

  public constructor(props: IProps) {
    super(props);
    this.msgQueueInputStore = new MsgQueueInputStore({
      dataModuleConfig: props.dataModuleConfig,
      initMapping: props.initMapping,
      handleConfigChange: props.handleConfigChange
    });
    this.state = {
      previewVisible: false
    };
  }

  /**
   * @description: 数据输入保存校验
   * 先校验 form 表单，再校验输出的字段有无过滤/排序操作 （rules:过滤，orders:排序）
   * 校验不成功返回 undefined，反之返回相应的 formData
   * @return: undefined / config
   */
  public saveVerify = () => {
    const formData = this.msgQueueRef.saveVerify();
    const moreSetData = this.moreSetRef.saveVerify();
    const { originStruct } = this.msgQueueInputStore;
    if (!formData) return;

    const flag = _.every(originStruct, o => {
      return !!o.name;
    });
    if (!flag) {
      message.error('字段设置变量名必填');
      return;
    }

    const uniqList = _.unionBy(originStruct, 'name');
    if (uniqList?.length !== originStruct?.length) {
      message.error('字段设置变量名不能重复');
      return;
    }

    const config = {
      ...formData,
      ...moreSetData,
      originStruct
    };
    return config;
  };

  public render() {
    return (
      <Provider msgQueueInputStore={this.msgQueueInputStore}>
        <MsgQueueInputForm
          wrappedComponentRef={(ref: any) => {
            if (!this.msgQueueRef) {
              this.msgQueueRef = ref;
            }
          }}
          handleConfigChange={this.props.handleConfigChange}
          updateNodeNameByTag={this.props.updateNodeNameByTag}
        />

        {/* 字段设置 */}
        <Fieldset
          handleConfigChange={this.props.handleConfigChange}
          ref={(ref: any) => {
            if (!this.fieldRef) {
              this.fieldRef = ref;
            }
          }}
        />
        <MoreSet
          wrappedComponentRef={(ref: any) => {
            if (!this.moreSetRef) {
              this.moreSetRef = ref;
            }
          }}
        />
      </Provider>
    );
  }
}

export default MsgQueueInput;
