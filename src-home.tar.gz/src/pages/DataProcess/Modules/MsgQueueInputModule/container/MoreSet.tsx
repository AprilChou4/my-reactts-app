import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Form, Radio } from 'sup-ui';
import TaskTitle from '../../components/TaskTitle';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import styles from '../style.less';
const FormItem = Form.Item;
interface IProps extends FormComponentProps {
  msgQueueInputStore?: any;
}

interface IState {}

@inject('msgQueueInputStore')
@observer
class MoreSet extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  /**
   * @description: sql 输入表单保存时校验
   * @return: formData/undefined
   * 当form 表单的信息校验通过之后 返回 form 表单对象，反之返回 null
   */
  public saveVerify = () => {
    let params: any;
    const { form } = this.props;
    form.validateFields((errors, values) => {
      if (errors) return;

      params = {
        ...values
      };
    });
    return params;
  };

  public render() {
    const { form, msgQueueInputStore } = this.props;
    const { handleConfigChange, formData } = msgQueueInputStore;
    const { offset } = formData;
    const { getFieldDecorator } = form;
    return (
      <div className={styles.MoreSetContainer}>
        <TaskTitle index={3} subTitle="更多设置" />
        <Form className={styles.formWrapper}>
          <FormItem label="初始Offset">
            {getFieldDecorator('offset', {
              initialValue: offset || 'latest',
              rules: [{ required: true }]
            })(
              <Radio.Group onChange={handleConfigChange}>
                <Radio value="earliest">earliest</Radio>
                <Radio value="latest">latest</Radio>
              </Radio.Group>
            )}
          </FormItem>
        </Form>
      </div>
    );
  }
}

export default Form.create<IProps>()(MoreSet);
