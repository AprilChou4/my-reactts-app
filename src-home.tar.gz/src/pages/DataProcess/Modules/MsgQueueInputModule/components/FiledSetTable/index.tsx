import React, { Component } from 'react';
import { Form } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import Icon from '@components/Icon';
import EditTable from '@components/Table/EditTable';
import { dataTypes } from '../../../../devTask.const';

interface IProps extends FormComponentProps {
  dataSource: any[];
  // 更新字段列表
  updateFieldList: (rules: any[]) => void;
}

class FieldSetTable extends Component<IProps> {
  /**
   *  单行操作保存
   * @param row  最新的行数据
   */
  public onRowSave = (row: any) => {
    const { dataSource, updateFieldList } = this.props;
    const newDataSource = _.map(dataSource, (item: any) => {
      return row.key === item.key ? { ...item, ...row } : item;
    });
    updateFieldList(newDataSource);
  };

  /**
   * @description: 删除某一行数据 将最新的数据结构传递给父组件
   * @param {object} record 某一行数据
   */
  private delRecord = (record: any) => {
    const { dataSource, updateFieldList } = this.props;
    const newDataSource = _.filter(
      dataSource,
      (item: any) => item.key !== record.key
    );
    updateFieldList(newDataSource);
  };

  /**
   * 校验变量名是否重名
   * @param _rule
   * @param value
   * @param callback
   */
  public handleValidNameRepeat = (
    _rule: any,
    value: any,
    callback: any,
    record: any
  ) => {
    const { dataSource } = this.props;
    if (value) {
      const verifyRes = _.some(dataSource, (i: any) => {
        return i.key !== record.key && i.name === value;
      });
      if (verifyRes) {
        callback('变量不能重名');
      } else {
        callback();
      }
    } else {
      callback();
    }
  };
  private getColumns = () => {
    return [
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 110,
        editable: true,
        isToggleEdit: true,
        type: 'input',
        fieldDecorator: (record: any) => {
          return {
            rules: [
              {
                required: true,
                message: '变量名不能为空',
                whitespace: true
              },
              {
                validator: (_rule: any, value: any, callback: any) =>
                  this.handleValidNameRepeat(_rule, value, callback, record)
              }
            ]
          };
        }
      },
      {
        title: '设置类型',
        dataIndex: 'dataType',
        width: 100,
        key: 'dataType',
        editable: true,
        type: 'select',
        trigger: 'onChange',
        config: {
          selectOptions: dataTypes,
          allowClear: false
        }
      },
      {
        title: '描述',
        dataIndex: 'showName',
        key: 'showName',
        // width: 80,
        editable: true,
        type: 'input',
        isToggleEdit: true
      },
      {
        title: '移除',
        width: 50,
        align: 'center',
        render: (_text: any, record: any) => (
          <Icon
            type="remove"
            style={{ verticalAlign: 'middle' }}
            onClick={e => {
              e.stopPropagation();
              this.delRecord(record);
            }}
          />
        )
      }
    ];
  };

  public render() {
    const { dataSource } = this.props;
    const columns: any = this.getColumns();
    return (
      <>
        <EditTable
          size="small"
          className="task-edit-table"
          rowKey="key"
          columns={columns}
          dataSource={dataSource}
          onRowSave={this.onRowSave}
          // scroll={{ y: 400 }}
          pagination={false}
          // getForm={(f: any) => (this.form = f)}
          style={{ width: 500 }}
        />
      </>
    );
  }
}

export default Form.create<IProps>({ name: 'varSetTable' })(FieldSetTable);
