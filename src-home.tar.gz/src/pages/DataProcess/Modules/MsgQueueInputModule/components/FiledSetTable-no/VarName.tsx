import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';

const FormItem = Form.Item;

export interface IVarNameProps {
  dataSource: any[];
  record: any;
  getFieldDecorator: any;
  onChange: (value: string) => void;
}
interface IState {
  editing: boolean;
  hasError: boolean;
}

class VarName extends Component<IVarNameProps, IState> {
  public constructor(props: IVarNameProps) {
    super(props);
    const value = _.get(props, 'record.variableName');
    this.state = {
      editing: _.isEmpty(value),
      hasError: _.isEmpty(value)
    };
  }

  private toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing });
  };

  private toggleStatus = (value: boolean) => {
    this.setState({
      hasError: value
    });
  };

  private handleValidNameRepeat = (_rule: any, value: any, callback: any) => {
    const { dataSource, record } = this.props;
    if (value !== '') {
      const verifyRes = _.some(
        dataSource,
        (i: any) => i.key !== record.key && i.variableName === value
      );
      if (verifyRes) {
        callback(true);
        this.toggleStatus(true);
      } else {
        callback();
        this.toggleStatus(false);
      }
    } else {
      callback(true);
      this.toggleStatus(true);
    }
  };

  private handleChange = (value: string) => {
    const { record, onChange } = this.props;
    if (!this.state.hasError) {
      this.toggleEdit();
      // record.variableName = value;

      onChange({ ...record, variableName: value });
    }
  };

  public render() {
    const { editing } = this.state;
    const { record, getFieldDecorator } = this.props;
    const variableName = _.get(record, 'variableName');
    return editing ? (
      <FormItem>
        {getFieldDecorator(`name_${record.key}`, {
          initialValue: variableName,
          rules: [
            {
              required: true,
              message: '变量名不能为空.',
              whitespace: true
            },
            {
              message: '变量不能重名',
              validator: this.handleValidNameRepeat
            }
          ],
          validateTrigger: ['onChange', 'onBlur']
        })(
          <Input
            autoFocus
            size="small"
            onBlur={(e: any) => {
              e.target.value && this.handleChange(e.target.value);
            }}
            onPressEnter={(e: any) => {
              e.target.value && this.handleChange(e.target.value);
            }}
          />
        )}
      </FormItem>
    ) : (
      <div
        className="editable-cell-value-wrap ellipsis-1"
        style={{
          paddingRight: 24,
          height: '24px',
          lineHeight: '24px'
        }}
        onClick={this.toggleEdit}
      >
        {variableName}
      </div>
    );
  }
}

export default VarName;
