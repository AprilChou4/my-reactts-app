import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';

import { getDataSourceListByType } from '../../module.service';

class FileOutputStore {
  private readonly initMapping: (params: any) => void;
  private readonly handleConfigChange: any;
  public mapping: any[] = [];
  @observable public originStruct: any[] = [];
  @observable public targetStruct: any[] = [];
  @observable public formData: any = {};
  @observable public formLoading = false;
  @observable public sourceTypes: any[] = [];
  @observable public sourceNames: any[] = [];
  @observable public sourceNameGroup: { [propName: string]: any[] } = {};

  public constructor({
    originStruct,
    dataModuleConfig,
    initMapping,
    handleConfigChange
  }: any) {
    const {
      mapping = [],
      targetStruct = [],
      extendConfig = {},
      ...restProps
    } = _.cloneDeep(dataModuleConfig);
    runInAction(() => {
      if (!restProps.inputType || restProps.inputType !== 4) {
        this.formData = {
          inputType: 4
        };
        this.mapping = [];
        this.targetStruct = [];
      } else {
        this.formData = { ...restProps, ...extendConfig };
        this.mapping = mapping;
        this.targetStruct = targetStruct;
      }
      this.originStruct = originStruct;
    });
    this.initMapping = initMapping;
    this.handleConfigChange = handleConfigChange;
    this.getDataSourceListByType();
  }

  /**
   * @description: 根据不同的输入类型获取数据源列表
   * @param {string} type 默认为 sql
   */
  @action.bound
  public async getDataSourceListByType() {
    runInAction(() => {
      this.formLoading = true;
    });
    const res = await getDataSourceListByType({ dataType: 'file' });
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.formLoading = false;
      });
      return;
    }
    const { sqlTypeList, table } = data.map;
    runInAction(() => {
      this.formLoading = false;
      // ftp(44)和smb(42)暂不支持输出
      this.sourceTypes = _.filter(
        sqlTypeList,
        v => ![42, 44].includes(v.sqlType)
      );
      this.sourceNames = _.filter(table, v => ![42, 44].includes(v.sqlType));
      this.sourceNameGroup = _.groupBy(table, 'sqlType');
    });
  }

  /**
   * @description: 输入类型切换
   */
  @action.bound
  public handleSourceKindChange = (value: number) => {
    runInAction(() => {
      this.formData = {
        inputType: value
      };
      this.initTargetStruct();
    });
  };

  /**
   * @description: 数据源类型切换
   */
  @action.bound
  public handleSourceTypeChange = (value: string) => {
    if (!value) return;
    runInAction(() => {
      this.sourceNames = this.sourceNameGroup[value];
    });
  };

  @action.bound
  public updateOriginStruct = (struct: any[] = []) => {
    this.originStruct = struct;
    this.initMapping({
      originStruct: this.originStruct,
      mapping: this.mapping,
      targetStruct: this.targetStruct
    });
    this.handleConfigChange();
  };

  @action.bound
  public updateTargetStruct = (struct: any[]) => {
    this.targetStruct = struct;
    this.handleConfigChange();
  };

  public updateMapping = (mapping: any[]) => {
    this.mapping = mapping;
  };

  @action.bound
  public initTargetStruct = (struct: [] = []) => {
    this.targetStruct = struct;
    this.mapping = [];
    this.initMapping({
      targetStruct: struct,
      mapping: []
    });
    this.handleConfigChange();
  };
}

export default FileOutputStore;
