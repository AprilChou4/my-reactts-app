import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';

import {
  getDataSourceListByType,
  getTableListBySourceName,
  getTableFieldInfo
} from '../../module.service';

class WmOutputStore {
  private readonly initMapping: (params: any) => void;
  private readonly handleConfigChange: any;
  public mapping: any[] = [];
  public originStruct: any[] = [];
  @observable public formLoading = false;
  @observable public tableLoading = false;
  @observable public targetStruct: any[] = [];
  @observable public formData: any = {};
  @observable public sourceTypes: any[] = [];
  @observable public sourceNames: any[] = [];
  @observable public tableNameList: any[] = [];
  @observable public sourceNameGroup: { [propName: string]: any[] } = {};

  public constructor({
    originStruct,
    dataModuleConfig,
    initMapping,
    handleConfigChange
  }: any) {
    const {
      mapping = [],
      targetStruct = [],
      extendConfig = {},
      ...restProps
    } = _.cloneDeep(dataModuleConfig);
    runInAction(() => {
      if (!restProps.inputType || restProps.inputType !== 10) {
        this.formData = {
          inputType: 10
        };
        this.mapping = [];
        this.targetStruct = [];
      } else {
        this.formData = { ...restProps, ...extendConfig };
        this.mapping = mapping;
        this.targetStruct = targetStruct;
      }
      this.originStruct = originStruct;
    });
    this.initMapping = initMapping;
    this.handleConfigChange = handleConfigChange;
    this.getDataSourceListByType();
  }

  /**
   * @description: 根据不同的输入类型获取数据源列表
   * @param {string} type 默认为 sql
   */
  @action.bound
  public async getDataSourceListByType() {
    this.formLoading = true;
    const res = await getDataSourceListByType({ dataType: 'wm' });
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.formLoading = false;
      });
      return;
    }
    const { sqlTypeList, table } = data.map;
    runInAction(() => {
      this.formLoading = false;
      this.sourceTypes = sqlTypeList;
      this.sourceNames = table;
      this.sourceNameGroup = _.groupBy(table, 'sqlType');
      this.formData = {
        sourceType: sqlTypeList[0]?.sqlType,
        sourceId: table[0]?.id,
        ...this.formData
      };
    });
    const { sourceKind, sourceType, sourceName, sourceId } = this.formData;
    //if (tableViewName) {
    const params = {
      restype: sourceKind,
      sqlType: sourceType,
      resname: sourceName,
      id: sourceId
    };
    this.getTableListBySourceName(params);
    //}
  }

  /**
   * @description: 输入类型切换
   * @param {type}
   * @return:
   */
  @action.bound
  public handleSourceKindChange = (value: number) => {
    runInAction(() => {
      this.formData = {
        inputType: value
      };
      this.initTargetStruct();
    });
  };

  /**
   * @description: 数据源类型切换
   * @param {type}
   * @return:
   */
  @action.bound
  public handleSourceTypeChange = (value: string) => {
    if (!value) return;
    runInAction(() => {
      this.sourceNames = this.sourceNameGroup[value];
      this.tableNameList = [];
    });
  };

  /**
   * @description: 根据选择数据源名称拉取对应数据库表的列表
   * @param {object} params restype 输入类型
   * @param {string} restype 输入类型 (sql/nosql/...)
   * @param {string} sqlType 数据源类型 (mysql/orcal/postgrsql...)
   * @param {string} resName 数据源名称 (数据库)
   * @param {number} id 对应表的id
   */
  @action.bound
  public async getTableListBySourceName(params: any) {
    this.formLoading = true;
    const res = await getTableListBySourceName(params);
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.formLoading = false;
        this.tableNameList = [];
      });
      return;
    }
    const { tableNameList = [] } = data.map;
    runInAction(() => {
      this.formLoading = false;
      this.tableNameList = tableNameList;
    });
  }

  /**
   * @description: 获取对应数据表下的字段详细信息
   * @param {object} params 请求参数
   */
  @action.bound
  public async getTableFieldInfo(params: any) {
    this.tableLoading = true;
    const res = await getTableFieldInfo(params);
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.tableLoading = false;
      });
      return;
    }
    const { struct } = data.map;
    runInAction(() => {
      this.tableLoading = false;
      this.targetStruct = struct;
      this.mapping = [];
      this.initMapping({
        mapping: this.mapping,
        targetStruct: struct
      });
    });
  }

  @action.bound
  public updateFormData = (updateItem: any) => {
    this.formData = Object.assign(this.formData, updateItem);
  };

  @action.bound
  public updateOriginStruct = (struct: any[] = []) => {
    this.originStruct = struct;
    this.initMapping({
      originStruct: this.originStruct,
      targetStruct: this.targetStruct
    });
    this.handleConfigChange();
  };

  @action.bound
  public updateTargetStruct = (struct: any[]) => {
    this.targetStruct = struct;
    this.handleConfigChange();
  };

  public updateMapping = (mapping: any[]) => {
    this.mapping = mapping;
  };

  @action.bound
  public initTargetStruct = (struct: [] = []) => {
    this.targetStruct = struct;
    this.mapping = [];
    this.initMapping({
      targetStruct: struct,
      mapping: []
    });
    this.handleConfigChange();
  };
}

export default WmOutputStore;
