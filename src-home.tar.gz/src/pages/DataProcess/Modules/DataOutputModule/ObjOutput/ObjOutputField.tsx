import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Button, Table } from 'sup-ui';

import { TableCellText } from '@components/Table';
import TaskTitle from '../../components/TaskTitle';
import styles from './index.less';

const columns = [
  {
    title: '属性',
    dataIndex: 'showName',
    width: 130,
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '别名',
    dataIndex: 'name',
    width: 130,
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '数据类型',
    dataIndex: 'dataType',
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  }
];

interface IProps {
  onPreview: () => void;
  outputStore?: any;
}
interface IState {
  selectedRowKeys: [];
}

@inject('outputStore')
@observer
class ObjOutputField extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      selectedRowKeys: []
    };
  }

  public updateSelectedRowKeys = (selectedRowKeys: []): void => {
    this.setState({ selectedRowKeys });
  };

  public render() {
    const {
      outputStore: { targetStruct, tableLoading, instanceInfo }
    } = this.props;
    const { selectedRowKeys } = this.state;
    const rowSelection: any = {
      columnWidth: '50px',
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      getCheckboxProps: (record: any): any => {
        if (record.dataType === 'Bytes') return { disabled: true };
      }
    };
    return (
      <div className={styles.fieldWrapper}>
        <TaskTitle
          index={2}
          subTitle="目标源关系字段"
          rightNode={
            <Button
              className={styles.outPutFieldBtn}
              size="small"
              disabled={
                !targetStruct.length || !_.isNil(instanceInfo.system_id)
              }
              onClick={this.props.onPreview}
            >
              预览
            </Button>
          }
        />
        <Table
          size="small"
          rowKey="name"
          className={styles.fieldTable}
          dataSource={targetStruct}
          columns={columns}
          loading={tableLoading}
          rowSelection={rowSelection}
          pagination={false}
        />
      </div>
    );
  }
}

export default ObjOutputField;
