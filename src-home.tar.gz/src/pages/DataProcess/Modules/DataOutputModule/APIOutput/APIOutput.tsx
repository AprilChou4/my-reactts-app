import React, { Component, Fragment } from 'react';
import { inject, observer } from 'mobx-react';
import { message, Spin } from 'sup-ui';

import TaskTitle from '../../components/TaskTitle';
import APIOutputForm from './APIOutputForm';
import RestfulOutputParams from './RestfulOutputParams';
import OutputParamsTable from './OutputParamsTable';

interface IProps {
  variables: any[];
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
  outputStore?: any;
}

interface IState {}

@inject('outputStore')
@observer
class APIOutput extends Component<IProps, IState> {
  private apiOutputFormRef: any;
  private restfulRef: any;

  public saveVerify = () => {
    const formData = this.apiOutputFormRef.saveVerify();
    if (formData.sourceType === 6) {
      return { ...formData };
    } else if (formData.sourceType === 7) {
      const params = this.restfulRef.verifyRules();
      if (!params) return;
      return { ...formData, ...params };
    } else {
      message.warning('数据源类型选择错误！');
      return;
    }
  };

  public render() {
    const { outputStore, variables, handleConfigChange, updateNodeNameByTag } =
      this.props;
    const {
      inParamsMode,
      formData,
      headerParams,
      inParams,
      jsonParams,
      targetStruct,
      requestUrl,
      originJson,
      dataRules,
      pageNo,
      cyclicalExec,
      updatePageNo,
      inParamsDataType,
      updateRequestUrl,
      updateHeaderParams,
      updateJsonParams,
      updateBodyParams,
      initTargetStruct
    } = outputStore;
    return (
      <Spin
        tip="Loading..."
        spinning={outputStore.formLoading}
        wrapperClassName="formLoading"
      >
        <APIOutputForm
          wrappedComponentRef={(ref: any) => {
            this.apiOutputFormRef = ref;
          }}
          outputStore={outputStore}
          handleConfigChange={handleConfigChange}
          updateNodeNameByTag={updateNodeNameByTag}
        />
        {formData.sourceType === 7 && (
          <RestfulOutputParams
            ref={(ref: any) => {
              this.restfulRef = ref;
            }}
            inParamsMode={inParamsMode}
            variables={variables}
            headerParams={headerParams}
            bodyParams={targetStruct}
            jsonParams={jsonParams}
            originJson={originJson}
            inParams={inParams}
            requestUrl={requestUrl}
            dataRules={dataRules}
            pageNo={pageNo}
            cyclicalExec={cyclicalExec}
            updatePageNo={updatePageNo}
            inParamsDataType={inParamsDataType}
            updateRequestUrl={updateRequestUrl}
            updateHeaderParams={updateHeaderParams}
            updateBodyParams={updateBodyParams}
            handleConfigChange={handleConfigChange}
            updateJsonParams={updateJsonParams}
            initTargetStruct={initTargetStruct}
          />
        )}
        {formData.sourceType !== 7 && (
          <Fragment>
            <TaskTitle index={2} subTitle="目标源入参" />
            <OutputParamsTable dataSource={targetStruct} />
          </Fragment>
        )}
      </Spin>
    );
  }
}

export default APIOutput;
