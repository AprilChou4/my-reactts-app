/*
 * @Description: 数据加工 API 数据源输入列表模式
 * @Author: liyongshuai
 */
import React, { Component } from 'react';
import classnames from 'classnames';
import { Table, Form, Select, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import { TableCellText } from '@components/Table';
import { popupContainer } from '@utils/propUtil';
import { baseTypes } from '../../../devTask.const';
import styles from './APIOutput.less';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps extends FormComponentProps {
  dataSource: any[];
  handleConfigChange: () => void;
  updateDataSource: (dataSource: any[]) => void;
  editType?: boolean;
}

class APIOutputBodyTable extends Component<IProps> {
  public static defaultProps = {
    editType: false
  };

  public constructor(props: IProps) {
    super(props);
  }
  public verifyRules = () => {
    let params;
    const { form, dataSource } = this.props;
    form.validateFields((errors: any) => {
      if (!errors) {
        params = dataSource;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 根据行 key 值，更新dataSource
   */
  public updateRulesByKey = (newRecord: any) => {
    const { key } = newRecord;
    const newDataSource: any[] = _.map(this.props.dataSource, (item: any) =>
      item.key === key ? newRecord : item
    );
    this.props.updateDataSource(newDataSource);
  };

  public handleDataTypeChange = (dataType: string, record: any) => {
    const newRecord = { ...record, dataType, value: undefined };
    this.updateRulesByKey(newRecord);
  };

  public getColumns = () => {
    const {
      form: { getFieldDecorator },
      editType
    } = this.props;

    const columns = [
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: '50%',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: '50%',
        render: (text: string, record: any) => {
          if (editType) {
            return (
              <FormItem>
                {getFieldDecorator(`dataType_${record.name}`, {
                  initialValue: _.get(record, 'dataType', undefined),
                  rules: [
                    {
                      required: true,
                      message: '-请选择-'
                    }
                  ]
                })(
                  <Select
                    placeholder="-请选择-"
                    dropdownMatchSelectWidth={false}
                    onChange={(v: string) => {
                      this.handleDataTypeChange(v, record);
                    }}
                    getPopupContainer={popupContainer}
                  >
                    {_.map(baseTypes, item => (
                      <Option key={item} value={item}>
                        {item}
                      </Option>
                    ))}
                  </Select>
                )}
              </FormItem>
            );
          } else {
            return text;
          }
        }
      }
    ];

    return columns;
  };

  public render() {
    const columns: any = this.getColumns();
    const { dataSource } = this.props;
    return (
      <Table
        size="small"
        className={classnames(
          'task-edit-table',
          dataSource.length && styles.inputParamsTable
        )}
        rowKey="name"
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({ name: 'APIOutputBodyTable' })(
  APIOutputBodyTable
);
