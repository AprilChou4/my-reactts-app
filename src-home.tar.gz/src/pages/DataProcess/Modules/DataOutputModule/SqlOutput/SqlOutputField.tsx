import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';

import PrimaryKeyTable from '../../components/PrimaryKeyTable';
import styles from './index.less';

interface IProps {
  outputStore?: any;
}

interface IState {}

@inject('outputStore')
@observer
class SqlOutputField extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  /**
   * @description: 改变table表格唯一索引
   * @param {object} record 每一行表格数据
   * @param {object} e checkbox onChange 返回参数
   * unique 0:代表没有唯一索引  1:代表从源表中自带的  2:代表用户自定义的
   */
  public handleKeyChange = (record: any, value: any): void => {
    const { outputStore } = this.props;
    const targetStruct = _.cloneDeep(outputStore.targetStruct);
    const targetIndex = _.findIndex(
      targetStruct,
      (o: any) => o.name === record.name
    );
    if (targetIndex === -1) return;
    targetStruct[targetIndex].unique = value ? 2 : 0;
    outputStore.updateTargetStruct(targetStruct);
  };

  public render() {
    const { targetStruct, tableLoading } = this.props.outputStore;
    return (
      <div className={styles.sqlOutputField}>
        <PrimaryKeyTable
          loading={tableLoading}
          dataSource={targetStruct}
          handleKeyChange={this.handleKeyChange}
        />
      </div>
    );
  }
}

export default SqlOutputField;
