export const grainConfigMap: any = {
  6: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '第一条记录当前分钟第一秒' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '最后一条记录当前分钟最后一秒' }
    ],
    startShowKeys: [], //需要展示后面输入框的key
    endShowKeys: [],
    range1: [0, 0], //输入框字段范围
    range2: [0, 0],
    needGreater: false //end是否需要大于start
  },
  5: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '第一条记录当前小时' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '最后记录当前小时' }
    ],
    startShowKeys: [2],
    endShowKeys: [2],
    range1: [0, 59],
    range2: [0, 59],
    needGreater: false
  },
  4: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '第一条记录当前天' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '最后记录当前天' }
    ],
    startShowKeys: [2],
    endShowKeys: [2],
    range1: [0, 23],
    range2: [0, 23],
    needGreater: false
  },
  3: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '第一条记录当前月' },
      { value: 3, label: '第一条记录当前月最后一天' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '最后记录当前月' },
      { value: 3, label: '最后记录当前月最后一天' }
    ],
    startShowKeys: [2],
    endShowKeys: [2],
    range1: [1, 31],
    range2: [1, 31],
    needGreater: false
  },
  2: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '第一条记录当前年' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '最后记录当前年' }
    ],
    startShowKeys: [2],
    endShowKeys: [2],
    range1: [1, 12],
    range2: [1, 12],
    needGreater: false
  },
  1: {
    startOptions: [
      { value: 1, label: '第一条记录' },
      { value: 2, label: '年份' }
    ],
    endOptions: [
      { value: 1, label: '最后一条记录' },
      { value: 2, label: '年份' }
    ],
    startShowKeys: [2],
    endShowKeys: [2],
    range1: [1990, new Date().getFullYear()],
    range2: [1990, new Date().getFullYear()],
    needGreater: true
  }
};
