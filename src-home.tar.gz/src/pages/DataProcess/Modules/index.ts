import { lazy } from 'react';

const modules: any = {
  // 数据输入
  DataInputModule: lazy(() => import('./DataInputModule')),
  // 消息队列输入
  MsgQueueInputModule: lazy(() => import('./MsgQueueInputModule')),
  // 数据处理
  // sql执行
  SqlScriptModule: lazy(() => import('./SqlScriptModule')),
  // 数据集
  DataSampleModule: lazy(() => import('./DataSampleModule')),
  // 数据过滤
  DataFilterModule: lazy(() => import('./DataFilterModule')),
  // 数据连接
  DataJoinModule: lazy(() => import('./DataJoinModule')),
  // 数据排序
  DataSortModule: lazy(() => import('./DataSortModule')),
  //数据合并
  MergeModule: lazy(() => import('./MergeModule')),
  //缺失值处理
  MissingValueFillModule: lazy(() => import('./MissingValueFillModule')),
  // 数据类型转换
  DataTypeConversionModule: lazy(() => import('./DataTypeConversionModule')),
  // 数据补齐
  DataFillModule: lazy(() => import('./DataFillModule')),
  // 变量设置
  VariableSetModule: lazy(() => import('./VariableSetModule')),
  DataAggregation: lazy(() => import('./DataAggregation')),
  AggregationModule: lazy(() => import('./AggregationModule')),
  // 表转置
  TableTransposeModule: lazy(() => import('./TableTransposeModule')),
  CustomModule: lazy(() => import('./CustomModule')),
  // 大数据模型
  BigDataModelRuntimeModule: lazy(
    () => import('./BigDataModelRuntimeModule/index')
  ),
  BigDataModelUpdateModule: lazy(
    () => import('./BigDataModelUpdateModule/index')
  ),
  // 过程控制
  BranchModule: lazy(() => import('./BranchModule')),
  // 数据输出
  DataOutputModule: lazy(() => import('./DataOutputModule')),
  // 消息队列输出
  MsgQueueOutputModule: lazy(() => import('./MsgQueueOutputModule')),
  HBASEOutputModule: lazy(() => import('./HBASEOutputModule')),
  // 安全脱敏
  DataMaskModule: lazy(() => import('./DataMaskModule')),
  // 数据质量
  DataQualityModule: lazy(() => import('./DataQualityModule'))
};

export default modules;
