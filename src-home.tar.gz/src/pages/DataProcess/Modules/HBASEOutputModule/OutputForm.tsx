import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Form, Spin, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import { DataSourceName, DataSourceTable } from '../components/DataSourceForm';
import TaskTitle from '../components/TaskTitle';

const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
  onSourceTableChange: () => void;
  hBaseStore?: any;
}

@inject('hBaseStore')
@observer
class OutputForm extends Component<IProps> {
  public saveVerify = () => {
    let params: any;
    const { form, hBaseStore } = this.props;
    form.validateFields((errors: any, values: any) => {
      if (errors) return;
      const { sourceId, tableViewName } = values;
      const { name: resname = '', sqlType = '' } =
        _.find(hBaseStore.sourceNames, (o: any) => o.id === sourceId) || {};
      // 区分返回数据结构
      params = {
        inputType: 1,
        sourceType: sqlType,
        sourceId,
        sourceName: resname,
        extendConfig: {
          tableViewName
        }
      };

      // 当sourceType === 9 时  为 Hive 输出
      if (sqlType === 9) {
        const { insertMode, hdfsPath, hdfsId } = values;
        params.extendConfig = _.assign(params.extendConfig, {
          insertMode,
          hdfsPath,
          hdfsId
        });
      }
    });
    return params;
  };

  /**
   * @description: 数据源名称切换,获取对应数据源下表的列表
   * 数据源名称发生改变 同步更改算子节点的名称
   * @param {number} sourceId 数据源id 需根据 sourceNames 查询除详细信息
   */
  private handleSourceNameChange = (sourceId: number): void => {
    const { hBaseStore, form } = this.props;
    const { name: resname = '', sqlType = '' } =
      _.find(hBaseStore.sourceNames, (o: any) => o.id === sourceId) || {};

    const params = {
      sqlType,
      resname,
      id: sourceId
    };
    form.setFieldsValue({
      tableViewName: undefined
    });
    hBaseStore.getTableListBySourceName(params);
    this.props.handleConfigChange();
    this.props.updateNodeNameByTag(resname);
  };

  /**
   * @description: 选择数据表显示该表的字段信息等
   * @param {string} tableName 数据表名称
   */
  private handleSourceTableChange = (tableName: string): void => {
    if (!tableName) return;
    const { form, hBaseStore } = this.props;
    form.validateFields(
      ['sourceType', 'sourceId'],
      (errors: any, values: any) => {
        if (errors) return;
        const { sourceId } = values;
        const params = {
          id: sourceId,
          tableName
        };
        hBaseStore.getTableColumnFamily(params);
        this.props.onSourceTableChange();
        this.props.handleConfigChange();
      }
    );
  };

  public render() {
    const { form, hBaseStore } = this.props;
    const { getFieldDecorator } = form;
    const {
      formLoading,
      sourceNames,
      tableNameList = [],
      formData: { sourceId, tableViewName }
    } = hBaseStore;
    return (
      <Form
        style={{
          marginLeft: '18px'
        }}
      >
        <TaskTitle index={1} subTitle="选择数据源" />
        <Spin
          tip="Loading..."
          spinning={formLoading}
          wrapperClassName="formLoading"
        >
          <FormItem label="数据源类型" colon={false}>
            {getFieldDecorator('sourceType', {
              initialValue: 'hbase',
              rules: [{ required: true, message: '请选择数据源类型!' }]
            })(<Input className="inputBox" disabled />)}
          </FormItem>
          <DataSourceName
            formKey="sourceId"
            initialValue={sourceId}
            sourceNames={sourceNames}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceNameChange}
          />
          <DataSourceTable
            formKey="tableViewName"
            initialValue={tableViewName}
            tableList={tableNameList}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceTableChange}
          />
        </Spin>
      </Form>
    );
  }
}

export default Form.create<IProps>({ name: 'OutputForm' })(OutputForm);
