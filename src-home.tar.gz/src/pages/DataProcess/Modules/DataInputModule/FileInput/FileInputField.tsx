import React, { Component, Fragment } from 'react';
import { inject, observer } from 'mobx-react';
import { Button } from 'sup-ui';

import TaskTitle from '../../components/TaskTitle';
import PreviewInputData from '../components/PreviewInputData';
import PrimaryKeyTable from '../../components/PrimaryKeyTable';
import styles from './index.less';

interface IProps {
  variables: any[];
  onPreview: () => void;
  fileInputStore?: any;
}
interface IState {}

@inject('fileInputStore')
@observer
class FileInputField extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      previewVisible,
      previewDataLoading,
      previewData,
      originStruct,
      cancelPreview,
      loading
    } = this.props.fileInputStore;
    return (
      <Fragment>
        <TaskTitle index={2} subTitle="输出字段配置" />
        <div className={styles.fieldContainer}>
          <div className={styles.tableHeader}>
            输出字段
            <Button
              size="small"
              disabled={!originStruct.length || previewDataLoading}
              onClick={this.props.onPreview}
            >
              预览
            </Button>
          </div>
          <PrimaryKeyTable
            loading={loading}
            hasIndex={false}
            dataSource={originStruct}
          />
        </div>
        <PreviewInputData
          visible={previewVisible}
          loading={previewDataLoading}
          dataSource={previewData}
          columnStruct={originStruct}
          onCancel={cancelPreview}
        />
      </Fragment>
    );
  }
}

export default FileInputField;
