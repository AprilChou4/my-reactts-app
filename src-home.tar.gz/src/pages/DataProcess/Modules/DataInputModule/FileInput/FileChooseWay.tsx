import React, { FunctionComponent } from 'react';
import { Radio, Form } from 'sup-ui';
import { RadioChangeEvent } from 'sup-ui/lib/radio';

const RadioGroup = Radio.Group;
const FormItem = Form.Item;
interface IProps {
  initialValue: number;
  getFieldDecorator: any;
  onChange: (value: RadioChangeEvent) => void;
}

const FileChooseWay: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, initialValue, onChange } = props;
  return (
    <FormItem label="文件选择方式" style={{ marginBottom: 0 }} colon={false}>
      {getFieldDecorator('chooseWay', {
        rules: [{ required: true, message: '请选择文件选择方式!' }],
        initialValue
      })(
        <RadioGroup onChange={onChange}>
          <Radio value={1}>文件选择</Radio>
          <Radio value={2}>文件匹配</Radio>
          <Radio value={3}>文件上传</Radio>
        </RadioGroup>
      )}
    </FormItem>
  );
};

export default FileChooseWay;
