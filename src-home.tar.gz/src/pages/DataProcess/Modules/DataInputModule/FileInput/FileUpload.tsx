import React, { Component } from 'react';
import { Upload, Button, message, Modal } from 'sup-ui';

import { TASK_URL } from '@config/env';
import { getReqBaseHeader } from '@services/apiUtils';
import FileDetect from './FileDetect';
import { fileNameIsInclude } from '../../module.service';
import styles from './index.less';

const { confirm } = Modal;

interface IProps {
  activePath: string;
  formLoading: boolean;
  fileName: string;
  uploadFileList: any[];
  getFieldDecorator: any;
  sourceId: string;
  updateFileName: (value: string) => void;
  updateFormLoading: (bool: boolean) => void;
  updateUploadFile: (params?: {
    struct: any[];
    filepath: string;
    fileList: any[];
  }) => void;
}

interface IState {
  uploadStatus: boolean;
}

class FileUpload extends Component<IProps, IState> {
  private duplicateNameDealType: number;
  public constructor(props: IProps) {
    super(props);
    this.state = { uploadStatus: true };
    this.duplicateNameDealType = 0;
  }

  private getFileName = () => {
    return this.props.fileName;
  };
  /**
   * @description: 上传文件之前，需要先校验文件是否存在
   * 如果出现重名需要提供给用户选项，是否重名覆盖，或者输入新的文件名
   * @param {object} file sup-ui 上传钩子函数返回的文件列表参数
   * @return: promise 上传之前的操作是否成功
   */
  private beforeUpload = (file: any) => {
    const {
      updateFormLoading,
      updateFileName,
      activePath,
      getFieldDecorator,
      sourceId
    } = this.props;
    updateFormLoading(true);
    return new Promise<void>((resolve, reject) => {
      const suffix = file.name?.substring(file.name.lastIndexOf('.'));
      const isFileType = /.xls|.xlxs|.csv$/.test(suffix);
      if (!isFileType) {
        message.error('请上传xls，xlsx，csv格式的文件');
        updateFormLoading(false);
        reject(false);
      }
      fileNameIsInclude({
        src: `${activePath}/${file.name}`,
        sourceId
      })
        .then((res: any) => {
          const { code, data } = res;
          if (code === 200) {
            const { fileExist } = data.map;
            if (fileExist) {
              // 如果文件名存在则默认 文件选择方式为 覆盖 1
              this.duplicateNameDealType = 1;
              confirm({
                title: (
                  <h4 className={styles.modalTitle}>文件重名,请选择操作方式</h4>
                ),
                content: (
                  <FileDetect
                    getFieldDecorator={getFieldDecorator}
                    changeFileType={this.changeFileType}
                    updateFileName={updateFileName}
                  />
                ),
                keyboard: false,
                onOk: () => {
                  if (this.duplicateNameDealType === 1) {
                    resolve();
                  } else {
                    if (this.getFileName()) {
                      resolve();
                    } else {
                      message.error('请输入新文件名');
                      updateFormLoading(false);
                      reject();
                    }
                  }
                },
                onCancel: () => {
                  updateFormLoading(false);
                  reject();
                }
              });
            } else {
              // 如果文件名不存在 则 文件选择方式恢复默认 0
              this.duplicateNameDealType = 0;
              resolve();
            }
          } else {
            // 如果接口请求失败  则 文件选择方式恢复默认 0
            updateFormLoading(false);
            reject();
          }
        })
        .catch(() => {
          updateFormLoading(false);
        });
    });
  };

  private changeFileType = (value: number) => {
    this.duplicateNameDealType = value;
    if (value === 1) {
      this.props.updateFileName('');
    }
  };

  private getFileType = (fileName: string) => {
    if (!_.isString(fileName)) return;
    const startIndex = fileName.lastIndexOf('.');
    const type = fileName.substring(startIndex, fileName.length);
    return type;
  };

  public render() {
    const {
      activePath,
      formLoading,
      updateFormLoading,
      fileName,
      updateUploadFile,
      uploadFileList,
      sourceId
    } = this.props;
    const uploadProps: any = {
      action: `${TASK_URL}/upload/fileAndparse`,
      name: 'file',
      method: 'post',
      headers: getReqBaseHeader(),
      data: (file: any) => {
        if (!activePath) {
          message.warning('请先选择数据源!');
          return;
        }
        let isCover = false;
        let isRename = false;
        let newName: string | undefined;
        // 文件上传的方式选择覆盖
        if (this.duplicateNameDealType === 1) {
          isCover = true;
        } else if (this.duplicateNameDealType === 2) {
          // 文件上传方式选择为 重命名
          const fileSuffix = this.getFileType(file.name);
          if (fileSuffix) {
            isRename = true;
            newName = `${fileName}${fileSuffix}`;
          }
        } else {
          isRename = false;
          newName = file.name;
        }
        return {
          src: activePath,
          file: file.name,
          isCover,
          isRename,
          newName,
          sourceId
        };
      },
      beforeUpload: this.beforeUpload,
      onChange: (info: any) => {
        const { status: fileStatus, name } = info.file;
        if (fileStatus === 'removed') return;
        const [{ uid, status }] = info.fileList;
        if (fileStatus === 'error' || fileStatus === 'done') {
          const {
            response: { code, message: msg, data }
          } = info.file;
          updateFormLoading(false);
          if (code === 200) {
            const { struct, filepath } = data.map;
            const replaceFileName = filepath?.replace(activePath, '');
            const params: any = {
              struct,
              filepath,
              fileList: [{ uid, name: replaceFileName, status }]
            };
            updateUploadFile(params);
            //
            const currFileName = filepath.substring(
              0,
              filepath.lastIndexOf('.')
            );
            message.success(`${currFileName}上传成功`);
          } else {
            message.error(msg);
            updateUploadFile();
            this.setState({
              uploadStatus: true
            });
            return;
          }
        } else {
          const params: any = {
            fileList: [{ uid, name, status }]
          };
          updateUploadFile(params);
        }
      },
      onRemove: () => {
        if (this.state.uploadStatus) {
          message.success(`删除成功`);
        }
        this.setState({
          uploadStatus: true
        });
        updateUploadFile();
      },
      fileList: uploadFileList
    };

    const { uploadStatus } = this.state;

    return (
      <div style={{ width: '245px', marginBottom: '16px' }}>
        <Upload {...uploadProps}>
          <Button
            style={{ width: '245px', height: '32px' }}
            disabled={
              !activePath ||
              !!uploadFileList.length ||
              !uploadStatus ||
              formLoading
            }
          >
            点击上传文件
          </Button>
        </Upload>
      </div>
    );
  }
}

export default FileUpload;
