import React, { FunctionComponent } from 'react';
import { Table } from 'sup-ui';

import DialogModal from '@components/Modal/Dialog';
import { TableCellText } from '@components/Table';
import { formatValueByType } from '../../../devTask.helper';

interface IProps {
  visible: boolean;
  loading: boolean;
  columnStruct: any[];
  dataSource: any[];
  onCancel: () => void;
}

const PreviewInputData: FunctionComponent<IProps> = (props: IProps) => {
  const { visible, loading, columnStruct, dataSource, onCancel } = props;
  const getTableItemWidth = (dataType: string) => {
    switch (dataType) {
      case 'Boolean':
        return '80px';
      case 'Timestamp':
        return '180px';
      case 'Date':
        return '120px';
      default:
        return `${120}px`;
    }
  };

  const columns = _.map(columnStruct, (item: any) => ({
    title: () => <TableCellText text={item.name} />,
    dataIndex: item.name,
    width: getTableItemWidth(item.dataType),
    className: 'ellipsis-hide',
    render: (v: any) => (
      <TableCellText text={formatValueByType(v, item.dataType)} />
    )
  }));
  return (
    <DialogModal
      title="数据预览"
      width="80%"
      bodyStyle={{ height: '80vh' }}
      visible={visible}
      onCancel={onCancel}
      footer={null}
    >
      <Table
        className="mp-table-gray"
        size="small"
        rowKey={(_record, index) => `preview_${index}`}
        loading={loading}
        columns={columns}
        dataSource={dataSource}
        scroll={{ x: '100%', y: 'calc(80vh - 80px)' }}
        pagination={false}
      />
    </DialogModal>
  );
};

export default PreviewInputData;
