import React, { Component, Fragment } from 'react';
import { inject, observer } from 'mobx-react';
import { Form } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import { transJsonParse } from '@utils/common';
import { DataSourceName } from '../../components/DataSourceForm';

import ObjectSelector from '../../components/ObjectSelector';
import styles from '../InputForm.less';

interface IProps extends FormComponentProps {
  objInputStore?: any;
  updateNodeNameByTag: (name: string) => void;
}
interface IState {}

@inject('objInputStore')
@observer
class ObjInputForm extends Component<IProps, IState> {
  private selectorRef: any;
  public saveVerify = () => {
    let params: any = null;
    const {
      form,
      objInputStore: {
        templateInfo,
        instanceInfo,
        attributeInfo,
        dataSource,
        sourceNames
      }
    } = this.props;

    form.validateFields((errors, values) => {
      if (errors) return;

      const selectors = this.selectorRef.handleSubmitForm();

      if (!selectors) return;

      const { sourceId } = values;
      const { accountId, secretKey, tenantId, url, name, isAuth } = dataSource;
      const { sqlType } = _.find(sourceNames, ['id', sourceId]);
      const modelType = _.isEmpty(instanceInfo)
        ? 0
        : _.isEmpty(attributeInfo)
        ? 1
        : 2; //0模板，1实例，2属性

      params = {
        inputType: 3,
        sourceType: sqlType,
        sourceId,
        sourceName: name,
        tenantId,
        extendConfig: {
          templateId: templateInfo.id,
          templateName: templateInfo.enName,
          templateDisplayName: templateInfo.displayName,
          templateNamespace: templateInfo.namespace,
          ...(!_.isEmpty(instanceInfo)
            ? {
                instanceId: instanceInfo.system_id,
                instanceName: instanceInfo.system_en_name,
                instanceDisplayName: instanceInfo.system_display_name
              }
            : {}),
          ...(!_.isEmpty(attributeInfo)
            ? {
                attributeInfo,
                attributeName: attributeInfo.name,
                attributeNamespace: attributeInfo.namespace,
                historical: selectors.history ? 1 : 0 //是否勾选历史
              }
            : {}),
          modelType,
          accountId,
          secretKey,
          tenantId,
          url,
          isAuth
        }
      };
    });

    return params;
  };

  public handleSourceNameChange = (sourceId: number): void => {
    const {
      objInputStore: { sourceNames, changeDataSource }
    } = this.props;
    const { url, union, name } = _.find(sourceNames, ['id', sourceId]);
    const { tenantId, accountId, secretKey, isAuth } = transJsonParse(union);

    changeDataSource({
      url,
      name,
      isAuth,
      secretKey,
      accountId,
      tenantId
    });
    this.props.updateNodeNameByTag(name);
  };

  public handleSelectorChange = (data: any) => {
    this.props.objInputStore.handleSelectorChange(data);
  };

  public render() {
    const {
      form: { getFieldDecorator },
      objInputStore: {
        dataSource,
        sourceId,
        sourceNames,
        templateInfo,
        instanceInfo,
        attributeInfo,
        historical
      }
    } = this.props;

    return (
      <Fragment>
        <Form className={styles.formWrapper}>
          <DataSourceName
            formKey="sourceId"
            initialValue={sourceId}
            sourceNames={sourceNames}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceNameChange}
          />
        </Form>
        <ObjectSelector
          wrappedComponentRef={(ref: any) => {
            this.selectorRef = ref;
          }}
          initValue={{ templateInfo, instanceInfo, attributeInfo, historical }}
          dataSource={dataSource}
          onChange={this.handleSelectorChange}
        />
      </Fragment>
    );
  }
}

export default Form.create<IProps>({ name: 'ObjInputForm' })(ObjInputForm);
