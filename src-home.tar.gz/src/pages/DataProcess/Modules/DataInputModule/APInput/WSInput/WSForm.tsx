import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Form, Spin } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import {
  DataSourceType,
  DataSourceName
} from '../../../components/DataSourceForm';
import styles from './index.less';

interface IProps extends FormComponentProps {
  wStore?: any;
  formLoading: boolean;
  sourceType: undefined | number;
  sourceTypes: any[];
  sourceNames: any[];
  sourceId: string;
  handleSourceTypeChange: (value: string) => void;
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
}

interface IState {}

@inject('wStore')
@observer
class WSForm extends Component<IProps, IState> {
  public saveVerify = () => {
    let params: any;
    const { form, sourceNames } = this.props;
    form.validateFields((errors, values) => {
      if (errors) return;
      const { sourceId } = values;
      const { inParamsMode } = this.props.wStore;
      const { name: resname = '', sqlType = '' } =
        _.find(sourceNames, (o: any) => o.id === sourceId) || {};
      params = {
        inputType: 6,
        sourceType: sqlType,
        sourceId,
        sourceName: resname,
        inParamsMode
      };
    });
    return params;
  };

  /**
   * @description: 数据源类型切换,获取对应的数据源名称列表,同时将数据表清空
   * @param {string} value
   */
  private handleSourceTypeChange = (value: string): void => {
    const { form } = this.props;
    form.setFieldsValue({
      sourceId: undefined
    });
    this.props.handleSourceTypeChange(value);
  };

  /**
   * @description: 数据源名称切换,获取对应数据源下表的列表
   * 数据源名称发生改变 同步更改算子节点的名称
   * @param {number} sourceId 数据源id 需根据 sourceNames 查询除详细信息
   */
  private handleSourceNameChange = (sourceId: string): void => {
    const { form, sourceNames } = this.props;
    const { name: resname = '', sqlType = '' } =
      _.find(sourceNames, (o: any) => o.id === sourceId) || {};
    const params = {
      restype: 'api',
      sqlType,
      resname,
      id: sourceId
    };
    form.setFieldsValue({
      sourceType: sqlType
    });

    this.props.wStore.getAPIParamsBySourceName(params);
    this.props.updateNodeNameByTag(resname);
  };

  public render() {
    const {
      form: { getFieldDecorator },
      sourceType,
      sourceTypes,
      sourceNames,
      sourceId,
      formLoading
    } = this.props;
    return (
      <Form className={styles.formWrapper}>
        <Spin spinning={formLoading} wrapperClassName="formLoading">
          <DataSourceType
            formKey="sourceType"
            initialValue={sourceType}
            sourceTypes={sourceTypes}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceTypeChange}
          />
          <DataSourceName
            formKey="sourceId"
            initialValue={sourceId}
            sourceNames={sourceNames}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceNameChange}
          />
        </Spin>
      </Form>
    );
  }
}

export default Form.create<IProps>({ name: 'WSForm' })(WSForm);
