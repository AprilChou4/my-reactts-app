/*
 * @Description: 数据加工 API 数据源输入列表模式
 * @Author: liyongshuai
 */
import React, { Component } from 'react';
import classnames from 'classnames';
import { Table, Form, Select, message, Checkbox } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import SetValueByDataType from '../../../components/SetValueByDataType';
import { TableCellText } from '@components/Table';
import { popupContainer } from '@utils/propUtil';
import { getTimeTypeByValue, transVarType2DataType } from '@utils/timeUtil';
import styles from './index.less';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps extends FormComponentProps {
  loading: boolean;
  variables: any[];
  dataSource: any[];
  updateDataSource: (newDataSource: any[]) => void;
}

class ReqParamsTable extends Component<IProps> {
  public constructor(props: IProps) {
    super(props);
  }
  public verifyRules = () => {
    let params;
    const { form, dataSource } = this.props;
    form.validateFields((errors: any) => {
      if (!errors) {
        params = dataSource;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 根据索引，更新dataSource
   */
  private updateRulesByIndex = (index: number, newRecord: any) => {
    const newDataSource = _.cloneDeep(this.props.dataSource);
    newDataSource[index] = newRecord;
    this.props.updateDataSource(newDataSource);
  };

  /**
   * @description: 修改指定字段是否开启循环遍历，入参中只能有一个字段支持循环
   * 当且仅当字段选择的处理方式为变量，并且选择的变量为上游变量设置算子设置的 table/column类型才可勾选
   * 如果循环对应的变量不一致，则需要将之前设置的是否循环置为否
   * @param {boolean} value
   * @param {any} record
   * @param {number} index
   */
  private handleCyclicalExec = (
    value: boolean,
    _record: any,
    index: number
  ) => {
    const { dataSource } = this.props;
    const targetValue = dataSource[index].value;
    const newDataSource = _.map(this.props.dataSource, (item, itemIndex) => {
      if (itemIndex === index) {
        return { ...item, cyclicalExec: value };
      } else if (item.value === targetValue) {
        return { ...item };
      } else {
        return { ...item, cyclicalExec: false };
      }
    });
    this.props.updateDataSource(newDataSource);
  };

  private handleTypeChange = (value: number, record: any, index: number) => {
    const newRecord = {
      ...record,
      type: value,
      value: undefined,
      cyclicalExec: value === 1 ? false : record.cyclicalExec
    };
    this.updateRulesByIndex(index, newRecord);
  };

  private handleValueChange = (v: any, record: any, index: number) => {
    const newRecord = {
      ...record
    };
    if (record.type === 1) {
      newRecord.value = v;
    } else if (record.type === 2) {
      const selectVB =
        _.find(this.props.variables, (item: any) => v === item.name) || {};
      newRecord.dataType = transVarType2DataType(selectVB);
      newRecord.value = v;
      newRecord.cyclicalExec =
        selectVB.type === 5 ? newRecord.cyclicalExec : false;
    }

    this.updateRulesByIndex(index, newRecord);
  };

  public getColumns = () => {
    const {
      form: { getFieldDecorator },
      variables
    } = this.props;
    return [
      {
        title: '',
        dataIndex: 'required',
        key: 'required',
        width: 20,
        render: (text: number) => (
          <span className={text === 1 ? styles.formRequire : ''} />
        )
      },
      {
        title: '循环遍历',
        dataIndex: 'cyclicalExec',
        key: 'cyclicalExec',
        width: 80,
        render: (v: boolean, record: any, index: number) => (
          <Checkbox
            checked={v}
            disabled={
              !(
                record.type === 2 &&
                record.value &&
                _.get(
                  _.find(variables, i => i.name === record.value),
                  'type'
                ) === 5
              )
            }
            onChange={(e: any) => {
              this.handleCyclicalExec(e.target.checked, record, index);
            }}
          />
        )
      },
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: 120
      },
      {
        title: '处理方式',
        dataIndex: 'type',
        key: 'type',
        width: 120,
        render: (_text: any, record: any, index: number) => {
          return (
            <FormItem>
              {getFieldDecorator(`handle_type_${record.name}`, {
                initialValue: _.get(record, 'type', undefined),
                rules: [
                  {
                    required: true,
                    message: '-请选择-'
                  }
                ]
              })(
                <Select
                  placeholder="-请选择-"
                  size="small"
                  dropdownMatchSelectWidth={false}
                  onChange={(v: number) => {
                    this.handleTypeChange(v, record, index);
                  }}
                  getPopupContainer={popupContainer}
                >
                  <Option key={1} value={1}>
                    常量
                  </Option>
                  <Option key={2} value={2}>
                    变量
                  </Option>
                </Select>
              )}
            </FormItem>
          );
        }
      },
      {
        title: '值',
        dataIndex: 'value',
        key: 'value',
        render: (value: any, record: any, index: number) => {
          const { type, dataType } = record;
          let varType = '';
          if (type === 1) {
            varType = 'const';
          } else if (type === 2) {
            varType = 'let';
          }
          let newVariables: any[] = [];
          if (varType === 'let') {
            // 当变量是确定值且变量的类型与字段的数据类型一致时才允许选择
            newVariables = _.filter(variables, (item: any) => {
              if (item.dataType === 'Datetime') {
                const { type: iType, value: iValue } = item.constValue;
                if (iType === 1) {
                  const valueDataType = getTimeTypeByValue(iValue);
                  return valueDataType === dataType;
                } else {
                  return false;
                }
              } else {
                return item.dataType === dataType;
              }
            });
          }
          return (
            <SetValueByDataType
              formKey={`value_${index}_`}
              size="small"
              value={value}
              dataType={record.dataType}
              required={!!record.required}
              varType={varType}
              variables={newVariables}
              getFieldDecorator={getFieldDecorator}
              onChange={(v: any) => {
                this.handleValueChange(v, record, index);
              }}
            />
          );
        }
      }
    ];
  };

  public render() {
    const columns: any = this.getColumns();
    const { dataSource, loading } = this.props;
    return (
      <Table
        size="small"
        className={classnames(
          'task-edit-table',
          dataSource.length && styles.inputParamsTable
        )}
        style={{
          marginBottom: '10px'
        }}
        rowKey={(_record, index) => `params_${index}`}
        loading={loading}
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({ name: 'ReqParamsTable' })(ReqParamsTable);
