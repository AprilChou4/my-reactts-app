/*
 * @Description: 数据加工 API restful
 * @Author: liyongshuai
 */
import React, { Component, Fragment } from 'react';
import { Switch, Popover, message } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import { Provider } from 'mobx-react';

import Icon from '@components/Icon';
import JsonTree from '../../../components/JsonTree';
import ReqParamsTable from './ReqParamsTable';
import PrimaryKeyTable from '../../../components/PrimaryKeyTable';
import TaskTitle from '../../../components/TaskTitle';
import RestForm from './RestForm';
import { isDefinedVar } from '../../../module.helper';
import { verifyUrl, getJsonArrVar } from './restful.helper';
import RestfulStore from '../../stores/restful.store';
import styles from './index.less';

interface IProps {
  apiInputStore?: any;
  dataModuleConfig: any;
  variables: any[];
  initMapping: (mappingParams: any) => void;
  updateNodeNameByTag: (name: string) => void;
  handleConfigChange: () => void;
}

@inject('apiInputStore')
@observer
class RestfulInput extends Component<IProps> {
  private formRef: any;
  private headerParamsRef: any;
  private inParamsRef: any;
  private restfulStore: any;
  public constructor(props: IProps) {
    super(props);
    this.restfulStore = new RestfulStore(
      _.pick(props, ['dataModuleConfig', 'initMapping', 'handleConfigChange'])
    );
  }

  public saveVerify = () => {
    const formData = this.formRef.saveVerify();
    if (!formData) return;
    const headerParams = this.headerParamsRef.verifyRules();
    const { inParamsMode, requestUrl, cyclicVariableNode, failedContinue } =
      this.restfulStore;
    const { variables } = this.props;

    if (!verifyUrl(requestUrl, variables)) return;
    if (!headerParams) return;
    let cyclicVariableName;
    if (cyclicVariableNode === 'url') {
      const urlVar = requestUrl.match(/#\{(\w+)\}/g);
      if (urlVar && urlVar.length) {
        const targetVar = _.find(urlVar, i => {
          const varName = i.slice(2, -1);
          return (
            _.get(
              _.find(variables, o => o.name === varName),
              'type'
            ) === 5
          );
        });
        if (targetVar) {
          cyclicVariableName = targetVar.slice(2, -1);
        }
      }
    } else if (cyclicVariableNode === 'header') {
      cyclicVariableName = _.get(
        _.find(headerParams, i => i.cyclicalExec),
        'value'
      );
    }
    if (inParamsMode === 1) {
      const inParams = this.inParamsRef.verifyRules();
      if (!inParams) return;
      if (cyclicVariableNode === 'body') {
        cyclicVariableName = _.get(
          _.find(inParams, i => i.cyclicalExec),
          'value'
        );
      }
      return {
        ...formData,
        url: requestUrl,
        headerParams,
        inParams,
        cyclicalExec: !!cyclicVariableNode,
        cyclicVariableName,
        cyclicVariableNode,
        failedContinue: cyclicVariableNode ? failedContinue : undefined
      };
    } else if (inParamsMode === 2) {
      const { jsonParams, originJson } = this.restfulStore;
      if (cyclicVariableNode === 'body') {
        const { column, table } = getJsonArrVar(
          JSON.stringify(jsonParams),
          variables
        );
        if (column.length + table.length === 0) {
          message.warning('请求体开启循环必须含有一个循环变量！');
          return;
        } else if (column.length + table.length > 1) {
          message.warning('请求体开启循环最多含有一个循环变量！');
          return;
        } else {
          cyclicVariableName = _.get(_.concat(column, table), '0.name');
        }
      }
      return {
        ...formData,
        url: requestUrl,
        headerParams,
        jsonParams: isDefinedVar(jsonParams)
          ? jsonParams
          : JSON.stringify(jsonParams),
        extendConfig: {
          originJson: JSON.stringify(originJson)
        },
        cyclicalExec: !!cyclicVariableNode,
        cyclicVariableName,
        cyclicVariableNode,
        failedContinue: cyclicVariableNode ? failedContinue : undefined
      };
    } else {
      return;
    }
  };

  public render() {
    const { updateNodeNameByTag, handleConfigChange, variables } = this.props;
    const {
      sourceType,
      sourceTypes,
      sourceNames,
      sourceId,
      formLoading,
      handleSourceTypeChange
    } = this.props.apiInputStore;
    const {
      inParamsMode,
      headerParams,
      inParams,
      originStruct,
      jsonParams,
      originJson,
      updateJsonParams,
      updateHeaderParams,
      updateInParams,
      cyclicVariableNode,
      handleBodyCycle,
      tableLoading
    } = this.restfulStore;
    return (
      <Provider restfulStore={this.restfulStore}>
        <div style={{ width: '80%', marginLeft: '18px' }}>
          <RestForm
            wrappedComponentRef={(ref: any) => {
              if (_.isNil(this.formRef)) {
                this.formRef = ref;
              }
            }}
            variables={variables}
            sourceId={sourceId}
            formLoading={formLoading || tableLoading}
            sourceType={sourceType}
            sourceTypes={sourceTypes}
            sourceNames={sourceNames}
            handleSourceTypeChange={handleSourceTypeChange}
            updateNodeNameByTag={updateNodeNameByTag}
            handleConfigChange={handleConfigChange}
          />

          <label className={styles.label}>
            请求头参数（注：带 * 属于必填项）
          </label>
          <ReqParamsTable
            wrappedComponentRef={(ref: any) => {
              this.headerParamsRef = ref;
            }}
            loading={tableLoading}
            variables={variables}
            dataSource={headerParams}
            updateDataSource={updateHeaderParams}
          />
          {inParamsMode === 1 && (
            <Fragment>
              <label className={styles.label}>
                请求体参数（注：带 * 属于必填项）
              </label>
              <ReqParamsTable
                wrappedComponentRef={(ref: any) => {
                  this.inParamsRef = ref;
                }}
                loading={tableLoading}
                variables={variables}
                dataSource={inParams}
                updateDataSource={updateInParams}
              />
            </Fragment>
          )}
          {inParamsMode === 2 && (
            <Fragment>
              <div className={styles.formRequire}>
                JSON文本
                <label style={{ marginLeft: '10px' }}>
                  循环遍历
                  <Popover
                    content={<p>根据输入数据，循环请求获取数据，进行汇总</p>}
                    placement="bottom"
                    trigger="click"
                  >
                    <Icon
                      type="circle-help"
                      style={{ verticalAlign: '-4px' }}
                    />
                    ：
                  </Popover>
                </label>
                <Switch
                  size="small"
                  disabled={
                    cyclicVariableNode === 'url' ||
                    cyclicVariableNode === 'header'
                  }
                  className={styles.switchBox}
                  checked={cyclicVariableNode === 'body'}
                  onChange={handleBodyCycle}
                />
              </div>
              <div className={styles.jsonWrapper}>
                <JsonTree
                  json={jsonParams}
                  originJson={originJson}
                  variables={variables}
                  onChange={updateJsonParams}
                />
              </div>
            </Fragment>
          )}
          <TaskTitle index={2} subTitle="输出字段" />
          <PrimaryKeyTable dataSource={originStruct} hasIndex={false} />
        </div>
      </Provider>
    );
  }
}

export default RestfulInput;
