import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Form, Input, Spin, Switch, Popover } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import Icon from '@components/Icon';
import {
  DataSourceType,
  DataSourceName
} from '../../../components/DataSourceForm';
import { verifyUrl } from './restful.helper';
import styles from './index.less';

const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  restfulStore?: any;
  variables: any[];
  formLoading: boolean;
  sourceId: string;
  sourceType: undefined | number;
  sourceTypes: any[];
  sourceNames: any[];
  handleSourceTypeChange: (value: string) => void;
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
}

interface IState {}

@inject('restfulStore')
@observer
class RestForm extends Component<IProps, IState> {
  public saveVerify = () => {
    let params: any;
    const { form, restfulStore, sourceNames } = this.props;
    form.validateFields((errors, values) => {
      if (errors) return;
      const { inParamsMode } = restfulStore;
      const sourceId = _.get(values, 'sourceId');
      const { name: resname = '', sqlType = '' } =
        _.find(sourceNames, (o: any) => o.id === sourceId) || {};
      params = {
        inputType: 6,
        sourceType: sqlType,
        sourceId,
        sourceName: resname,
        inParamsMode
      };
    });
    return params;
  };

  /**
   * @description: 数据源类型切换,获取对应的数据源名称列表,同时将数据表清空
   * @param {string} value
   */
  public handleSourceTypeChange = (value: string): void => {
    const { form } = this.props;
    form.setFieldsValue({
      sourceId: undefined
    });
    this.props.handleSourceTypeChange(value);
  };

  /**
   * @description: 数据源名称切换,获取对应数据源下表的列表
   * 数据源名称发生改变 同步更改算子节点的名称
   * @param {number} sourceId 数据源id 需根据 sourceNames 查询除详细信息
   */
  public handleSourceNameChange = (sourceId: string): void => {
    const { sourceNames, form } = this.props;
    const { name: resname = '', sqlType = '' } =
      _.find(sourceNames, (o: any) => o.id === sourceId) || {};

    const params = {
      restype: 'api',
      sqlType,
      resname,
      id: sourceId
    };
    form.setFieldsValue({
      sourceType: sqlType
    });

    this.props.restfulStore.getAPIParamsBySourceName(params);
    this.props.handleConfigChange();
    this.props.updateNodeNameByTag(resname);
  };

  private getCycleNode = (cycleNode: string) => {
    switch (cycleNode) {
      case 'url':
        return '请求路径';
      case 'header':
        return '请求头';
      case 'body':
        return '请求体';

      default:
        return '';
    }
  };
  private updateRequestUrl = (e: any) => {
    const { value } = e.target;
    const verifyRes = verifyUrl(value, this.props.variables);
    if (verifyRes) {
      this.props.restfulStore.updateRequestUrl(value, _.isArray(verifyRes));
    }
  };

  public render() {
    const {
      form,
      restfulStore,
      sourceType,
      sourceTypes,
      sourceNames,
      sourceId,
      formLoading
    } = this.props;
    const { getFieldDecorator } = form;
    const {
      inParamsMode,
      requestUrl,
      failedContinue,
      handleFailedContinue,
      cyclicVariableNode
    } = restfulStore;
    return (
      <Form className={styles.formWrapper}>
        <Spin spinning={formLoading} wrapperClassName="formLoading">
          <DataSourceType
            formKey="sourceType"
            initialValue={sourceType}
            sourceTypes={sourceTypes}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceTypeChange}
          />
          <DataSourceName
            formKey="sourceId"
            initialValue={sourceId}
            sourceNames={sourceNames}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceNameChange}
          />
          <div className={styles.labelRow}>
            <label className={styles.label} style={{ marginRight: '10px' }}>
              入参格式：
            </label>
            <span>
              {inParamsMode === 1
                ? '列表格式'
                : inParamsMode === 2
                ? 'JSON格式'
                : ''}
            </span>
          </div>
          <div className={styles.labelRow}>
            <label className={styles.label}>循环节点：</label>
            <span>{this.getCycleNode(cyclicVariableNode)}</span>
          </div>
          <div className={styles.labelRow}>
            <label>
              单次执行失败跳过
              <Popover
                content={
                  <p>开启后，单次执行失败直接跳过，进行下次接口接口调用</p>
                }
                placement="bottom"
                trigger="click"
              >
                <Icon type="circle-help" style={{ verticalAlign: '-4px' }} />：
              </Popover>
            </label>
            <Switch
              size="small"
              disabled={!cyclicVariableNode}
              className={styles.switchBox}
              checked={!!(cyclicVariableNode && failedContinue)}
              onChange={handleFailedContinue}
            />
          </div>
          <FormItem label={`请求地址（注:变量以#{}标识）`}>
            {getFieldDecorator('requestUrl', {
              initialValue: requestUrl,
              rules: [{ required: true, message: '请输入请求地址！' }],
              validateTrigger: ['onChange', 'onBlur']
            })(
              <Input
                autoComplete="off"
                style={{ marginBottom: '10px' }}
                onBlur={this.updateRequestUrl}
                onPressEnter={this.updateRequestUrl}
              />
            )}
          </FormItem>
        </Spin>
      </Form>
    );
  }
}

export default Form.create<IProps>({ name: 'RestForm' })(RestForm);
