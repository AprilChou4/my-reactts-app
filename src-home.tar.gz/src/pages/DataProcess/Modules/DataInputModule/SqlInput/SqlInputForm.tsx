import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import {
  Form,
  Row,
  Col,
  Input,
  Radio,
  Button,
  message,
  Modal,
  Spin
} from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import SqlEditor from '@components/ScriptEditor/SqlEditor';
import {
  DataSourceType,
  DataSourceName,
  DataSourceTable
} from '../../components/DataSourceForm';

import styles from '../InputForm.less';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const { confirm } = Modal;

interface IProps extends FormComponentProps {
  handleConfigChange: () => void;
  updateNodeNameByTag: (name: string) => void;
  sqlInputStore?: any;
}

interface IState {
  querySql: string;
}

interface ISqlVarProps {
  sql: string;
  varArr: any[];
  getReplaceSql: (v: string) => void;
}

interface ISqlVarState {
  varArr: any[];
  replaceSql: string;
}

class SqlVar extends Component<ISqlVarProps, ISqlVarState> {
  public constructor(props: ISqlVarProps) {
    super(props);
    const { varArr } = props;
    this.state = {
      varArr,
      replaceSql: this.replaceSql(varArr)
    };
  }

  public replaceSql = (varArr: any[]) => {
    let { sql } = this.props;
    _.forEach(varArr, (item: any) => {
      sql = sql.replace(item.varName, item.varValue);
    });
    return sql;
  };

  public changeVarValue = (index: number, e: any) => {
    const { varArr } = this.state;
    varArr[index].varValue = e.target.value;
    const replaceSql = this.replaceSql(varArr);
    this.setState({
      varArr,
      replaceSql
    });
    this.props.getReplaceSql(replaceSql);
  };

  public render() {
    const { varArr, replaceSql } = this.state;
    return (
      <div className={styles.varSqlWrapper}>
        {_.map(varArr, (item: any, index: number) => (
          <Row key={item.varName} style={{ marginBottom: '10px' }}>
            <Col span={7} className={styles.varSqlLabel}>
              {item.varName}
            </Col>
            <Col span={16} offset={1}>
              <Input onChange={this.changeVarValue.bind(this, index)} />
            </Col>
          </Row>
        ))}
        <h4 className={styles.varSqlTips}>匹配后的SQL语句:</h4>
        <p className={styles.varSqlText}>{replaceSql}</p>
      </div>
    );
  }
}

@inject('sqlInputStore')
@observer
class SqlForm extends Component<IProps, IState> {
  private replaceSql: string;
  public constructor(props: IProps) {
    super(props);
    this.replaceSql = '';
    this.state = {
      querySql: props.sqlInputStore.formData.querySql || ''
    };
  }

  /**
   * @description: sql 输入表单保存时校验
   * sourceType 为数据源类型（大类）
   * sourceId 为数据源名称ID（小类） 需要通过数据源ID 查找数据源名称 sourceName返回给后台
   * @param {type}
   * @return: formData/undefined
   * 当form 表单的信息校验通过之后 返回 form 表单对象，反之返回 null
   */
  public saveVerify = () => {
    let params: any;
    const { form, sqlInputStore } = this.props;
    form.validateFields((errors, values) => {
      if (errors) return;
      const { queryType, sourceId, tableViewName } = values;
      const { sourceNames, formData } = sqlInputStore;
      const { name: sourceName = '', sqlType = '' } =
        _.find(sourceNames, (o: any) => o.id === sourceId) || {};
      params = {
        inputType: 1,
        sourceType: sqlType,
        sourceId,
        sourceName,
        extendConfig: {
          queryType,
          tableViewName
        }
      };
      if (queryType === 0) {
        params.extendConfig.column = formData.column;
      } else if (queryType === 1) {
        const querySql = this.getQuerySql();
        if (querySql) {
          params.extendConfig.tableViewName = undefined;
          params.extendConfig.querySql = querySql;
        } else {
          params = null;
          return;
        }
      } else {
        params = null;
        return;
      }
    });
    return params;
  };

  /**
   * @description: 数据源类型切换,获取对应的数据源名称列表,同时将数据表清空
   * @param {string} value
   */
  public handleSourceTypeChange = (value: string): void => {
    const { form, sqlInputStore } = this.props;
    form.setFieldsValue({
      sourceId: undefined,
      tableViewName: undefined
    });
    sqlInputStore.handleSourceTypeChange(value);
    sqlInputStore.initOriginStruct();
    this.props.handleConfigChange();
  };

  /**
   * @description: 数据源名称切换,获取对应数据源下表的列表
   * 数据源名称发生改变 同步更改算子节点的名称
   * @param {number} sourceId 数据源id 需根据 sourceNames 查询除详细信息
   */
  public handleSourceNameChange = (sourceId: number): void => {
    const { sqlInputStore, form } = this.props;
    const { name: resname = '', sqlType = '' } =
      _.find(sqlInputStore.sourceNames, (o: any) => o.id === sourceId) || {};

    const params = {
      restype: 'sql',
      sqlType,
      resname,
      id: sourceId
    };
    form.setFieldsValue({
      sourceType: sqlType,
      tableViewName: undefined
    });
    sqlInputStore.initOriginStruct();
    sqlInputStore.getTableListBySourceName(params);
    sqlInputStore.updateFormData({ column: {} });
    this.props.updateNodeNameByTag(resname);
    this.props.handleConfigChange();
  };

  public handleQueryTypeChange = (e: any) => {
    const { value } = e.target;
    const { form, sqlInputStore } = this.props;
    if (value === 0) {
      const sourceId = form.getFieldValue('sourceId');
      const { tableViewName } = sqlInputStore.formData;
      if (tableViewName) {
        this.handleSourceTableChange(tableViewName);
      } else if (sourceId) {
        this.handleSourceNameChange(sourceId);
      }
    } else if (value === 1) {
      sqlInputStore.initOriginStruct();
    }
    sqlInputStore.toggleTableView(value === 0);
  };

  /**
   * @description: 选择数据表显示该表的字段信息等
   * 重新获取输入表的字段信息，需要重新初始化映射表
   * @param {string} tableName 数据表名称
   */
  public handleSourceTableChange = (tableName: string): void => {
    if (!tableName) return;
    const { form, sqlInputStore } = this.props;
    form.validateFields(
      ['sourceType', 'sourceId'],
      (errors: any, values: any) => {
        if (errors) return;
        const { sourceId } = values;
        const { name: resname = '', sqlType = '' } =
          _.find(sqlInputStore.sourceNames, (o: any) => o.id === sourceId) ||
          {};
        const params = {
          restype: 'sql',
          sqlType,
          resname,
          id: sourceId,
          tableName
        };
        sqlInputStore.getTableFieldInfo(params);
        this.props.handleConfigChange();
      }
    );
  };

  public getReplaceSql = (replaceSql: string) => {
    this.replaceSql = replaceSql;
  };

  public handleSqlChange = (sql: string) => {
    this.setState({
      querySql: sql
    });
    this.props.handleConfigChange();
  };

  public handleQuerySql = (sql: string, replaceSql?: string): void => {
    if (!sql) {
      message.warning('请输入SQL语句!');
      return;
    }
    const { form, sqlInputStore } = this.props;
    form.validateFields(['sourceType', 'sourceId'], (errors, values) => {
      const { sourceId } = values;
      const { name: resname = '', sqlType = '' } =
        _.find(sqlInputStore.sourceNames, (o: any) => o.id === sourceId) || {};
      if (errors) return;
      const params: any = {
        restype: 'sql',
        sqlType,
        resname,
        id: sourceId
      };
      if (replaceSql) {
        params.superSql = replaceSql;
      } else {
        params.superSql = sql;
      }
      sqlInputStore.getTableFieldInfo(params);
      this.props.handleConfigChange();
    });
  };

  public testSql = () => {
    const sql = this.getQuerySql();
    if (!sql) return;
    // 判断是否含有变量
    let sqlVarArr: string[] = [];
    try {
      sqlVarArr = _.uniq(sql.match(/#\{(\w+)\}/g));
    } catch (error) {
      console.error(error);
    }
    if (sqlVarArr.length) {
      const varArr: any[] = _.map(sqlVarArr, item => {
        return {
          varName: item,
          varValue: ''
        };
      });
      confirm({
        title: <h4 className={styles.varSqlTitle}>请输入测试变量值</h4>,
        content: (
          <SqlVar
            sql={sql}
            varArr={varArr}
            getReplaceSql={this.getReplaceSql}
          />
        ),
        keyboard: false,
        onOk: () => {
          this.handleQuerySql(sql, this.replaceSql);
        }
      });
    } else {
      this.handleQuerySql(sql);
    }
  };

  public getQuerySql = () => {
    const { querySql } = this.state;
    if (!querySql) {
      message.warning('请输入SQL语句!');
      return;
    }
    return querySql;
  };

  public render() {
    const { form, sqlInputStore } = this.props;
    const { getFieldDecorator, getFieldValue } = form;
    const {
      formLoading,
      tableNameList,
      sourceTypes,
      sourceNames,
      formData: {
        tableViewName,
        column = {},
        sourceType,
        sourceId,
        queryType = 0
      }
    } = sqlInputStore;

    const isTable = (getFieldValue('queryType') || 0) === 0;
    return (
      <Spin
        tip="Loading..."
        spinning={formLoading}
        wrapperClassName="formLoading"
      >
        <Form className={styles.formWrapper}>
          <DataSourceType
            formKey="sourceType"
            initialValue={sourceType}
            sourceTypes={sourceTypes}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceTypeChange}
          />
          <DataSourceName
            formKey="sourceId"
            initialValue={sourceId}
            sourceNames={sourceNames}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleSourceNameChange}
          />
          <FormItem>
            {getFieldDecorator('queryType', { initialValue: queryType })(
              <RadioGroup onChange={this.handleQueryTypeChange}>
                <Radio value={0}>数据表/视图</Radio>
                <Radio value={1}>高级SQL</Radio>
              </RadioGroup>
            )}
          </FormItem>
          <dl className={styles.tabWrapper}>
            {isTable && (
              <dt className={styles.tableView}>
                <DataSourceTable
                  formKey="tableViewName"
                  initialValue={tableViewName}
                  tableList={tableNameList}
                  getFieldDecorator={getFieldDecorator}
                  onChange={this.handleSourceTableChange}
                />
                <Row className="inputBox">
                  <Col span={11}>
                    <FormItem label="表行数" colon={false}>
                      <Input
                        disabled
                        style={{ width: '118px' }}
                        value={column.row}
                      />
                    </FormItem>
                  </Col>
                  <Col span={11} offset={2}>
                    <FormItem label="字段数" colon={false}>
                      <Input
                        disabled
                        style={{ width: '118px' }}
                        value={column.column}
                      />
                    </FormItem>
                  </Col>
                </Row>
              </dt>
            )}
            {!isTable && (
              <dd className={styles.heightSql}>
                <Button onClick={this.testSql} className={styles.testBtn}>
                  测试
                </Button>
                <FormItem
                  label="高级SQL(注:修改SQL语句后需重新点击测试!SQL变量以#{}标识)"
                  className={styles.formRequire}
                >
                  <SqlEditor
                    sqlValue={this.state.querySql}
                    onChange={this.handleSqlChange}
                  />
                  )
                </FormItem>
              </dd>
            )}
          </dl>
        </Form>
      </Spin>
    );
  }
}

export default Form.create<IProps>({ name: 'SqlForm' })(SqlForm);
