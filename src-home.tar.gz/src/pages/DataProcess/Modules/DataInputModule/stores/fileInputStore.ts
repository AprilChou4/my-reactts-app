import { sourceKinds } from '@consts/dataSource';
import { action, observable, runInAction } from 'mobx';
import { message } from 'sup-ui';

import {
  getDataSourceListByType,
  getTableDataByFilePath,
  getFileList,
  getFileFieldInfo
} from '../../module.service';

class FileStore {
  private readonly initMapping: (params: any) => void;
  private readonly handleConfigChange: any;
  public mapping: any[] = [];
  @observable public formLoading = false;
  @observable public tableLoading = false;
  @observable public originStruct: any[] = [];
  public targetStruct: any[] = [];
  @observable public tableView = false;
  @observable public formData: any = {};
  @observable public activePath = '';
  @observable public sourceTypes: any[] = [];
  @observable public sourceNames: any[] = [];
  @observable public sourceNameGroup: { [propName: string]: any[] } = {};
  @observable public pathList: any[] = [];
  @observable public ruleFilePath = '';
  @observable public fileCount = 0;
  @observable public fileMatchMessage = ''; // 文件匹配提示
  @observable public previewData = [];
  @observable public previewVisible = false;
  @observable public previewDataLoading = false;

  public constructor({
    dataModuleConfig,
    initMapping,
    handleConfigChange
  }: any) {
    const {
      mapping = [],
      originStruct = [],
      targetStruct = [],
      extendConfig = {},
      ...restProps
    } = _.cloneDeep(dataModuleConfig);
    runInAction(() => {
      if (!restProps.inputType || restProps.inputType !== 4) {
        this.formData = {
          inputType: 4
        };
        this.mapping = [];
        this.originStruct = [];
      } else {
        this.formData = { ...restProps, ...extendConfig };
        this.mapping = mapping;
        this.originStruct = originStruct;
      }
      this.targetStruct = targetStruct;
    });
    this.initMapping = initMapping;
    this.handleConfigChange = handleConfigChange;
    this.getDataSourceListByType();
  }

  /**
   * @description: 根据不同的输入类型获取数据源列表
   * @param {string} type 默认为 sql
   */
  @action.bound
  public async getDataSourceListByType() {
    this.formLoading = true;
    const res = await getDataSourceListByType({ dataType: 'file' });
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.formLoading = false;
      });
      return;
    }
    const { sqlTypeList, table } = data.map;
    runInAction(() => {
      this.formLoading = false;
      this.sourceTypes = sqlTypeList;
      this.sourceNames = table;
      this.sourceNameGroup = _.groupBy(table, 'sqlType');
      const { sourceId, chooseWay = 1 } = this.formData;
      /*
       * 当选择的有数据源时（sourceId）,查找对应的文件路径
       * 如果有 则通过文件路径查询文件列表
       */
      if (sourceId) {
        const { url } = _.find(table, o => o.id === sourceId) || {};
        if (url) {
          this.activePath = url;
          if (chooseWay === 1 && url) {
            this.getFileList({ src: url });
          }
        }
      }
    });
  }

  /**
   * @description: 数据源类型切换
   */
  @action.bound
  public handleSourceTypeChange = (value: string) => {
    if (!value) return;
    this.sourceNames = this.sourceNameGroup[value];
    this.formData.sourceType = value;
  };

  /**
   * @description: 当文件选择方式切换时，初始化文件信息
   */
  @action.bound
  public initFileInfo = () => {
    this.fileCount = 0;
    this.ruleFilePath = '';
    this.initOriginStruct();
  };

  @action.bound
  public updateActivePath = (url: string) => {
    this.activePath = url;
  };

  @action.bound
  public updateFormData = (updateItem: any) => {
    this.formData = Object.assign(this.formData, updateItem);
    this.handleConfigChange();
  };

  @action.bound
  public async getTableDataByFilePath(params: any) {
    runInAction(() => {
      this.previewVisible = true;
      this.previewDataLoading = true;
      this.previewData = [];
    });
    const res = await getTableDataByFilePath({
      sourceId: this.formData.sourceId,
      ...params
    });
    const { code, data, message: mes } = res;
    if (code !== 200) {
      message.error(mes);
      runInAction(() => {
        this.previewDataLoading = false;
      });
      return;
    } else {
      runInAction(() => {
        this.previewDataLoading = false;
        this.previewData = data.map.list;
      });
    }
  }

  @action.bound
  public cancelPreview = () => {
    this.previewVisible = false;
  };

  /**
   * @description: 更新数据来源数组 与 initOriginStruct 对应
   * 仅用作数组中某个或多个单元的编辑修改，不用于整个数组替换（包括不限于删除，新增）
   * @param {array} 该数据来源数组
   */
  @action.bound
  public updateOriginStruct = (struct: any[]) => {
    this.originStruct = struct;
    this.handleConfigChange();
  };

  /**
   * @description: 初始化数据来源 与 updateOriginStruct 对应
   * 用且仅用作数据来源整个替换，删除/新增
   * 重新初始化数据来源之后，需要重新渲染映射表
   * @param {array} 新的数据来源数组
   */
  @action.bound
  public initOriginStruct = (struct: [] = []) => {
    this.originStruct = struct;
    this.mapping = [];
    this.initMapping({
      originStruct: struct
    });
    this.handleConfigChange();
  };

  /**
   * @description: 获取文件选择list
   */
  public async getFileList(params: any) {
    runInAction(() => {
      this.formLoading = true;
    });
    const res = await getFileList({
      sourceId: this.formData.sourceId,
      ...params
    });
    const { code, message: msg, data } = res;
    if (code !== 200) {
      message.error(msg);
      runInAction(() => {
        this.formLoading = false;
      });
      return;
    }
    runInAction(() => {
      this.pathList = data.links;
      this.formLoading = false;
    });
    this.handleConfigChange();
  }

  /**
   * @description: 获取文件字段
   */
  public async getFileFieldInfo(params: any) {
    runInAction(() => {
      this.formLoading = true;
    });
    const res = await getFileFieldInfo({
      sourceId: this.formData.sourceId,
      ...params
    });
    const { code, message: msg, data } = res;
    if (code === 200) {
      const { struct, filepath, fileCount } = data.map;
      this.initOriginStruct(struct);

      runInAction(() => {
        if (filepath) {
          this.ruleFilePath = filepath;
          // 当时文件规则时，需要记录匹配到多少个文件
          if (params.type === 2) {
            this.fileCount = fileCount;
          } else {
            this.fileCount = 0;
          }
        } else {
          this.ruleFilePath = '';
          this.fileCount = 0;
        }
        // 文件匹配提示语
        if (filepath && fileCount) {
          this.fileMatchMessage = `匹配到${filepath.replace(
            `${this.activePath}/`,
            ''
          )}等${fileCount}个文件`;
        } else {
          this.fileMatchMessage = '未匹配到文件';
        }
        this.formLoading = false;
      });
    } else {
      message.error(msg);
      runInAction(() => {
        this.formLoading = false;
      });
    }
  }

  @action.bound
  public updateFormLoading = (bool: boolean) => {
    this.formLoading = bool;
  };
}

export default FileStore;
