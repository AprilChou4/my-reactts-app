import { action, computed, observable } from 'mobx';
import update from 'immutability-helper';
import { message } from 'sup-ui';

interface AggreFieldItem {
  key: number;
  name: string;
  showName: string;
}
interface MoveItem {
  name: string;
  showName: string;
  dataType: string;
  [propName: string]: any;
}

class AggregationStore {
  public sourceList = []; //源数据
  private readonly toggleChangedStatus: (status: boolean) => void;
  private hasDirty = false;
  @observable public keyword = ''; //搜索字段
  @observable.struct public selectedRowKeys: string[] = []; //选中的行
  @observable public groupFieldList: any[] = []; //分组字段组列表
  @observable public aggreFieldList: AggreFieldItem[] = []; //聚合字段组列表
  public aggreFormValues = {}; //aggre_form表单初始值
  public periodFormValues = {}; //period_form表单初始值
  @observable public visible = false; //预览弹窗
  @observable public previewList = []; //预览数据

  public keys = 0;

  public constructor(config: any, sourceData: any, toggleChangedStatus: any) {
    this.sourceList = sourceData;
    this.toggleChangedStatus = toggleChangedStatus;
    this.initData(config);
  }

  @action
  public initData(config: any) {
    if (!_.isEmpty(config)) {
      const {
        groupFields = [],
        aggregationFields = [],
        aggregationCycle = {}
      } = config;
      //分组
      this.groupFieldList = groupFields;

      //聚合
      const aggreList: any = [],
        aggreFormValues: any = {};
      aggregationFields.forEach((item: any) => {
        const key = this.keys++;
        aggreList.push({
          key,
          ...item
        });
        aggreFormValues[`${key}_targetName`] = item.targetName;
        aggreFormValues[`${key}_targetShowName`] = item.targetShowName;
        aggreFormValues[`${key}_aggregationRule`] = item.aggregationRule;
      });
      this.aggreFieldList = aggreList;
      this.aggreFormValues = aggreFormValues;

      //聚合周期
      this.periodFormValues = aggregationCycle;
    }
  }

  /*总列表模块*/
  /*过滤列表项*/
  @computed
  public get filterSourceList(): MoveItem[] {
    const filterFields = ['name'];
    return _.filter(this.sourceList, (item: any) =>
      _.some(filterFields, field => item[field].indexOf(this.keyword) !== -1)
    );
  }

  /*聚合周期-聚合基准时间字段Options*/
  @computed
  public get aggreBaseOptions(): MoveItem[] {
    //去除分组字段，筛选出时间字段
    const timeType = ['Timestamp', 'Date', 'Year'];
    const base = _.differenceBy(this.sourceList, this.groupFieldList, 'name');
    return _.filter(base, item => timeType.indexOf(item['dataType']) > -1);
  }
  /*聚合周期-额外输出数据记录字段Options*/
  @computed
  public get extraFieldOptions(): MoveItem[] {
    return _.differenceBy(this.sourceList, this.groupFieldList, 'name');
  }
  /*聚合周期-额外输出数据记录字段Options*/
  @computed
  public get sortFieldOptions(): MoveItem[] {
    //筛选出可以排序的字段
    const cantSortType = ['Bytes'];
    return _.filter(
      this.sourceList,
      item => cantSortType.indexOf(item['dataType']) === -1
    );
  }

  /*更改搜索字段*/
  @action.bound
  public changeKeyword(keyword: string) {
    this.keyword = keyword;
  }
  /*更新列表选择行*/
  @action.bound
  public updateSelectedRowKeys(selectedKeys: string[]) {
    this.selectedRowKeys = selectedKeys;
  }

  @action.bound
  public addGroupFieldItems(moveItems: MoveItem[]) {
    const diffList = _.differenceBy(moveItems, this.groupFieldList, 'name');
    if (diffList.length < moveItems.length) {
      message.warning('已过滤重复添加的字段!');
    }
    const deleteKeys = _.map(diffList, item => item.name);
    this.groupFieldList = [...this.groupFieldList, ...diffList];
    this.selectedRowKeys = _.difference(this.selectedRowKeys, deleteKeys);
    if (diffList.length > 0) this.markConfigAsDirty();
  }

  @action.bound
  public addAggreFieldItems(moveItems: MoveItem[]) {
    const NumField = [
      'Integer',
      'Double',
      'Long',
      'BigDecimal',
      'Float',
      'Short'
    ];
    const diffList = _.filter(moveItems, item =>
      _.includes(NumField, item.dataType)
    );
    if (diffList.length < moveItems.length) {
      message.warning('已过滤非数值类型!');
    }
    const deleteKeys = _.map(diffList, item => item.name);
    const tempList = _.map(diffList, item => ({
      key: this.keys++,
      ...item
    }));
    this.aggreFieldList = [...this.aggreFieldList, ...tempList];
    this.selectedRowKeys = _.difference(this.selectedRowKeys, deleteKeys);
    if (diffList.length > 0) this.markConfigAsDirty();
  }

  /*添加对应列表*/
  @action.bound
  public addSpecifyFieldItems(field: string) {
    //从filterSourceList里筛选出selectedRowKeys项
    const moveItems: MoveItem[] = _.filter(
      this.filterSourceList,
      item => this.selectedRowKeys.indexOf(item['name']) > -1
    );
    if (moveItems.length === 0) {
      message.warning('请选择要添加的字段!');
      return;
    }

    if (field === '1') {
      this.addGroupFieldItems(moveItems);
    } else if (field === '2') {
      this.addAggreFieldItems(moveItems);
    }
  }

  /*分组字段模块*/
  /*拖动列表项*/
  @action.bound
  public moveGroupFieldItem(dragIndex: number, hoverIndex: number) {
    const dragRow = this.groupFieldList[dragIndex];
    this.groupFieldList = update(this.groupFieldList, {
      $splice: [
        [dragIndex, 1],
        [hoverIndex, 0, dragRow]
      ]
    });
    this.markConfigAsDirty(); //标记更改
  }
  /*删除列表项*/
  @action.bound
  public deleteGroupFieldItems(selectedRowKeys: any[]) {
    if (this.groupFieldList.length === 0) return;
    const deleteItems = _.filter(
      this.groupFieldList,
      item => selectedRowKeys.indexOf(item['name']) > -1
    );
    this.groupFieldList = _.differenceBy(
      this.groupFieldList,
      deleteItems,
      'name'
    );
    this.markConfigAsDirty(); //标记更改
  }

  /*聚合字段模块*/
  /*删除列表项*/
  @action.bound
  public deleteAggreFieldItems(selectedRowKeys: any[]) {
    if (this.aggreFieldList.length === 0) return;
    const deleteItems = _.filter(
      this.aggreFieldList,
      item => selectedRowKeys.indexOf(item['key']) > -1
    );
    this.aggreFieldList = _.differenceBy(
      this.aggreFieldList,
      deleteItems,
      'key'
    );
    this.markConfigAsDirty(); //标记更改
  }

  /*触发了config修改*/
  @action.bound
  public markConfigAsDirty() {
    if (this.hasDirty || this.sourceList.length === 0) return;
    this.hasDirty = true;
    this.toggleChangedStatus(true);
  }

  @action.bound
  public changeDataPreviewVisible(visible: boolean) {
    this.visible = visible;
  }
  @action.bound
  public changeDataPreviewList(list: any) {
    this.previewList = list;
  }
}

export default AggregationStore;
