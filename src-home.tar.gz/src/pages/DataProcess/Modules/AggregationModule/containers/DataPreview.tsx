import React, { Component } from 'react';
import { Modal, Table } from 'sup-ui';
import { inject, observer } from 'mobx-react';
import { TableCellText } from '@components/Table';

const columns = [
  {
    title: '字段',
    dataIndex: 'name',
    width: 150,
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '字段含义',
    dataIndex: 'showName',
    width: 150,
    className: 'ellipsis-hide',
    render: (text: string) => <TableCellText text={text} />
  },
  {
    title: '数据类型',
    dataIndex: 'dataType'
  }
];

interface IProps {
  store?: any;
}
interface IState {}

@inject('store')
@observer
class DataPreview extends Component<IProps, IState> {
  public handleClose = () => {
    this.props.store.changeDataPreviewVisible(false);
  };

  public render() {
    const { visible, previewList } = this.props.store;
    return (
      <Modal
        title="聚合预览"
        visible={visible}
        onCancel={this.handleClose}
        footer={null}
      >
        <Table
          size="small"
          rowKey="name"
          columns={columns}
          dataSource={previewList}
          scroll={{ y: 400 }}
          pagination={false}
        />
      </Modal>
    );
  }
}

export default DataPreview;
