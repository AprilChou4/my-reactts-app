import React, { Component } from 'react';
import { Form, Table, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import Icon from '@components/Icon';
import {
  getExtendConfig,
  getTargetVar,
  getTypeOptions,
  getFieldOptions
} from './varSet.helper';
import ConstValueInterface from './ConstValueInterface';
import VarName from './VarName';
import VarSetType from './VarSetType';
import FieldInterface from './FieldInterface';

interface IProps extends FormComponentProps {
  dataSource: any[];
  variables: [];
  dataModuleInputDatas: [];
  updateRules: (rules: any[]) => void;
}

class VarSetTable extends Component<IProps> {
  public constructor(props: IProps) {
    super(props);
  }

  public verifyRules = () => {
    let params;
    this.props.form.validateFields((errors: any) => {
      if (!errors) {
        params = true;
      } else {
        message.error('请校验必填信息!');
        params = false;
      }
    });
    return params;
  };

  /**
   * @description: 变量选择变化事件
   * 默认设置类型为常量
   */
  private handleVarNameChange = (value: string, record: any) => {
    const targetVar: any = getTargetVar(value, this.props.variables);
    const newRecord = {
      ...record,
      variableName: value,
      dataType: _.get(targetVar, 'dataType'),
      extendConfig: getExtendConfig(_.get(record, 'type'), targetVar)
    };
    this.updateRulesByKey(newRecord);
  };

  /**
   * @description: 修改某条数据的 设置类型
   * @param {string} value 设置的类型 1-常量 2-字段  3-Table整表 4-Row第一行  5-Column 某列
   */
  private handleTypeChange = (value: any, record: any) => {
    const targetVar: any = getTargetVar(
      record.variableName,
      this.props.variables
    );
    const newRecord = {
      ...record,
      type: value,
      extendConfig: getExtendConfig(value, targetVar)
    };
    this.updateRulesByKey(newRecord);
  };

  private handleExtendConfigChange = (extendConfig: any, record: any) => {
    const newRecord = { ...record, extendConfig };
    this.updateRulesByKey(newRecord);
  };

  private updateRulesByKey = (newRecord: any) => {
    const newDataSource = _.map(this.props.dataSource, (item: any) =>
      item.key === newRecord.key ? newRecord : item
    );
    this.props.updateRules(newDataSource);
  };

  /**
   * @description: 删除某一行数据 将最新的数据结构传递给父组件
   * @param {object} record 某一行数据
   */
  private delRecord = (record: any) => {
    const { dataSource } = this.props;
    const newDataSource = _.filter(
      dataSource,
      (item: any) => item.key !== record.key
    );
    this.props.updateRules(newDataSource);
  };

  private getColumns = () => {
    const {
      form: { getFieldDecorator },
      variables,
      dataSource
    } = this.props;
    return [
      {
        title: '变量',
        dataIndex: 'variableName',
        key: 'variableName',
        width: 110,
        render: (_text: string, record: any) => (
          <VarName
            formKey={`${record.key}_variableName`}
            getFieldDecorator={getFieldDecorator}
            initialValue={record.variableName}
            options={_.filter(
              variables,
              (varItem: any) =>
                !_.find(dataSource, o => o.variableName === varItem.name)
            )}
            onChange={(value: string) => {
              this.handleVarNameChange(value, record);
            }}
          />
        )
      },
      {
        title: '变量类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: 80
      },
      {
        title: '设置类型',
        dataIndex: 'type',
        width: 100,
        key: 'type',
        render: (_text: any, record: any) => (
          <VarSetType
            formKey={`${record.key}_type`}
            initialValue={record.type}
            getFieldDecorator={getFieldDecorator}
            options={getTypeOptions(record, this.props.variables)}
            onChange={value => this.handleTypeChange(value, record)}
          />
        )
      },
      {
        dataIndex: 'extendConfig',
        key: 'extendConfig',
        render: (text: any, record: any) => {
          const { key, type: recordType, dataType, extendConfig = {} } = record;
          if (recordType === 1) {
            return (
              <ConstValueInterface
                formKey={`${key}_extendConfig`}
                value={text}
                dataType={dataType}
                getFieldDecorator={getFieldDecorator}
                onChange={(value: any) => {
                  this.handleExtendConfigChange(value, record);
                }}
              />
            );
          } else {
            const { constValue, name } = extendConfig;
            const { dataModuleInputDatas } = this.props;
            return (
              <FieldInterface
                formKey={`${key}_name`}
                recordType={recordType}
                getFieldDecorator={getFieldDecorator}
                initialValue={name}
                options={getFieldOptions({
                  recordType,
                  dataType,
                  constValue: constValue ? constValue.value : '',
                  inputDatas: dataModuleInputDatas
                })}
                onChange={value => {
                  this.handleExtendConfigChange(
                    _.assign(extendConfig, {
                      name: value
                    }),
                    record
                  );
                }}
              />
            );
          }
        }
      },
      {
        title: '移除',
        width: 50,
        align: 'center',
        render: (_text: any, record: any) => (
          <Icon
            type="remove"
            onClick={e => {
              e.stopPropagation();
              this.delRecord(record);
            }}
          />
        )
      }
    ];
  };

  public render() {
    const { dataSource } = this.props;
    const columns: any = this.getColumns();
    return (
      <Table
        size="small"
        className="task-base-table task-edit-table"
        rowKey="key"
        columns={columns}
        dataSource={dataSource}
        scroll={{ y: 'auto' }}
        pagination={false}
      />
    );
  }
}

export default Form.create<IProps>({ name: 'varSetTable' })(VarSetTable);
