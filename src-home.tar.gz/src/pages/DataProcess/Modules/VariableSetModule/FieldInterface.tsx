import React, { FunctionComponent } from 'react';
import { Form, Select, InputNumber } from 'sup-ui';
import { popupContainer } from '@utils/propUtil';

const FormItem = Form.Item;
const { Option } = Select;

interface IProps {
  formKey: string;
  recordType: number;
  initialValue: string;
  options: any[];
  onChange: (value: string) => void;
  getFieldDecorator: any;
}

const FieldInterface: FunctionComponent<IProps> = (props: IProps) => {
  const {
    formKey,
    initialValue,
    recordType,
    getFieldDecorator,
    options,
    onChange
  } = props;
  return (
    <div style={{ display: 'flex' }}>
      {(recordType === 2 || recordType === 5) && (
        <FormItem style={{ marginRight: '5px', width: '150px' }}>
          {getFieldDecorator(formKey, {
            initialValue,
            rules: [
              {
                required: true,
                message: '请选择'
              }
            ]
          })(
            <Select
              size="small"
              placeholder="-请选择-"
              getPopupContainer={popupContainer}
              dropdownMatchSelectWidth={false}
              onChange={onChange}
            >
              {_.map(options, (item: any) => (
                <Option key={item.name} value={item.name}>
                  {item.name}
                </Option>
              ))}
            </Select>
          )}
        </FormItem>
      )}
      {(recordType === 2 || recordType === 4) && (
        <div className="sup-form-item-children">
          <InputNumber
            size="small"
            min={1}
            value={1}
            style={{
              width: '60px',
              marginRight: '5px'
            }}
            disabled={true}
          />
          <span style={{ width: '60px', marginRight: '10px' }}>行</span>
        </div>
      )}
    </div>
  );
};

export default FieldInterface;
