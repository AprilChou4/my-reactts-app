import React, { PureComponent } from 'react';
import { Table, Button } from 'sup-ui';

import uuid from '@utils/uuid';
import FieldSearch from '../components/FieldSearch';
import TaskTitle from '../components/TaskTitle';
import { baseTableColumns } from '../components/BaseTable';
import VarSetTable from './VarSetTable';
import {
  getDataModuleInputDatas,
  getInputDatasChangedStatus
} from '../module.helper';
import { IModuleProps } from '../module';
import { verifyingItemByKeys } from './varSet.helper';
import styles from '../index.less';

interface IState {
  dataModuleTag: string;
  dataModuleInputDatas: [];
  filterSourceDataStruct: any[];
  keyword: string;
  variables: [];
  rules: any[];
  targetKeys: [];
  filterFields: string[];
}

class VariableSetModule extends PureComponent<IModuleProps, IState> {
  private varSetRef: any;

  public constructor(props: IModuleProps) {
    super(props);
    this.state = {
      dataModuleTag: '', // 模块tag
      dataModuleInputDatas: [], // 输入数据
      filterSourceDataStruct: [], // 过滤后的数据
      variables: [],
      rules: [], // 输出数据
      targetKeys: [], // 输出数据的keys
      filterFields: ['name'],
      keyword: ''
    };
    props.initApi(this.saveConfig);
  }

  public static getDerivedStateFromProps(nextProps: any, state: any) {
    const { dataModuleTag, dataModuleInputDatas, dataModuleConfig, variables } =
      nextProps;
    const nextInputDatas = getDataModuleInputDatas(dataModuleInputDatas);
    // 根据`dataModuleInputDatas`与`nextDataModuleInputDatas`判断数据源是否已经改变
    const inputStructChanged = getInputDatasChangedStatus(
      state.dataModuleInputDatas,
      nextInputDatas
    );

    let newRules = _.cloneDeep(state.rules);

    // 根据`variables`判断变量是否改变
    const isVariablesChanged = !_.isEqual(variables, state.variables);
    let variablesState = {};
    if (isVariablesChanged) {
      variablesState = {
        variables: _.isArray(variables) ? variables : []
      };
    }

    // 根据`dataModuleTag`判断组件是否改变
    const isDataModuleTagChanged = dataModuleTag !== state.dataModuleTag;
    if (isDataModuleTagChanged || inputStructChanged) {
      newRules = _.get(dataModuleConfig, 'rules', []);
    }

    // 校验 已选变量 和 已选字段 是否合法
    newRules = _.map(newRules, (item: any) => {
      const verifyingItem = verifyingItemByKeys(
        nextInputDatas,
        variables,
        item
      );
      return {
        ...item,
        invild: verifyingItem.invild,
        errFieldKeys: verifyingItem.errFieldKeys
      };
    });

    // 当组件改变或者数据源改变时，对state中的各项做相应的改变
    return isDataModuleTagChanged || inputStructChanged
      ? _.merge(
          {
            dataModuleInputDatas: nextInputDatas,
            filterSourceDataStruct: nextInputDatas,
            variables: _.isArray(variables) ? variables : []
          },
          isDataModuleTagChanged
            ? {
                dataModuleTag,
                rules: newRules
              }
            : null
        )
      : { ...variablesState, rules: newRules };
  }

  public componentDidUpdate(_prevProps: IModuleProps, prevState: any) {
    const {
      dataModuleInputDatas: prevInputDatas = [],
      variables: prevVariables = []
    } = prevState;
    const {
      dataModuleInputDatas: nextInputDatas = [],
      variables: nextVariables = [],
      rules = []
    } = this.state;

    if (
      !_.isEqual(prevInputDatas, nextInputDatas) ||
      !_.isEqual(prevVariables, nextVariables)
    ) {
      this.initRulesInvild(rules);
    }
  }

  private initRulesInvild = (rules: any) => {
    const setFieldObj: any = {};
    _.forEach(
      _.filter(rules, item => item.invild),
      ({ errFieldKeys = [] }) => {
        _.forEach(errFieldKeys, fieldKey => {
          setFieldObj[fieldKey] = {
            value: ''
          };
        });
      }
    );
  };

  /**
   * @description: 保存配置信息
   * @return: object config
   */
  private saveConfig = () => {
    const verifyRes = this.varSetRef.verifyRules();
    if (!verifyRes) return;
    return {
      struct: this.state.dataModuleInputDatas,
      rules: _.map(this.state.rules, item => {
        const newItem = { ...item };
        if (item.dataType === 'Datetime') {
          const type = _.get(newItem, 'extendConfig.constValue.type', '');
          if (_.startsWith(`${type}`, '1')) {
            _.set(newItem, 'extendConfig.constValue.type', 1);
          }
        }
        return newItem;
      })
    };
  };

  /**
   * @description: 配置信息发生改变后触发函数,修改算子是否更改状态
   */
  private handleConfigChange = () => {
    this.props.toggleChangedStatus();
  };

  /**
   * @description: 新增变量设置
   */
  private addVarSetRule = () => {
    const { rules } = this.state;
    const newRecord = {
      key: uuid(6),
      variableName: undefined,
      dataType: undefined,
      type: 1,
      extendConfig: {
        name: undefined,
        lineNum: '1',
        constValue: undefined
      }
    };
    this.setState({
      rules: _.concat(rules, newRecord)
    });
    this.handleConfigChange();
  };

  /**
   * @description: 对 rules 进行增删改查之后将新的rules 覆盖
   * @param {array} rules 新的 rules 结构
   */
  private handleUpdateRules = (rules: any) => {
    this.setState({
      rules
    });
    this.handleConfigChange();
  };

  /**
   * @description: 根据关键词过滤源数据
   * @param {string} keyword
   */
  private handleSearch = (keyword: string) => {
    const { dataModuleInputDatas, filterFields } = this.state;
    const filterSourceDataStruct = _.filter(dataModuleInputDatas, (item: any) =>
      _.some(
        filterFields,
        (field: any) => _.get(item, [field], '').indexOf(keyword) !== -1
      )
    );
    this.setState({
      keyword,
      filterSourceDataStruct
    });
  };

  public render() {
    const { rules, filterSourceDataStruct, variables, keyword } = this.state;

    return (
      <dl className={styles.container}>
        <dt className={styles.leftContainer}>
          <div className={styles.title}>
            <TaskTitle index={1} subTitle="选择数据源" />
            <FieldSearch value={keyword} handleSearch={this.handleSearch} />
          </div>
          <Table
            size="small"
            className="task-base-table"
            rowKey="name"
            columns={baseTableColumns}
            dataSource={filterSourceDataStruct}
            scroll={{ y: 'auto' }}
            pagination={false}
          />
        </dt>
        <dd className={styles.rightContainer}>
          <div className={styles.title}>
            <TaskTitle index={2} subTitle="变量设置" />
            <Button size="small" type="primary" onClick={this.addVarSetRule}>
              新增
            </Button>
          </div>
          <VarSetTable
            wrappedComponentRef={(ref: any) => {
              if (!this.varSetRef) {
                this.varSetRef = ref;
              }
            }}
            dataSource={rules}
            variables={variables}
            dataModuleInputDatas={this.state.dataModuleInputDatas}
            updateRules={this.handleUpdateRules}
          />
        </dd>
      </dl>
    );
  }
}
export default VariableSetModule;
