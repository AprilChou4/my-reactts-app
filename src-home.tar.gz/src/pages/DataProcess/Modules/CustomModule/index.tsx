import React, { Component } from 'react';
import { Provider } from 'mobx-react';

import {
  getDataModuleInputDatas,
  getDerivedStateFromProps
} from '../module.helper';
import ModuleTab from '../components/ModuleTab';

import { IModuleProps } from '../module';
import ScriptInput from './ScriptInput';
import OutputData from './OutputData';
import CustomScriptStore from './customScript.store';

interface IProps extends IModuleProps {}

interface IState {
  dataModuleTag: string;
  dataModuleInputDatas: any[];
}

class CustomModule extends Component<IProps, IState> {
  private customStore: any;

  public constructor(props: IProps) {
    super(props);
    const inputDatas = getDataModuleInputDatas(props.dataModuleInputDatas);
    this.state = {
      dataModuleTag: '',
      dataModuleInputDatas: inputDatas
    };
    this.customStore = new CustomScriptStore({
      config: props.dataModuleConfig,
      inputDatas,
      handleConfigChange: this.handleConfigChange
    });
    props.initApi(this.saveConfig);
  }

  public componentDidUpdate(_preProps: any, preState: any) {
    if (
      !_.isEqual(preState.dataModuleInputDatas, this.state.dataModuleInputDatas)
    ) {
      this.customStore.handleInputDataChange(this.state.dataModuleInputDatas);
    }
  }
  public static getDerivedStateFromProps(nextProps: any, state: any) {
    return getDerivedStateFromProps(nextProps, state);
  }

  /**
   * @description: 保存配置信息
   * @return: object config
   */
  public saveConfig = () => {
    const { customType, customParams, execResult, javascript, outDataset } =
      this.customStore;
    return {
      dataset: this.state.dataModuleInputDatas,
      type: customType,
      params: customParams,
      execResult,
      script: javascript,
      struct: outDataset
    };
  };

  /**
   * @description: 配置信息发生改变后触发函数,修改算子是否更改状态
   */
  public handleConfigChange = () => {
    this.props.toggleChangedStatus();
  };

  public render() {
    return (
      <Provider customStore={this.customStore}>
        <ModuleTab
          tabs={['脚本输入', '脚本输出']}
          leftNode={
            <ScriptInput
              inputData={this.state.dataModuleInputDatas}
              variables={this.props.variables || []}
            />
          }
          rightNode={<OutputData />}
        />
      </Provider>
    );
  }
}
export default CustomModule;
