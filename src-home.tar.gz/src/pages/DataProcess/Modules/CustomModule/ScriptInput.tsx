import React, { Component } from 'react';
import { inject, observer } from 'mobx-react';
import { Table, Button, Radio, Spin } from 'sup-ui';
import classnames from 'classnames';

// import GroovyEditor from '@components/ScriptEditor/GroovyEditor';
// import ShellEditor from '@components/ScriptEditor/ShellEditor';
import JavaScriptEditor from '@components/ScriptEditor/JavaScriptEditor';
import Icon from '@components/Icon';
import { baseTableColumns } from '../components/BaseTable';
import TaskTitle from '../components/TaskTitle';
import FieldSearch from '../components/FieldSearch';
import DebugDataModal from './DebugDataModal';

import styles from './index.less';

interface IProps {
  customStore?: any;
  inputData: any[];
  variables: any[];
}

interface IState {
  keyword: string;
  debugModalVisible: boolean;
}

@inject('customStore')
@observer
class ScriptInput extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      keyword: '',
      debugModalVisible: false
    };
  }

  private handleCustomType = (e: any) => {
    this.props.customStore.handleCustomType(e.target.value);
  };

  private toggleDebugModalVisible = (bool: boolean) => {
    this.setState({
      debugModalVisible: bool
    });
  };

  private handleSave = (customParams: any[]) => {
    this.props.customStore.saveCustomParams(customParams);
    this.toggleDebugModalVisible(false);
  };

  /**
   * @description: 根据关键词过滤源数据
   * @param {string} keyword
   */
  private handleSearch = (keyword: string) => {
    this.setState({
      keyword
    });
  };

  private handleGroovy = (_value: any) => {
    //console.log(value);
  };

  private handleJavaScript = (value: string) => {
    this.props.customStore.updateCustomScript(value);
  };

  private handleDebugLogVisible = () => {
    this.props.customStore.handleDebugLogVisible();
  };

  private customDebug = () => {
    this.props.customStore.customDebug(this.props.variables);
  };

  public render() {
    const { keyword, debugModalVisible } = this.state;
    const {
      inputData,
      variables = [],
      customStore: {
        customType,
        customParams,
        javascript,
        execResult,
        outDataset,
        debugStatus,
        debugLogVisible,
        debugLogs
      }
    } = this.props;

    return (
      <dl className={styles.container}>
        <dt className={styles.leftContainer}>
          <div className={styles.title}>
            <TaskTitle index={1} subTitle="选择数据源" />
            <FieldSearch value={keyword} handleSearch={this.handleSearch} />
          </div>
          <Table
            size="small"
            className="task-base-table"
            rowKey="name"
            columns={baseTableColumns}
            dataSource={_.filter(inputData, item =>
              _.includes(item.name, keyword)
            )}
            scroll={{ y: 'auto' }}
            pagination={false}
          />
        </dt>
        <dd className={styles.scriptContainer}>
          <TaskTitle index={2} subTitle="自定义" />
          <div className={styles.opera}>
            <Radio.Group onChange={this.handleCustomType} value={customType}>
              {/* <Radio value="JAVASCRIPT">JavaScript</Radio>
              <Radio value="SHELL">Shell</Radio>
              <Radio value="GROOVY">Groovy</Radio> */}
            </Radio.Group>
            <span className={styles.operaBtn}>
              <Button
                size="small"
                disabled={debugStatus === 'pending' || inputData.length === 0}
                onClick={this.toggleDebugModalVisible.bind(this, true)}
              >
                数据模拟
              </Button>
              <Button
                size="small"
                disabled={debugStatus === 'pending' || inputData.length === 0}
                className={
                  debugStatus === 'fail' || debugStatus === 'notDebug'
                    ? 'warning'
                    : ''
                }
                onClick={this.customDebug}
              >
                调试
              </Button>
            </span>
          </div>
          <div className={styles.debugWrapper}>
            <ul className={styles.editorContainer}>
              <Spin spinning={debugStatus === 'pending'}>
                <li
                  className={classnames(
                    styles.editorItem,
                    customType === 'JAVASCRIPT' && styles.activeItem
                  )}
                >
                  <JavaScriptEditor
                    value={javascript}
                    variables={_.concat(
                      ['dataList', 'log', 'debug'],
                      _.filter(
                        _.map(variables, (item: any) => {
                          if (_.isObject(item.constValue)) {
                            return item.constValue.type === 1
                              ? item.name
                              : undefined;
                          } else {
                            return item.name;
                          }
                        }),
                        i => i
                      )
                    )}
                    height="100%"
                    onChange={this.handleJavaScript}
                  />
                </li>
                {/* <li
                  className={classnames(
                    styles.editorItem,
                    customType === 'SHELL' && styles.activeItem
                  )}
                >
                  <ShellEditor
                    value=""
                    height="100%"
                    onChange={this.handleGroovy}
                  />
                </li>
                <li
                  className={classnames(
                    styles.editorItem,
                    customType === 'GROOVY' && styles.activeItem
                  )}
                >
                  <GroovyEditor
                    value=""
                    height="100%"
                    onChange={this.handleGroovy}
                  />
                </li> */}
              </Spin>
            </ul>
            <div className={styles.debugResult}>
              <h3 className={styles.debugResultTitle}>
                调试结果
                <Icon
                  type="arrow-down"
                  viewBox="0 0 10 6"
                  className={!debugLogVisible ? styles.rotate : ''}
                  onClick={this.handleDebugLogVisible}
                />
              </h3>
              <div
                className={classnames(
                  styles.debugResultContent,
                  debugLogVisible && styles.debugResultContentShow
                )}
              >
                {_.map(debugLogs, (logItem, logIndex) => (
                  <p key={`log_${logIndex}`}>{JSON.stringify(logItem)}</p>
                ))}
              </div>
            </div>
          </div>
          {debugModalVisible && (
            <DebugDataModal
              inputData={inputData}
              debugData={customParams}
              outDataset={outDataset}
              previewData={execResult}
              debugModalVisible={true}
              onDebugModalVisible={this.toggleDebugModalVisible}
              onOk={this.handleSave}
            />
          )}
        </dd>
      </dl>
    );
  }
}

export default ScriptInput;
