import React, { Component, Fragment } from 'react';
import classnames from 'classnames';
import { Tabs, Table, Form, Button, Divider, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import { ColumnProps } from 'sup-ui/es/table';

import Icon from '@components/Icon';
import { DelBtn, AddBtn } from '@components/Button';
import { TableCellText } from '@components/Table';
import DialogModal from '@components/Modal/Dialog';
import uuid from '@utils/uuid';
import { getMockData } from '../module.helper';
import SetValueByDataType from '../components/SetValueByDataType';
import styles from './index.less';

const { TabPane } = Tabs;

interface IProps extends FormComponentProps {
  inputData: any[];
  debugData: any[];
  previewData: any[];
  outDataset: any[];
  debugModalVisible: boolean;
  onDebugModalVisible: (value: boolean) => void;
  onOk: (debugData: any[]) => void;
}
interface IState {
  selectedRowKeys: any[];
  debugData: any[];
  loading: boolean;
}

class DebugDataModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      selectedRowKeys: [],
      loading: _.isEmpty(props.debugData),
      debugData: _.cloneDeep(props.debugData)
    };
  }

  public componentDidMount() {
    if (_.isEmpty(this.props.debugData)) {
      const mockData = _.map(_.range(10), () => ({
        ...getMockData(this.props.inputData),
        DAM_debugDataRowKey: uuid(4)
      }));
      setTimeout(() => {
        this.setState({
          debugData: mockData,
          loading: false
        });
      }, 500);
    }
  }

  private handleOk = () => {
    this.props.form.validateFieldsAndScroll((error: any) => {
      if (error) {
        message.error('参数信息有误请核对!');
        return;
      } else {
        this.props.onOk(this.state.debugData);
      }
    });
  };

  private addMockData = () => {
    this.setState({
      debugData: _.concat(this.state.debugData, {
        ...getMockData(this.props.inputData),
        DAM_debugDataRowKey: uuid(4)
      })
    });
  };

  private copyMockData = (key: string) => {
    const { debugData } = this.state;
    const dataIndex = _.findIndex(
      debugData,
      item => item.DAM_debugDataRowKey === key
    );
    if (dataIndex < 0) return;
    const insertItem = {
      ...debugData[dataIndex]
    };
    insertItem['DAM_debugDataRowKey'] = uuid(4);
    debugData.splice(dataIndex + 1, 0, insertItem);
    this.setState({
      debugData
    });
  };

  private batchCopyMockData = () => {
    const { debugData, selectedRowKeys } = this.state;
    if (debugData.length + selectedRowKeys.length > 50) {
      message.warning('数据量超过最大限制条数！');
      return;
    }
    _.forEach(selectedRowKeys, key => {
      const dataIndex = _.findIndex(
        debugData,
        item => item.DAM_debugDataRowKey === key
      );
      if (dataIndex >= 0) {
        const insertItem = {
          ...debugData[dataIndex]
        };
        insertItem['DAM_debugDataRowKey'] = uuid(4);
        debugData.splice(dataIndex + 1, 0, insertItem);
      }
    });
    this.setState({
      debugData,
      selectedRowKeys: []
    });
  };

  private deleteMockData = (key: string) => {
    const { debugData } = this.state;
    this.setState({
      debugData: _.remove(debugData, item => item.DAM_debugDataRowKey !== key)
    });
  };

  private batchDeleteMockData = () => {
    const { debugData, selectedRowKeys } = this.state;
    this.setState({
      debugData: _.remove(
        debugData,
        item => !_.includes(selectedRowKeys, item.DAM_debugDataRowKey)
      ),
      selectedRowKeys: []
    });
  };

  private handleRecordChange = (
    targetValue: string | number,
    field: string,
    record: { DAM_debugDataRowKey: string; dataType: string }
  ) => {
    const { debugData } = this.state;
    const dataIndex = _.findIndex(
      debugData,
      item => item.DAM_debugDataRowKey === record.DAM_debugDataRowKey
    );
    if (dataIndex < 0) return;
    if (record.dataType === 'Boolean') {
      debugData[dataIndex][field] = _.isNil(targetValue) ? null : !!targetValue;
    } else if (
      _.includes(
        [
          'Integer',
          'Long',
          'BigInteger',
          'Double',
          'Float',
          'BigDecimal',
          'Year'
        ],
        record.dataType
      )
    ) {
      debugData[dataIndex][field] = Number(targetValue);
    } else {
      debugData[dataIndex][field] = targetValue;
    }
    this.setState({
      debugData
    });
  };

  private handleSelectChange = (selectedRowKeys: any[]) => {
    this.setState({ selectedRowKeys });
  };

  private getTableItemWidth = (dataType: string, itemWidth: number) => {
    switch (dataType) {
      case 'Boolean':
        return '100px';
      case 'Timestamp':
        return '210px';
      case 'Date':
        return '180px';
      default:
        return `${itemWidth}px`;
    }
  };

  private getInputColumns = () => {
    const { inputData } = this.props;
    let itemWidth = 120;
    if (inputData.length) {
      const calcWidth =
        (document.body.offsetWidth * 0.8 - 200) / this.props.inputData.length;
      itemWidth = calcWidth > itemWidth ? calcWidth : itemWidth;
    }
    const mockDataTitle: ColumnProps<any>[] = _.map(inputData, item => ({
      title: item.name,
      dataIndex: item.name,
      key: item.name,
      width: this.getTableItemWidth(item.dataType, itemWidth),
      render: (text: any, record: any) => (
        <SetValueByDataType
          formKey={`${item.name}_${record.DAM_debugDataRowKey}`}
          varType="const"
          size="small"
          value={
            item.dataType === 'Boolean'
              ? text === true
                ? 1
                : text === false
                ? 0
                : undefined
              : text
          }
          required={false}
          dataType={item.dataType}
          getFieldDecorator={this.props.form.getFieldDecorator}
          onChange={(v: any) => {
            this.handleRecordChange(v, item.name, record);
          }}
        />
      )
    }));
    mockDataTitle.push({
      title: '操作',
      dataIndex: 'operation',
      fixed: 'right',
      align: 'center',
      width: '120px',
      render: (_text: string, record: any) => (
        <Fragment>
          <div className="more">
            <Icon type="ellipsis" />
          </div>
          <div className="operator">
            <a
              onClick={this.copyMockData.bind(this, record.DAM_debugDataRowKey)}
            >
              复制
            </a>
            <Divider type="vertical" />
            <a
              onClick={this.deleteMockData.bind(
                this,
                record.DAM_debugDataRowKey
              )}
            >
              删除
            </a>
          </div>
        </Fragment>
      )
    });
    return mockDataTitle;
  };

  private getOutputColumns = () => {
    const { outDataset } = this.props;
    let itemWidth = 120;
    if (outDataset.length) {
      const calcWidth =
        (document.body.offsetWidth * 0.8 - 200) / this.props.outDataset.length;
      itemWidth = calcWidth > itemWidth ? calcWidth : itemWidth;
    }
    const previewDataTitle: ColumnProps<any>[] = _.map(outDataset, item => ({
      title: item.name,
      dataIndex: item.name,
      key: item.name,
      width: this.getTableItemWidth(item.dataType, itemWidth),
      className: 'ellipsis-hide',
      render: (text: any) => {
        if (item.dataType === 'Boolean' && _.isBoolean(text)) {
          text = text.toString();
        }
        return <TableCellText text={text} />;
      }
    }));
    return previewDataTitle;
  };

  public render() {
    const { previewData, debugModalVisible, onDebugModalVisible } = this.props;
    const { selectedRowKeys, debugData, loading } = this.state;
    const rowSelection = {
      selectedRowKeys,
      onChange: this.handleSelectChange
    };
    return (
      <DialogModal
        width="80%"
        title="数据预览"
        okText="确定"
        visible={debugModalVisible}
        maskClosable={false}
        onOk={this.handleOk}
        onCancel={() => onDebugModalVisible(false)}
        bodyStyle={{ padding: '20px 20px 0' }}
      >
        <Tabs>
          <TabPane tab="数据输入" key="1" className={styles.debugInput}>
            <div className={styles.debugInputOpera}>
              <AddBtn
                ghost
                disabled={debugData.length >= 50}
                onClick={this.addMockData}
              />
              <Button
                disabled={!selectedRowKeys.length}
                onClick={this.batchCopyMockData}
              >
                复制
              </Button>
              <DelBtn
                disabled={!selectedRowKeys.length}
                onClick={this.batchDeleteMockData}
              />
            </div>
            <Table
              size="small"
              className={classnames('task-base-table', styles.debugTable)}
              rowKey="DAM_debugDataRowKey"
              loading={loading}
              columns={this.getInputColumns()}
              rowSelection={rowSelection}
              dataSource={debugData}
              scroll={{ x: '100%', y: 'calc(80vh - 260px)' }}
              pagination={false}
            />
            <p className={styles.tips}>共{debugData.length}条</p>
          </TabPane>
          <TabPane tab="数据输出" key="2">
            <Table
              size="small"
              className={classnames('task-base-table', styles.debugTable)}
              rowKey={(_record, index) => `preview_${index}`}
              columns={this.getOutputColumns()}
              dataSource={previewData}
              scroll={{ x: '100%', y: 'calc(80vh - 260px)' }}
              pagination={false}
            />
            <p className={styles.tips}>共{previewData.length}条</p>
          </TabPane>
        </Tabs>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>({ name: 'debugDataModal' })(DebugDataModal);
