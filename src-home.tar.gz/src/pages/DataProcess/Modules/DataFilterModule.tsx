import React, { Component } from 'react';

import uuid from '@utils/uuid';
import TransferTable from './components/TransferTable';
import FilterTable from './components/FilterTable';
import { getDerivedStateFromProps } from './module.helper';
import { IModuleProps } from './module';

interface IState {
  dataModuleTag: string;
  dataModuleInputDatas: [];
  rules: any[];
  variables: any[];
}

class DataFilterModule extends Component<IModuleProps, IState> {
  private filterRef: any;
  public constructor(props: IModuleProps) {
    super(props);

    this.state = {
      dataModuleTag: '', // 模块tag
      dataModuleInputDatas: [], // 输入数据
      rules: _.cloneDeep(_.get(props, 'dataModuleConfig.rules', [])), // 过滤条件数组
      variables: []
    };
    props.initApi(this.saveConfig);
  }

  public static getDerivedStateFromProps(nextProps: any, state: any) {
    return getDerivedStateFromProps(nextProps, state);
  }

  /**
   * @description: 保存配置信息
   * @return: object config
   */
  private saveConfig = () => {
    const verifyRes = this.filterRef.verifyRules();
    if (!verifyRes) return;
    const { rules, dataModuleInputDatas } = this.state;
    return {
      rules,
      struct: dataModuleInputDatas
    };
  };

  /**
   * @description: 配置信息发生改变后触发函数,修改算子是否更改状态
   */
  private handleConfigChange = () => {
    this.props.toggleChangedStatus();
  };

  // 设置角色穿梭层数据变化的回调事件
  private handleTransferChange = (moveKeys: any) => {
    this.setState(({ dataModuleInputDatas, rules }: any) => {
      const newRules = _.concat(
        rules,
        dataModuleInputDatas
          .filter(({ name }: any) => _.includes(moveKeys, name))
          .map((record: any) => {
            return _.assign({}, record, {
              key: uuid(6),
              filterValueType: 1,
              type: undefined,
              value: undefined
            });
          })
      );

      return {
        rules: newRules
      };
    });
    this.handleConfigChange();
  };

  private updateRules = (rules: any[]) => {
    this.setState({
      rules
    });
    this.handleConfigChange();
  };

  public render() {
    const { rules, dataModuleInputDatas, variables } = this.state;

    return (
      <TransferTable
        leftTitle="选择过滤字段"
        rightTitle="设置过滤条件"
        selectedKeyName="name"
        sourceDataStructure={dataModuleInputDatas}
        targetKeys={rules.map(({ name }: any) => name)}
        onChange={this.handleTransferChange}
        needFilter={false}
        rightComponent={
          <FilterTable
            dataSource={rules}
            variables={variables}
            updateRules={this.updateRules}
            wrappedComponentRef={(ref: any) => {
              if (!this.filterRef) {
                this.filterRef = ref;
              }
            }}
          />
        }
      />
    );
  }
}
export default DataFilterModule;
