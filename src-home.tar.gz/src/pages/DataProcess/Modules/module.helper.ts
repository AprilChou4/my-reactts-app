import { message } from 'sup-ui';
import Mock, { Random } from 'mockjs';

const TYPE_TEXT_MAP: any = {
  // data: '数据集' || 'Dataset',
  data: '数据集',
  // model: '模型' || 'Model',
  model: '模型'
};

/**
 * 检查算法组件中指定类型及覆盖范围的输入节点中的数据是否完备
 * @param {array} inputDatas - 算法组件输入节点的数据集合
 * @param {array} checkTypes - 需要检查算法组件输入节点的类型，默认['data', 'model']都需要检查
 * @param {boolean} checkByEvery - 是否检查类型的每一项
 * @return {null|string} 返回校验的结果
 */
export const checkInputDatasReady = (
  inputDatas = [],
  checkTypes = ['data', 'model'],
  checkByEvery = true
) => {
  // 检查节点数据中空数据结构，并组合成提示语
  // 若`data`类型为空 >>> ['数据集']
  // 若`model`类型为空 >>> ['模型']
  // 若`data`与`model`类型均为空 >>> ['数据集, 模型']
  const existedCheckTypes = _.intersection(
    inputDatas.reduce((types, { type }) => _.concat(types, type), []),
    checkTypes
  );

  let checkResult = null;

  // 检查是否连线
  // 这里，其实做了这样一个校验。猜测：原始的算子配置menu.json其实可以约定输入算子的类型，
  // 比如算子C必须链接data类型的算子A和model类型的算子B，但算子C可以在不链接A和B的情况下先配置config，
  // 然后保存。这时候该方法就可以提示“请请连接数据集(A)与模型(B)”。当然，这里还进行了过滤操作。
  // 不过，中台目前全是data类型，这个提示信息貌似被忽略了
  const checkConnectedResult = existedCheckTypes
    .reduce((preCheckResult: any[], type: string) => {
      // 过滤节点数据中指定类型的节点数据
      const checkInputDatas = inputDatas.filter(
        (data: any) => data.type === type
      );
      // 根据是否检查对象的每一项从而检查
      const isConnected =
        checkByEvery === true
          ? _.every(
              checkInputDatas,
              ({ dataStructure }) => !_.isNil(dataStructure)
            )
          : _.some(
              checkInputDatas,
              ({ dataStructure }) => !_.isNil(dataStructure)
            );
      return _.concat(
        preCheckResult,
        isConnected && checkInputDatas.length !== 0 ? null : TYPE_TEXT_MAP[type]
      );
    }, [])
    .filter((r: any) => r !== null);

  // 检查连线后是否有数据传递
  // 这里同理，在C算子有链接的算子AB后，检查A和B算子的输出是否有值？没有的话
  // 提示： “未检测到A与B”，其实目前来讲，数据中台也未使用到这个提示。
  const checkEmptyResult = existedCheckTypes
    .reduce((preCheckResult: any[], type: string) => {
      // 过滤节点数据中指定类型的节点数据
      const checkInputDatas = inputDatas.filter(
        (data: any) => data.type === type
      );
      // 根据是否检查对象的每一项从而检查
      const isReady =
        checkByEvery === true
          ? _.every(
              checkInputDatas,
              ({ dataStructure }) => !_.isEmpty(dataStructure)
            )
          : _.some(
              checkInputDatas,
              ({ dataStructure }) => !_.isEmpty(dataStructure)
            );
      return _.concat(
        preCheckResult,
        isReady && checkInputDatas.length !== 0 ? null : TYPE_TEXT_MAP[type]
      );
    }, [])
    .filter((r: any) => r !== null);

  if (checkConnectedResult.length) {
    checkResult = `请连接${checkConnectedResult.join('与')}`;
  } else if (checkEmptyResult.length) {
    checkResult = `未检测到${checkEmptyResult.join('与')}`;
  }

  return checkResult;
};

/**
 * 获取算法组件输入节点中首个指定`type`类型的数据结构
 * @param {array} inputDatas - 算法组件输入节点的数据集合
 * @param {*} type - 过滤的类型
 * @return {array} [headDataStructure = []] - 返回数组
 */
export const getInputDataStruct = (inputDatas: any, type = 'data') => {
  const headDataFilterByType =
    _.isArray(inputDatas) && !_.isEmpty(inputDatas)
      ? _.head(
          inputDatas.filter(
            data =>
              // 过滤`data`类型的输入节点的数据结构
              type === '' || data.type === type
          )
        )
      : null;
  return _.isEmpty(headDataFilterByType) ||
    _.isEmpty(headDataFilterByType.dataStructure)
    ? []
    : _.cloneDeep(headDataFilterByType.dataStructure);
};

/**
 * 获取下次传入的输入数据
 * @param {array} inputDatas - 输入节点的数据集合
 */
export const getDataModuleInputDatas = (inputDatas: any[]): any[] => {
  const nextInputDatas = _.isArray(inputDatas)
    ? getInputDataStruct(inputDatas)
    : [];
  return nextInputDatas;
};

/**
 * 获取输入数据的改变状态
 * @param {array} preInputDatas - 上次输入的数据
 * @param {array} nextInputDatas - 这次输入的数据
 */
export const getInputDatasChangedStatus = (
  prevInputDatas: any,
  nextInputDatas: any
) => {
  return !_.isEqual(prevInputDatas, nextInputDatas);
};

/**
 * @description: 校验sql 或 xml 中是否还有变量，并将 变量以数组的形式返回
 * @param {string} str
 */
export const checkIncludeVar = (str: string) => {
  let varArr: string[] = [];
  try {
    varArr = _.uniq(str.match(/#\{(\w+)\}/g));
  } catch (error) {
    console.error(error);
  }
  return varArr;
};

/**
 * @description: 判断字符串中是否含有变量
 * （ps：规定如果在JSON或者SQL或者自定义脚本中，使用变量，那么变量的统一规则为 #{变量名}）
 * @param {string} str 待校验的字符串
 * @return boolean
 */
export const isDefinedVar = (str: string): boolean => {
  const varReg = /^#\{(\w+)\}$/g;
  if (typeof str !== 'string') return false;
  return varReg.test(str);
};

/**
 * @description: 判断用户输入的变量是否已经在任务变量配置中定义
 * 注：用户输入的变量均为 #{xxx}格式 ，所以在比较的时候 采用 slice 去除前后特殊符号进行比较
 * @param {array} variables 任务变量配置中自定义的变量
 * @param {array} varArr 用户输入的变量（sql/xml等）
 * @return: array|boolean
 * 当返回 array 时，返回用户输入但尚未定义的变量
 * 当放回 boolean 并且为 false 时，证明用户输入的变量都已经定义
 */
export const varIsUndefined = (variables: any[], varArr: any[]) => {
  const nonexistentVars = _.filter(
    varArr,
    varItem =>
      !_.find(variables, (item: any) => item.name === varItem.slice(2, -1))
  );
  if (nonexistentVars.length) {
    message.warning(
      `变量${nonexistentVars.join(',')}不存在任务变量配置中，请核对！`
    );
    return nonexistentVars;
  } else {
    return false;
  }
};

/**
 * @description: 根据数据字段数据类型生成对应的mock数据
 * @param {array} struct 字段数据信息
 * @return {object} 根据数据类型生成的一组mock数据
 */
export const getMockData = (struct: any[]) => {
  const mockObj: {
    [propName: string]: any;
  } = {};
  _.forEach(struct, item => {
    switch (item.dataType) {
      case 'Timestamp':
        mockObj[item.name] = Random.datetime('yyyy-MM-dd  HH:mm:ss');
        break;
      case 'Date':
        mockObj[item.name] = Random.date('yyyy-MM-dd');
        break;
      case 'Time':
        mockObj[item.name] = Random.time();
        break;
      case 'Year':
        mockObj[item.name] = Random.date('yyyy');
        break;
      case 'Float':
        mockObj[item.name] = Random.float(60, 100, 3, 5);
        break;
      case 'Double':
        mockObj[item.name] = Random.float(60, 100, 3, 5);
        break;
      case 'Decimal':
        mockObj[item.name] = Random.float(60, 100, 3, 5);
        break;
      case 'BigDecimal':
        mockObj[item.name] = Random.float(1000, 100000, 3, 5);
        break;
      case 'Integer':
        mockObj[item.name] = Random.integer(20, 200);
        break;
      case 'Long':
        mockObj[item.name] = Random.integer(1000, 100000);
        break;
      case 'Boolean':
        mockObj[`${item.name}|1-2`] = true;
        break;
      case 'String':
        mockObj[item.name] = Mock.mock('@string("lower", 5)');
        break;
      default:
        break;
    }
  });
  return Mock.mock(mockObj);
};

/**
 * @description: 根据映射关系 找到对应输入信息源的信息
 * @param {array} mapping  映射表对应的关系
 * @param {array} inputDatas 映射表输入的源信息
 * @param {array} targetStruct 映射表的目标表信息
 * @return {array} struct  映射之后的数据结构
 */
export const getMappingStruct = ({
  mapping = [],
  inputDatas = [],
  targetStruct = []
}: {
  mapping: any[];
  inputDatas: any;
  targetStruct: any[];
}) => {
  const struct: any[] = [];
  _.forEach(mapping, item => {
    const { originName, targetName } = item;
    const targetField = _.find(targetStruct, o => o.name === targetName);
    const originField = _.find(inputDatas, o => o.name === originName);
    if (!_.isNil(targetField) && !_.isNil(originField)) {
      struct.push(
        _.assign(targetField, _.omit(originField, ['name', 'showName']), {
          DAM_line_key: undefined
        })
      );
    }
  });
  return struct;
};

/**
 * @description: 当上游节点算子发生改变或输出数据发生改变或全局变量发生改变 返回最新state
 * 通用的算子 props 发生改变自动更新 当前算子的 state
 * @param {any} nextProps
 * @param {any} state
 * @return {object} newState
 */
export const getDerivedStateFromProps = (nextProps: any, state: any) => {
  const { dataModuleTag, dataModuleInputDatas, variables } = nextProps;
  const nextDataModuleInputDatas =
    getDataModuleInputDatas(dataModuleInputDatas);
  // 根据`dataModuleInputDatas`与`nextDataModuleInputDatas`判断数据源是否已经改变
  const isModuleStructChanged = getInputDatasChangedStatus(
    state.dataModuleInputDatas,
    nextDataModuleInputDatas
  );
  // 根据`dataModuleTag`判断组件是否改变
  const isDataModuleChanged = dataModuleTag !== state.dataModuleTag;
  // 根据`variables`判断变量是否改变
  const isVariablesChanged = !_.isEqual(variables, state.variables);
  // 当组件改变或者数据源改变时，对state中的各项做相应的改变
  return isDataModuleChanged || isModuleStructChanged || isVariablesChanged
    ? {
        dataModuleTag,
        dataModuleInputDatas: nextDataModuleInputDatas,
        variables: _.isArray(variables) ? variables : []
      }
    : null;
};
