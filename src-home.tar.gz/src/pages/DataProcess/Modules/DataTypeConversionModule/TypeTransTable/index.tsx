import React, { Component } from 'react';
import classnames from 'classnames';
import { Form, Select, Table, message } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

import { popupContainer } from '@utils/propUtil';
import { TableCellText } from '@components/Table';
import Icon from '@components/Icon';
import {
  getOptionsByDataType,
  enumVerifyFn,
  getTargetInfoByKey
} from '../TypeTrans.helper';
import TransMode from '../TransMode';

import styles from './index.less';

const FormItem = Form.Item;
const { Option, OptGroup } = Select;

// 根据原始类型获取转换后类型

interface IProps extends FormComponentProps {
  currentRecord: any;
  dataSource: any[];
  updateRules: (newRules: any[]) => void;
  updateCurrentRecord: (record: any) => void;
}

interface IState {
  interComp: string;
  interCompKey: string;
}

class TypeTransTable extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      interComp: '',
      interCompKey: ''
    };
  }

  /**
   * @description: 保存校验规则
   * 首先校验页面所显示 form 表单，如果 false 则不走详细的具体的字段校验规则
   * 反之，遍历每行数据，如果本身就有错误则返回 false
   * @return {boolean} 返回数据是否校验成功
   */
  public verifyRules = () => {
    let verifyRes;
    const { form, dataSource, updateRules } = this.props;
    form.validateFields((errors: any) => {
      verifyRes = !errors;
    });
    if (verifyRes) {
      const newRules = _.map(dataSource, item => {
        // 如果数据在用户组态阶段没有感知到错误的 则需要进一步走详细的校验
        if (!item.hasError) {
          const fn = enumVerifyFn[item.type];
          // 判断是否含有详细的校验规则，如果有需要进行详细的判断
          if (_.isFunction(fn)) {
            const res = fn(item.extendConfig, item.dataType);
            if (!res) {
              return { ...item, hasError: true };
            } else {
              return item;
            }
          } else {
            return item;
          }
        } else {
          return item;
        }
      });
      if (_.some(newRules, item => item.hasError)) {
        updateRules(newRules);
        verifyRes = false;
      } else {
        verifyRes = true;
      }
    }
    if (!verifyRes) {
      message.error('请校验核对必填信息!');
    }
    return verifyRes;
  };

  /**
   * @description: 根据当前配置，渲染对应的转换详细方式，并返回对应的默认配置
   * @return: 对应默认配置
   */
  private updateInterComp = (
    record: any,
    defaultExtendConfig: any,
    isLeaf: boolean,
    interComp: string
  ) => {
    let comp = '';
    let compKey = '';
    let extendConfig = {};
    // 判断是否需要扩展配置
    if (defaultExtendConfig) {
      /**
       * 判断扩展配置是否嵌套（详细说明见 TypeTrans.consts.ts）
       * 如果是，则需要根据对应的数据类型获取默认配置，反之直接获取
       */
      if (isLeaf) {
        const targetConfig = defaultExtendConfig[record.dataType];
        if (targetConfig) {
          comp = interComp;
          compKey = record.key;
          extendConfig = targetConfig;
          this.setState({
            interComp,
            interCompKey: record.key
          });
        }
      } else {
        comp = interComp;
        compKey = record.key;
        extendConfig = { ...defaultExtendConfig };
      }
    }

    // 在生成详细配置之前，需要将上次的扩展配置对应的组件清除
    this.setState(
      {
        interComp: ''
      },
      () => {
        this.setState({
          interComp: comp,
          interCompKey: compKey
        });
      }
    );
    return extendConfig;
  };

  /**
   * @description: 用户选择完对应的转换类型后，生成对应初始化信息操作
   * 如果有对应的扩展配置，则需要渲染对应的组件（对应于 interComp，注意在渲染对应的组件之前需要将上次的组件清除 ）
   * hasError 每一行数据默认数据成功与否标识
   * 有些数据能够在用户编辑阶段即能识别错误的直接提示用户
   * 反之有些数据不能在用户组态阶段就能感知的，需要在保存的时候进行详细的校验
   */
  private handleTypeChange = (value: any, record: any): void => {
    const { dataSource } = this.props;
    const {
      targetDataType = record.dataType,
      interComp = '',
      defaultExtendConfig,
      isLeaf
    } = getTargetInfoByKey(value);
    // 根据选择的对应枚举类型，获取到对应的默认配置，生成当前数据的配置信息，type/targetDataType 为必须项
    // targetDataType 优先取defaultExtendConfig中的配置，其次取默认配置，如果都没有取本身数据类型
    const currentRecord = {
      ...record,
      hasError: false,
      type: value,
      targetDataType: _.get(
        defaultExtendConfig,
        [record.dataType, 'targetDataType'],
        targetDataType
      )
    };
    const extendConfig = this.updateInterComp(
      currentRecord,
      defaultExtendConfig,
      isLeaf,
      interComp
    );

    currentRecord.extendConfig = extendConfig;
    const newDataSource = _.map(dataSource, item =>
      item.name === record.name ? currentRecord : item
    );
    this.props.updateRules(newDataSource);
    this.props.updateCurrentRecord(currentRecord);
  };

  private handleDelete = (record: any): void => {
    const { dataSource } = this.props;
    const { key } = record;
    _.remove(dataSource, (o: any) => o.key === key);
    this.props.updateRules(dataSource);
    this.props.updateCurrentRecord({});
    this.setState({
      interComp: '',
      interCompKey: ''
    });
  };

  private getColumns = () => {
    const {
      form: { getFieldDecorator }
    } = this.props;
    return [
      {
        title: '字段',
        dataIndex: 'name',
        key: 'name',
        width: 100,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '类型',
        dataIndex: 'dataType',
        key: 'dataType',
        width: 90
      },
      {
        title: '转换后类型',
        dataIndex: 'targetDataType',
        key: 'targetDataType',
        width: 110
      },
      {
        title: '转换方式',
        dataIndex: 'type',
        key: 'type',
        width: 186,
        render: (_text: any, record: any) => {
          const { key, type } = record;
          return (
            <FormItem className={styles.transType}>
              {getFieldDecorator(`trans_type_${key}`, {
                initialValue: type || undefined,
                rules: [
                  {
                    required: true,
                    message: '请选择'
                  }
                ]
              })(
                <Select
                  size="small"
                  placeholder="-请选择-"
                  getPopupContainer={popupContainer}
                  onChange={value => this.handleTypeChange(value, record)}
                >
                  {_.map(getOptionsByDataType(record.dataType), item => (
                    <OptGroup key={item.key} label={item.optGroup}>
                      {_.map(item.options, op => (
                        <Option key={op.key} value={op.key}>
                          {op.label}
                        </Option>
                      ))}
                    </OptGroup>
                  ))}
                </Select>
              )}
            </FormItem>
          );
        }
      },
      {
        title: '移除',
        align: 'center',
        width: 50,
        render: (_text: any, record: any) => (
          <Icon
            type="remove"
            onClick={e => {
              e.stopPropagation();
              this.handleDelete(record);
            }}
          />
        )
      }
    ];
  };

  /**
   * @description: 修改某条数据以及currentRecord
   * @param {object} currentRecord 当前行数据
   */
  private handleUpdateRecord = (currentRecord: any): void => {
    const { dataSource } = this.props;
    const { key } = currentRecord;
    const newDataSource = _.map(dataSource, item =>
      item.key === key ? { ...currentRecord } : item
    );
    this.props.updateRules(newDataSource);
    this.props.updateCurrentRecord(currentRecord);
  };

  public render() {
    const {
      dataSource,
      form: { getFieldDecorator },
      currentRecord,
      updateCurrentRecord
    } = this.props;
    const { interComp, interCompKey } = this.state;
    const columns: any = this.getColumns();
    return (
      <div className={styles.typeTransWrapper}>
        <Table
          size="small"
          className={`task-edit-table ${styles.tableWrapper}`}
          rowClassName={(record: any) =>
            classnames(
              {
                invild: record.hasError
              },
              record.hasError ? styles.error : '',
              record.key === currentRecord.key ? styles.active : ''
            )
          }
          rowKey="key"
          columns={columns}
          dataSource={dataSource}
          scroll={{
            y: 'auto'
          }}
          pagination={false}
          onRow={(record: any) => {
            return {
              onDoubleClick: (e: MouseEvent) => {
                e.preventDefault();
                updateCurrentRecord(record);
                const {
                  interComp: targetInterComp = '',
                  defaultExtendConfig,
                  isLeaf
                } = getTargetInfoByKey(record.type);
                this.updateInterComp(
                  record,
                  defaultExtendConfig,
                  isLeaf,
                  targetInterComp
                );
              }
            };
          }}
        />
        {interComp && (
          <TransMode
            interComp={interComp}
            key={interCompKey}
            currentRecord={currentRecord}
            getFieldDecorator={getFieldDecorator}
            onChange={this.handleUpdateRecord}
          />
        )}
      </div>
    );
  }
}
export default Form.create<IProps>({ name: 'typeTransTable' })(TypeTransTable);
