/*
 * @Description: 单位转换 枚举-42
 * @Author: liyongshuai
 */
import React, { FunctionComponent } from 'react';
import { Form, Select } from 'sup-ui';

import { units } from '../../TypeTrans.const';
import { ExtendComProps } from './interface';
import styles from '../index.less';

const FormItem = Form.Item;
const { Option } = Select;

const TransUnit: FunctionComponent<ExtendComProps> = (
  props: ExtendComProps
) => {
  const { getFieldDecorator, onChange, currentRecord = {} } = props;
  const { extendConfig = {} } = currentRecord;

  return (
    <FormItem label="转换后单位" className={styles.formItem}>
      {getFieldDecorator(`transformUnit_42`, {
        initialValue: extendConfig.transformUnit,
        rules: [
          {
            required: true,
            message: '请选择'
          }
        ]
      })(
        <Select
          size="small"
          placeholder="-请选择-"
          onChange={value => {
            currentRecord.extendConfig.transformUnit = value;
            onChange(currentRecord);
          }}
        >
          {_.map(units, unit => (
            <Option key={unit.key} value={unit.key}>
              {unit.label}
            </Option>
          ))}
        </Select>
      )}
    </FormItem>
  );
};

export default TransUnit;
