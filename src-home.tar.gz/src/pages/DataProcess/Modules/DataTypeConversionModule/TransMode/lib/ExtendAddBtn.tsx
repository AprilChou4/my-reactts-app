import React, { FunctionComponent } from 'react';
import { Button } from 'sup-ui';
import Icon from '@components/Icon';

import styles from '../index.less';

interface IProps {
  onClick: () => void;
}

const ExtendAddBtn: FunctionComponent<IProps> = (props: IProps) => {
  return (
    <Button size="small" className={styles.addBtn} onClick={props.onClick}>
      <Icon type="add" fill="#1a91eb" />
    </Button>
  );
};

export default ExtendAddBtn;
