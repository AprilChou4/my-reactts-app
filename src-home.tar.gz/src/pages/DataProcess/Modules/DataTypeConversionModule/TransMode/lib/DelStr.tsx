import React, { FunctionComponent, Fragment } from 'react';
import { Form, Input } from 'sup-ui';

import Icon from '@components/Icon';
import uuid from '@utils/uuid';
import { updateExtendList } from '../../TypeTrans.helper';
import ExtendAddBtn from './ExtendAddBtn';
import { ExtendComProps } from './interface';
import styles from '../index.less';

const FormItem = Form.Item;

const DelStr: FunctionComponent<ExtendComProps> = (props: ExtendComProps) => {
  const { getFieldDecorator, onChange, currentRecord = {} } = props;
  const { extendConfig = {} } = currentRecord;
  const { deCharacterList = [] } = extendConfig;
  return (
    <Fragment>
      <ul className={styles.extendConfig}>
        {_.map(deCharacterList, item => (
          <li key={item.key} className={styles.listWrapper}>
            <FormItem label="待去掉字符" className={styles.formItem}>
              {getFieldDecorator(`deStr_${item.key}`, {
                initialValue: item.deStr,
                rules: [
                  {
                    required: true,
                    message: '请输入'
                  }
                ],
                validateTrigger: ['onChange', 'onBlur']
              })(
                <Input
                  size="small"
                  onChange={e => {
                    currentRecord.extendConfig.deCharacterList =
                      updateExtendList(
                        deCharacterList,
                        item.key,
                        'deStr',
                        e.target.value
                      );
                    onChange(currentRecord);
                  }}
                />
              )}
            </FormItem>
            <div className={styles.operation}>
              <span className={styles.label}>操作</span>
              <Icon
                className={styles.delIcon}
                type="remove"
                disabled={deCharacterList.length === 1}
                onClick={() => {
                  _.remove(deCharacterList, (o: any) => o.key === item.key);
                  onChange(currentRecord);
                }}
              />
            </div>
          </li>
        ))}
      </ul>
      <ExtendAddBtn
        onClick={() => {
          currentRecord.extendConfig.deCharacterList.push({
            key: uuid(6),
            deStr: ''
          });
          onChange(currentRecord);
        }}
      />
    </Fragment>
  );
};

export default DelStr;
