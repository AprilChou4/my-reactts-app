/**
 * 组件名: 数据集
 * 组件别名: DataSampleModule
 * 输入节点: D
 * 输出节点: D
 * 组件默认配置: 无
 * 错误检查规则: 1、无数据输入时, 提示'请连接数据集'
 */

import { checkInputDatasReady, getInputDataStruct } from '../module.helper';

/**
 * 数据输入的验证函数
 * @param {object} config - 算法配置项
 * @param {object} inputDatas - 输入数据
 * @returns {object} verifiedResult - 验证结果
 * @returns {null|string} verifiedResult.error - 验证失败的错题提示，若没有错误，返回null
 * @returns {object} verifiedResult.outputDataStructures - 验证后输出的数据结构，此算法只输出`data`类型
 */
export default ({ config = {}, inputDatas = [] }) => {
  // 检验输入节点中的数据结构是否全部不为空
  const checkInputDatasReadyResult = checkInputDatasReady(inputDatas);
  // // 组件输入节点中首个`data`类型的数据结构
  const headDataTypeInputDataStructure = getInputDataStruct(inputDatas, 'data');
  // 配置项中的数据结构
  const mapping = _.get(config, ['mapping'], []);
  const struct = _.get(config, ['struct'], []);
  // 验证结果的提示信息
  let verifiedMessage = checkInputDatasReadyResult;

  // 检验输入节点中的结果为`null`，即为通过其校验
  if (checkInputDatasReadyResult === null) {
    // 通过`id`是否为空及数据结构是否为空，来共同判断是否已经选取数据集
    if (_.isEmpty(struct)) {
      verifiedMessage = '输出字段为空，请配置';
    } else if (
      !_.every(mapping, i =>
        _.find(headDataTypeInputDataStructure, h => h.name === i.originName)
      )
    ) {
      verifiedMessage = '输入数据发生改变，请重新配置';
    }
  }

  return {
    // 错误提示
    error: verifiedMessage,
    // 输出节点的数据结构
    outputDataStructures: {
      data: _.isNil(struct) ? null : _.cloneDeep(struct)
    }
  };
};
