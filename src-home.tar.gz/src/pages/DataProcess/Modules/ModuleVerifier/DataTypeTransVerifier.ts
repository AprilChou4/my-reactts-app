/**
 * 组件名: 数据类型转换
 * 组件别名: DataTypeConversionModule
 * 输入节点: D
 * 输出节点: D
 * 组件默认配置: 无
 * 错误检查规则: 1、`rules`是否为空, 提示'此组件未配置'
 */

import { checkInputDatasReady } from '../module.helper';

/**
 * 数据类型转换的验证函数
 * @param {object} config - 算法配置项
 * @param {object} inputDatas - 输入数据
 * @returns {object} verifiedResult - 验证结果
 * @returns {null|string} verifiedResult.error - 验证失败的错题提示，若没有错误，返回null
 * @returns {object} verifiedResult.outputDataStructures - 验证后输出的数据结构，此算法只输出`data`类型
 */
export default ({ config = {}, inputDatas = [] }) => {
  // 检验输入节点中的数据结构是否全部不为空
  const checkInputDatasReadyResult = checkInputDatasReady(inputDatas);
  const rules = _.get(config, 'rules', []);
  // 验证结果的提示信息
  let verifiedMessage = checkInputDatasReadyResult;

  // 通过`rules`是否为空，判断是否配置完成
  if (_.isEmpty(rules)) {
    verifiedMessage = '此组件未配置';
  }

  return {
    // 错误提示
    error: verifiedMessage,
    // 输出节点的数据结构
    outputDataStructures: {
      // 数据型
      data: _.get(config, 'struct', [])
    }
  };
};
