/**
 * @module 数据算法验证模块
 */

import RulesVerifier from './RulesVerifier';
import DataInputVerifier from './DataInputVerifier';
import DataSampleVerifier from './DataSampleVerifier';
import SqlVerifier from './SqlVerifier';
import DataTypeTransVerifier from './DataTypeTransVerifier';
import DataFillVerifier from './DataFillVerifier';
import MergeModuleVerifier from './MergeModuleVerifier';
import AggregationModuleVerifier from './AggregationModuleVerifier';
import DataJoinVerifier from './DataJoinVerifier';
import DataOutputVerifier from './DataOutputVerifier';
import TableTransposeVerifier from './TableTransposeVerifier';
import CustomScriptVerifier from './CustomScriptVerifier';
import VariableSetVerifier from './VariableSetVerifier';
import BigDataModelRuntimeVerifier from './BigDataModelRuntimeVerifier';
import BigDataModelUpdateVerifier from './BigDataModelUpdateVerifier';
import BranchVerifier from './BranchVerifier';
import MsgQueueInputVerifier from './MsgQueueInputVerifier';
import MsgQueueOutputVerifier from './MsgQueueOutputVerifier';
/**
 * 节点模块验证函数
 * @param {string} alias - 别名
 * @param {object} config - 算法配置项
 * @param {array} inputDatas - 算法输入节点的数据结构集合
 * @param {array} outputAlias - 算法输出节点的算子类型
 * @returns {object} verifiedResult - 验证结果
 * @returns {null|string} verifiedResult.error - 验证失败的错题提示，若没有错误，返回null
 * @returns {object} verifiedResult.outputDataStructures - 验证后输出的数据结构，目前只有`data`1个类型
 */
export default ({
  alias = '',
  config = {},
  inputDatas = [],
  inputNodes = [],
  outputAlias = []
}: {
  alias: string;
  config: any;
  inputDatas: any[];
  inputNodes: any[];
  outputAlias: string[];
}) => {
  let verifier = _.noop;
  switch (alias) {
    // 数据输入
    case 'DataInputModule':
      verifier = DataInputVerifier;
      break;
    // 消息队列输入
    case 'MsgQueueInputModule':
      verifier = MsgQueueInputVerifier;
      break;
    // sql
    case 'SqlScriptModule':
      verifier = SqlVerifier;
      break;
    // 数据集
    case 'DataSampleModule':
      verifier = DataSampleVerifier;
      break;
    // 数据连接
    case 'DataJoinModule':
      verifier = DataJoinVerifier;
      break;
    // 数据合并
    case 'MergeModule':
      verifier = MergeModuleVerifier;
      break;
    // 数据类型转换
    case 'DataTypeConversionModule':
      verifier = DataTypeTransVerifier;
      break;
    // 数据补齐
    case 'DataFillModule':
      verifier = DataFillVerifier;
      break;
    case 'VariableSetModule':
      verifier = VariableSetVerifier;
      break;
    // 数据聚合
    case 'AggregationModule':
      verifier = AggregationModuleVerifier;
      break;
    // 表转置
    case 'TableTransposeModule':
      verifier = TableTransposeVerifier;
      break;
    case 'CustomModule':
      verifier = CustomScriptVerifier;
      break;
    // 分支任务
    case 'BranchModule':
      verifier = BranchVerifier;
      break;
    // 数据输出
    case 'DataOutputModule':
      verifier = DataOutputVerifier;
      break;
    // 消息队列输出
    case 'MsgQueueOutputModule':
      verifier = MsgQueueOutputVerifier;
      break;
    // 模型运行
    case 'BigDataModelRuntimeModule':
      verifier = BigDataModelRuntimeVerifier;
      break;
    // 模型更新
    case 'BigDataModelUpdateModule':
      verifier = BigDataModelUpdateVerifier;
      break;
    // 共用校验函数
    default:
      verifier = RulesVerifier;
      break;
  }

  // 执行验证函数，解构验证返回值
  const verifiedResult = verifier({
    alias,
    config,
    inputDatas,
    inputNodes,
    outputAlias
  });

  if (verifier === _.noop || _.isNil(verifiedResult)) {
    // throw new Error(
    //   'TaskDataVerifier must need a function verifier.'
    // );
    // console.error('TaskDataVerifier must need a function verifier.');
  }

  return {
    error: _.get(verifiedResult, ['error'], null),
    outputDataStructures: _.get(verifiedResult, ['outputDataStructures'], {})
  };
};
