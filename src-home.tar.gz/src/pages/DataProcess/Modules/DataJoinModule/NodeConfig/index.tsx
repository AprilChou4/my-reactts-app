import React, { Component } from 'react';
import { Provider } from 'mobx-react';
import NodePanel from './containers/NodePanel';
import DataTable from './containers/DataTable';
import NodeConfigStore from './store/nodeconfigstore';
import { message } from 'sup-ui';

interface IProps {
  dataModuleConfig: any;
  dataModuleInputDatas: any[];
  toggleChangedStatus: () => void;
  updateUsingNodes: (tags: string[]) => void;
}
interface IState {}
class NodeConfig extends Component<IProps, IState> {
  private readonly store: any;
  public constructor(props: IProps) {
    super(props);
    const {
      dataModuleConfig,
      dataModuleInputDatas,
      toggleChangedStatus,
      updateUsingNodes
    } = props;

    this.store = new NodeConfigStore(
      dataModuleConfig,
      dataModuleInputDatas,
      toggleChangedStatus,
      updateUsingNodes
    );
  }

  public handleSubmit = () => {
    //校验、拼合数据
    let outerFlag = false;
    const rules: any = [];
    const { mainNodeTag, nodeInfoMap } = this.store;

    //至少需要一组连接
    const haveLinkNode = _.find(nodeInfoMap, ['position', 'vice']);

    if (!haveLinkNode) {
      message.warning('至少需要配置一组数据连接!');
      return;
    }

    //每组连接关联条件必须填充完整
    const viceGroup = _.sortBy(_.filter(nodeInfoMap, ['position', 'vice']), [
      'sequence'
    ]);

    _.forEach(viceGroup, (node: any, index: number): any => {
      const { position, dataTable, name, linkType, tag } = node;
      let innerFlag = false,
        temp: any = {};

      if (position === 'vice') {
        if (!dataTable.length) {
          outerFlag = true;
          message.warning(`${name}至少需要配置一条关联条件!`);
          return false;
        }

        temp = {
          joinType: linkType,
          nodeId: tag,
          sequence: index + 1,
          condition: []
        };

        const arr: any = [];

        _.forEach(dataTable, ({ main, vice, key }): any => {
          if (main && vice) {
            const [originFieldSource, originField] = main.split('|:|');
            const [targetFieldSource, targetField] = vice.split('|:|');

            arr.push({
              originField,
              targetField,
              outputOriginField: originField, //输出配置内对应的origin字段名
              outputTargetField: targetField, //输出配置内对应的target字段名
              originFieldSource,
              targetFieldSource
            });
          } else {
            innerFlag = true;
            message.warning(`请完善${name}下第${key + 1}条关联条件!`);
            return false;
          }
        });

        //提前退出循环
        if (innerFlag) {
          outerFlag = true;
          return false;
        }

        temp.condition = _.uniqWith(arr, _.isEqual);

        rules.push(temp);
      }
    });

    //数据未收集完全
    if (outerFlag) {
      return null;
    }

    return {
      parentNode: mainNodeTag,
      rules
    };
  };

  public render() {
    return (
      <Provider store={this.store}>
        <NodePanel>
          <DataTable />
        </NodePanel>
      </Provider>
    );
  }
}

export default NodeConfig;
