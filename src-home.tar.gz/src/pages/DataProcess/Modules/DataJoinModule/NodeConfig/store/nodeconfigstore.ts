import { action, computed, observable, runInAction } from 'mobx';
import TipsDelete from '@components/Modal/TipsDelete';

//使用|：|作为分隔符，避免与name字段重复
class NodeConfigStore {
  private readonly sourceData: any;
  private readonly toggleChangedStatus: (status: boolean) => void;
  private readonly updateUsingNodes: (tags: string[]) => void;
  private hasDirty = false;
  public sequence = 0;
  public sourceFieldMap: any = {};
  public mainNodeTag = '';
  @observable public nodeInfoMap: any = {};
  @observable public currentSelectedNode: any = null;

  public constructor(
    config: any,
    sourceData: any,
    toggleChangedStatus: any,
    updateUsingNodes: any
  ) {
    this.sourceData = sourceData;
    this.toggleChangedStatus = toggleChangedStatus;
    this.updateUsingNodes = updateUsingNodes;
    this.initData(config);
  }

  @action
  public initData(config: any) {
    const ignoreConfigData = () => {
      //格式化初始数据
      _.each(
        this.sourceData,
        ({ dataModuleName, dataStructure, sourceNodeTag }: any) => {
          //初始化数据
          this.nodeInfoMap[sourceNodeTag] = {
            tag: sourceNodeTag,
            name: dataModuleName,
            sequence: 0, //排序，主要是确定vice节点的顺序
            position: 'all', //all-列表内; main-主节点; vice-副节点
            linkType: 1, //连接类型: 1左联、2右联、3内联、4全联
            dataTable: [] //node对应的table数据: {main: 'abc', vice: 'efg'}
          };

          //输入源字段列表
          this.sourceFieldMap[sourceNodeTag] = _.map(dataStructure, item => ({
            ...item,
            dataModuleName,
            uniKey: `${sourceNodeTag}|:|${item.name}|:|${item.dataType}`
          }));
        }
      );
    };

    if (!_.isEmpty(config)) {
      const { parentNode, rules } = config;

      //判断输入源与config是否匹配
      const viceNodeTags = _.map(rules, 'nodeId');
      const sourceTags = _.map(this.sourceData, 'sourceNodeTag');
      const isFit = _.every(viceNodeTags.concat([parentNode]), tag =>
        _.includes(sourceTags, tag)
      );

      if (!isFit) {
        //不匹配，忽略config配置(未考虑数据变化的情况)
        ignoreConfigData();
        return;
      }

      //根据config数据初始化
      _.each(
        this.sourceData,
        ({ dataModuleName, dataStructure, sourceNodeTag }: any) => {
          let type = 1,
            data: any = [];
          const idx = viceNodeTags.indexOf(sourceNodeTag);
          const pos =
            sourceNodeTag === parentNode ? 'main' : idx > -1 ? 'vice' : 'all';

          if (idx > -1) {
            //vice节点
            const { joinType, condition } = _.find(rules, [
              'nodeId',
              sourceNodeTag
            ]);

            type = joinType;

            data = _.map(condition, (row, i) => {
              const {
                originField,
                targetField,
                originFieldSource,
                targetFieldSource
              } = row;
              const { dataType } = _.find(dataStructure, ['name', targetField]);

              return {
                key: i,
                main: `${originFieldSource}|:|${originField}|:|${dataType}`,
                vice: `${targetFieldSource}|:|${targetField}|:|${dataType}`
              };
            });
          }

          this.nodeInfoMap[sourceNodeTag] = {
            tag: sourceNodeTag,
            name: dataModuleName,
            sequence: idx > -1 ? idx : 0,
            position: pos,
            linkType: type,
            dataTable: data
          };

          //输入源字段列表
          this.sourceFieldMap[sourceNodeTag] = _.map(dataStructure, item => ({
            ...item,
            dataModuleName,
            uniKey: `${sourceNodeTag}|:|${item.name}|:|${item.dataType}`
          }));
        }
      );
    } else {
      ignoreConfigData();
    }

    //标记vice-node的顺序
    this.sequence = this.sourceData.length;
  }

  //由单一数据源计算各列节点
  @computed
  public get splitNodeList() {
    const inputList: any = [],
      mainList: any = [],
      viceList: any = [];

    _.forEach(this.nodeInfoMap, value => {
      switch (value.position) {
        case 'all':
          inputList.push(value);
          break;
        case 'main':
          this.mainNodeTag = value.tag;
          mainList.push(value);
          break;
        case 'vice':
          viceList.push(value);
          break;
      }
    });

    const sortedViceList = _.sortBy(viceList, ['sequence']);

    return { inputList, mainList, viceList: sortedViceList };
  }

  //由单一数据源生成dataTable数据
  @computed
  public get currentDataTableList() {
    if (!this.currentSelectedNode) {
      return [];
    }

    const dataTable = this.nodeInfoMap[this.currentSelectedNode]['dataTable'];

    return _.map(dataTable, (data: any, index: number) => ({
      ...data,
      key: index
    }));
  }

  //dataTable主下拉框
  @computed
  public get fieldSelectList() {
    const mainFields: any = [],
      viceFields: any = [];
    const main = this.sourceFieldMap[this.mainNodeTag];
    const vice = this.sourceFieldMap[this.currentSelectedNode];
    const seq = this.nodeInfoMap[this.currentSelectedNode]['sequence'];

    //刷选出小于seq的vice-node，取他们的tag集合
    const tags = _.map(
      _.filter(
        this.nodeInfoMap,
        ({ position, sequence }) => position === 'vice' && sequence < seq
      ),
      node => node.tag
    );

    mainFields.push(...main);
    viceFields.push(...vice);

    _.forEach(tags, tag => {
      mainFields.push(...this.sourceFieldMap[tag]);
    });

    return { mainFields, viceFields };
  }

  @action.bound
  public updateNodeProperty(tag: string, key: string, value: any) {
    this.nodeInfoMap[tag][key] = value;

    if (key === 'position') {
      this.nodeInfoMap[tag]['sequence'] = this.sequence++;
      this.filterUsingNodes();
    }

    this.markConfigAsDirty();
  }

  @action.bound
  public switchSelectedNode(tag: string) {
    this.currentSelectedNode = tag;
  }

  //删除画布上的节点
  @action.bound
  public deleteDrawerNode() {
    const tag = this.currentSelectedNode;
    if (tag) {
      const { dataTable, name, sequence } = this.nodeInfoMap[tag];
      const hasData = dataTable.length > 0;

      if (hasData) {
        TipsDelete({
          title: `确定移除${name}节点?`,
          content: '该节点下的关联条件及输出字段将被清除!',
          onOk: () => {
            runInAction(() => {
              this.currentSelectedNode = null;
              this.nodeInfoMap[tag] = {
                ...this.nodeInfoMap[tag],
                position: 'all',
                linkType: 1,
                dataTable: []
              };
              this.filterUsingNodes();
              this.clearInvalidData(tag, sequence);
            });
          }
        });
      } else {
        this.currentSelectedNode = null;
        this.nodeInfoMap[tag] = {
          ...this.nodeInfoMap[tag],
          position: 'all',
          linkType: 1,
          dataTable: []
        };
        this.filterUsingNodes();
        this.clearInvalidData(tag, sequence);
      }

      this.markConfigAsDirty();
    } else {
      const hasViceNodes = this.splitNodeList.viceList.length > 0;

      if (hasViceNodes) return;

      this.nodeInfoMap[this.mainNodeTag]['position'] = 'all';
      this.mainNodeTag = '';
      this.filterUsingNodes();
    }
  }

  //删除vice节点后，需要清除dataTable内使用到该节点数据的data项
  @action.bound
  public clearInvalidData(tag: string, seq: number) {
    _.forEach(this.nodeInfoMap, node => {
      const { position, sequence, dataTable } = node;
      if (position === 'vice' && sequence > seq) {
        _.remove(dataTable, ({ main }) => {
          if (!main) {
            return;
          }
          const [dataTag] = main.split('|:|');

          return dataTag === tag;
        });
      }
    });
  }

  //筛选出使用到的nodes
  @action.bound
  public filterUsingNodes() {
    const tags = _.map(this.nodeInfoMap, ({ position, tag }) =>
      _.includes(['main', 'vice'], position) ? tag : undefined
    ).filter(Boolean);

    this.updateUsingNodes(tags);
  }

  //table新增数据
  @action.bound
  public addNewTableData() {
    const tag = this.currentSelectedNode;
    const key = this.nodeInfoMap[tag]['dataTable'].length;

    this.nodeInfoMap[tag]['dataTable'].push({
      key,
      main: undefined,
      vice: undefined
    });
  }

  //table删除数据
  @action.bound
  public deleteTableData(keys: number[]) {
    const tag = this.currentSelectedNode;

    _.forEach(keys, key => {
      this.nodeInfoMap[tag]['dataTable'].splice(key, 1);
    });

    this.markConfigAsDirty();
  }

  //更新dataTable数据，即Select下拉数据
  @action.bound
  public updateDataTableValue(index: number, key: string, value: string) {
    const tag = this.currentSelectedNode;

    this.nodeInfoMap[tag]['dataTable'][index][key] = value;
    this.markConfigAsDirty();
  }

  /*触发了config修改*/
  @action.bound
  public markConfigAsDirty() {
    if (this.hasDirty) {
      return;
    }

    this.hasDirty = true;
    this.toggleChangedStatus(true);
  }
}

export default NodeConfigStore;
