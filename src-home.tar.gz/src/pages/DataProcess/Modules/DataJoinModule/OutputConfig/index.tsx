import React, { Component } from 'react';
import { Button, message } from 'sup-ui';
import { Provider, observer } from 'mobx-react';
import FieldCollectTable from './containers/FieldCollectTable';
import OutputFieldTable from './containers/OutputFieldTable';
import OutputConfigStore from './outputConfigStore';
import styles from './index.less';

interface IProps {
  dataModuleConfig: any;
  dataModuleInputDatas: any[];
  toggleChangedStatus: () => void;
}
interface IState {}

@observer
class OutputConfig extends Component<IProps, IState> {
  private readonly outputConfigStore: any;
  public constructor(props: IProps) {
    super(props);
    const { dataModuleConfig, dataModuleInputDatas, toggleChangedStatus } =
      props;

    this.outputConfigStore = new OutputConfigStore(
      dataModuleConfig,
      dataModuleInputDatas,
      toggleChangedStatus
    );
  }

  public handleSubmit = () => {
    const { filteredOutputFields } = this.outputConfigStore;

    if (!filteredOutputFields.length) {
      message.warning('至少添加一条输出字段!');
      return null;
    }

    //校验是否有重名或未填写(未校验name格式)
    const hasError = _.find(filteredOutputFields, ['dupName', true]);
    if (hasError) {
      message.warning('输出配置字段必须唯一且不能为空!');
      return null;
    }
    const struct: any[] = [];
    const mapping: any[] = [];
    _.forEach(filteredOutputFields, item => {
      const { dataModuleName, fieldSource, originName, ...rest } = item;
      mapping.push({
        originName,
        targetName: item.name,
        dataModuleName,
        fieldSource
      });
      struct.push(_.omit(rest, ['key', 'dupName']));
    });
    return {
      struct,
      mapping
    };
  };

  public updateUsingNodes = (tags: string[]) => {
    this.outputConfigStore.filterFieldList(tags);
  };

  public render() {
    const { selectedRowKeys, addOutputField } = this.outputConfigStore;

    return (
      <Provider outputConfigStore={this.outputConfigStore}>
        <div className={styles.container}>
          <FieldCollectTable />
          <div className={styles.operator}>
            <Button
              icon="right"
              className={styles.btn}
              onClick={addOutputField}
              title="右移"
              disabled={!selectedRowKeys.length}
            />
          </div>
          <OutputFieldTable />
        </div>
      </Provider>
    );
  }
}
export default OutputConfig;
