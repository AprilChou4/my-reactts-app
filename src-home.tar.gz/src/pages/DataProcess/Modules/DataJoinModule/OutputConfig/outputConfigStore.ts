import { action, computed, observable } from 'mobx';
import { message } from 'sup-ui';

class OutputConfigStore {
  private readonly sourceData: any;
  private readonly toggleChangedStatus: (status: boolean) => void;
  private hasDirty = false;
  @observable public usingNodes: string[] = []; //节点配置用到的节点
  @observable public selectedRowKeys: string[] | number[] = [];
  @observable public fieldCollectList: any[] = [];
  @observable public outputFieldList: any[] = [];

  public constructor(config: any, sourceData: any, toggleChangedStatus: any) {
    this.sourceData = sourceData;
    this.toggleChangedStatus = toggleChangedStatus;
    this.initData(config);
  }

  @action
  public initData(config: any) {
    //格式化初始数据，包括第一次进来和编辑时
    const fieldList: any[] = [];
    _.forEach(
      this.sourceData,
      ({ dataModuleName, dataStructure, sourceNodeTag }: any) => {
        _.forEach(dataStructure, dataItem => {
          fieldList.push({
            ...dataItem,
            dataModuleName,
            fieldSource: sourceNodeTag,
            originName: dataItem.name,
            key: `${sourceNodeTag}_${dataItem.name}`
          });
        });
      }
    );

    this.fieldCollectList = fieldList;

    if (!_.isEmpty(config)) {
      const { struct, parentNode, rules, mapping } = config;
      //判断输入源与config是否匹配
      const tags = _.map(mapping, 'fieldSource');
      const sourceTags = _.map(this.sourceData, 'sourceNodeTag');
      const isFit = _.every(tags, tag => _.includes(sourceTags, tag));

      if (!isFit) {
        //不匹配，忽略config配置(未考虑数据变化的情况)
        return;
      }

      this.outputFieldList = _.map(struct, structItem => {
        const restInfo =
          _.find(
            mapping,
            mappingItem => mappingItem.targetName === structItem.name
          ) || {};
        return {
          ...structItem,
          ...restInfo,
          key: `${structItem.fieldSource}_${structItem.name}`,
          dupName: false
        };
      });

      this.usingNodes = _.map(rules, 'nodeId').concat([parentNode]);
    }
  }

  @action.bound
  public updateSelectedRowKeys(selectedKeys: string[] | number[]) {
    this.selectedRowKeys = selectedKeys;
  }

  @action.bound
  public addOutputField() {
    const temp = _.filter(this.fieldCollectList, data =>
      _.includes(this.selectedRowKeys, data.key)
    );

    const diff = _.differenceBy(temp, this.outputFieldList, 'key');

    if (temp.length > diff.length) {
      message.warning('已过滤重复添加字段!');
    }
    this.outputFieldList = _.concat(
      this.outputFieldList,
      _.map(diff, i => ({
        ...i,
        name: `${i.originName || ''}_${i.dataModuleName || ''}`
      }))
    );
    this.selectedRowKeys = [];
    this.markConfigAsDirty();
  }

  @computed
  public get filteredOutputFields() {
    //判断字段是否有重复的，标记出来
    const map: any = {};
    const temp = _.cloneDeep(this.outputFieldList);

    _.forEach(temp, data => {
      const { name } = data;

      if (map[name]) {
        data.dupName = true;
        map[name].dupName = true;
      } else {
        map[name] = data;
        data.dupName = !data.name;
      }
    });

    return temp;
  }

  @computed
  public get filteredFieldCollect() {
    //只展示节点配置内配置过的节点数据列表
    return _.filter(this.fieldCollectList, ({ fieldSource }) =>
      _.includes(this.usingNodes, fieldSource)
    );
  }

  @action.bound
  public updateOutputField(index: number, key: string, value: string) {
    this.outputFieldList[index][key] = value;
    this.markConfigAsDirty();
  }

  @action.bound
  public deleteOutputField(index: number) {
    this.outputFieldList.splice(index, 1);
    this.markConfigAsDirty();
  }

  @action.bound
  public filterFieldList(tags: string[]) {
    this.usingNodes = tags;
    this.selectedRowKeys = [];

    this.outputFieldList = _.filter(this.outputFieldList, ({ fieldSource }) =>
      _.includes(tags, fieldSource)
    );
  }

  /*触发了config修改*/
  @action.bound
  public markConfigAsDirty() {
    if (this.hasDirty) {
      return;
    }

    this.hasDirty = true;
    this.toggleChangedStatus(true);
  }
}

export default OutputConfigStore;
