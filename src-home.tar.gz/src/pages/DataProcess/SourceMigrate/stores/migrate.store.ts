import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import {
  getTaskList,
  enableTaskImmediately,
  enableTask,
  disableTask,
  deleteTask,
  getTaskError
} from '../migrate.service';

class MigrateStore {
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams = {
    keyword: '',
    syncType: [],
    status: [],
    result: [],
    pageNum: 1,
    pageSize: 20
  };
  @observable public visible = false;
  @observable public selectedTask = {};

  public constructor() {
    this.getList();
  }

  @action.bound
  public async getList() {
    this.loading = true;

    const res = await getTaskList(this.searchParams);

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const {
        pagination: { total },
        list
      } = res || {};

      this.list = list || [];
      this.count = total;
    });
  }

  @action.bound
  public handleRefreshList() {
    if (this.loading) {
      return;
    }

    this.getList();
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }

  @action.bound
  public checkTaskDetail(record: any) {
    this.selectedTask = record;
    this.visible = true;
  }

  @action.bound
  public handleVisibleChange(visible: boolean, refresh = false) {
    this.visible = visible;

    if (refresh) {
      this.getList();
    }
  }

  @action.bound
  public async hangdleEnableTaskImmediately(record: any) {
    const { id } = record;
    this.loading = true;
    const res = await enableTaskImmediately(id);
    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      message.success('操作成功');
      this.getList();
    });
  }

  //切换状态
  @action.bound
  public async handleSwitchStatus(record: any) {
    const { id, status } = record;
    let res: any;

    this.loading = true;

    if (status === 1) {
      res = await disableTask(id);
    } else {
      res = await enableTask(id);
    }

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      message.success('操作成功');
      this.getList();
    });
  }

  //删除
  @action.bound
  public async handleDeleteTask(ids: any, remove: boolean, callback: any) {
    this.loading = true;

    const res = await deleteTask({
      jobIds: ids,
      remove
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      message.success('操作成功');
      this.getList();
      callback();
    });
  }

  //错误信息
  @action.bound
  public async getTaskError(id: any, callback: any) {
    const res = await getTaskError(id);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      callback(res.data || '');
    });
  }
}

export default MigrateStore;
