import http from '@services/http';
import { RESOURCE_URL, ETL_URL } from '@config/env';

/**
 * 获取任务列表
 * @param params
 * @returns
 */
export function getTaskList(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/list`, params);
}

/**
 * 立即执行
 * @param id
 * @returns
 */
export function enableTaskImmediately(id: any): Promise<any> {
  return http.get(`${ETL_URL}/cdc/task/run/${id}`);
}

export function enableTask(id: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/start/${id}`);
}

export function disableTask(id: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/stop/${id}`);
}

export function deleteTask(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/delete`, params);
}

export function getTaskDetail(id: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/info/${id}`);
}

export function addTask(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/add`, params);
}

/**
 * 编辑任务
 * @param params
 * @returns
 */
export function updateTask(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/task/edit`, params);
}

//检查任务名称是否已经存在
export function getNameExist(name: string): Promise<any> {
  return http.get(`${ETL_URL}/cdc/task/${name}`);
}

//数据源列表
export function getSourceList(params: any): Promise<any> {
  return http.post(`${RESOURCE_URL}/query`, params);
}

//数据源列表
export function getSourceListById(params: any): Promise<any> {
  return http.post(`${RESOURCE_URL}/query/resource`, params);
}

/**
 * 根据数据源ID获取数据源下的所有表(弃用)
 * @param id
 * @returns
 */
export function getTableList(
  id: string | number,
  sourceType?: string
): Promise<any> {
  if (sourceType === 'model')
    return http.post(`${ETL_URL}/cdc/supos/models`, {
      sourceId: id
    });
  return http.get(`${ETL_URL}/cdc/query/select/table/${id}`);
}

/**
 * 带分页获取数据源下的表
 * @param params
 * @returns
 */
export function getTableListByQuery(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/query/table`, params);
}

/**
 * 根据数据源ID获取OODM表单模板列表
 * @param params
 * @returns
 */
export function getOODMList(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/supos/models`, params);
}

//检测数据源表是否有唯一索引或主键
export function checkUniquePK(id: any): Promise<any> {
  return http.get(`${ETL_URL}/cdc/anyPkOrUnique/${id}`);
}
//检测数据源是否开启bin-log
export function checkBinLog(id: any): Promise<any> {
  return http.get(`${ETL_URL}/cdc/check/binlog/${id}`);
}

//错误信息
export function getTaskError(id: any): Promise<any> {
  return http.get(`${ETL_URL}/cdc/query/task/log/${id}`);
}

//执行履历
export function getRecordLists(params: any): Promise<any> {
  return http.post(`${ETL_URL}/cdc/query/task/log/history`, params);
}

//任务执行统计详情
export function getTaskSummaryInfo(id: string): Promise<any> {
  return http.get(`${ETL_URL}/cdc/query/task/statistics/${id}`);
}
