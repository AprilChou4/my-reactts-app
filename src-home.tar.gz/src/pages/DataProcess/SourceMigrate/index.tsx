import React, { Component, Fragment } from 'react';
import { RouteComponentProps } from 'react-router-dom';
import { Button, Divider, Table, Tooltip } from 'sup-ui';
import { observer } from 'mobx-react';
import memoizeOne from 'memoize-one';
import moment from 'moment';
import { AddBtn, DelBtn } from '@components/Button';
import Icon from '@components/Icon';
import CustomPaging from '@components/CustomPaging';
import ColumnFilter from '@components/ColumnFilter';
import TableFilter from '@components/TableFilter';
import { TableCellText } from '@components/Table';
import ConfirmDialog from './components/ConfirmDialog';
import ErrorModal from './components/ErrorModal';
import TaskDrawer from './containers/TaskDrawer';
import TaskInfoDrawer from './containers/TaskInfoDrawer';
import {
  migrateTypes,
  migrateMethods,
  taskStatus,
  execStatus,
  generateEnumMap,
  tableSyncStatus
} from './consts/enum';
import { tableColumns } from './consts/columns';
import MigrateStore from './stores/migrate.store';
import styles from './index.less';

const syncStatusMap: any = {
  1: '增量',
  2: '全量',
  3: '周期增量',
  4: '周期全量'
};

interface IProps extends RouteComponentProps {}

interface IState {
  dialogVisible: boolean;
  errorVisible: boolean;
  infoVisible: boolean;
  selectedRecord: any;
  errors: any;
  checkedColumns: any[];
  selectedRowKeys: any[];
}

@observer
class Migrate extends Component<IProps, IState> {
  private readonly typeMap: any;
  private readonly taskMap: any;
  private readonly execMap: any;
  private readonly store: MigrateStore;
  private currentTask: any;
  public constructor(props: IProps) {
    super(props);

    const checkedItems = _.map(_.filter(tableColumns, 'check'), 'dataIndex');

    this.state = {
      dialogVisible: false,
      errorVisible: false,
      infoVisible: false,
      selectedRecord: null,
      errors: '',
      checkedColumns: checkedItems,
      selectedRowKeys: []
    };

    this.typeMap = generateEnumMap(migrateMethods);
    this.taskMap = generateEnumMap(migrateTypes);
    this.execMap = generateEnumMap(execStatus);
    this.store = new MigrateStore();
  }

  public updateCheckedColumns = (checkedItems: any[]) => {
    this.setState({
      checkedColumns: checkedItems
    });
  };

  public updateSelectedRowKeys = (selectedRowKeys: []): void => {
    this.setState({ selectedRowKeys });
  };

  public getEnumData = (dataIndex: string): any => {
    switch (dataIndex) {
      case 'taskType':
        return migrateTypes;
      case 'syncType':
        return migrateMethods;
      case 'status':
        return taskStatus;
      case 'result':
        return execStatus;
      default:
        return [];
    }
  };

  public getColumnSearchProps = (dataIndex: string, isEnum: boolean) => ({
    filterDropdown: ({ setSelectedKeys, confirm, selectedKeys }: any) => (
      <TableFilter
        isEnum={isEnum}
        enumData={this.getEnumData(dataIndex)}
        confirm={confirm}
        selectedKeys={selectedKeys}
        setSelectedKeys={setSelectedKeys}
      />
    )
  });

  private handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;

    //筛选filters
    const {
      name = [],
      syncType = [],
      status = [],
      result = [],
      taskType = []
    } = filters;

    const orderBy = [
      {
        name: sorter.field,
        order: sorter.order === 'ascend' ? 'ASC' : 'DESC'
      }
    ];
    //const newSyncType = _.
    this.store.updateSearchParams({
      keyword: name.length ? name[0] : '',
      syncType,
      taskType,
      status,
      result,
      orderBy,
      pageNum: current,
      pageSize
    });
  };

  private handleSwitchStatus = (record: any) => {
    const { handleSwitchStatus } = this.store;

    handleSwitchStatus(record);
  };

  private handleEditData = (record: any) => {
    const { checkTaskDetail } = this.store;
    if (record.status === 1) return;
    checkTaskDetail(record);
  };

  private handleInfoVisible = (record: any) => {
    this.setState({ infoVisible: true, selectedRecord: record });
  };

  private handleDeleteData = (remove: boolean) => {
    const { handleDeleteTask } = this.store;
    let ids = this.currentTask;

    if (_.isPlainObject(this.currentTask as any)) {
      ids = [this.currentTask.id];
    }

    if (!ids.length) {
      return;
    }

    handleDeleteTask(ids, remove, () => {
      this.setState({
        selectedRowKeys: []
      });
    });

    this.currentTask = null;
    this.setState({
      dialogVisible: false
    });
  };

  public handleShowError = (taskId: any) => {
    const { getTaskError } = this.store;

    getTaskError(taskId, (errors: string) => {
      this.setState({
        errorVisible: true,
        errors
      });
    });
  };

  private getColumns = () => {
    return [
      {
        title: '任务ID',
        dataIndex: 'id',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: any, record: any) => {
          return (
            <a onClick={() => this.handleEditData(record)}>
              <TableCellText text={text} />
            </a>
          );
        }
      },
      {
        title: '任务名称',
        dataIndex: 'name',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: any, record: any) => {
          return (
            <a onClick={() => this.handleInfoVisible(record)}>
              <TableCellText text={text} />
            </a>
          );
        },
        ...this.getColumnSearchProps('name', false)
      },
      {
        title: '数据流向',
        dataIndex: 'dataFlow',
        width: 180,
        className: 'ellipsis-hide',
        render: (_text: string, record: any) => {
          const { sourceSubCatalog, targetSubCatalog } = record;

          return (
            <TableCellText
              text={`${sourceSubCatalog} -> ${targetSubCatalog || '数据仓库'}`}
            />
          );
        }
      },
      {
        title: '任务类型',
        dataIndex: 'taskType',
        width: 180,
        className: 'ellipsis-hide',
        render: (_text: string, record: any) => {
          return <TableCellText text={this.taskMap[record.taskType]} />;
        },
        ...this.getColumnSearchProps('taskType', true)
      },
      {
        title: '迁移方式',
        dataIndex: 'syncType',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={this.typeMap[text]} />,
        ...this.getColumnSearchProps('syncType', true)
      },
      {
        title: '任务状态',
        dataIndex: 'status',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: any) => {
          const status = taskStatus.find(item => item.key === +text);
          return status ? (
            <span style={{ color: status.color }}>{status.showName}</span>
          ) : (
            ''
          );
        },
        ...this.getColumnSearchProps('status', true)
      },
      // {
      //   title: '最近一次执行时间',
      //   dataIndex: 'lastExecTime',
      //   width: 150,
      //   className: 'ellipsis-hide dateTime',
      //   render: (text: number) => {
      //     const txt = text ? moment(text).format('YYYY-MM-DD HH:mm') : '-';
      //     return <TableCellText text={txt} />;
      //   }
      // },
      {
        title: '执行状态',
        dataIndex: 'result',
        width: 140,
        className: 'ellipsis-hide',
        render: (text: any, record: any) => {
          const { id, syncStatus } = record;

          if (_.isNil(text)) {
            return <TableCellText text={'-'} />;
          }

          const txt = this.execMap[text];

          //执行正常下显示任务当前的同步状态, 兼容0
          const syncText =
            _.isNil(syncStatus) || !syncStatus
              ? ''
              : ` | ${syncStatusMap[syncStatus]}`;
          const tablesyncStatusKey =
            tableSyncStatus[record.tableSyncStatus]?.enumKey; //2表示表同步异常
          return (
            <div className={styles.resultBox}>
              <span
                style={{
                  color:
                    text === 1 && tablesyncStatusKey !== 2
                      ? '#36af47'
                      : '#ed1c24'
                }}
              >
                {tablesyncStatusKey === 2 ? '异常' : txt}
                {text === 1 && syncText}
              </span>
              {(text !== 1 || tablesyncStatusKey === 2) && (
                <Icon
                  onClick={() => this.handleShowError(id)}
                  type="circle-info"
                  fill="#ed1c24"
                  width={14}
                  height={14}
                />
              )}
            </div>
          );
        },
        ...this.getColumnSearchProps('result', true)
      },
      {
        title: '创建人',
        dataIndex: 'createName',
        width: 150,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text || '-'} />
      },
      {
        title: '最近修改人',
        dataIndex: 'lastModifyName',
        width: 150,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text || '-'} />
      },
      {
        title: '最近修改时间',
        dataIndex: 'lastModifyTime',
        width: 150,
        className: 'ellipsis-hide',
        sorter: true,
        render: (text: number) => {
          const txt = text ? moment(text).format('YYYY-MM-DD HH:mm') : '-';

          return <span style={{ color: '#7f8fa4' }}>{txt}</span>;
        }
      },
      {
        title: '描述',
        dataIndex: 'description',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '操作',
        align: 'center',
        fixed: 'right',
        width: 240,
        render: (_text: any, record: any) => {
          return (
            <Fragment>
              <div className="operator">
                <a onClick={() => this.handleSwitchStatus(record)}>
                  {record.status === 1 ? '停用' : '启用'}
                </a>
                <Divider type="vertical" />
                {record.status === 1 ? (
                  <Tooltip placement="top" title="任务停用才能编辑">
                    <a
                      onClick={() => this.handleEditData(record)}
                      className={styles.disabled}
                    >
                      编辑
                    </a>
                  </Tooltip>
                ) : (
                  <a onClick={() => this.handleEditData(record)}>编辑</a>
                )}

                <Divider type="vertical" />
                {record.status === 1 ? (
                  <Tooltip placement="top" title="任务停用才能删除">
                    <a
                      className={styles.disabled}
                      onClick={() => {
                        if (record.status === 1) return;
                        this.currentTask = record;
                        this.setState({
                          dialogVisible: true
                        });
                      }}
                    >
                      删除
                    </a>
                  </Tooltip>
                ) : (
                  <a
                    onClick={() => {
                      if (record.status === 1) return;
                      this.currentTask = record;
                      this.setState({
                        dialogVisible: true
                      });
                    }}
                  >
                    删除
                  </a>
                )}

                {/* {record.taskType === 2 &&
                  (tableSyncStatus.find(
                    item => item.key === +record.tableSyncStatus
                  )?.enumKey === 0 && record.status === 1 ? (
                    <>
                      <Divider type="vertical" />
                      <Tooltip placement="top" title="任务执行中">
                        <a className={styles.disabled}>立即执行</a>
                      </Tooltip>
                    </>
                  ) : (
                    <>
                      <Divider type="vertical" />
                      <a
                        onClick={() => {
                          this.store.hangdleEnableTaskImmediately(record);
                        }}
                      >
                        立即执行
                      </a>
                    </>
                  ))} */}
                {record.taskType === 2 && (
                  <>
                    <Divider type="vertical" />
                    <a
                      onClick={() => {
                        this.store.hangdleEnableTaskImmediately(record);
                      }}
                    >
                      立即执行
                    </a>
                  </>
                )}
              </div>
              <div className="more">
                <Icon type="ellipsis" width={13} />
              </div>
            </Fragment>
          );
        }
      }
    ];
  };

  private getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 50;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public render() {
    const {
      loading,
      list,
      searchParams,
      count,
      visible,
      handleVisibleChange,
      selectedTask,
      checkTaskDetail,
      handleRefreshList
    } = this.store;
    const {
      checkedColumns,
      dialogVisible,
      selectedRowKeys,
      errorVisible,
      errors,
      infoVisible,
      selectedRecord
    } = this.state;
    const rowSelection: any = {
      columnWidth: 50,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true
    };
    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );

    return (
      <div className={styles.container}>
        <div className={styles.header}>
          <h3>整库迁移</h3>
          <div className={styles.operator}>
            <AddBtn
              ghost
              title="新增"
              onClick={() => checkTaskDetail({ id: null })}
            />
            <Button className={styles.btn} onClick={handleRefreshList}>
              刷新
            </Button>
            <DelBtn
              disabled={selectedRowKeys.length === 0}
              onClick={() => {
                this.currentTask = selectedRowKeys;
                this.setState({
                  dialogVisible: true
                });
              }}
            />
          </div>
          <ColumnFilter
            sourceColumns={tableColumns}
            onOk={this.updateCheckedColumns}
          />
        </div>
        <div className={styles.content}>
          <div className={`${styles.table} mp-table-white mp-table-grow`}>
            <Table
              loading={loading}
              columns={filterColumns}
              rowSelection={rowSelection}
              dataSource={list}
              onChange={this.handleTableChange}
              rowKey="id"
              pagination={{
                current: searchParams.pageNum,
                pageSize: searchParams.pageSize,
                total: count,
                showTotal: total => `共${total}条`,
                itemRender: CustomPaging,
                pageSizeOptions: ['20', '50', '100'],
                showSizeChanger: true,
                showQuickJumper: true
              }}
              scroll={{
                x: totalWidthX,
                y: 'calc(100% - 50px)'
              }}
            />
          </div>
        </div>
        {visible && (
          <TaskDrawer
            task={selectedTask}
            visible={visible}
            onVisibleChange={handleVisibleChange}
          />
        )}
        {infoVisible && (
          <TaskInfoDrawer
            task={selectedRecord}
            visible={infoVisible}
            onVisibleChange={() =>
              this.setState({ infoVisible: false, selectedRecord: null })
            }
          />
        )}
        {errorVisible && (
          <ErrorModal
            error={errors}
            visible={errorVisible}
            onVisibleChange={() => this.setState({ errorVisible: false })}
          />
        )}
        <ConfirmDialog
          onOk={this.handleDeleteData}
          visible={dialogVisible}
          onVisibleChange={() => this.setState({ dialogVisible: false })}
        />
      </div>
    );
  }
}

export default Migrate;
