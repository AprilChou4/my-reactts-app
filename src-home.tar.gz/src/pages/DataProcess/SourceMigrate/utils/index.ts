export function formatexecLongTime(time: number) {
  if (time < 1000) {
    return time + ' 毫秒';
  }
  if (time < 1000 * 60) {
    return (time / 1000).toFixed(1) + ' 秒';
  }
  if (time < 3600000) {
    return (time / 1000 / 60).toFixed(1) + ' 分钟';
  }
  return (time / 1000 / 60 / 60).toFixed(1) + ' 小时';
}
