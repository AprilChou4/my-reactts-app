import React, { Component, createContext } from 'react';
import { Table, Input, message, Form, Tooltip, Select } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import Icon from '@components/Icon';
import { TableCellText } from '@components/Table';
import { AddBtn } from '@components/Button';
import TableSelector from '../TableSelector';

import {
  SyncTableTypeEnum,
  SyncTypeEnum,
  TaskTypeEnum
} from '../../stores/detail.store';
import styles from './index.less';

const { Option } = Select;
const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }

      this.toggleEdit();

      handleSave(dataIndex, { ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;
    const isPrefix = dataIndex === 'prefix';

    return (
      <div className={styles['editable-cell']}>
        {editing ? (
          <Form.Item>
            {form.getFieldDecorator(dataIndex, {
              initialValue: record[dataIndex]
            })(
              <Input
                style={{ textAlign: isPrefix ? 'right' : 'left' }}
                ref={node => (this.input = node)}
                onPressEnter={this.save}
                onBlur={this.save}
              />
            )}
          </Form.Item>
        ) : (
          <div
            className={styles.cell}
            onClick={this.toggleEdit}
            title={record[dataIndex] || '请输入'}
            style={{ textAlign: isPrefix ? 'right' : 'left' }}
          >
            {record[dataIndex] || <span>请输入</span>}
          </div>
        )}
        {dataIndex === 'prefix' && (
          <p title={record['tableName']}>{record['tableName']}</p>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps extends FormComponentProps {
  source: any; //选中的数据源 { id }
  target: any; //目标源
  list?: any[];
  prefix: any; //目标表前缀
  isEdit: boolean;
  taskType?: number;
  syncTableType?: number;
  syncType?: number;
  isInfo?: boolean; //是否为任务详情页面
  sourceType?: string; //来源表类型
}
interface IState {
  visible: boolean;
  statelists: any[];
}

class TableComp extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const { list = [], isEdit } = props;

    this.state = {
      statelists: isEdit ? _.cloneDeep(list) : [],
      visible: false
    };
  }

  private handleVisibleChange = (visible: boolean) => {
    this.setState({
      visible
    });
  };

  private handleAdd = () => {
    const { source } = this.props;

    if (_.isNil(source) || _.isNil(source.id)) {
      message.warning('请先选择数据源!');
      return;
    }

    this.setState({
      visible: true
    });
  };
  // 配置增量字段
  private handleFieldSelect = (e: string, index: number) => {
    const newLists = _.map(this.state.statelists, (item: any, i) => {
      if (i === index) {
        return { ...item, incrementField: e };
      } else {
        return item.incrementField
          ? item
          : _.findIndex(item.timeField, n => n === e) === -1
          ? item
          : { ...item, incrementField: e };
      }
    });
    this.setState({
      statelists: newLists
    });
  };
  private getOperationIcon = (record: any) => {
    const { isEdit, isInfo } = this.props;
    //详情
    if (isInfo) return '-';
    //全部表
    if (this.props.syncTableType === SyncTableTypeEnum.allTables) return '-';
    //编辑且实时模式
    if (isEdit && this.props.taskType === TaskTypeEnum.intimesync) return '-';
    //编辑 离线 且 存在的不能删除
    console.log(record);
    if (
      isEdit &&
      this.props.taskType === TaskTypeEnum.offlinesync &&
      record.exists
    )
      return '-';
    return (
      <Icon
        type="remove"
        width={22}
        onClick={() => this.handleRemoveItems([record.id])}
      />
    );
  };
  public getColumns = (): any[] => {
    const {
      form: { getFieldDecorator },
      isEdit,
      prefix,
      target: { type },
      syncType,
      sourceType
    } = this.props;

    const colums: any[] = [
      {
        title: '源表表名',
        width: 160,
        dataIndex: 'tableName',
        className: 'ellipsis-hide',
        render: (text: any, record: any) => {
          const { exists } = record;

          return (
            <div className={styles.info}>
              <TableCellText text={text} />
              {!_.isNil(exists) && !exists && (
                <div className={styles.icon}>
                  <Tooltip title="数据源中该表已被删除!">
                    <Icon
                      type="circle-info"
                      fill="#ed1c24"
                      width={14}
                      height={14}
                    />
                  </Tooltip>
                </div>
              )}
            </div>
          );
        }
      },
      {
        title: '源表中文名',
        width: 160,
        dataIndex: 'sourceCnName',
        className: 'ellipsis-hide',
        render: (text: any) => <TableCellText text={text} />
      },
      {
        title: `${type === 'model' ? '别名' : '目标表表名'} (前缀+表名)`,
        width: 160,
        dataIndex: 'prefix',
        // editable: !isEdit,
        className: 'ellipsis-hide',
        render: (_text: any, record: any) => {
          const { tableName } = record;

          return <TableCellText text={`${prefix}${tableName}`} />;
        }
      },
      {
        title: type === 'model' ? '表单模板名称' : '目标表中文名',
        width: 'auto',
        dataIndex: 'targetCnName',
        editable: !isEdit,
        render: (text: any) => <TableCellText text={text} />
      },

      {
        title: '操作',
        width: 50,
        align: 'center',
        render: (_value: any, record: any) => (
          <div style={{ height: '30px', padding: '5px 0' }}>
            {this.getOperationIcon(record)}
          </div>
        )
      }
    ];
    if (syncType === SyncTypeEnum.periodIncrease && sourceType !== 'model') {
      colums.splice(4, 0, {
        title: '增量字段',
        width: 140,
        dataIndex: 'timeField',
        render: (_value: any, record: any, index: number) => {
          return record.timeField ? (
            <Form.Item
              className={styles.increamentField}
              style={{ width: '120px' }}
            >
              {getFieldDecorator(`incrementField_${index}`, {
                rules: [
                  {
                    required: true,
                    message: '-请选择-'
                  }
                ],
                initialValue: record.incrementField,
                validateTrigger: ['onChange', 'onBlur']
              })(
                <Select onSelect={(e: any) => this.handleFieldSelect(e, index)}>
                  {record.timeField.map((item: any) => {
                    return (
                      <Option value={item} key={item}>
                        {item}
                      </Option>
                    );
                  })}
                </Select>
              )}
            </Form.Item>
          ) : (
            <div>{record.incrementField}</div>
          );
        }
      });
    }
    return colums;
  };

  public handleAddItem = (tables: any[]) => {
    const { statelists } = this.state;
    const oldTables = _.intersectionBy(statelists, tables, 'id');
    const newTables = _.differenceBy(tables, statelists, 'id');
    const items = _.map(
      newTables,
      ({ id, tableName, remark, timeField, incrementField }) => ({
        id,
        tableName,
        sourceCnName: remark,
        targetCnName: remark,
        timeField,
        incrementField
      })
    );

    this.setState({
      visible: false,
      statelists: oldTables.concat(items)
    });
  };

  public handleCellSave = (dataIndex: string, row: any) => {
    this.handleValueChange(row.id, dataIndex, row[dataIndex]);
  };

  public handleValueChange = (id: number, name: string, value: any): void => {
    const { statelists } = this.state;
    const arr = _.cloneDeep(statelists);
    const target = _.find(arr, ['id', id]);

    target[name] = value;

    this.setState({
      statelists: arr
    });
  };

  public handleRemoveItems = (ids: any[]) => {
    const { statelists } = this.state;
    const remainList = _.filter(statelists, item => !_.includes(ids, item.id));

    this.setState({
      statelists: remainList
    });
  };

  public validateDatas = () => {
    //校验，拼装数据
    const { statelists } = this.state;
    const {
      target: { type },
      syncType,
      sourceType
    } = this.props;

    //迁移到supos，表单模板名称必填
    if (type === 'model') {
      for (let i = 0; i < statelists.length; i++) {
        if (!statelists[i]['targetCnName']) {
          message.error('表单模板名称不能为空!');
          return;
        }
      }
    }

    if (syncType === SyncTypeEnum.periodIncrease && sourceType !== 'model') {
      for (let i = 0; i < this.state.statelists.length; i++) {
        if (!this.state.statelists[i].incrementField) {
          message.error('增量字段不能为空!');
          return;
        }
      }
    }
    return _.map(statelists, data => ({
      sourceTableName: data.tableName,
      sourceTableRemarks: data.sourceCnName,
      targetTableRemarks: data.targetCnName,
      incrementField: data.incrementField
    }));
  };
  // 模式选为所有表时 现在不展示Table 故不再需要
  // public componentDidMount() {
  //   const { source, sourceType } = this.props;
  //   if (this.props.syncTableType === SyncTableTypeEnum.allTables) {
  //     getTableList(source.id, sourceType).then(res => {
  //       if (res.code === 200) {
  //         this.setState({
  //           statelists: _.map(
  //             res.data.tables,
  //             ({ name, pk, remark, timeField }) => ({
  //               id: name,
  //               pk, //是否含有主键
  //               tableName: name,
  //               remark,
  //               timeField,
  //               incrementField: ''
  //             })
  //           )
  //         });
  //       }
  //     });
  //   }
  // }

  public render() {
    const { source, isEdit, isInfo, syncTableType, taskType } = this.props;
    const { statelists, visible } = this.state;
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });

    return (
      <div className={styles.container}>
        {!(isEdit && taskType === TaskTypeEnum.intimesync) &&
          syncTableType === SyncTableTypeEnum.partTables &&
          !isInfo && (
            <div className={styles.header}>
              <AddBtn title="新增源表" onClick={this.handleAdd} ghost />
            </div>
          )}
        <Table
          size="small"
          rowKey="id"
          components={{
            body: {
              row: EditableFormRow,
              cell: EditableCell
            }
          }}
          columns={columns}
          dataSource={statelists}
          scroll={this.props?.isInfo ? {} : { y: 260 }}
          pagination={false}
        />
        {visible && (
          <TableSelector
            sourceId={source.id}
            chosenList={statelists}
            visible={visible}
            taskType={taskType!}
            sourceType={this.props.sourceType}
            onVisibleChange={this.handleVisibleChange}
            onOk={this.handleAddItem}
          />
        )}
      </div>
    );
  }
}

export default Form.create({})(TableComp);
