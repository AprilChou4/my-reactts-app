import React, { Component } from 'react';
import { Checkbox, Input, Table } from 'sup-ui';
import { TaskTypeEnum } from '../../stores/detail.store';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import styles from './index.less';

const Search = Input.Search;

interface IProps {
  total: number;
  loading?: boolean;
  pagination: any;
  source: any[]; //{label: string; value: string; disabled?: boolean}
  taskType: number;
  disableList: string[];
  onCheckChange: any;
  type: 'source' | 'target';
  onQueryChange: (params: any) => void;
}

interface IState {
  list: any[];
  selectedRowKeys: string[];
}

class CheckList extends Component<IProps, IState> {
  private readonly debounceFuc: any;
  public constructor(props: IProps) {
    super(props);

    const { source, disableList = [], taskType, onQueryChange } = props;
    const disIds = _.map(disableList, 'id');
    const temp = _.map(source, val => ({
      ...val,
      disabled:
        taskType === TaskTypeEnum.intimesync
          ? _.includes(disIds, val.id) || !val.pk
          : _.includes(disIds, val.id)
    }));
    this.debounceFuc = _.debounce(onQueryChange, 800);
    this.state = {
      list: temp,
      selectedRowKeys: []
    };
  }

  public componentDidUpdate(prevProps: IProps) {
    const { source, disableList } = this.props;
    if (prevProps.source !== source || prevProps.disableList !== disableList) {
      const disIds = _.map(disableList, 'id');
      const list = _.map(source, val => ({
        ...val,
        disabled: _.includes(disIds, val.id)
      }));
      this.setState({
        list
      });
    }
  }
  /**
   * 搜索内容改变处理
   * @param e
   */
  private handleValueChange = (e: any) => {
    this.debounceFuc({
      tableName: e.target.value
    });
  };

  /**
   * 是否主键改变
   * @param e
   */
  private handleKeyChange = (e: any) => {
    const { onQueryChange } = this.props;
    onQueryChange({
      keyOrUnique: e.target.checked
    });
  };

  private handleTableChange = (pagination: any) => {
    //页码
    const { current, pageSize } = pagination;
    const { onQueryChange } = this.props;
    onQueryChange({
      pageNum: current,
      pageSize
    });
  };
  private getColumns = () => {
    return [
      {
        title: '表名',
        dataIndex: 'tableName',
        width: 200,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      }
    ];
  };
  public updateSelectedRowKeys = (selectedRowKeys: []): void => {
    const { onCheckChange } = this.props;
    this.setState({ selectedRowKeys });
    onCheckChange(selectedRowKeys);
  };
  public render() {
    const { type, total, pagination, loading = false } = this.props;
    const { list, selectedRowKeys } = this.state;
    const title = type === 'source' ? '源表' : '已选源表';

    const rowSelection: any = {
      columnWidth: 50,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      getCheckboxProps: (record: any) => ({
        disabled: record.disabled
      })
    };
    const columns = this.getColumns();
    return (
      <div className={styles.checkBox} style={{ flex: 1 }}>
        <h4>{title}</h4>
        <div className={styles.search}>
          <Search
            placeholder="输入关键字搜索"
            onChange={this.handleValueChange}
            style={{ width: 170 }}
          />
          {type === 'source' && (
            <Checkbox
              checked={pagination.keyOrUnique}
              onChange={this.handleKeyChange}
            >
              含有主键
            </Checkbox>
          )}
        </div>

        <div className={`${styles.table} mp-table-gray-light mp-table-grow`}>
          <Table
            loading={loading}
            rowSelection={rowSelection}
            rowKey="id"
            columns={columns}
            dataSource={list}
            onChange={this.handleTableChange}
            pagination={{
              total,
              showTotal: count => `共 ${count} 条`,
              current: pagination.pageNum,
              pageSize: pagination.pageSize,
              itemRender: CustomPaging
            }}
            scroll={{
              y: 'calc(100% - 36px)'
            }}
          />
        </div>
      </div>
    );
  }
}

export default CheckList;
