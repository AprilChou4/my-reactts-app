import React, { Component } from 'react';
import { Checkbox, Input } from 'sup-ui';
import { TaskTypeEnum } from '../../stores/detail.store';
import styles from './index.less';

const CheckboxGroup = Checkbox.Group;
const Search = Input.Search;

interface IProps {
  source: any[]; //{label: string; value: string; disabled?: boolean}
  taskType: number;
  disableList: string[];
  checkedList: string[];
  onCheckChange: any;
  type: 'source' | 'target';
}

interface IState {
  list: any[];
  searchValue: any;
  hasKey: boolean;
}

class TargetCheckList extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    const { source, disableList = [], taskType } = props;
    const disIds = _.map(disableList, 'id');
    const temp = _.map(source, ({ id, tableName, pk = true }) => ({
      label: tableName,
      value: id,
      pk,
      disabled:
        taskType === TaskTypeEnum.intimesync
          ? _.includes(disIds, id) || !pk
          : _.includes(disIds, id)
    }));

    this.state = {
      list: temp,
      searchValue: '',
      hasKey: true
    };
  }

  private handleValueChange = (e: any) => {
    this.setState({
      searchValue: e.target.value
    });
  };

  private handleKeyChange = (e: any) => {
    this.setState({
      hasKey: e.target.checked
    });
  };

  private handleCheckAll = () => {
    const { list, searchValue } = this.state;
    const { onCheckChange } = this.props;
    const temp = _.filter(list, ({ label }) => label.indexOf(searchValue) > -1);

    const checkedList = _.map(
      _.filter(temp, ({ disabled }) => !disabled),
      'value'
    );

    onCheckChange(checkedList);
  };

  private handleCheckReverse = () => {
    const { list, searchValue } = this.state;
    const { checkedList, onCheckChange } = this.props;
    const current = _.filter(
      list,
      ({ label }) => label.indexOf(searchValue) > -1
    );

    const temp = _.map(
      _.filter(current, ({ disabled }) => !disabled),
      'value'
    );

    const reverse = _.difference(temp, checkedList);

    onCheckChange(reverse);
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    const { disableList, source, taskType } = this.props;

    if (
      !_.isEqual(disableList, prevProps.disableList) ||
      !_.isEqual(source, prevProps.source)
    ) {
      const disIds = _.map(disableList, 'id');
      const temp = _.map(source, ({ id, tableName, pk = true }) => ({
        label: tableName,
        value: id,
        pk,
        disabled:
          taskType === TaskTypeEnum.intimesync
            ? _.includes(disIds, id) || !pk
            : _.includes(disIds, id) //离线模式允许选择不含主键(pk:false)的表
      }));
      this.setState({
        list: temp
      });
    }
  }

  public render() {
    const { type, checkedList, onCheckChange } = this.props;
    const { list, searchValue, hasKey } = this.state;
    const title = type === 'source' ? '源表' : '已选源表';
    const searchList = _.filter(
      list,
      ({ label }) => label.indexOf(searchValue) > -1
    );
    const filterList =
      type === 'source'
        ? _.filter(searchList, ({ pk }) => (hasKey ? pk : true))
        : searchList;

    return (
      <div className={styles.checkBox}>
        <h4>{title}</h4>
        <div className={styles.search}>
          <Search
            placeholder="输入关键字搜索"
            onChange={this.handleValueChange}
            style={{ width: 170 }}
          />
          {type === 'source' && (
            <Checkbox checked={hasKey} onChange={this.handleKeyChange}>
              含有主键
            </Checkbox>
          )}
        </div>
        <div className={styles.list}>
          <CheckboxGroup
            options={filterList}
            value={checkedList}
            onChange={onCheckChange}
          />
        </div>
        <div className={styles.btns}>
          <a onClick={this.handleCheckAll}>全选</a>
          <a onClick={this.handleCheckReverse}>反选</a>
          <p>
            {checkedList.length}/{list.length}
          </p>
        </div>
      </div>
    );
  }
}

export default TargetCheckList;
