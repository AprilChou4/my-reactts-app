import React, { Component, createRef } from 'react';
import { message } from 'sup-ui';
import { observer } from 'mobx-react';
import DialogModal from '@components/Modal/Dialog';
import CheckList from './CheckList';
import TargetCheckList from './TargetCheckList';
import { getTableListByQuery } from '../../migrate.service';
import { TaskTypeEnum } from '../../stores/detail.store';
import styles from './index.less';

interface IProps {
  sourceId: any; //数据源信息
  chosenList: any[]; //已选列表
  visible: boolean;
  taskType: number;
  onVisibleChange: any;
  onOk: any;
  sourceType?: string;
}

interface IState {
  list: any[];
  loading: boolean;
  chosenList: any[];
  leftCheckKeys: string[];
  rightCheckList: any[];
  queryParams?: any;
  sourceTotal: number;
}

/**
 * 新增源表组件
 */
@observer
class TableSelector extends Component<IProps, IState> {
  private readonly checkRef: any;
  public constructor(props: IProps) {
    super(props);

    const temp = _.map(props.chosenList, ({ id, tableName }) => ({
      id,
      tableName
    }));

    this.checkRef = createRef();
    this.state = {
      list: [],
      loading: false,
      chosenList: temp,
      leftCheckKeys: [],
      rightCheckList: [],
      queryParams: {
        keyOrUnique: true,
        pageNum: 1,
        pageSize: 100,
        sourceId: props.sourceId,
        tableName: ''
      },
      sourceTotal: 0
    };
  }

  public handleSubmit = () => {
    const { chosenList } = this.state;
    const { onOk, onVisibleChange } = this.props;

    if (chosenList.length === 0) {
      message.error('请至少选择一张表!');
      return;
    }

    onOk(chosenList);
    onVisibleChange(false);
  };

  public handleLeftCheckChange = (keys: string[]) => {
    this.setState({
      leftCheckKeys: keys
    });
  };

  public handleRightCheckChange = (list: any[]) => {
    this.setState({
      rightCheckList: list
    });
  };

  public moveToRight = () => {
    const { list, leftCheckKeys, chosenList } = this.state;
    const move = _.filter(list, ({ id }) => _.includes(leftCheckKeys, id));

    this.checkRef.current && this.checkRef.current?.updateSelectedRowKeys([]);
    this.setState({
      chosenList: _.concat(chosenList, move)
    });
  };

  public moveToLeft = () => {
    const { rightCheckList, chosenList } = this.state;
    const remain = _.filter(
      chosenList,
      ({ id }) => !_.includes(rightCheckList, id)
    );

    this.setState({
      rightCheckList: [],
      chosenList: remain
    });
  };

  public renderFooter = () => {
    const { onVisibleChange } = this.props;

    return (
      <div className={styles.modalFooter}>
        <div className={styles.next} onClick={this.handleSubmit}>
          确定
        </div>
        <div className={styles.cancel} onClick={() => onVisibleChange(false)}>
          取消
        </div>
      </div>
    );
  };

  public componentDidMount() {
    //获取数据
    const { queryParams } = this.state;
    this.setState({
      loading: true
    });
    getTableListByQuery(queryParams).then(res => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const list = _.get(res, 'data.list', []);

      this.setState({
        loading: false,
        list: _.map(list, ({ name, pk, remark, timeField }) => ({
          id: name,
          pk, //是否含有主键
          tableName: name,
          remark,
          timeField,
          incrementField: ''
        })),
        sourceTotal: _.get(res, 'data.total', 0)
      });
    });
  }

  public componentDidUpdate(_preProps: IProps, preState: IState) {
    const { queryParams } = this.state;
    if (preState.queryParams !== queryParams) {
      this.setState({
        loading: true
      });
      getTableListByQuery(queryParams).then(res => {
        if (res.code !== 200) {
          message.error(res.message);
          return;
        }

        const list = _.get(res, 'data.list', []);

        this.setState({
          loading: false,
          list: _.map(list, ({ name, pk, remark, timeField }) => ({
            id: name,
            pk, //是否含有主键
            tableName: name,
            remark,
            timeField,
            incrementField: ''
          })),
          sourceTotal: _.get(res, 'data.total', 0)
        });
      });
    }
  }
  private handleQueryChange = (params: any) => {
    this.setState({
      queryParams: { ...this.state.queryParams, ...params }
    });
  };
  public render() {
    const { visible, onVisibleChange, taskType } = this.props;
    const {
      list,
      loading,
      chosenList = [],
      leftCheckKeys,
      rightCheckList,
      sourceTotal,
      queryParams
    } = this.state;
    const disableRight = leftCheckKeys.length === 0;
    const disableLeft = rightCheckList.length === 0;

    return (
      <DialogModal
        width={850}
        title="新增源表"
        visible={visible}
        onCancel={() => onVisibleChange(false)}
        bodyStyle={{ padding: '0' }}
        wrapClassName={styles.modalContainer}
        footer={this.renderFooter()}
      >
        <div className={styles.container}>
          <CheckList
            ref={this.checkRef}
            loading={loading}
            type="source"
            total={sourceTotal}
            pagination={queryParams}
            source={list}
            taskType={taskType}
            onCheckChange={this.handleLeftCheckChange}
            disableList={chosenList}
            onQueryChange={this.handleQueryChange}
          />

          <div className={styles.operator}>
            <div
              className={`${styles.r} ${disableRight ? styles.disable : ''}`}
              onClick={this.moveToRight}
            >
              <p className={styles.arrow} />
            </div>
            <div
              className={`${disableLeft ? styles.disable : ''}`}
              onClick={this.moveToLeft}
            >
              <p className={styles.arrow} />
            </div>
          </div>
          <TargetCheckList
            type="target"
            source={chosenList}
            taskType={taskType}
            checkedList={rightCheckList}
            onCheckChange={this.handleRightCheckChange}
            disableList={
              taskType === TaskTypeEnum.offlinesync
                ? this.props.chosenList.filter((item: any) => {
                    return item.exists ? true : false;
                  })
                : []
            }
          />
        </div>
      </DialogModal>
    );
  }
}

export default TableSelector;
