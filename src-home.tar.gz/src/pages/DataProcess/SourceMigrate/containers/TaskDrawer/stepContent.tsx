import React, { createRef } from 'react';
import { observer } from 'mobx-react';
import { Form, Radio, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import TableComp from '../../components/TableComp';
import { syncModes } from '../../consts/enum';
import ScheduleDispatch from '../../components/ScheduleConfig';
import {
  SyncTableTypeEnum,
  SyncTypeEnum,
  TaskTypeEnum
} from '../../stores/detail.store';
import { indicatorNameRule } from '@consts/rules';
import styles from './index.less';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;

interface IProps extends FormComponentProps {
  store: any;
  isEdit: boolean;
}

interface IState {}

@observer
class StepContent extends React.Component<IProps, IState> {
  private tableRef: any;
  private formRef: any;
  public constructor(props: IProps) {
    super(props);
    this.tableRef = createRef();
    this.formRef = createRef();
  }

  public handleRadioChange = async (e: any) => {
    const { updateFormData } = this.props.store;
    updateFormData({ syncTableType: e.target.value });
  };

  public handlePrefix = (e: any) => {
    const { updateFormData } = this.props.store;
    updateFormData({ prefix: e.target.value });
  };
  public render() {
    const {
      form: { getFieldDecorator },
      store: { formData, updateFormData, tablePk },
      isEdit
    } = this.props;

    const { sourceId, sourceType, targetType, taskType } = formData;

    const source = { id: sourceId, type: sourceType };
    const target = { type: targetType };

    return (
      <div>
        <Form>
          {formData.taskType === 1 && (
            <>
              <h3 className={styles.title}>同步的表</h3>
              <FormItem label="">
                {getFieldDecorator('syncTableType', {
                  initialValue: formData.syncTableType || 1
                })(
                  <RadioGroup
                    disabled={isEdit}
                    onChange={this.handleRadioChange}
                  >
                    {syncModes.map(item => (
                      <Radio value={item.key} key={item.key}>
                        {item.showName}
                      </Radio>
                    ))}
                  </RadioGroup>
                )}
              </FormItem>
            </>
          )}
          {formData.syncTableType === SyncTableTypeEnum.allTables &&
            tablePk && (
              <p className={styles.tips}>
                全部表中有不包含唯一索引的表，请选择部分表
              </p>
            )}
          <FormItem label="目标表前缀">
            {getFieldDecorator('prefix', {
              initialValue: formData.prefix,
              rules: [
                { max: 50, message: '长度不能超过50' },
                {
                  pattern: indicatorNameRule.pattern,
                  message: indicatorNameRule.message
                }
              ]
            })(<Input disabled={isEdit} onChange={this.handlePrefix} />)}
          </FormItem>

          {!(
            formData.taskType === TaskTypeEnum.intimesync &&
            formData.syncTableType === SyncTableTypeEnum.allTables
          ) && (
            <TableComp
              key={formData.syncTableType}
              isEdit={isEdit}
              ref={ref => (this.formRef = ref)}
              wrappedComponentRef={(ref: any) => (this.tableRef = ref)}
              source={source}
              target={target}
              list={formData.syncTables}
              prefix={formData.prefix}
              syncType={formData.syncType}
              syncTableType={formData.syncTableType}
              taskType={formData.taskType}
              sourceType={formData.sourceType}
            />
          )}

          {formData.syncType === SyncTypeEnum.periodAll && (
            <>
              <h3 className={styles.title}>全量同步设置</h3>
              <FormItem label="写入前清空数据：">
                {getFieldDecorator('cleanOldData', {
                  initialValue: formData.cleanOldData || false,
                  rules: [{ required: true }]
                })(
                  <RadioGroup
                    onChange={e =>
                      updateFormData({ cleanOldData: e.target.value })
                    }
                  >
                    <Radio value={true} key={'1'}>
                      {'是'}
                    </Radio>
                    <Radio value={false} key={'0'}>
                      {'否'}
                    </Radio>
                  </RadioGroup>
                )}
              </FormItem>
            </>
          )}

          {taskType === TaskTypeEnum.offlinesync && (
            <>
              <h3 className={styles.title}>调度配置</h3>
              <ScheduleDispatch
                schedule={formData.schedule}
                store={this.props.store}
              />
            </>
          )}
        </Form>
      </div>
    );
  }
}

export default Form.create<IProps>()(StepContent);
