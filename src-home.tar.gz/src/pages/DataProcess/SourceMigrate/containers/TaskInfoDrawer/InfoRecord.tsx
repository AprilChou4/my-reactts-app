import React, { FC, useState } from 'react';
import { Table, Row, Col } from 'sup-ui';
import RadioGroup from 'sup-ui/lib/radio/group';
import RadioButton from 'sup-ui/lib/radio/radioButton';
import { useRequest, useMemoizedFn } from 'ahooks';
import CustomPaging from '@components/CustomPaging';
import { getRecordLists } from '../../migrate.service';
import { TableCellText } from '@components/Table';
import moment from 'moment';
import { formatexecLongTime } from '../../utils';
import styles from './index.less';
interface IProps {
  task: any;
}

const InfoRecord: FC<IProps> = props => {
  const { taskType } = props.task;
  const [searchParams, setSearchParams] = useState({
    pageSize: 20,
    pageNum: 1,
    result: [1, 2], //任务执行状态 1 正常 2 异常
    id: props.task.id
  });
  const { data, loading } = useRequest(() => getRecordLists(searchParams), {
    refreshDeps: [searchParams],
    loadingDelay: 100
  });

  const getColumns = () => {
    return taskType === 1
      ? [
          {
            title: '操作时间',
            dataIndex: 'lastModifiedTime',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: number) => {
              return moment(text).format('YYYY-MM-DD HH:mm:ss');
            }
          },
          {
            title: '操作类型',
            dataIndex: 'execCondition',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: string) => {
              return <TableCellText text={text} />;
            }
          }
        ]
      : [
          {
            title: '操作时间',
            dataIndex: 'lastModifiedTime',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: number) => {
              return moment(text).format('YYYY-MM-DD HH:mm:ss');
            }
          },
          {
            title: '执行时长',
            dataIndex: 'execLongTime',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: number) => {
              return formatexecLongTime(text);
            }
          },
          {
            title: '成功数量',
            dataIndex: 'successNum',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: number) => {
              return text;
            }
          },
          {
            title: '失败数量',
            dataIndex: 'failNum',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: number) => {
              return text;
            }
          },
          {
            title: '执行结果',
            dataIndex: 'execCondition',
            //width: 200,
            className: 'ellipsis-hide',
            render: (text: string) => {
              return <TableCellText text={text} />;
            }
          }
        ];
  };
  const handleTableChange = useMemoizedFn((pagination: any) => {
    const { current, pageSize } = pagination;
    setSearchParams({
      ...searchParams,
      pageSize,
      pageNum: current
    });
  });
  const handleTabChange = (e: any) => {
    if (e.target.value === '0') {
      setSearchParams({
        ...searchParams,
        pageSize: 20,
        pageNum: 1,
        result: [1, 2]
      });
    } else {
      setSearchParams({
        ...searchParams,
        pageSize: 20,
        pageNum: 1,
        result: [+e.target.value]
      });
    }
  };
  return (
    <div className={styles.recordOfContainer}>
      {/* <Row>
        <Col span={24} style={{ textAlign: 'right' }}>
          <RadioGroup
            defaultValue="0"
            buttonStyle="solid"
            onChange={handleTabChange}
            className={styles.recordRadioButton}
          >
            <RadioButton value="0">所有</RadioButton>
            <RadioButton value="1">成功</RadioButton>
            <RadioButton value="2">失败</RadioButton>
          </RadioGroup>
        </Col>
      </Row> */}
      <Table
        className={styles.recordOfTable}
        loading={loading}
        columns={getColumns()}
        dataSource={data?.list ?? []}
        onChange={handleTableChange}
        rowKey="id"
        pagination={{
          current: searchParams.pageNum,
          pageSize: searchParams.pageSize,
          total: data?.pagination?.total ?? 0,
          showTotal: total => `共${total}条`,
          itemRender: CustomPaging,
          pageSizeOptions: ['20', '50', '100'],
          showSizeChanger: true,
          showQuickJumper: true
        }}
        scroll={{
          y: 'calc(100% - 50px)'
        }}
      />
    </div>
  );
};

export default InfoRecord;
