import React, { Component } from 'react';
import { observer } from 'mobx-react';
import memoizeOne from 'memoize-one';
import { Table, Modal, Tooltip } from 'sup-ui';
import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import UnusualStore from '../../stores/unusual.store';
import styles from './index.less';

interface IProps {
  onVisibleChange: any;
  taskId: any;
  visible: boolean;
}

@observer
class UnusualData extends Component<IProps> {
  private readonly store: UnusualStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new UnusualStore(props.taskId);
  }

  public handleTableChange = (pagination: any) => {
    this.store.updateSearchParams({
      pageNum: pagination.current,
      pageSize: pagination.pageSize
    });
  };

  public generateColumns = memoizeOne((dynamicColumns: any[]): any =>
    _.map(dynamicColumns, column => ({
      title: (
        <Tooltip title={column.dataIndex} placement="topLeft">
          <p className={styles.tit}>{column.dataIndex}</p>
        </Tooltip>
      ),
      width: column.width,
      dataIndex: column.dataIndex,
      className: 'ellipsis-hide',
      render: (text: string) => {
        return <TableCellText text={text} />;
      }
    }))
  );

  public getFilterColumns = memoizeOne((columns: any[]): any => {
    const cols = columns.slice();
    if (cols.length < 8) {
      _.forEach(cols, col => {
        col.width = 'auto';
      });

      return { filterColumns: cols, totalWidthX: 'auto' };
    }

    let totalWidthX = 0;

    _.forEach(
      cols,
      col => col.width && _.isNumber(col.width) && (totalWidthX += col.width)
    );

    //将倒数第一列的宽度置为auto
    cols[cols.length - 1]['width'] = 'auto' as any;

    return { filterColumns: cols, totalWidthX };
  });

  public render() {
    const { visible, onVisibleChange } = this.props;
    const { loading, count, searchParams, dataSource, dynamicColumns } =
      this.store;
    const columns = this.generateColumns(dynamicColumns);
    const { filterColumns, totalWidthX } = this.getFilterColumns(columns);

    return (
      <Modal
        visible={visible}
        footer={null}
        onCancel={() => onVisibleChange(false)}
        width="1080px"
        title="最近一次异常数据"
        className={styles.unusualModal}
        bodyStyle={{ padding: '12px 20px 0' }}
      >
        <div className={`${styles.table} mp-table-gray-light mp-table-grow`}>
          <Table
            loading={loading}
            columns={filterColumns}
            dataSource={dataSource}
            rowKey={() => _.uniqueId()}
            onChange={this.handleTableChange}
            pagination={{
              total: count,
              current: searchParams.pageNum,
              pageSize: searchParams.pageSize,
              showTotal: total => `共${total}条`,
              itemRender: CustomPaging
            }}
            scroll={{
              x: totalWidthX,
              y: 'calc(100% - 40px)'
            }}
          />
        </div>
      </Modal>
    );
  }
}

export default UnusualData;
