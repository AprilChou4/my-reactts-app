import React, { Component } from 'react';
import { Modal } from 'sup-ui';
import styles from './index.less';

interface IProps {
  source: any;
  visible: boolean;
  onVisibleChange: any;
}

interface IState {}

class ErrorLog extends Component<IProps, IState> {
  public render() {
    const { visible, onVisibleChange, source } = this.props;

    return (
      <Modal
        visible={visible}
        footer={null}
        onCancel={() => onVisibleChange(false)}
        width="1080px"
        title="错误日志"
        className={styles.executionModal}
        bodyStyle={{ padding: '12px 20px' }}
      >
        <div className={styles.errorLogWrapper}>{source}</div>
      </Modal>
    );
  }
}

export default ErrorLog;
