import http from '@services/http';
import { TASK_URL } from '@config/env';

export const getTaskList = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/getPageInfo`, data);
};

export const deleteTask = (data: any[]): Promise<any> => {
  return http.post(`${TASK_URL}/release/delete/batch`, data);
};

//单个copy
export const copyTask = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/developer/copy`, data);
};

export const startTask = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/start/${data}`);
};

export const stopTask = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/stop/${data}`);
};

export const batchStartTask = (data: any[]): Promise<any> => {
  return http.post(`${TASK_URL}/release/start/batch`, data);
};

export const batchStopTask = (data: any[]): Promise<any> => {
  return http.post(`${TASK_URL}/release/stop/batch`, data);
};

export const getTaskRecordExec = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/execHistory`, data);
};

//任务执行履历 重跑
export const reExecution = (data: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/reRun/${data.id}/${data.type}`, data);
};

//即时触发接口
export const manualRun = (id: string): Promise<any> => {
  return http.post(`${TASK_URL}/release/manualRun/${id}`);
};

//最近一次异常数据
export const getUnusualList = (params: any): Promise<any> => {
  return http.post(`${TASK_URL}/release/exception/data-list`, params);
};

//错误日志
export const getErrorLogs = (logId: any): Promise<any> => {
  return http.get(`${TASK_URL}/release/exception/detail/${logId}`);
};
