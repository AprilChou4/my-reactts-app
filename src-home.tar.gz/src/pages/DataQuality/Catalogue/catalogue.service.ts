import http from '@services/http';
import { QUALITY_URL } from '@config/env';

//获取目录
export function getCatalogue(): Promise<any> {
  return http.get(`${QUALITY_URL}/catalogue/list`);
}

//新增目录
export function addCatalogue(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/catalogue/add`, params);
}

//编辑目录
export function editCatalogue(id: any, params: any): Promise<any> {
  return http.put(`${QUALITY_URL}/catalogue/edit/${id}`, params);
}

//删除目录
export function deleteCatalogue(id: any): Promise<any> {
  return http.delete(`${QUALITY_URL}/catalogue/delete/${id}`);
}

//移动目录
export function moveCatalogue(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/catalogue/move`, params);
}
