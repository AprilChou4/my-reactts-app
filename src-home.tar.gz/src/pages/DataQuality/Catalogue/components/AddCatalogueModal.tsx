import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import DialogModal from '@components/Modal/Dialog';
import CataTreeSelector from '../../CataTreeSelector';
import { ruleNameReg } from '../../consts/regexp';
import styles from '../index.less';

const FormItem = Form.Item;

interface IProps extends FormComponentProps {
  visible: boolean;
  onVisibleChange: any;
  values: any;
  onOk: any;
  loading: boolean;
}
interface IState {}

class AddCatalogueModal extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public handleOK = () => {
    const { form, onOk } = this.props;
    form.validateFields((error: any, formValues: any) => {
      if (error) return;

      onOk(formValues);
    });
  };

  public renderFooter = () => {
    const { onVisibleChange } = this.props;

    return (
      <div className={styles.cataModalFooter}>
        <div className={styles.next} onClick={this.handleOK}>
          确认
        </div>
        <div className={styles.cancel} onClick={() => onVisibleChange(false)}>
          取消
        </div>
      </div>
    );
  };

  public render() {
    const { visible, values, loading, onVisibleChange } = this.props;
    const {
      form: { getFieldDecorator }
    } = this.props;
    const update = !_.isNil(values.id);

    return (
      <DialogModal
        width={480}
        title={update ? '重命名' : '新建目录'}
        visible={visible}
        loading={loading}
        maskClosable={false}
        onCancel={() => onVisibleChange(false)}
        bodyStyle={{ padding: '26px 110px 14px' }}
        wrapClassName={styles.modalContainer}
        footer={this.renderFooter()}
      >
        <Form>
          <FormItem label="目录名称" colon={false}>
            {getFieldDecorator('groupName', {
              initialValue: values.groupName,
              rules: [
                {
                  required: true,
                  pattern: ruleNameReg,
                  message: `仅限中英文、数字和下划线, 长度不超50`
                }
              ]
            })(<Input placeholder="请输入目录名称" autoComplete="off" />)}
          </FormItem>
          {!update && (
            <FormItem label="上级目录" colon={false}>
              {getFieldDecorator('parentId', {
                initialValue: values.parentId
              })(
                <CataTreeSelector disable={false} showRoot={true} level={2} />
              )}
            </FormItem>
          )}
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>()(AddCatalogueModal);
