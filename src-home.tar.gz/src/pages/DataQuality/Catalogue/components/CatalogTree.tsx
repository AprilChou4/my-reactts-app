import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Tree, Empty, Spin, message } from 'sup-ui';
import Icon from '@components/Icon';
import TipsDelete from '@components/Modal/TipsDelete';
import styles from '../index.less';

const { TreeNode, DirectoryTree } = Tree;

interface IProps {
  readOnly: boolean;
  store: any;
}
interface IState {}

@observer
class CatalogTree extends Component<IProps, IState> {
  private containerRef: any;
  //删除节点
  public deleteNode = (e: any, item: any) => {
    e.stopPropagation();

    const config = {
      title: '确认要删除该目录?',
      content: '目录下包含规则时不可被删除',
      onOk: () => {
        this.props.store.deleteNode(item);
      }
    };

    TipsDelete(config);
  };

  //自定义节点title
  public treeTitle = (item: any) => {
    const { editNode } = this.props.store;
    const { readOnly } = this.props;

    return (
      <div className={styles.customerTitle}>
        <div className={styles.edit}>
          <span title={item.name}>{item.name}</span>
        </div>
        {item.editable && !readOnly && (
          <div className="operator">
            <Icon
              onClick={(e: any) => {
                e.stopPropagation();
                editNode(item);
              }}
              type="edit"
              fill="white"
              height={24}
              width={20}
            />
            <Icon
              onClick={(e: any) => {
                this.deleteNode(e, item);
              }}
              type="remove"
              fill="white"
              height={24}
              width={20}
            />
          </div>
        )}
      </div>
    );
  };

  //递归节点树结构
  public loopTreeNode = (data: any) => {
    return data.map((item: any) => {
      if (item.children) {
        return (
          <TreeNode
            key={item.key}
            dataRef={item}
            title={this.treeTitle(item)}
            selectable={item.selectable}
          >
            {this.loopTreeNode(item.children)}
          </TreeNode>
        );
      }

      return (
        <TreeNode
          key={item.key}
          isLeaf={item.isLeaf}
          selectable={item.selectable}
          title={this.treeTitle(item)}
          dataRef={item}
        />
      );
    });
  };

  public handleTreeExpend = (expandedKeys: string[]) => {
    const { updateExpandedKeys } = this.props.store;

    updateExpandedKeys(expandedKeys);
  };

  public componentDidMount(): void {
    this.props.store.bindTreeDirectoryRef(this.containerRef);
  }

  //获取节点的目录层级数量
  private getLevelCount = (tree: any[], level = 1): number => {
    let result = level;

    for (const node of tree) {
      let temp = level;

      if (node.children.length) {
        temp = this.getLevelCount(node.children, level + 1);

        result = Math.max(temp, result);
      }
    }

    return result;
  };

  public handleDrop = (info: any) => {
    const { moveNode } = this.props.store;
    const { dragNode, node, dropToGap, dropPosition } = info;
    const { dataRef: dragDataRef } = dragNode.props;
    const { dataRef: dropDataRef, pos: dropPos } = node.props;
    //pos=1表示在drop节点的上方。pos=-1则在下方
    const pos = dropPosition - Number(_.last(dropPos.split('-')));

    const result: any = {
      nodeId: dragDataRef.id,
      dropId: dropDataRef.id,
      dropIn: !dropToGap,
      inDropTop: pos === -1
    };

    //先获取drag/drop的目录层级
    const dropLevel = dropPos.split('-').length - 1;
    const dragCount = this.getLevelCount([dragDataRef]);
    const pad = dropToGap ? -1 : 0;

    if (dragCount + dropLevel + pad > 3) {
      message.error('最大支持3级目录!');
      return;
    }

    moveNode(result);
  };

  public render() {
    const {
      treeLoading,
      treeData,
      selectedKeys,
      expandedKeys,
      handleTreeNodeSelect
    } = this.props.store;
    const { readOnly } = this.props;

    return (
      <div className={styles.treeContainer}>
        <div
          className={styles.directoryTree}
          ref={ref => (this.containerRef = ref)}
        >
          <Spin spinning={treeLoading}>
            {treeData.length > 0 ? (
              <DirectoryTree
                draggable={!readOnly}
                expandAction={false}
                selectedKeys={selectedKeys}
                expandedKeys={expandedKeys}
                onSelect={handleTreeNodeSelect}
                onExpand={this.handleTreeExpend}
                onDrop={this.handleDrop}
              >
                {this.loopTreeNode(treeData)}
              </DirectoryTree>
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </Spin>
        </div>
      </div>
    );
  }
}

export default CatalogTree;
