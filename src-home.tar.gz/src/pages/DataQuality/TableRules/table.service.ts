import http from '@services/http';
import { QUALITY_URL } from '@config/env';

export function getTableRecord(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/record/table/count`, params);
}

export function getTableRules(params: any, body: any): Promise<any> {
  return http.post(`${QUALITY_URL}/record/table/rules`, body, '', { params });
}

//错误信息
export function getTaskError(id: any): Promise<any> {
  return http.get(`${QUALITY_URL}/task/error/${id}`);
}
