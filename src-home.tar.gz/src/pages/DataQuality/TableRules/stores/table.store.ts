import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getTableRecord, getTableRules, getTaskError } from '../table.service';

class TableStore {
  private readonly info: any;
  @observable public noData = true;
  @observable public ruleNum = 0;
  @observable public abnormalNum = 0;
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams: any = {
    pageIndex: 1,
    pageSize: 20
  };

  public constructor(info: any) {
    this.info = info;

    if (_.isEmpty(info) || _.isNil(info.sourceId)) {
      return;
    }

    this.getCount();
    this.getList();
  }

  @action.bound
  public async getCount() {
    const { sourceId, tableName } = this.info;
    const res = await getTableRecord({
      checkSourceId: sourceId,
      checkTable: tableName,
      checkResult: false
    });

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      this.abnormalNum = res.data.data || 0;
    });
  }

  @action.bound
  public async getList() {
    this.loading = true;

    const { sourceId, tableName } = this.info;
    const res = await getTableRules(this.searchParams, {
      checkSourceId: sourceId,
      checkTable: tableName
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const {
        list,
        pagination: { total }
      } = res.data || {};

      this.list = list || [];
      this.count = total || 0;
      this.ruleNum = total || 0;

      if (this.noData) {
        this.noData = this.list.length === 0;
      }
    });
  }

  //错误信息
  @action.bound
  public async getTaskError(taskId: any, ruleId: any, callback: any) {
    const res = await getTaskError(taskId);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const errors = _.filter(
        res.data.list || [],
        err => err && err.type === 'RULE' && err.id === ruleId
      );

      callback(errors);
    });
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }
}

export default TableStore;
