import React, { Component } from 'react';
import Icon from '@components/Icon';
// import StaffSelector from '../../../StaffSelector';
import OrganizationSelector from '@components/OrganizationSelector';
import styles from './index.less';

interface IProps {
  value?: any;
  onChange?: any;
}

interface IState {
  visible: boolean;
}

class WarnObj extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    this.state = {
      visible: false
    };
  }

  public handleVisibleChange = (visible: boolean) => {
    this.setState({
      visible
    });
  };

  public handleRemove = (e: any, value: any) => {
    e.stopPropagation();

    const { value: list = [], onChange } = this.props;
    const remains = _.filter(list, item => item.value !== value);

    onChange && onChange(remains);
  };

  // public handleOk = ({ persons }: any) => {
  //   const { onChange } = this.props;
  //
  //   console.log(persons);
  //   return;
  //
  //   onChange && onChange(persons);
  // };

  public handleOk = (values: any) => {
    const { onChange } = this.props;
    const persons = _.map(values || [], ({ code, name }) => ({
      value: code,
      label: name
    }));

    onChange && onChange(persons);
  };

  public render() {
    const { value: list = [] } = this.props;
    const { visible } = this.state;
    const pValues = _.map(list, ({ value, label }) => ({
      code: value,
      name: label
    }));

    return (
      <div className={styles.container}>
        <div
          className={styles.cont}
          onClick={() => this.handleVisibleChange(true)}
        >
          <ul>
            {list.map(({ value, label }: any) => (
              <li key={value}>
                <p>{label}</p>
                <Icon
                  type="close"
                  fill="#8b8b8b"
                  width={18}
                  height={18}
                  onClick={e => this.handleRemove(e, value)}
                />
              </li>
            ))}
          </ul>
          {list.length === 0 && <h4>-请选择-</h4>}
        </div>
        {visible && (
          <OrganizationSelector
            selectType="Person"
            multiple={true}
            value={pValues}
            onChange={this.handleOk}
            visible={visible}
            onVisibleChange={this.handleVisibleChange}
          />
          // <StaffSelector
          //   visible={visible}
          //   onVisibleChange={this.handleVisibleChange}
          //   source={list}
          //   onOk={this.handleOk}
          // />
        )}
      </div>
    );
  }
}

export default WarnObj;
