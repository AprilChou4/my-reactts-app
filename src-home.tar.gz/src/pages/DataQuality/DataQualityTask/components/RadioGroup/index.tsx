import React, { Component } from 'react';
import styles from './index.less';

interface IProps {
  source: any[];
  value?: any;
  onChange?: any;
}

interface IState {}

class RadioGroup extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public handleChange = ({ key, disable }: any) => {
    const { onChange } = this.props;
    if (disable) {
      return;
    }

    onChange(key);
  };

  public render() {
    const { value, source } = this.props;

    return (
      <ul className={styles.container}>
        {source.map(item => (
          <li
            key={item.key}
            onClick={() => this.handleChange(item)}
            className={`${value === item.key ? styles.active : ''} ${
              item.disable ? styles.disable : ''
            }`}
          >
            {item.showName}
          </li>
        ))}
      </ul>
    );
  }
}

export default RadioGroup;
