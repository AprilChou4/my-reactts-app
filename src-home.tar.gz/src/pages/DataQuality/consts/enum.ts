interface ListItem {
  key: number | string;
  showName: string;
  desc?: string;
  disable?: boolean;
}

//规则类型
export const ruleTypes: any[] = [
  {
    key: 1,
    showName: '空值检查',
    desc: '检查字段是否为空',
    icon: 'empty',
    disable: false
  },
  {
    key: 2,
    showName: '重复值检查',
    desc: '检查重复数据',
    icon: 'duplicate',
    disable: false
  },
  {
    key: 3,
    showName: '值域检查',
    desc: '检查数值字段取值范围',
    icon: 'range',
    disable: false
  },
  {
    key: 4,
    showName: '数据格式检查',
    desc: '检查字段值的格式是否规范',
    icon: 'format',
    disable: false
  },
  {
    key: 5,
    showName: '枚举值检查',
    desc: '检查字段是否超出枚举值',
    icon: 'enum',
    disable: false
  },
  {
    key: 6,
    showName: '指标波动检查',
    desc: '检查数值字段的波动情况',
    icon: 'indicator',
    disable: true
  }
];

//问题等级
export const questionLevels: ListItem[] = [
  { key: 1, showName: '一般' },
  { key: 2, showName: '重要' },
  { key: 3, showName: '严重' }
];

//左值域区间
export const leftRange: ListItem[] = [
  { key: '1', showName: '[' },
  { key: '2', showName: '(' },
  { key: '3', showName: '(-∞' }
];

//左值域区间
export const rightRange: ListItem[] = [
  { key: '1', showName: ']' },
  { key: '2', showName: ')' },
  { key: '3', showName: '+∞)' }
];

//数据格式
export const dataFormat: any[] = [
  {
    key: '1',
    showName: '身份证',
    reg: '^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$'
  },
  { key: '2', showName: '手机号码', reg: '^1\\d{10}$' },
  { key: '3', showName: '固定电话', reg: '^\\d{3}-\\d{8}|\\d{4}-\\d{7}$' },
  { key: '4', showName: '电子邮箱', reg: '^\\S+@\\S+$' },
  {
    key: '5',
    showName: 'IP地址',
    reg: '^((0{0,2}\\d|0?\\d{2}|1\\d{2}|2[0-4]\\d|25[0-5])\\.){3}(0{0,2}\\d|0?\\d{2}|1\\d{2}|2[0-4]\\d|25[0-5])$'
  },
  { key: '6', showName: '年份', sample: 'YYYY', reg: '^\\d{4}$' },
  {
    key: '7',
    showName: '月份',
    sample: 'YYYY-MM 或 YYYY/MM 或 YYYYMM',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])$'
  },
  {
    key: '8',
    showName: '日期',
    sample: 'YYYY-MM-DD 或 YYYY/MM/DD 或 YYYYMMDD',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])\\1(0[1-9]|[12][0-9]|3[01])$'
  },
  {
    key: '9',
    showName: '时间',
    sample: 'YYYY-MM-DD HH:mm:ss 或 YYYY/MM/DD HH:mm:ss 或 YYYYMMDD HH:mm:ss',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])\\1(0[1-9]|[12][0-9]|3[01]) ([01][0-9]|[2][0-3])(:[0-5][0-9]){2}$'
  },
  { key: '10', showName: '自定义[正则表达式]', reg: '.*' }
];

//执行周期
export const execCycle: ListItem[] = [
  { key: 1, showName: '定时执行' },
  { key: 2, showName: '手动触发' }
];

//调度周期
export const scheduleCycle: ListItem[] = [
  { key: 1, showName: '日' },
  { key: 2, showName: '周', disable: true },
  { key: 3, showName: '月', disable: true }
];

//告警方式
export const warnTypes: any[] = [
  { value: 1, label: '站内信' },
  { value: 2, label: '邮件' },
  // { value: 3, label: '钉钉' },
  { value: 4, label: '微信' }
];

//告警等级
export const warnLevels: ListItem[] = [
  { key: 1, showName: '一般' },
  { key: 2, showName: '重要' },
  { key: 3, showName: '严重' }
];

//数值类型
export const numberTypes = [
  'TINYINT',
  'SMALLINT',
  'INT',
  'BIGINT',
  'BIT',
  'FLOAT',
  'DOUBLE',
  'DECIMAL',
  'NUMERIC',
  'MONEY',
  'SMALLMONEY',
  'REAL',
  'NUMBER',
  'INTEGER',
  'BINARY_FLOAT',
  'BINARY_DOUBLE'
];
