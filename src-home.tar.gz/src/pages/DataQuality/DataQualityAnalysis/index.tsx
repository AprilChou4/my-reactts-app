import React, { Component } from 'react';
import { Col, Row } from 'sup-ui';
import { observer } from 'mobx-react';
import PieChart from './components/PieChart';
import LineChart from './components/LineChart';
import RulesTable from './containers/RulesTable';
import AnalysisStore from './stores/analysis.store';
import styles from './index.less';

interface IProps {}

interface IState {}

@observer
class DataQualityAnalysis extends Component<IProps, IState> {
  private readonly store: AnalysisStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new AnalysisStore();
  }

  public render() {
    const { questionCount, scoreRange, scoreTrend, handleScoreTrendChange } =
      this.store;

    return (
      <div className={styles.container}>
        <div className={styles.header}>质量分析</div>
        <div className={styles.content}>
          <Row gutter={15}>
            <Col span={8}>
              <PieChart data={_.cloneDeep(questionCount)} />
            </Col>
            <Col span={16}>
              <LineChart
                range={scoreRange}
                onRangeChange={handleScoreTrendChange}
                data={_.cloneDeep(scoreTrend)}
              />
            </Col>
          </Row>
          <div className={styles.ruleWrapper}>
            <p className={styles.tit}>数据质量问题TOP10规则</p>
            <RulesTable store={this.store} />
          </div>
        </div>
      </div>
    );
  }
}

export default DataQualityAnalysis;
