import http from '@services/http';
import { METADATA_URL, QUALITY_URL } from '@config/env';

//规则列表
export function getRuleList(params: any, body: any): Promise<any> {
  return http.post(`${QUALITY_URL}/rule/list`, body, '', { params });
}

//移动规则
export function moveRule(params: any): Promise<any> {
  return http.put(`${QUALITY_URL}/rule/move`, params);
}

//复制规则
export function copyRule(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/rule/copy`, params);
}

//删除规则
export function deleteRule(params: any): Promise<any> {
  return http.delete(`${QUALITY_URL}/rule/delete`, params);
}

//获取数据源
export function getSourceList(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/sources`, params);
}

//获取数据源下表
export function getSourceTables(params: any): Promise<any> {
  return http.post(`${METADATA_URL}/mttbl/list`, params);
}

//获取标准集列表
export function getStandardSets(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/rule/sets`, params);
}

//获取标准列表
export function getStandardList(setId: any): Promise<any> {
  return http.get(`${QUALITY_URL}/rule/standard/${setId}`);
}

//获取标准映射字段
export function getStandardMapping(standardId: any): Promise<any> {
  return http.get(`${QUALITY_URL}/rule/standard/mapping/${standardId}`);
}

//批量保存规则
export function saveRule(params: any): Promise<any> {
  return http.post(`${QUALITY_URL}/rule/batchAdd`, params);
}
