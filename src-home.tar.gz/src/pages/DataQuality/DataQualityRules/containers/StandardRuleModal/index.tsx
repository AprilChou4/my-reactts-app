import React, { Component, createRef } from 'react';
import { observer } from 'mobx-react';
import { Empty, message } from 'sup-ui';
import DialogModal from '@components/Modal/Dialog';
import CataTreeSelector from '../../../CataTreeSelector';
import StandardSelector from '../StandardSelector';
import ListTable from './ListTable';
import StandardStore from '../../stores/standard.store';
import styles from './index.less';

interface IProps {
  groupId: any;
  visible: boolean;
  onVisibleChange: any;
}

interface IState {}

@observer
class StandardRuleModal extends Component<IProps, IState> {
  private readonly listRef: any;
  private readonly store: StandardStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new StandardStore(props.groupId);
    this.listRef = createRef();
  }

  public handleSubmit = () => {
    const { handleSubmit, catalogueId } = this.store;

    if (_.isNil(catalogueId)) {
      message.error('请选择分类目录!');
      return;
    }

    if (!this.listRef.current) {
      return;
    }

    const params = this.listRef.current.validateDatas();

    if (!params) {
      return;
    }

    handleSubmit(params, () => {
      this.props.onVisibleChange(false, true);
    });
  };

  public renderFooter = () => {
    const { onVisibleChange } = this.props;

    return (
      <div className={styles.modalFooter}>
        <div className={styles.next} onClick={this.handleSubmit}>
          保存
        </div>
        <div className={styles.cancel} onClick={() => onVisibleChange(false)}>
          取消
        </div>
      </div>
    );
  };

  public render() {
    const { visible, onVisibleChange } = this.props;
    const {
      catalogueId,
      dataSource,
      rules,
      loading,
      submitting,
      handleCatalogueChange,
      handleStandardChange
    } = this.store;

    return (
      <DialogModal
        width={1380}
        title="基于数据标准配置"
        visible={visible}
        loading={submitting}
        onCancel={() => onVisibleChange(false)}
        bodyStyle={{ padding: '0px' }}
        wrapClassName={styles.modalContainer}
        footer={this.renderFooter()}
      >
        <div className={styles.container}>
          <div className={styles.sider}>
            <div className={styles.cata}>
              <label>分类目录</label>
              <CataTreeSelector
                value={catalogueId}
                onChange={handleCatalogueChange}
                disable={false}
              />
            </div>
            <StandardSelector onChange={handleStandardChange} />
            <div className={styles.rules}>
              <h3>规则类型</h3>
              {rules.length ? (
                <ul>
                  {rules.map(item => (
                    <li key={item.type}>
                      <div className={styles.tit}>
                        <span className={styles[item.icon]} />
                        <p>{item.showName}检查</p>
                      </div>
                      {item.type !== 1 && (
                        <div className={styles.cont}>
                          <span>{item.showName}：</span>
                          <p>{item.value}</p>
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </div>
          </div>
          <div className={styles.content}>
            <ListTable
              ref={this.listRef}
              dataSource={dataSource}
              loading={loading}
            />
          </div>
        </div>
      </DialogModal>
    );
  }
}

export default StandardRuleModal;
