import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { TreeSelect } from 'sup-ui';

interface IProps {
  onLoad: any;
  value: any; //{ code, name }
  onChange: any;
}

interface IState {
  list: any[];
}

@observer
class CompanySelector extends Component<IProps, IState> {
  private readonly nameMap: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      list: []
    };
    this.nameMap = {};
  }

  public handleChange = ({ value }: any) => {
    if (this.props.value) {
      const { code } = this.props.value;

      if (code === value) {
        return;
      }
    }

    this.props.onChange({
      code: value,
      name: this.nameMap[value]
    });
  };

  private recurseTree(childs: any[], pKey?: any, pName?: any) {
    const result: any[] = [];

    childs = _.sortBy(childs, ['sort']);

    childs.forEach((node: any) => {
      const children = node.children || [];
      const key = _.isNil(pKey) ? node.id.toString() : `${pKey}_${node.id}`;
      const showName = _.isNil(pName) ? node.name : `${pName} / ${node.name}`;

      const tree: any = {
        key,
        id: node.id,
        value: node.id.toString(),
        title: node.name,
        isLeaf: children.length === 0,
        selectable: true,
        children: []
      };

      this.nameMap[node.id] = showName;

      if (children.length > 0) {
        tree.children = this.recurseTree(children, key, showName);
      }

      result.push(tree);
    });

    return result;
  }

  private fetchList = () => {
    const { onLoad, onChange } = this.props;
    onLoad().then((res: any) => {
      const list = this.recurseTree(res.data.list || []);

      this.setState({
        list
      });

      //默认选中第一个
      if (list.length) {
        const { id } = _.head(list);
        onChange({
          code: id,
          name: this.nameMap[id]
        });
      }
    });
  };

  public componentDidMount() {
    this.fetchList();
  }

  public render() {
    const { value } = this.props;
    const { list } = this.state;
    const sValue: any = value
      ? { value: value.code, label: value.name }
      : undefined;

    return (
      <TreeSelect
        labelInValue
        style={{ width: '100%' }}
        value={sValue}
        dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
        getPopupContainer={triggerNode =>
          triggerNode.parentElement as HTMLElement
        }
        placeholder="-请选择-"
        onChange={this.handleChange}
        treeData={list}
      />
    );
  }
}

export default CompanySelector;
