import http from '@services/http';
import { QUALITY_URL } from '@config/env';

//获取公司列表
export function getCompanyList(): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/company`);
}

//获取部门列表
export function getDepartList(params: any): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/department`, params);
}

//获取岗位列表
export function getJobList(params: any): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/job`, params);
}

//获取公司人员列表
export function getCompPerson(params: any): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/company/person`, params);
}

//获取部门人员列表
export function getDepartPerson(params: any): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/department/person`, params);
}

//获取岗位人员列表
export function getJobPerson(params: any): Promise<any> {
  return http.get(`${QUALITY_URL}/staff/job/person`, params);
}
