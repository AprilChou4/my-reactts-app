import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Table } from 'sup-ui';
import { TableCellText } from '@components/Table';
import PersonStore from '../stores/person.store';
import styles from '../index.less';

interface IProps {
  info: any;
  keys: any;
  updateRowKeys: any;
  chosenList: any; //已选列表
}
interface IState {}

@observer
class PersonTable extends Component<IProps, IState> {
  private readonly store: PersonStore;
  public constructor(props: IProps) {
    super(props);

    this.store = new PersonStore();
  }

  public handleTableChange = (pagination: any) => {
    //页码
    const { current, pageSize } = pagination;

    this.store.updateSearchParams({
      pageIndex: current,
      pageSize
    });
  };

  public getColumns = () => {
    return [
      {
        title: '姓名',
        dataIndex: 'name',
        width: 80,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '岗位',
        dataIndex: 'positionName',
        width: 'auto',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      }
    ];
  };

  public renderTitle = () => {
    const { info = {} } = this.props;
    const { name = '' } = info;

    return `${name}人员列表`;
  };

  public componentDidUpdate(prevProps: Readonly<IProps>) {
    if (!_.isEqual(this.props.info, prevProps.info)) {
      this.store.updateTableInfo(this.props.info);
    }
  }

  public render() {
    const { loading, list, searchParams, count } = this.store;
    const { keys, updateRowKeys, chosenList } = this.props;
    const columns = this.getColumns();
    const chosenKeys = _.map(chosenList, 'value');
    const rowSelection = {
      columnWidth: 40,
      selectedRowKeys: keys,
      onChange: updateRowKeys,
      hideDefaultSelections: true,
      getCheckboxProps: (record: any): any => ({
        disabled: _.includes(chosenKeys, record.code)
      })
    };

    return (
      <div className={styles.personTable}>
        <h3>{this.renderTitle()}</h3>
        <div className={`${styles.table} mp-table-grow`}>
          <Table
            size="small"
            loading={loading}
            columns={columns}
            dataSource={list}
            rowSelection={rowSelection}
            onChange={this.handleTableChange}
            rowKey="code"
            pagination={{
              current: searchParams.pageIndex,
              pageSize: searchParams.pageSize,
              total: count,
              showTotal: total => `共${total}条`,
              showSizeChanger: false,
              showQuickJumper: false
            }}
            scroll={{
              y: 'calc(100% - 32px)'
            }}
          />
        </div>
      </div>
    );
  }
}

export default PersonTable;
