import React, { Component } from 'react';
import { TreeSelect } from 'sup-ui';
import { getCatalogue } from './catatree.service';

interface IProps {
  value?: any; //groupId
  onChange?: any;
  level?: number; //显示几层目录（1，2，3）, 默认100
  showRoot?: boolean; //显示根目录，默认false
  disable: boolean;
}

interface IState {
  list: any[];
}

class CataTreeSelector extends Component<IProps, IState> {
  private readonly nameMap: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      list: []
    };
    this.nameMap = {};
  }

  public handleChange = ({ value }: any) => {
    this.props.onChange(value);
  };

  private recurseTree(childs: any[], pKey?: any, pName?: any) {
    const { level = 100 } = this.props;
    const result: any[] = [];

    childs.forEach((node: any) => {
      const children = node.children;
      const key = _.isNil(pKey)
        ? node.groupId.toString()
        : `${pKey}_${node.groupId}`;
      const lev = key.split('_').length;
      const showName = _.isNil(pName)
        ? node.groupName
        : `${pName} / ${node.groupName}`;

      const tree: any = {
        key,
        id: +node.groupId,
        value: node.groupId.toString(),
        title: node.groupName,
        isLeaf: children.length === 0 || lev === level,
        selectable: true,
        children: []
      };

      this.nameMap[node.groupId] = showName;

      if (children.length > 0 && lev < level) {
        tree.children = this.recurseTree(children, key, showName);
      }

      result.push(tree);
    });

    return result;
  }

  private fetchCataList = () => {
    const { showRoot = false } = this.props;
    getCatalogue().then((res: any) => {
      const list = this.recurseTree(res.data.list || []);

      if (showRoot) {
        list.unshift({
          key: '-1',
          id: -1,
          value: '-1',
          title: '根目录',
          isLeaf: true,
          selectable: true,
          children: []
        });

        this.nameMap['-1'] = '根目录';
      }

      this.setState({
        list
      });
    });
  };

  public componentDidMount() {
    this.fetchCataList();
  }

  public render() {
    const { value, disable } = this.props;
    const { list } = this.state;
    const label = value ? this.nameMap[value] : '';
    const sValue: any = value ? { label, value } : undefined;

    return (
      <TreeSelect
        labelInValue
        style={{ width: '100%' }}
        value={sValue}
        disabled={disable}
        dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
        getPopupContainer={triggerNode =>
          triggerNode.parentElement as HTMLElement
        }
        placeholder="-请选择-"
        onChange={this.handleChange}
        treeData={list}
      />
    );
  }
}

export default CataTreeSelector;
