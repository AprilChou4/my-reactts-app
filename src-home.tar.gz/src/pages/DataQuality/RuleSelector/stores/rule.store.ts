import { observable, action, runInAction } from 'mobx';
import { message } from 'sup-ui';
import { getRuleList } from '../rule.service';

class RuleStore {
  private readonly debounceGetList: any;
  private readonly initParams = {
    keyword: '',
    ruleType: [],
    level: [],
    order: {
      key: 'createTime',
      orderType: 'DESC'
    },
    pageIndex: 1,
    pageSize: 20
  };
  @observable public selectedRows: any[] = []; //选中的行
  @observable public selectedRowKeys: any[] = [];
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams: any = {};
  @observable public selectedCatalogue: any = {}; //当前选中目录

  @observable public moveModalVisible = false; //移动弹窗
  @observable public ruleTypeModalVisible = false; //规则类型弹窗
  @observable public ruleModalVisible = false; //规则详情弹窗

  @observable public selectedRule = {
    id: null,
    type: 1,
    groupId: undefined
  }; //当前操作的rule

  public constructor() {
    runInAction(() => {
      this.searchParams = { ...this.initParams };
    });

    this.debounceGetList = _.debounce(this.getList, 600);
  }

  @action.bound
  public updateSelectedRowKeys(
    selectedKeys: string[] | number[],
    selectedRows: any[]
  ) {
    this.selectedRowKeys = selectedKeys;
    this.selectedRows = selectedRows;
  }

  @action.bound
  public handleCatalogueChange(catalog: any) {
    this.selectedCatalogue = catalog;
    this.updateSearchParams({}, true);
  }

  @action.bound
  public async getList() {
    const { id } = this.selectedCatalogue;

    if (_.isNil(id)) {
      return;
    }

    this.loading = true;

    const { keyword, ruleType, level, order, pageIndex, pageSize } =
      this.searchParams;
    const params: any = {
      groupId: id,
      createTimeAscOrder: order.orderType === 'ASC'
    };

    if (keyword) {
      params.keyword = keyword;
    }

    if (ruleType.length) {
      params.ruleType = ruleType;
    }

    if (level.length) {
      params.level = level;
    }

    const res = await getRuleList(
      {
        pageIndex,
        pageSize
      },
      params
    );

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const {
        pagination: { total },
        list
      } = res.data || {};

      this.list = list || [];
      this.count = total;
    });
  }

  @action.bound
  public updateKeyword = (value: string) => {
    if (this.loading) {
      return;
    }

    this.searchParams = { ...this.searchParams, keyword: value, pageIndex: 1 };
    this.debounceGetList();
  };

  @action.bound
  public updateSearchParams(params: any, reset?: boolean) {
    const baseParams = reset ? this.initParams : this.searchParams;
    this.searchParams = { ...baseParams, ...params };
    this.getList();
  }
}

export default RuleStore;
