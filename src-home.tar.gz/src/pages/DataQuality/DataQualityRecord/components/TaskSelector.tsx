import React, { Component } from 'react';
import { Select, Spin, message } from 'sup-ui';
import styles from '../index.less';

const { Option } = Select;

interface IProps {
  loadData: any;
  value: any;
  onChange: any;
}
interface IState {
  keyword: string;
  pageIndex: any;
  pageSize: any;
  list: any[];
  fetching: boolean;
  loading: boolean;
  disableFetch: boolean;
}
class TaskSelector extends Component<IProps, IState> {
  private readonly handleSearch: any;
  public constructor(props: Readonly<IProps>) {
    super(props);
    this.state = {
      keyword: '',
      pageIndex: 1,
      pageSize: 20,
      list: [],
      fetching: false,
      loading: false,
      disableFetch: false
    };
    this.handleSearch = _.debounce(this.handleSelectSearch.bind(this), 500);
  }

  public async fetchData() {
    const { loadData } = this.props;
    const { disableFetch, pageIndex, pageSize } = this.state;

    if (disableFetch) {
      return;
    }

    this.setState({
      loading: true
    });

    const { keyword } = this.state;
    const params: any = {};

    if (keyword) {
      params.keyword = keyword;
    }

    const res = await loadData(
      {
        pageIndex,
        pageSize
      },
      params
    );

    if (res.code !== 200) {
      message.error(`${res.message}`);
      this.setState({
        fetching: false,
        loading: false
      });
      return;
    }

    const { list = [] } = res.data || {};

    if (list.length < pageSize) {
      this.setState({
        disableFetch: true
      });
    }

    this.setState(prevState => ({
      list: prevState.list.concat(list),
      fetching: false,
      loading: false
    }));
  }

  public handleSelectSearch(keyword: string) {
    this.setState(
      { keyword, fetching: true, list: [], pageIndex: 1, disableFetch: false },
      () => {
        this.fetchData();
      }
    );
  }

  public handleSelectChange = (value: any) => {
    const { onChange } = this.props;

    if (onChange) {
      onChange(value);
    }
  };

  public handleSelectScroll = (e: any) => {
    const { list, loading } = this.state;

    if (list.length === 0 || loading) {
      return;
    }

    const {
      target: { scrollTop, scrollHeight, offsetHeight }
    } = e;

    if (scrollTop + offsetHeight + 2 >= scrollHeight) {
      this.setState(
        prevState => ({
          pageIndex: prevState.pageIndex + 1
        }),
        () => {
          this.fetchData();
        }
      );
    }
  };

  public handleSelectFocus = () => {
    const { list, disableFetch } = this.state;

    if (list.length === 0 && !disableFetch) {
      this.setState({
        fetching: true
      });
      this.fetchData();
    }
  };

  public handleSelectBlur = () => {
    if (this.state.keyword) {
      this.setState({
        list: [],
        keyword: '',
        pageIndex: 1,
        disableFetch: false
      });
    }
  };

  public render() {
    const { value } = this.props;
    const { list, fetching, loading } = this.state;

    return (
      <div className={styles.selector}>
        <Select
          labelInValue
          showSearch
          allowClear={true}
          loading={loading}
          defaultActiveFirstOption={false}
          value={value}
          getPopupContainer={triggerNode =>
            triggerNode.parentElement as HTMLElement
          }
          placeholder="-请选择-"
          notFoundContent={fetching ? <Spin size="small" /> : '暂无数据'}
          filterOption={false}
          onSearch={this.handleSearch}
          onChange={this.handleSelectChange}
          onPopupScroll={this.handleSelectScroll}
          onFocus={this.handleSelectFocus}
          onBlur={this.handleSelectBlur}
        >
          {list.map(item => (
            <Option key={item.id} value={item.id}>
              {item.schemeName}
            </Option>
          ))}
        </Select>
      </div>
    );
  }
}

export default TaskSelector;
