import { observable, action, runInAction, computed } from 'mobx';
import { message } from 'sup-ui';
import { getRecordDetail, getTaskError } from '../record.service';

class DetailStore {
  private readonly record: any;
  @observable public ruleNum = 0;
  @observable public abnormalNum = 0;
  @observable public score = 0;
  @observable public list: any[] = [];
  @observable public count = 0;
  @observable public loading = false;
  @observable public searchParams: any = {
    ruleName: '',
    checkResult: []
  };
  @observable public selectedRule: any = {};
  @observable public ruleVisible = false; //记录详情drawer

  public constructor(record: any) {
    this.record = record;
    this.getList();
  }

  @action.bound
  public async getList() {
    this.loading = true;

    const { schemeId, scheduleTime } = this.record;
    const res = await getRecordDetail({
      scheduleId: schemeId,
      scheduleTime
    });

    runInAction(() => {
      this.loading = false;

      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const {
        ruleNum = 0,
        abnormalNum = 0,
        score = 0,
        ruleDatas
      } = res.data || {};

      this.ruleNum = ruleNum;
      this.abnormalNum = abnormalNum;
      this.score = score;
      this.list = ruleDatas || [];
      // this.count = total;
    });
  }

  //错误信息
  @action.bound
  public async getTaskError(taskId: any, ruleId: any, callback: any) {
    const res = await getTaskError(taskId);

    runInAction(() => {
      if (res.code !== 200) {
        message.error(res.message);
        return;
      }

      const errors = _.filter(
        res.data.list || [],
        err => err && err.type === 'RULE' && err.id === ruleId
      );

      callback(errors);
    });
  }

  @computed
  public get filterList() {
    const { ruleName, checkResult } = this.searchParams;
    let result = this.list;

    if (ruleName) {
      result = _.filter(result, data => _.includes(data.ruleName, ruleName));
    }

    if (checkResult.length) {
      result = _.filter(result, data =>
        _.includes(checkResult, data.checkResult)
      );
    }

    return result;
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
  }

  @action.bound
  public checkRuleDetail(record: any) {
    this.selectedRule = record;
    this.ruleVisible = true;
  }

  @action.bound
  public handleVisibleChange(visible: boolean) {
    this.ruleVisible = visible;
  }
}

export default DetailStore;
