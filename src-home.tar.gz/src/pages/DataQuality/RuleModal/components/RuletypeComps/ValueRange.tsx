import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';
import CataTreeSelector from '../../../CataTreeSelector';
import FieldsSelector from '../FieldsSelector';
import RangeSelector from '../RangeSelector';
import QuestionLevel from '../QuestionLevel';
import { formLayout } from '../../../consts/utils';
import { ruleNameReg } from '../../../consts/regexp';
import styles from './index.less';

const TextArea = Input.TextArea;
const FormItem = Form.Item;

interface IProps {
  form: any;
  values?: any;
  disable: boolean;
}

interface IState {}

class ValueRange extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator },
      values,
      disable
    } = this.props;

    return (
      <div className={styles.container}>
        <Form {...formLayout} colon={false} className={styles.rangeContainer}>
          <FormItem label="名称" required>
            {getFieldDecorator('ruleName', {
              initialValue: values.ruleName,
              rules: [
                {
                  required: true,
                  pattern: ruleNameReg,
                  message: `仅限中英文、数字和下划线，长度不超过50!`
                }
              ]
            })(
              <Input
                disabled={disable}
                placeholder="仅限中英文、数字和下划线，长度不超过50"
              />
            )}
          </FormItem>
          <FormItem label="分类目录">
            {getFieldDecorator('groupId', {
              initialValue: values.groupId,
              rules: [{ required: true, message: `请选择分类目录` }]
            })(<CataTreeSelector disable={disable} />)}
          </FormItem>
          <FormItem label="" wrapperCol={{ span: 24 }} required>
            {getFieldDecorator('fields', {
              initialValue: values.fields
            })(<FieldsSelector disable={disable} />)}
          </FormItem>
          <p className={styles.reminder}>只支持数值类型字段</p>
          <FormItem label="值域" required>
            {getFieldDecorator('range', {
              initialValue: values.range || []
            })(<RangeSelector disable={disable} />)}
          </FormItem>
          <FormItem label="描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: `描述长度不能超过255!` }]
            })(
              <TextArea
                disabled={disable}
                placeholder="长度不超过255"
                autosize={{ minRows: 3, maxRows: 6 }}
              />
            )}
          </FormItem>
          <FormItem label="问题等级">
            {getFieldDecorator('level', {
              initialValue: values.level || 1
            })(<QuestionLevel disabled={disable} />)}
          </FormItem>
        </Form>
      </div>
    );
  }
}

export default ValueRange;
