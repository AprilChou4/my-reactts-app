import React, { Component, Fragment } from 'react';

import { databaseList } from '@consts/dataSource';

import styles from './DataSourceList.less';

interface IDataSourceListProps {
  dataSourceType?: string;
  showDataSourceForm: any;
  activeNav: string;
}

class DataSourceList extends Component<IDataSourceListProps> {
  public constructor(props: IDataSourceListProps) {
    super(props);
  }

  /**
   * @description: 添加数据源,展示数据源表单
   * @param {string} dataSourceType 数据源类型 MySQL/posetgressSQL/...
   */
  private addDataSource = (
    dataSourceType: string,
    isDisable: boolean
  ): void => {
    if (isDisable) return;
    this.props.showDataSourceForm(dataSourceType);
  };

  public hideModal = () => {
    this.setState({
      visible: false
    });
  };

  public filterDataBaseList = (activeNav: string) => {
    if (!activeNav) {
      return databaseList;
    } else {
      const data = _.filter(
        databaseList,
        (item: any) => item.restype === activeNav
      );
      return data;
    }
  };
  public render() {
    const { activeNav } = this.props;

    const wrapperStyle = !activeNav ? styles.borderWrapper : null;

    return (
      <Fragment>
        {_.map(this.filterDataBaseList(activeNav), item => {
          return (
            <div
              key={item.key}
              className={`${styles.unitWrapper} ${wrapperStyle}`}
            >
              <h4 className={styles.title}>{item.name}</h4>
              <ul className={styles.listWrapper}>
                {_.map(item.children, (itm: any, index: number) => {
                  const { name, isDisable, key } = itm;
                  return (
                    <li
                      key={name}
                      className={`${styles.listItem} ${
                        (index + 1) % 5 === 0 ? styles.noMarginRight : ''
                      }`}
                    >
                      <div
                        className={`${styles.iconWrapper} ${styles[key]} ${
                          isDisable ? styles.isDisable : ''
                        }`}
                        onClick={this.addDataSource.bind(this, name, isDisable)}
                      >
                        <div className={styles.iconHover} />
                      </div>
                      <div className={styles.basename}>{name}</div>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </Fragment>
    );
  }
}
export default DataSourceList;
