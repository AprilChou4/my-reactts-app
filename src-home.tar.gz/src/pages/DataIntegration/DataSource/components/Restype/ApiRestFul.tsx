import React, { Component, Fragment } from 'react';
import { Form, Switch, Select } from 'sup-ui';

import {
  BodyParams,
  RestOutParams,
  RequestParams,
  DataSourceName,
  DataSourceDescript,
  DataSourceApi,
  UserInformation,
  DataInputNum
} from '@components/DataSource';

import styles from '../DataSourceForm.less';
import uuid from '@utils/uuid';

const FormItem = Form.Item;
const { Option } = Select;
const methodList = ['GET', 'POST', 'PUT', 'DELETE'];
const charsetList = ['UTF-8', 'UTF-16', 'GB2312'];

interface IProps {
  itemForm: any;
  connectRes: any;
  setFieldsValue: any;
  connectRestfulData: any;
  getFieldDecorator: any;
}
interface IState {}

class ApiRestFul extends Component<IProps, IState> {
  public inParamsRef: any;
  public outParamsRef: any;
  public headerRef: any;

  public state = {
    authType: 0,
    apiFields: [],
    method: 'POST'
  };

  public componentDidMount() {
    const { itemForm } = this.props;
    if (!_.isEmpty(itemForm)) {
      const {
        spec: { union }
      } = itemForm;
      const { authType, method } = union;

      this.setState({
        method,
        authType
      });
    }
  }

  public getApiSourceData = () => {
    const headerParams = this.headerRef.getParams();
    const inParams = this.inParamsRef.getInParams();
    const outParams = this.outParamsRef.getOutParams();
    const resultJson = this.props.connectRestfulData;
    return {
      ...inParams,
      ...outParams,
      header: headerParams,
      resultJson: { ...resultJson }
    };
  };

  public handleAuthType = (check: boolean) => {
    this.setState({
      authType: check ? 1 : 0
    });
  };

  public getApiFields = (value: any) => {
    const reg = /[#]\{\w+\}/g;
    const filterReg = /\w+/;
    const filterFields = value.match(reg);
    const bodyFields = _.map(filterFields, (item: any) => ({
      paramsName: item.match(filterReg)[0],
      paramsDataType: 'String',
      key: uuid(6),
      edit: false
    }));

    this.setState({
      apiFields: bodyFields
    });
  };

  public handleChangeMethod = (method: string) => {
    this.setState({
      method
    });
  };

  public render() {
    const { authType, apiFields, method } = this.state;
    const {
      itemForm,
      itemForm: { spec = {} },
      connectRes,
      setFieldsValue,
      getFieldDecorator,
      connectRestfulData
    } = this.props;
    const union = _.get(spec, 'union', {});

    return (
      <Fragment>
        <Form
          className={connectRes ? styles.formWrapper : ''}
          style={{ maxHeight: '70vh', overflow: 'auto' }}
        >
          <DataSourceName
            getFieldDecorator={getFieldDecorator}
            defaultValue={itemForm.name}
          />
          <DataSourceDescript
            getFieldDecorator={getFieldDecorator}
            defaultValue={itemForm.description}
          />
          <DataSourceApi
            label="地址"
            type="ip"
            getApiFields={this.getApiFields}
            defaultValue={itemForm.url}
            getFieldDecorator={getFieldDecorator}
          />
          <FormItem label="http方法">
            {getFieldDecorator('method', {
              initialValue: _.get(union, 'method', 'POST')
            })(
              <Select onChange={this.handleChangeMethod}>
                {_.map(methodList, (item: any) => (
                  <Option key={item} value={item}>
                    {item}
                  </Option>
                ))}
              </Select>
            )}
          </FormItem>
          <FormItem label="响应字符编码">
            {getFieldDecorator('charset', {
              initialValue: _.get(union, 'charset', 'UTF-8')
            })(
              <Select>
                {_.map(charsetList, (item: any) => (
                  <Option key={item} value={item}>
                    {item}
                  </Option>
                ))}
              </Select>
            )}
          </FormItem>
          <DataInputNum
            min={0}
            formKey="maxTransferNum"
            label="单次最大允许数据量"
            defaultValue={_.get(union, 'maxTransferNum', 2000)}
            getFieldDecorator={getFieldDecorator}
          />
          <FormItem label="http授权">
            {getFieldDecorator('authType', {
              valuePropName: 'checked',
              initialValue: !!authType
            })(<Switch onChange={this.handleAuthType} />)}
          </FormItem>
          {authType ? (
            <UserInformation
              getFieldDecorator={getFieldDecorator}
              defaultValue={{
                username: _.get(union, 'username', ''),
                password: _.get(union, 'password', '')
              }}
            />
          ) : null}
          <div className={styles.headersParams}>
            <div className={styles.title}>Headers参数</div>
            <RequestParams
              wrappedComponentRef={(ref: any) => {
                this.headerRef = ref;
              }}
              dataSource={_.get(union, 'header', [])}
            />
          </div>
          <BodyParams
            union={union}
            method={method}
            apiFields={apiFields}
            setFieldsValue={setFieldsValue}
            getFieldDecorator={getFieldDecorator}
            ref={(ref: any) => {
              this.inParamsRef = ref;
            }}
          />
          <RestOutParams
            union={union}
            connectRestfulData={connectRestfulData}
            getFieldDecorator={getFieldDecorator}
            ref={(ref: any) => {
              this.outParamsRef = ref;
            }}
          />
        </Form>
      </Fragment>
    );
  }
}

export default ApiRestFul;
