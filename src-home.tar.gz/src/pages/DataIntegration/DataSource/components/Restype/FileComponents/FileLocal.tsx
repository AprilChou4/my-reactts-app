import React, { Component, Fragment } from 'react';
import {
  FileType,
  WindowsPath,
  DataSourcePath,
  DataSourceName,
  DataSourceDescript
} from '@components/DataSource';

const isWin = process.env.SYSTEM === 'WIN';

interface IProps {
  url: string;
  name: string;
  fileType: string;
  description: string;
  getFieldDecorator: any;
}

interface IState {}

class FileLocal extends Component<IProps, IState> {
  public render() {
    const { name, description, fileType, url, getFieldDecorator } = this.props;

    return (
      <Fragment>
        <DataSourceName
          getFieldDecorator={getFieldDecorator}
          defaultValue={name}
        />
        <DataSourceDescript
          getFieldDecorator={getFieldDecorator}
          defaultValue={description}
        />
        <FileType
          getFieldDecorator={getFieldDecorator}
          defaultValue={fileType}
        />
        {/*  此组件为, 没有设置校验规则前  */}
        {/* <FormItem label="文件目录相对路径">
          {getFieldDecorator('url', {
            initialValue: url.replace('/volumes/supfiles/', ''),
            rules: [
              {
                required: true,
                whitespace: true,
                message: `请输入正确的文件路径`
              }
            ]
          })(<Input addonBefore="/volumes/supfiles/" />)}
        </FormItem> */}
        {/*  设置校验规则后的组件,  与FileHDFS.tsx, ApiService.tsx  共用同一组件  */}
        {isWin ? (
          <WindowsPath
            defaultValue={url}
            getFieldDecorator={getFieldDecorator}
          />
        ) : (
          <DataSourcePath
            label="文件目录相对路径"
            addonBefore={'/volumes/supfiles/'}
            getFieldDecorator={getFieldDecorator}
            defaultValue={url.replace('/volumes/supfiles/', '')}
          />
        )}
      </Fragment>
    );
  }
}

export default FileLocal;
