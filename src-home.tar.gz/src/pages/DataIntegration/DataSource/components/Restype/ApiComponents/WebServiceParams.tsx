import React, { Component, createContext } from 'react';
import { Select, Switch, Table, Input, message, Form } from 'sup-ui';
import { DelBtn } from '@components/Button';
import Icon from '@components/Icon';
import { TableCellText } from '@components/Table';
import { webServiceType } from '@consts/dataTypes';
import styles from '../../DataSourceForm.less';

const { Option } = Select;

const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      if (!values[dataIndex]) {
        message.error('参数不能为空!');
        return;
      }

      //TODO: 根据数据类型校验
      // if (!attrNameReg.test(values[dataIndex])) {
      //   message.error(
      //     '字段名称只能由字母、数字、下划线、中文组成，且不能以数字开头!'
      //   );
      //   return;
      // }

      handleSave({ ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={styles['editable-cell-value-wrap']}
        onClick={() => {
          this.toggleEdit();
        }}
      >
        {record[dataIndex] ? (
          <TableCellText text={record[dataIndex]} />
        ) : (
          <span style={{ color: 'rgba(53, 64, 82, 0.5)', fontSize: '14px' }}>
            请输入
          </span>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  title: string;
  open: boolean;
  dataSource: any[];
}
interface IState {
  checked: boolean;
  list: any[];
  prevList: any[];
  selectedRowKeys: any[];
}

class WebServiceParams extends Component<IProps, IState> {
  public i = 0;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      checked: false,
      list: [],
      prevList: [],
      selectedRowKeys: []
    };
    //初始化table key
    this.i = props.dataSource.length;
  }

  public static getDerivedStateFromProps(
    nextProps: Readonly<IProps>,
    state: IState
  ) {
    if (!_.isEqual(nextProps.dataSource, state.prevList)) {
      const { dataSource, open } = nextProps;
      const temp = _.map(dataSource, (item: any, i: number) => ({
        key: i,
        ...item
      }));

      return {
        checked: open,
        list: temp,
        prevList: _.cloneDeep(dataSource),
        selectedRowKeys: []
      };
    }

    return null;
  }

  public getColumns = (): any[] => {
    return [
      {
        title: '参数',
        width: 'auto',
        dataIndex: 'param',
        editable: true
      },
      {
        title: '数据类型',
        width: 150,
        dataIndex: 'dataType',
        render: (value: any, record: any): any => {
          return (
            <Select
              value={value}
              placeholder="-请选择-"
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'dataType', val)
              }
            >
              {webServiceType.map((option: any) => (
                <Option value={option} key={option}>
                  {option}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '是否为必填项',
        width: 150,
        dataIndex: 'required',
        render: (value: any, record: any): any => {
          return (
            <Select
              value={value}
              placeholder="-请选择-"
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'required', val)
              }
            >
              <Option value={1} key={'1'}>
                是
              </Option>
              <Option value={0} key={'0'}>
                否
              </Option>
            </Select>
          );
        }
      },
      {
        title: '操作',
        width: 60,
        align: 'center',
        render: (_value: any, record: any) => (
          <div style={{ height: '30px', padding: '5px 0' }}>
            <Icon
              type="remove"
              width={22}
              onClick={() => this.handleRemoveItems([record.key])}
            />
          </div>
        )
      }
    ];
  };

  public handleSwitchChange = (checked: boolean) => {
    this.setState({
      checked
    });
  };

  public handleAddItem = () => {
    const { list } = this.state;
    const item = {
      key: this.i++,
      param: undefined,
      dataType: webServiceType[0],
      required: 0
    };

    this.setState({
      list: list.concat([item])
    });
  };

  public handleCellSave = (row: any) => {
    const { key, param } = row;
    this.handleValueChange(key, 'param', param);
  };

  public handleValueChange = (key: number, name: string, value: any): void => {
    const { list } = this.state;
    const temp = _.cloneDeep(list);
    const target = _.find(temp, ['key', key]);

    target[name] = value;

    this.setState({
      list: temp
    });
  };

  public handleBatchDeleteItems = () => {
    const { selectedRowKeys } = this.state;

    if (selectedRowKeys.length === 0) {
      message.warning('请选择要移除的参数!');
    } else {
      this.handleRemoveItems(selectedRowKeys);
    }
  };

  public handleRemoveItems = (keys: any) => {
    const { selectedRowKeys, list } = this.state;
    const remainKeys = _.filter(selectedRowKeys, key => !_.includes(keys, key));
    const remainList = _.filter(list, item => !_.includes(keys, item.key));

    this.setState({
      list: remainList,
      selectedRowKeys: remainKeys
    });
  };

  public updateSelectedRowKeys = (selectedKeys: string[] | number[]) => {
    this.setState({
      selectedRowKeys: selectedKeys
    });
  };

  public validateDatas = () => {
    //校验，拼装数据
    const { title } = this.props;
    const { list, checked } = this.state;
    let params: any[] = [];

    if (checked) {
      if (list.length === 0) {
        message.error(`${title}参数列表不能为空!`);
        return;
      }

      const hasError = _.find(list, data => !data.param);

      if (hasError) {
        message.error(`${title}参数不能为空!`);
        return;
      }

      params = _.map(list, data => ({
        param: data.param,
        dataType: data.dataType,
        required: data.required
      }));
    }

    return {
      open: checked,
      params
    };
  };

  public render() {
    const { title } = this.props;
    const { checked, list, selectedRowKeys } = this.state;
    const rowSelection = {
      columnWidth: 40,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true
    };
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });

    return (
      <div className={styles.webServiceParams}>
        <div className={styles.switch}>
          <h4>{title}</h4>
          <Switch checked={checked} onChange={this.handleSwitchChange} />
        </div>
        <div
          className={styles.content}
          style={{ display: checked ? 'block' : 'none' }}
        >
          <div className={styles.title}>
            <p>参数列表</p>
            <div className={styles.operator}>
              <div className={styles.btn} onClick={this.handleAddItem}>
                新增
              </div>
              <DelBtn onClick={this.handleBatchDeleteItems} />
            </div>
          </div>
          <Table
            size="small"
            rowKey="key"
            rowSelection={rowSelection}
            components={{
              body: {
                row: EditableFormRow,
                cell: EditableCell
              }
            }}
            columns={columns}
            dataSource={list}
            scroll={{ y: 180 }}
            pagination={false}
          />
        </div>
      </div>
    );
  }
}

export default WebServiceParams;
