import React, { Component } from 'react';
import { Table, Input, Form } from 'sup-ui';
import { TableCellText } from '@components/Table';

import styles from './index.less';
interface IProps {
  union: any;
  getFieldDecorator: any;
}
interface IState {}

const FormItem = Form.Item;
const requiredOption = ['否', '是'];

class ServiceConnect extends Component<IProps, IState> {
  public state = {
    dataSource: []
  };

  public componentDidMount() {
    const { union } = this.props;
    const { inParams } = JSON.parse(union);

    this.setState({
      dataSource: inParams
    });
  }

  public handleSave = (e: any, record: any) => {
    const { dataSource } = this.state;
    const {
      target: { value }
    } = e;

    const testParams = {
      ...record,
      defaultValue: value
    };

    this.setState({
      dataSource: _.map(dataSource, (item: any) =>
        item.key === testParams.key ? testParams : item
      )
    });
  };

  public getValue = () => {
    const { dataSource } = this.state;
    return {
      inParams: dataSource
    };
  };

  public render() {
    const { dataSource } = this.state;
    const { getFieldDecorator } = this.props;
    const columns = [
      {
        title: '序号',
        dataIndex: 'index',
        width: '60px',
        render: (_text: any, _record: any, index: number) => (
          <div>{index + 1}</div>
        )
      },
      {
        title: '参数名称',
        width: '100px',
        dataIndex: 'paramsName',
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '参数类型',
        width: '100px',
        dataIndex: 'paramsDataType'
      },
      {
        title: '是否为必填项',
        width: '120px',
        dataIndex: 'required',
        render: (text: any) => <TableCellText text={requiredOption[text]} />
      },
      {
        title: '测试数据',
        dataIndex: 'dataTest',
        render: (_text: any, record: any) => {
          const { required, key } = record;
          return (
            <FormItem style={{ margin: 0 }}>
              {getFieldDecorator(`dataTest_${key}`, {
                rules: [{ required }]
              })(
                <Input
                  onBlur={e => {
                    this.handleSave(e, record);
                  }}
                  onPressEnter={e => {
                    this.handleSave(e, record);
                  }}
                />
              )}
            </FormItem>
          );
        }
      }
    ];
    return (
      <Table
        columns={columns}
        dataSource={dataSource}
        pagination={false}
        className={styles.serviceConnect}
      />
    );
  }
}

export default ServiceConnect;
