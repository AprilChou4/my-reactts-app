import React, { Component, Fragment } from 'react';

import FormItem from 'sup-ui/lib/form/FormItem';

import XmlEditor from '@components/ScriptEditor/XmlEditor';
import { WebServiceParameter, DataRadio } from '@components/DataSource';

import styles from './index.less';

interface IProps {
  union: any;
  getFieldDecorator: any;
  handleInMode: (value: number) => void;
}

interface IState {
  inMode: number;
  requestXml: string;
}

const source = [
  { key: 1, name: '列表模式' },
  { key: 2, name: 'XML模式' }
];

class ApiWebService extends Component<IProps, IState> {
  public inParameterRef: any;
  public outParameterRef: any;

  public state = {
    inMode: 1,
    requestXml: ''
  };

  public componentDidMount() {
    const { union = {} } = this.props;
    this.setState({
      inMode: _.get(union, 'inMode', 1),
      requestXml: _.get(union, 'requestXml', '')
    });
  }

  public paramsXml = () => {
    const { requestXml } = this.state;
    return requestXml;
  };

  public paramsData = () => {
    const { inMode } = this.state;

    let inParams = {};
    let outParams = {};

    if (inMode === 1) {
      inParams = this.inParameterRef.getValues();
      outParams = this.outParameterRef.getValues();
    } else {
      outParams = this.outParameterRef.getValues();
    }

    return {
      inMode,
      ...inParams,
      ...outParams
    };
  };

  public handleInMode = (e: any) => {
    const {
      target: { value }
    } = e;
    this.setState({
      inMode: value
    });
    this.props.handleInMode(value);
  };

  public handleXmlChange = (xml: any) => {
    this.setState({
      requestXml: xml
    });
  };

  public render() {
    const { union, getFieldDecorator } = this.props;
    const { inMode, requestXml } = this.state;

    return (
      <Fragment>
        <DataRadio
          source={source}
          label="入参模式"
          formKey="inMode"
          colon={false}
          initialValue={inMode}
          onChange={this.handleInMode}
          style={{ marginBottom: 0 }}
          getFieldDecorator={getFieldDecorator}
        />
        {inMode === 1 ? (
          <WebServiceParameter
            paramsTypeText="入参"
            formKey="inParamsType"
            wrappedComponentRef={(ref: any) => (this.inParameterRef = ref)}
            dataSource={_.get(union, 'inParams', [])}
            switchStatus={!!_.get(union, 'inParamsType', 1)}
            propertyName={_.get(union, 'propertyName', '')}
          />
        ) : (
          <FormItem
            label="XML文本(注:变量以#{}标识)"
            colon={false}
            style={{ width: '100%' }}
            className={styles.formRequire}
          >
            <XmlEditor
              height={280}
              xmlValue={requestXml}
              onChange={this.handleXmlChange}
            />
          </FormItem>
        )}
        <WebServiceParameter
          paramsTypeText="出参"
          formKey="outParamsType"
          wrappedComponentRef={(ref: any) => (this.outParameterRef = ref)}
          dataSource={_.get(union, 'outParams', [])}
          switchStatus={!!_.get(union, 'outParamsType', 1)}
        />
      </Fragment>
    );
  }
}

export default ApiWebService;
