import React, { Component, Fragment } from 'react';
import { Form, Input, Switch } from 'sup-ui';
import {
  DataSourceName,
  DataSourceDescript,
  DataSourceApi,
  UserInformation
} from '@components/DataSource';

import { transJsonParse } from '@utils/common';

import styles from '../DataSourceForm.less';

const FormItem = Form.Item;

interface ISuposFormProps {
  itemForm: any;
  connectRes: any;
  getFieldDecorator: any;
  updateIsLocal: (check: boolean) => void;
}
interface ISuposFormStates {
  isAuth: boolean;
  isLocal: boolean;
}

class SuposForm extends Component<ISuposFormProps, ISuposFormStates> {
  public constructor(props: ISuposFormProps) {
    super(props);
    this.state = {
      isAuth: false,
      isLocal: false
    };
  }

  public componentDidMount() {
    const {
      itemForm: { spec = {} }
    } = this.props;
    const union = transJsonParse(_.get(spec, 'union', ''));
    this.setState({
      isAuth: _.get(union, 'isAuth', false),
      isLocal: _.get(union, 'isLocal', false)
    });
  }

  public handleAuthType = (check: boolean) => {
    this.setState({
      isAuth: check
    });
  };

  public handleSubCatalog = (check: boolean) => {
    this.setState(
      {
        isLocal: check
      },
      () => {
        this.props.updateIsLocal(check);
      }
    );
  };

  public render() {
    const { itemForm = {}, connectRes, getFieldDecorator } = this.props;

    const { isAuth, isLocal } = this.state;
    const spec = _.get(itemForm, 'spec', {});
    const union = transJsonParse(_.get(spec, 'union', ''));

    return (
      <Fragment>
        <Form className={connectRes ? styles.formWrapper : ''}>
          <FormItem label="本地数据源">
            {getFieldDecorator('isLocal', {
              valuePropName: 'checked',
              initialValue: isLocal
            })(<Switch onChange={this.handleSubCatalog} />)}
          </FormItem>
          <DataSourceName
            getFieldDecorator={getFieldDecorator}
            defaultValue={itemForm.name}
          />
          <DataSourceDescript
            getFieldDecorator={getFieldDecorator}
            defaultValue={itemForm.description}
          />
          {isLocal ? null : (
            <Fragment>
              <DataSourceApi
                label="supOS地址"
                type="ip"
                getFieldDecorator={getFieldDecorator}
                defaultValue={itemForm.url}
              />
              <FormItem label="supOS租户">
                {getFieldDecorator('tenantId', {
                  initialValue: union.tenantId
                })(<Input />)}
              </FormItem>
              <FormItem label="supOS认证">
                {getFieldDecorator('isAuth', {
                  valuePropName: 'checked',
                  initialValue: !!_.get(union, 'isAuth', false)
                })(<Switch onChange={this.handleAuthType} />)}
              </FormItem>
              {isAuth && (
                <UserInformation
                  getFieldDecorator={getFieldDecorator}
                  defaultValue={{
                    username: union.accountId,
                    password: union.secretKey
                  }}
                  colon={true}
                />
              )}
            </Fragment>
          )}
        </Form>
      </Fragment>
    );
  }
}

export default SuposForm;
