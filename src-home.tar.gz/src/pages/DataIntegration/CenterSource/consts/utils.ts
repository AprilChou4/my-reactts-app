//组装表单参数
const isWin = process.env.SYSTEM === 'WIN';

//注：表单values内使用 ip + port字段组合url参数，一般情况下，若无port，则ip即为url
export const getFormatParams = (
  values: any,
  type: string, //数据源类型
  catalog: string, //所属类型,
  extraParams: any //额外参数, api等复杂数据源
): any => {
  let params;
  const timezone = _.get(values, 'timezone', 'GMT+00:00');

  // 关系型数据源
  if (catalog === 'sql') {
    const {
      name,
      version,
      description,
      ip,
      port,
      dbName,
      username,
      password,
      url,
      sid,
      tagId,
      autoMetaTask,
      jdbcUrl,
      connectType,
      schema
    } = values;
    let urlParams = ip ? `${ip}:${port}` : '';
    let union: any = {};

    if (type === 'oracle') {
      union = { sid };
    }

    if (type === 'access' || type === 'paradox') {
      urlParams = url;
    }

    if (type === 'hdfs') {
      union = { filePath: url };
    }

    if (type === 'postgres') {
      union = { schema };
    }

    union.timezone = timezone;
    params = {
      ...values,
      name,
      description: description || '',
      catalog,
      subCatalog: type,
      namespace: 'default',
      replicate: 0,
      url: urlParams,
      tagId,
      autoMetaTask,
      jdbcUrl,
      connectType,
      spec: {
        dbName: dbName || '',
        version: version || '',
        instance: '',
        shared: true,
        union,
        username: username || '',
        password: password || ''
      }
    };
  }

  //文件数据源
  if (catalog === 'file') {
    const { username, password, url, path, ...rest } = values;
    let urlParams = url;
    const union: any = {};

    if (type === 'localfile') {
      urlParams = isWin ? url : `/volumes/supfiles/${url}`;
    }
    if (['ftp', 'smb'].includes(type)) {
      union.path = path;
    }

    if (type === 'hdfs') {
      union.timezone = timezone;
    }
    params = {
      ...rest,
      catalog,
      subCatalog: type,
      namespace: 'default',
      replicate: 0,
      url: urlParams,
      spec: {
        union,
        username: username || '',
        password: password || ''
      }
    };
  }

  //对象模型数据源
  if (catalog === 'supos') {
    const {
      isLocal,
      name,
      description,
      ip,
      isAuth,
      tenantId,
      username,
      password,
      tagId,
      autoMetaTask
    } = values;
    const union = {
      isLocal,
      isAuth,
      tenantId,
      accountId: username,
      secretKey: password,
      timezone
    };

    params = {
      name,
      description: description || '',
      catalog,
      subCatalog: type,
      namespace: 'default',
      replicate: 0,
      url: ip,
      tagId,
      autoMetaTask,
      spec: { union }
    };
  }

  //api数据源，webservice/restfull
  if (catalog === 'api') {
    if (type === 'webservice') {
      //区分新老数据
      if (values.hasOwnProperty('maxTransferNum')) {
        //老版本
        const {
          name,
          description,
          url,
          pathResolver,
          maxTransferNum,
          authType,
          username,
          password,
          method,
          nameSpace,
          inMode,
          propertyName,
          requestXml,
          tagId
        } = values;
        const { inParamsType, inParams, outParamsType, outParams } =
          extraParams;
        const union = {
          pathResolver,
          maxTransferNum,
          authType: authType ? 1 : 0,
          ...(authType && { username, password }),
          method,
          nameSpace,
          inMode,
          ...(inMode === 1 && {
            propertyName,
            inParamsType,
            inParams: inParamsType ? inParams : []
          }),
          ...(inMode === 2 && {
            inParamsType: requestXml ? 1 : 0,
            requestXml: requestXml || ''
          }),
          outParamsType,
          outParams: outParamsType ? outParams : [],
          timezone
        };

        params = {
          name,
          description: description || '',
          catalog,
          subCatalog: type,
          namespace: 'default',
          replicate: 0,
          url,
          spec: { union },
          tagId
        };
      } else {
        //新版本
        const {
          name,
          description,
          url,
          authType,
          username,
          password,
          method,
          nameSpace,
          pathResolver,
          inMode,
          outParamsType,
          tagId
        } = values;
        const { inParamsType, inParams, requestXml, outParams } = extraParams;
        const union = {
          authType: authType ? 1 : 0,
          ...(authType && { username, password }),
          method: inMode === 1 ? method : '',
          nameSpace: nameSpace || '',
          pathResolver: pathResolver || '',
          type: 2, //区分新老数据
          inMode,
          inParamsType,
          inParams: inMode === 1 && inParamsType === 1 ? inParams : [], // 当入参模式为列表，且有入参时，才读取 inParams
          requestXml: inMode === 2 ? requestXml : '',
          outParamsType,
          outParams: outParamsType ? outParams : [],
          timezone
        };

        params = {
          name,
          description: description || '',
          catalog,
          subCatalog: type,
          namespace: 'default',
          replicate: 0,
          url,
          spec: { union },
          tagId
        };
      }
    }

    if (type === 'restful') {
      const {
        name,
        description,
        url,
        method,
        charset,
        maxTransferNum,
        authType,
        username,
        password,
        inMode,
        inParamsDataType,
        tagId
      } = values;
      const union = {
        method,
        charset,
        maxTransferNum,
        authType: authType ? 1 : 0,
        ...(authType && { username, password }),
        inMode,
        ...(inMode === 1 && {
          inParamsDataType
        }),
        ...extraParams,
        timezone
      };

      params = {
        name,
        description: description || '',
        catalog,
        subCatalog: type,
        namespace: 'default',
        replicate: 0,
        url,
        spec: { union },
        tagId
      };
    }
  }

  //big_data数据源 hive/hbase
  if (catalog === 'big_data') {
    if (type === 'hive') {
      const {
        name,
        version,
        description,
        ip,
        port,
        dbName,
        username,
        password,
        dataTransfer,
        hdfsId,
        tagId,
        jdbcUrl,
        connectType
      } = values;
      const urlParams = ip ? `${ip}:${port}` : '';
      const union = { dataTransfer, hdfsId, timezone };

      params = {
        name,
        description: description || '',
        catalog: 'sql', //特殊处理，hive归于big_data下，但暂时传sql类
        subCatalog: type,
        namespace: 'default',
        replicate: 0,
        url: urlParams,
        spec: {
          dbName: dbName || '',
          version: version || '',
          instance: '',
          shared: true,
          union,
          username: username || '',
          password: password || ''
        },
        tagId,
        jdbcUrl,
        connectType
      };
    }

    if (type === 'hbase') {
      const {
        name,
        description,
        quorum,
        clientPort,
        master,
        openAuth,
        keytabPath,
        keytabServerAddress,
        keytabServerPort,
        keytabUserName,
        keytabPassword,
        confPath,
        confServerAddress,
        confServerPort,
        confUserName,
        confPassword,
        principal,
        tagId
      } = values;

      params = {
        name,
        description: description || '',
        catalog,
        subCatalog: type,
        namespace: 'default',
        replicate: 0,
        spec: {
          union: {
            quorum,
            clientPort,
            master,
            openAuth,
            keytabPath,
            keytabServerAddress,
            keytabServerPort,
            keytabUserName,
            keytabPassword,
            confPath,
            confServerAddress,
            confServerPort,
            confUserName,
            confPassword,
            principal,
            timezone
          }
        },
        tagId
      };
    }
  }

  // mq 消息队列
  if (catalog === 'mq') {
    const { name, msgId, groupId, accessKey, secretKey, timeout, tagId } =
      values;
    const union = { msgId, groupId, accessKey, secretKey, timeout };
    params = {
      ...values,
      name,
      catalog,
      subCatalog: type,
      namespace: 'default',
      replicate: 0,
      tagId,
      spec: { union }
    };
  }

  return params;
};
