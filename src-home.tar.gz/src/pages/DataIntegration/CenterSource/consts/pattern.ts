export const needNoSpace = (name: string): any[] => [
  {
    required: true,
    message: `请输入${name}`
  },
  {
    pattern: /^\S+$/,
    message: `请输入正确的${name}，不支持空格!`
  }
];

//port端口校验函数
const portRegExp = /^\d{4,5}$/;
export const portValidator = {
  validator: (_rule: any, value: any, callback: any) => {
    value -= 0;
    if (!portRegExp.test(value) || value < 1025 || value > 65534) {
      callback('请输入符合规范的端口号，应配置为“1025～65534”范围内');
    } else {
      callback();
    }
  }
};

export const filePathRegExp = /^([^\/\s]+)(\/([^\/\s]+))*$/g;

export const basePortValidator = (name: string): any[] => [
  {
    required: true,
    message: `请输入${name}!`
  },
  {
    pattern: /^\d+$/,
    message: `请输入正确的${name}，不支持空格!`
  }
];

// ip和端口号正在
const ipPortReg =
  /^(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d{2}|2[0-4]\d|25[0-5]):(\d{4,5})$/;

export const ipportValidator = {
  validator: (_rule: any, value: any, callback: any) => {
    if (!value) {
      callback();
      return;
    }

    const serveArr = value.split(',');
    const ipList: string[] = [];
    const portList: string[] = [];
    _.forEach(serveArr, item => {
      if (!item) {
        return;
      }
      if (!ipPortReg.test(item)) {
        callback('请输入正确的ip和端口号');
      }
      const [ip, port] = item.split(':');
      ipList.push(ip);
      portList.push(port);
    });
    const portFlag = _.every(portList, (item: any) => {
      item -= 0;
      return portRegExp.test(item) && item > 1025 && item < 65534;
    });
    if (!portFlag) {
      callback('请输入符合规范的端口号，应配置为“1025～65534”范围内');
    } else {
      callback();
    }
  }
};

// 文件路径 以/开头的字符 排除\:*?"<>|文件夹不支持的字符
export const filePathReg = {
  pattern: /^\/[^\:*?"<>|]*$/,
  message: '请输入以/开头的文件路径'
};

// 地址排除特殊中文字符
export const expecialCharReg = /^[^；，：‘’。！、“”]*$/;
