import {
  createCollect,
  getCollect,
  updateCollect,
  invokeCollect,
  pauseCollect,
  resumeCollect,
  getHistoryList
} from '../services/datasource.service';
import { message } from 'sup-ui';
import { observable, action, runInAction } from 'mobx';

class SourceCollectStore {
  private readonly refreshList: any;
  @observable public searchParams = {
    pageIndex: 1,
    pageSize: 20
  };
  @observable public list = [];
  @observable public count = 0;
  @observable public tableLoading = false;
  @observable public modalLoading = false;
  @observable public invoking = false;
  @observable public sourceId = null; //当前数据源Id
  @observable public scheduleId = '';
  @observable public info: any = {};
  @observable public infoVisible = false;

  public constructor(refreshList: any) {
    this.refreshList = refreshList;
  }

  @action.bound
  public updateSearchParams(params: any) {
    this.searchParams = { ...this.searchParams, ...params };
    this.getList();
  }

  @action.bound
  public handleSetScheduleId(scheduleId: string) {
    this.scheduleId = scheduleId;
  }

  @action.bound
  public handleSetSourceId(sourceId: any) {
    this.sourceId = sourceId;
  }

  @action.bound
  public handleVisible() {
    this.infoVisible = !this.infoVisible;

    //关闭弹窗重置数据
    if (!this.infoVisible) {
      this.list = [];
      this.count = 0;
      this.tableLoading = false;
      this.modalLoading = false;
      this.invoking = false;
      this.sourceId = null;
      this.scheduleId = '';
      this.info = {};
    }
  }

  @action.bound
  public handleInfoChange(key: any, value: any) {
    this.info[key] = value;
  }

  @action.bound
  public async getList() {
    this.tableLoading = true;
    const res = await getHistoryList({
      scheId: this.scheduleId,
      ...this.searchParams
    });
    runInAction(() => {
      this.tableLoading = false;
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }
      const { pagination = {}, list = [] } = res.data || {};

      this.list = list;
      this.count = _.get(pagination, 'total', 0);
    });
  }

  @action.bound
  public async getCollectInfo() {
    this.modalLoading = true;
    const res = await getCollect(this.scheduleId);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }
      this.info = res.data;
      this.invoking = this.info.collectStatus === '2' ? true : false; //2 采集中
      this.modalLoading = false;
    });
  }

  @action.bound
  public async handleInvokeCollect() {
    const { sourceid } = this.info;
    this.invoking = true;
    const res = await invokeCollect(sourceid);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }
      //this.invoking = false;
      message.success('元数据采集中');
      this.getList();
    });
  }

  @action.bound
  public async handleCollect() {
    if (!this.scheduleId) {
      const { sheduleStatus } = this.info;
      this.handleInfoChange('sheduleStatus', sheduleStatus === '1' ? '0' : '1');
      return;
    }

    const { sheduleStatus, sourceid } = this.info;
    const res =
      sheduleStatus === '1'
        ? await pauseCollect(sourceid)
        : await resumeCollect(sourceid);
    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }
      this.info.sheduleStatus = sheduleStatus === '0' ? '1' : '0';
    });
  }

  @action.bound
  public async updateInfo(params: any) {
    //区分编辑调度信息和新建调度信息
    const { sheduleStatus } = this.info;
    let res: any;

    if (this.scheduleId) {
      //更新
      res = await updateCollect(params);
    } else {
      if (!sheduleStatus || sheduleStatus === '0') {
        this.handleVisible();
        return;
      }

      const { collectPeriod, expr, adaptType, comment } = params;
      res = await createCollect({
        sourceId: this.sourceId,
        collectPeriod,
        expr,
        adaptType,
        comment
      });
    }

    runInAction(() => {
      if (res.code !== 200) {
        message.error(`${res.message}`);
        return;
      }

      if (!this.scheduleId) {
        this.refreshList();
      }

      message.success(this.scheduleId ? '更新成功' : '创建成功');
      this.handleVisible();
    });
  }
}

export default SourceCollectStore;
