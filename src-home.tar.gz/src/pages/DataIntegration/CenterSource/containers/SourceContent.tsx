import { inject, observer } from 'mobx-react';
import React, { Fragment } from 'react';
import BaseSystemCard from '../components/baseSystemCard';
import { Row, Col, Divider, Table, Empty, Spin } from 'sup-ui';
import styles from '../index.less';
import { TableCellText } from '@components/Table';
import { sourceNameMap } from '../consts/typeMap';
import memoizeOne from 'memoize-one';
import TipsDelete from '@components/Modal/TipsDelete';
import moment from 'moment';
import Icon from '@components/Icon';
import CustomPaging from '@components/CustomPaging';
interface IProps {
  store?: any;
  collectStore?: any;
}

interface IState {
  hasMore?: boolean;
  pageIndex?: number;
}

@inject('store', 'collectStore')
@observer
class SourceContent extends React.Component<IProps, IState> {
  private readonly sourceNameMap: any;
  public constructor(props: IProps) {
    super(props);
    this.state = {
      hasMore: false
    };
    this.sourceNameMap = sourceNameMap();
  }

  public handleTableChange = (pagination: any) => {
    const { tabKey, updateSearchParams } = this.props.store;
    //页码
    const { current, pageSize } = pagination;
    const params =
      tabKey === 'system'
        ? { pageNum: current, pageSize }
        : {
            pageFilter: {
              pageNum: current,
              pageSize
            }
          };
    updateSearchParams(params);
  };

  /**
   * 重新配置数据源
   * @param record
   */
  public handleSourceEdit = (record: any) => {
    const { updateCurrentSourceInfo, updateFromData } = this.props.store;
    const { subCatalog, catalog } = record;

    const info = {
      catalog,
      key: subCatalog,
      name: this.sourceNameMap[subCatalog]
    };

    updateFromData(record);
    updateCurrentSourceInfo(info);
  };

  public handleSourceDelete = (id: string, name: string) => {
    const { deleteSource } = this.props.store;
    const config = {
      title: '删除',
      content: `确定删除 ${name} 数据源？`,
      onOk: deleteSource.bind(this, [id])
    };
    TipsDelete(config);
  };

  public getColumns = () => {
    return [
      {
        title: '数据源名称',
        dataIndex: 'name',
        width: 240,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <a
            onClick={() => {
              this.handleSourceEdit(record);
            }}
          >
            <TableCellText text={text} />
          </a>
        )
      },
      {
        title: '类型',
        dataIndex: 'subCatalog',
        width: 160,
        className: 'ellipsis-hide',
        render: (text: string) => (
          <TableCellText text={this.sourceNameMap[text]} />
        )
      },
      {
        title: '链接信息',
        dataIndex: 'url',
        width: 200,
        className: 'ellipsis-hide',
        render: (_value: any, record: any) => {
          const { url, spec } = record;
          const text = `${url}/${spec.dbName} 用户名：${spec.username}`;

          return <TableCellText text={text} />;
        }
      },
      {
        title: '描述',
        dataIndex: 'description',
        width: 240,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '更新时间',
        dataIndex: 'updateTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        render: (text: string) => (
          <TableCellText
            text={
              !_.isEmpty(text) ? moment(text).format('YYYY-MM-DD HH:mm:ss') : ''
            }
          />
        )
      },
      {
        title: '连通状态',
        dataIndex: 'status',
        width: 100,
        className: 'ellipsis-hide',
        render: (value: any) => {
          switch (value) {
            case '1':
              return (
                <div className={styles.status}>
                  <Icon type="success" width={11} />
                  <div className={styles.success}>已连通</div>
                </div>
              );
            case '0':
              return (
                <div className={styles.status}>
                  <Icon type="error" width={8} />
                  <div className={styles.error}>失败</div>
                </div>
              );
            default:
              return (
                <div className={styles.status}>
                  <Icon type="error" width={8} />
                  <div className={styles.notAdmitted}>未连通</div>
                </div>
              );
          }
        }
      },
      {
        title: '操作',
        dataIndex: 'operation',
        fixed: 'right',
        align: 'center',
        width: 260,
        render: (_value: any, record: any) => (
          <Fragment>
            <div className="more">
              <Icon type="ellipsis" />
            </div>
            <div className="operator">
              <a onClick={() => this.handleSourceEdit(record)}>编辑</a>
              <Divider type="vertical" />
              <a
                onClick={() => this.handleSourceDelete(record.id, record.name)}
              >
                删除
              </a>
            </div>
          </Fragment>
        )
      }
    ];
  };

  public getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 50;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public handleCollectInfoVisible = (metaTaskId: string, sourceId: any) => {
    const { handleVisible, handleSetScheduleId, handleSetSourceId } =
      this.props.collectStore;
    handleSetScheduleId(metaTaskId);
    handleSetSourceId(sourceId);
    handleVisible();
  };

  public render() {
    const {
      loading,
      list,
      count,
      tabKey,
      searchParams,
      searchTagParams,
      selectedRowKeys,
      updateSelectedRowKeys,
      showType,
      deleteSource,
      checkedColumns
    } = this.props.store!;

    const rowSelection = {
      columnWidth: 50,
      selectedRowKeys,
      onChange: updateSelectedRowKeys,
      hideDefaultSelections: true
    };

    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );
    return (
      <div className={styles.systemContainer}>
        {showType === 'card' ? (
          <Spin spinning={loading}>
            <div className={styles.systemContainerBody}>
              {list && list.length ? (
                <Row>
                  {_.map(list || [], (item: any) => {
                    return (
                      <Col key={item.id} xs={24} md={12} xl={8} xxl={6}>
                        <BaseSystemCard
                          infos={item}
                          onEdit={this.handleSourceEdit}
                          onDelete={deleteSource}
                          onVisible={this.handleCollectInfoVisible}
                        />
                      </Col>
                    );
                  })}
                </Row>
              ) : (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
              )}
            </div>
          </Spin>
        ) : (
          <div className={styles.systemContainerBody}>
            <div className={`${styles.table} mp-table-white mp-table-grow`}>
              <Table
                loading={loading}
                rowSelection={rowSelection}
                columns={filterColumns}
                dataSource={list}
                onChange={this.handleTableChange}
                rowKey="id"
                pagination={{
                  current:
                    tabKey === 'system'
                      ? searchTagParams.pageNum
                      : searchParams.pageFilter.pageNum,
                  pageSize:
                    tabKey === 'system'
                      ? searchTagParams.pageSize
                      : searchParams.pageFilter.pageSize,
                  showTotal: total => `共${total}条`,
                  total: count,
                  itemRender: CustomPaging,
                  pageSizeOptions: ['20', '50', '100'],
                  showSizeChanger: true,
                  showQuickJumper: true
                }}
                scroll={{ x: totalWidthX, y: 'calc(100% - 52px)' }}
              />
            </div>
          </div>
        )}
      </div>
    );
  }
}

export default SourceContent;
