import React, { Component, createRef } from 'react';
import { inject, observer } from 'mobx-react';
import { Button, message, Popover, Radio } from 'sup-ui';
import Header from '@components/Header';
import { AddBtn, DelBtn } from '@components/Button';
import TipsDelete from '@components/Modal/TipsDelete';
import Icon from '@components/Icon';
import { dataSourceMap } from '../consts/typeMap';
import KeywordSearch from '@components/KeywordSearch';
import styles from '../index.less';

const tabs: any = _.map(dataSourceMap, ({ key, name, disable }) => ({
  key,
  name,
  disable
}));

interface IProps {
  store?: any;
}

interface IState {
  tab: string;
  // visible: boolean;
  sourceType: string;
}
interface ListModel {
  name: string;
  key: string;
  children: any[];
}

@inject('store')
@observer
class SourceHeader extends Component<IProps, IState> {
  public inputRef: any;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      // 当前只有一种，默认base
      tab: tabs[0]['key'],
      // visible: false,
      // 数据源类型，默认全部
      sourceType: 'all'
    };
    this.inputRef = createRef();
  }

  public refreshList = () => {
    const { updateSearchParams, tabKey, queryTagCount, updateSelectedRowKeys } =
      this.props.store;

    updateSelectedRowKeys([]);
    if (tabKey === 'system') {
      updateSearchParams({ pageNum: 1 });
      queryTagCount();
    } else {
      updateSearchParams({ pageFilter: { pageNum: 1, pageSize: 20 } });
    }
  };

  public handleBatchDelete = () => {
    const { selectedRowKeys, deleteSource } = this.props.store;

    const config = {
      title: '删除',
      content: '确定删除选中项？',
      onOk: deleteSource.bind(this, selectedRowKeys)
    };
    TipsDelete(config);
  };

  public handleBatchConnect = () => {
    const { selectedRowKeys, list, connectSourceBatch } = this.props.store;

    if (!selectedRowKeys.length) {
      message.warning('请选择要测试的数据源！');
      return;
    }

    const items = _.filter(list, item => _.includes(selectedRowKeys, item.id));

    connectSourceBatch(items);
  };

  public handleTabChange = ({ key, disable }: any) => {
    if (disable) {
      return;
    }

    this.setState({
      sourceType: key
    });
  };

  public handleAddSource = (item: any) => {
    const { updateCurrentSourceInfo, updateSourceVisible } = this.props.store;
    if (item.disable) {
      return;
    }
    updateCurrentSourceInfo(item);
    updateSourceVisible(false);
    setTimeout(() => {
      this.setState({
        sourceType: 'all'
      });
    });
  };

  public renderDataContent = () => {
    const { tab, sourceType } = this.state;
    const list = dataSourceMap[tab]['list'];

    // 展示的list
    const showList: ListModel[] =
      sourceType === 'all'
        ? list
        : _.filter(list, (item: any) => item.key === sourceType);

    return (
      <div className={styles.dataContent}>
        {showList.map((group: any) => (
          <div key={group.key} className={styles.group}>
            <h3>{group.name}</h3>
            <ul>
              {group.children.map((item: any) => (
                <li
                  key={item.key}
                  className={item.disable ? styles.disable : ''}
                  onClick={() =>
                    this.handleAddSource({ ...item, catalog: group.key })
                  }
                >
                  <div className={`${styles.icon} ${styles[item.key]}`} />
                  <p>{item.name}</p>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    );
  };

  public inputFocus = () => {
    if (this.inputRef) {
      this.inputRef.focus();
    }
  };

  public handleOnSearch = (value: string) => {
    const { updateSearchKey } = this.props.store;
    updateSearchKey(value);
  };

  public render() {
    const {
      loading,
      selectedRowKeys,
      tabKey,
      showType,
      searchTagParams,
      searchParams,
      sourceVisible,
      updateSourceVisible,
      handleChangeShowType
    } = this.props.store;

    const { tab, sourceType } = this.state;
    const list = [
      {
        name: '全部',
        key: 'all'
      }
    ].concat(dataSourceMap[tab]['list']);
    const searchValue =
      tabKey === 'system' ? searchTagParams.name : searchParams.name.val;
    return (
      <Header
        style={{
          height: '48px',
          flex: '0 0 48px',
          borderBottom: '1px solid #DFE3E9'
        }}
        className={styles.sourceHeader}
        left={
          <>
            <Popover
              visible={sourceVisible}
              onVisibleChange={(vis: boolean) => {
                updateSourceVisible(vis);
                this.setState({
                  sourceType: 'all'
                });
              }}
              placement="bottomLeft"
              overlayClassName={styles.dataPanel}
              content={sourceVisible && this.renderDataContent()}
              title={
                <ul className={styles.dataHeader}>
                  {list.map((group: any) => {
                    const { key, disable, name } = group || {};
                    return (
                      <li
                        key={key}
                        className={`${
                          key === sourceType ? styles.active : ''
                        } ${disable ? styles.disable : ''}`}
                        onClick={() => this.handleTabChange(group)}
                      >
                        {name}
                      </li>
                    );
                  })}
                </ul>
              }
              trigger="click"
            >
              <AddBtn ghost className={styles.headerBtn} />
            </Popover>
            <Button className={styles.headerBtn} onClick={this.refreshList}>
              刷新
            </Button>
            <Button
              className={styles.headerBtn}
              onClick={this.handleBatchConnect}
              disabled={loading || showType === 'card'}
            >
              测试连通性
            </Button>
            <DelBtn
              onClick={this.handleBatchDelete}
              disabled={!selectedRowKeys.length || showType === 'card'}
            />
          </>
        }
        right={
          <>
            <KeywordSearch
              value={searchValue}
              className={searchValue ? styles.searchActive : ''}
              ref={(el: any) => (this.inputRef = el)}
              suffix={
                searchValue ? (
                  <Icon
                    type="circle-close"
                    size="small"
                    onClick={() => {
                      this.inputFocus();
                      this.handleOnSearch('');
                    }}
                  />
                ) : (
                  <Icon type="search" onClick={this.inputFocus} />
                )
              }
              onSearch={this.handleOnSearch}
            />
            <Radio.Group
              value={showType}
              className={styles.btnGroup}
              onChange={e => handleChangeShowType(e.target.value)}
            >
              <Radio.Button value="card" className={styles.cardmode} />
              <Radio.Button value="table" className={styles.tablemode} />
            </Radio.Group>
          </>
        }
      />
    );
  }
}

export default SourceHeader;
