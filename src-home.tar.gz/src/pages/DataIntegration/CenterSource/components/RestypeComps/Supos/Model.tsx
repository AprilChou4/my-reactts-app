import React, { Component, Fragment } from 'react';
import { Form, Input, Switch } from 'sup-ui';
import TimeZoneSelect from '@components/TimeZoneSelect';
import { needNoSpace } from '../../../consts/pattern';
import { transJsonParse } from '@utils/common';
import SystemSelect from '../../../components/SystemSelect';
import styles from '../index.less';

const isWin = process.env.SYSTEM === 'WIN';
const TextArea = Input.TextArea;
const FormItem = Form.Item;

interface IProps {
  form: any;
  values?: any;
  toggleConnectVisible: any;
  update: boolean;
}
interface IState {
  local: boolean;
  auth: boolean;
}

class Model extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);

    const { isLocal, isAuth } = transJsonParse(
      _.get(props.values, 'spec.union', '{}')
    );

    this.state = {
      local: isLocal || false,
      auth: !!isAuth
    };

    props.toggleConnectVisible(!this.state.local);
  }

  public handleLocalSwitch = (check: boolean) => {
    this.setState({ local: check });
    this.props.toggleConnectVisible(!check);
  };

  public handleAuthSwitch = (check: boolean) => {
    this.setState({ auth: check });
  };

  public render() {
    const {
      form: { getFieldDecorator },
      values,
      update
    } = this.props;
    const { local, auth } = this.state;
    const { accountId, secretKey, tenantId } = transJsonParse(
      _.get(values, 'spec.union', '{}')
    );

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="本地数据源">
            {getFieldDecorator('isLocal', {
              initialValue: local,
              valuePropName: 'checked'
            })(<Switch onChange={this.handleLocalSwitch} />)}
          </FormItem>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: '请输入不超过255的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>
          <FormItem label="所属业务系统" required>
            {getFieldDecorator('tagId', {
              initialValue: values.tagId,
              rules: [{ required: true, message: '业务系统不能为空' }]
            })(<SystemSelect />)}
          </FormItem>

          <FormItem
            label="自动创建元数据采集任务"
            required
            style={isWin || update ? { display: 'none' } : {}}
          >
            {getFieldDecorator('autoMetaTask', {
              initialValue: _.get(values, 'autoMetaTask', !isWin),
              valuePropName: 'checked'
            })(<Switch />)}
          </FormItem>

          {!local && (
            <Fragment>
              <FormItem label="supOS地址">
                {getFieldDecorator('ip', {
                  initialValue: values.url,
                  rules: [...needNoSpace('supOS地址')]
                })(<Input size="large" />)}
              </FormItem>
              <FormItem label="supOS租户">
                {getFieldDecorator('tenantId', {
                  initialValue: tenantId
                })(<Input size="large" />)}
              </FormItem>
              <FormItem label="supOS认证">
                {getFieldDecorator('isAuth', {
                  initialValue: auth,
                  valuePropName: 'checked'
                })(<Switch onChange={this.handleAuthSwitch} />)}
              </FormItem>
              <div style={{ display: auth ? 'block' : 'none' }}>
                <FormItem label="用户名">
                  {getFieldDecorator('username', {
                    initialValue: accountId || '',
                    rules: [
                      {
                        pattern: /^\S+$/,
                        message: '不支持空格!'
                      }
                    ]
                  })(<Input size="large" />)}
                </FormItem>
                <FormItem label="密码">
                  {getFieldDecorator('password', {
                    initialValue: secretKey || '',
                    rules: [
                      {
                        pattern: /^\S+$/,
                        message: '不支持空格!'
                      }
                    ]
                  })(
                    <Input.Password
                      visibilityToggle={false}
                      autoComplete="new-password"
                      size="large"
                    />
                  )}
                </FormItem>
              </div>
            </Fragment>
          )}
          <TimeZoneSelect
            formKey="timezone"
            label="时区"
            size="large"
            disabled
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default Model;
