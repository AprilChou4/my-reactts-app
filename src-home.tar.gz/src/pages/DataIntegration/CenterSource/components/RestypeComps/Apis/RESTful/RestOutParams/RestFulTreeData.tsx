import React, { Component } from 'react';
import JSONTree from 'react-json-tree';
import { message } from 'sup-ui';
import uuid from '@utils/uuid';

interface IProps {
  dataSource: any;
  outDataSource: (v: any, o: string) => void;
}
interface IState {}

const getRelateKeys = (
  current: any,
  path: string,
  result: any[],
  isLast: boolean
) => {
  let cont = current;
  if (isLast && _.isArray(current) && current.length > 0) {
    //如果选中项目为多维数组的话, 不支持
    cont = current[0];
    if (!_.isPlainObject(cont)) {
      message.error('不支持');
      throw new Error('不支持');
    }
  }
  //将选中项保存到result
  if (_.isPlainObject(cont)) {
    for (const k in cont) {
      if (cont.hasOwnProperty(k) && !_.isObject(cont[k])) {
        result.push({
          paramsName: k,
          paramsDataType: 'String',
          path,
          isChildNode: isLast ? 1 : 2,
          key: uuid(6)
        });
      }
    }
  }
};

class RestFulTreeData extends Component<IProps, IState> {
  public result: any[] = [];
  public selectedItemType = 0;

  // 获取当前json的子节点
  public getCurrentData = (s: any, p: any) => {
    let i = 0,
      data = s;

    while (i < p.length) {
      data = data[p[i]];
      i++;
    }

    return data;
  };

  public getSelectedItemRelateKeys = (
    source: any, //当前json
    paths: any[], //当前用户选中的json的集合[]
    i = 0,
    result = [],
    isParentArray = false //上游节点是否为数组
  ) => {
    //root为默认根基点
    const isRoot = paths[i] === 'root';
    const current = isRoot
      ? source
      : this.getCurrentData(source, paths.slice(1, i + 1));

    if (isParentArray) {
      message.warning('该节点上游节点存在数组节点,  请重新选择!');
      throw new Error('不支持');
    }

    let isCurrentArray: boolean = isParentArray;
    if (_.isArray(current) && !isRoot) {
      isCurrentArray = true;
    } else {
      isCurrentArray = false;
    }

    //返回当前节点的json路径
    const path = isRoot ? 'root' : paths.slice(0, i + 1).join('/');

    i++;

    //判断当前的i  是否已经循环到选中的json节点
    const isLast = i === paths.length;
    //如果时选中的节点
    if (isLast) {
      //判断选中项的类型
      this.selectedItemType = _.isArray(current)
        ? 1
        : _.isPlainObject(current)
        ? 2
        : 0;
    }

    //保存json路径上的字段
    getRelateKeys(current, path, result, isLast);

    //当i还小于paths话, 说明json还没有走到被选中项
    if (i < paths.length) {
      this.getSelectedItemRelateKeys(source, paths, i, result, isCurrentArray);
    }

    return { result, selectedItemType: this.selectedItemType };
  };

  public handleJson = (e: any, key: string[], childType: string) => {
    e.stopPropagation();

    const { dataSource, outDataSource } = this.props;

    if (!(childType === 'Array' || childType === 'Object')) {
      message.warning('不能选择单个节点, 选择的节点必须为数组或者对象!');
      return;
    }

    try {
      const paths = key.reverse();
      const { result } = this.getSelectedItemRelateKeys(dataSource, paths);
      this.result = result;
    } catch (error) {
      console.error(error);
    }

    outDataSource(this.result, childType);
    this.forceUpdate();
  };

  public handleItem = (e: any) => {
    e.stopPropagation();
  };

  public render() {
    const { dataSource } = this.props;

    return (
      <JSONTree
        data={dataSource}
        getItemString={(
          _type: any,
          _data: any,
          itemType: any,
          itemString: any
        ) => {
          return (
            <span style={{ cursor: 'text' }} onClick={this.handleItem}>
              {itemType} - {itemString}
            </span>
          );
        }}
        invertTheme={false}
        labelRenderer={(key: string[], childType: string) => (
          <span
            style={{ cursor: 'pointer' }}
            onClick={e => {
              this.handleJson(e, key, childType);
            }}
          >
            {key[0]}
          </span>
        )}
        shouldExpandNode={() => true}
      />
    );
  }
}

export default RestFulTreeData;
