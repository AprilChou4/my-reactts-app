import React, { Component } from 'react';
import { Table } from 'sup-ui';

interface IProps {}
interface IState {
  dataSource: any[];
}

class NotParseParams extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      dataSource: [
        {
          key: 'Body',
          paramsName: 'Body',
          paramsDataType: 'String',
          required: 1
        }
      ]
    };
  }

  public getParams = () => {
    return _.map(this.state.dataSource, item => _.omit(item, 'key'));
  };

  private getColumns = () => {
    return [
      {
        title: '参数名称',
        width: '50%',
        dataIndex: 'paramsName'
      },
      {
        title: '参数类型',
        width: '50%',
        dataIndex: 'paramsDataType'
      }
    ];
  };

  public render() {
    const { dataSource } = this.state;
    return (
      <Table
        size="small"
        rowKey="key"
        className="mp-table-gray"
        dataSource={dataSource}
        columns={this.getColumns()}
        pagination={false}
      />
    );
  }
}

export default NotParseParams;
