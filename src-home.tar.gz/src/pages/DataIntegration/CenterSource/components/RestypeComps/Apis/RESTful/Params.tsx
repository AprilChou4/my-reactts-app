import React, { Component, createContext } from 'react';
import { Select, Table, Input, message, Form } from 'sup-ui';
import { DelBtn, AddBtn } from '@components/Button';
import Icon from '@components/Icon';
import { TableCellText } from '@components/Table';
import { webServiceType } from '@consts/dataTypes';
import styles from './index.less';

const { Option } = Select;
const Context = createContext({});

/*eslint-disable @typescript-eslint/no-unused-vars*/
const EditableRow = ({ form, index, ...props }: any) => (
  <Context.Provider value={form}>
    <tr {...props} />
  </Context.Provider>
);

const EditableFormRow = Form.create()(EditableRow);

interface ICellProps {
  record: any;
  handleSave: any;
  form: any;
  dataIndex: any;
  title: any;
  [propName: string]: any;
}
interface ICellState {
  editing: boolean;
}

class EditableCell extends React.Component<ICellProps, ICellState> {
  private form: any;
  private input: any;
  public state = {
    editing: false
  };

  public toggleEdit = () => {
    const editing = !this.state.editing;
    this.setState({ editing }, () => {
      if (editing) {
        this.input.focus();
      }
    });
  };

  public save = (e: any) => {
    const { record, handleSave, dataIndex } = this.props;

    this.form.validateFields((error: any, values: any) => {
      if (error && error[e.currentTarget.id]) {
        return;
      }
      this.toggleEdit();

      if (dataIndex === 'paramsName' && !values[dataIndex]) {
        message.error('参数不能为空!');
        return;
      }

      handleSave(dataIndex, { ...record, ...values });
    });
  };

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { editing } = this.state;

    return editing ? (
      <Form.Item style={{ margin: 0 }}>
        {form.getFieldDecorator(dataIndex, {
          initialValue: record[dataIndex]
        })(
          <Input
            ref={node => (this.input = node)}
            onPressEnter={this.save}
            onBlur={this.save}
          />
        )}
      </Form.Item>
    ) : (
      <div
        className={styles['editable-cell-value-wrap']}
        onClick={() => {
          this.toggleEdit();
        }}
      >
        {record[dataIndex] ? (
          <TableCellText text={record[dataIndex]} />
        ) : (
          <span style={{ color: 'rgba(53, 64, 82, 0.5)', fontSize: '14px' }}>
            请输入
          </span>
        )}
      </div>
    );
  };

  public render() {
    const {
      editable,
      dataIndex,
      title,
      record,
      index,
      handleSave,
      children,
      ...restProps
    } = this.props;
    return (
      <td {...restProps}>
        {editable ? (
          <Context.Consumer>{this.renderCell}</Context.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IProps {
  title: string;
  dataSource: any[];
}
interface IState {
  checked: boolean;
  list: any[];
  prevList: any[];
  selectedRowKeys: any[];
}

class Params extends Component<IProps, IState> {
  public i = 0;
  public constructor(props: IProps) {
    super(props);

    this.state = {
      checked: false,
      list: [],
      prevList: [],
      selectedRowKeys: []
    };
    //初始化table key
    this.i = props.dataSource.length;
  }

  public static getDerivedStateFromProps(
    nextProps: Readonly<IProps>,
    state: IState
  ) {
    if (!_.isEqual(nextProps.dataSource, state.prevList)) {
      const { dataSource } = nextProps;
      const temp = _.map(dataSource, (item: any, i: number) => ({
        key: i,
        ...item
      }));

      return {
        list: temp,
        prevList: _.cloneDeep(dataSource),
        selectedRowKeys: []
      };
    }

    return null;
  }

  public getColumns = (): any[] => {
    return [
      {
        title: '参数',
        width: 'auto',
        dataIndex: 'paramsName',
        editable: true
      },
      {
        title: '数据类型',
        width: 130,
        dataIndex: 'paramsDataType',
        render: (value: any, record: any): any => {
          return (
            <Select
              value={value}
              placeholder="-请选择-"
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'paramsDataType', val)
              }
            >
              {webServiceType.map((option: any) => (
                <Option value={option} key={option}>
                  {option}
                </Option>
              ))}
            </Select>
          );
        }
      },
      {
        title: '是否为必填项',
        width: 110,
        dataIndex: 'required',
        render: (value: any, record: any): any => {
          return (
            <Select
              value={value}
              placeholder="-请选择-"
              onChange={(val: string) =>
                this.handleValueChange(record.key, 'required', val)
              }
            >
              <Option value={1}>是</Option>
              <Option value={0}>否</Option>
            </Select>
          );
        }
      },
      {
        title: '测试数据',
        width: 130,
        dataIndex: 'defaultValue',
        editable: true
      },
      {
        title: '操作',
        width: 60,
        align: 'center',
        render: (_value: any, record: any) => (
          <div style={{ height: '30px', padding: '5px 0' }}>
            <Icon
              type="remove"
              width={22}
              onClick={() => this.handleRemoveItems([record.key])}
            />
          </div>
        )
      }
    ];
  };

  public handleAddItem = () => {
    const { list } = this.state;
    const item = {
      key: this.i++,
      paramsName: undefined,
      paramsDataType: webServiceType[0],
      required: 0,
      defaultValue: undefined
    };

    this.setState({
      list: list.concat([item])
    });
  };

  public handleCellSave = (dataIndex: string, row: any) => {
    this.handleValueChange(row.key, dataIndex, row[dataIndex]);
  };

  public handleValueChange = (key: number, name: string, value: any): void => {
    const { list } = this.state;
    const temp = _.cloneDeep(list);
    const target = _.find(temp, ['key', key]);

    target[name] = value;

    this.setState({
      list: temp
    });
  };

  public handleBatchDeleteItems = () => {
    const { selectedRowKeys } = this.state;

    if (selectedRowKeys.length === 0) {
      message.warning('请选择要移除的参数!');
    } else {
      this.handleRemoveItems(selectedRowKeys);
    }
  };

  public handleRemoveItems = (keys: any) => {
    const { selectedRowKeys, list } = this.state;
    const remainKeys = _.filter(selectedRowKeys, key => !_.includes(keys, key));
    const remainList = _.filter(list, item => !_.includes(keys, item.key));

    this.setState({
      list: remainList,
      selectedRowKeys: remainKeys
    });
  };

  public updateSelectedRowKeys = (selectedKeys: string[] | number[]) => {
    this.setState({
      selectedRowKeys: selectedKeys
    });
  };

  public validateDatas = () => {
    //校验，拼装数据
    const { title } = this.props;
    const { list } = this.state;
    let params: any[] = [];

    const hasError = _.find(list, data => !data.paramsName);

    if (hasError) {
      message.error(`${title}参数不能为空!`);
      return;
    }

    params = _.map(list, data => ({
      paramsName: data.paramsName,
      paramsDataType: data.paramsDataType,
      required: data.required,
      defaultValue: data.defaultValue || ''
    }));

    return params;
  };

  public render() {
    const { list, selectedRowKeys } = this.state;
    const rowSelection = {
      columnWidth: 40,
      selectedRowKeys,
      onChange: this.updateSelectedRowKeys,
      hideDefaultSelections: true
    };
    const columns = this.getColumns().map((col: any) => {
      if (!col.editable) {
        return col;
      }

      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          handleSave: this.handleCellSave
        })
      };
    });

    return (
      <div className={styles.params}>
        <div className={styles.content}>
          <div className={styles.title}>
            <p>参数列表</p>
            <div className={styles.operator}>
              <AddBtn
                title="新增"
                ghost
                className={styles.btn}
                onClick={this.handleAddItem}
              />
              <DelBtn onClick={this.handleBatchDeleteItems} />
            </div>
          </div>
          <Table
            size="small"
            rowKey="key"
            className="mp-table-gray"
            rowSelection={rowSelection}
            components={{
              body: {
                row: EditableFormRow,
                cell: EditableCell
              }
            }}
            columns={columns}
            dataSource={list}
            scroll={{ y: 180 }}
            pagination={false}
          />
        </div>
      </div>
    );
  }
}

export default Params;
