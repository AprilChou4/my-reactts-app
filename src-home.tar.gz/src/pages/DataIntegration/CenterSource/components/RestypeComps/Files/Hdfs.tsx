import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';
import TimeZoneSelect from '@components/TimeZoneSelect';
import TimeZoneTips from '../../TimeZoneTips';
import {
  filePathRegExp,
  needNoSpace,
  portValidator
} from '../../../consts/pattern';
import { transJsonParse } from '@utils/common';
import SystemSelect from '../../../components/SystemSelect';
import styles from '../index.less';

const TextArea = Input.TextArea;
const FormItem = Form.Item;

interface IProps {
  form: any;
  values?: any;
}
interface IState {}

class Hdfs extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator },
      values
    } = this.props;
    const [ip, port] = _.split(_.get(values, 'url', ''), ':');
    const { filePath } = transJsonParse(_.get(values, 'spec.union', '{}'));

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: '请输入不超过255的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>

          <FormItem label="所属业务系统" required>
            {getFieldDecorator('tagId', {
              initialValue: values.tagId,
              rules: [{ required: true, message: '业务系统不能为空' }]
            })(<SystemSelect />)}
          </FormItem>

          <FormItem label="服务器地址">
            {getFieldDecorator('ip', {
              initialValue: ip,
              rules: [...needNoSpace('服务器地址')]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="服务器端口" required>
            {getFieldDecorator('port', {
              initialValue: port,
              rules: [portValidator]
            })(<Input placeholder="端口号范围：“1025～65534”" size="large" />)}
          </FormItem>
          <FormItem label="用户名">
            {getFieldDecorator('username', {
              initialValue: _.get(values, 'spec.username', ''),
              rules: [...needNoSpace('用户名')]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="文件目录相对路径">
            {getFieldDecorator('url', {
              initialValue: filePath,
              rules: [
                {
                  required: true,
                  pattern: filePathRegExp,
                  message: `请输入正确的解析路径!`
                }
              ]
            })(<Input placeholder="例: path/path/path" size="large" />)}
          </FormItem>
          <TimeZoneSelect
            formKey="timezone"
            size="large"
            label={<TimeZoneTips />}
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default Hdfs;
