import React, { Component } from 'react';
import { Form, Input, Tooltip } from 'sup-ui';
import { needNoSpace } from '../../../consts/pattern';
import SystemSelect from '../../../components/SystemSelect';
import Icon from '@components/Icon';
import styles from '../index.less';

const TextArea = Input.TextArea;
const FormItem = Form.Item;

interface IProps {
  form: any;
  values?: any;
}

interface IState {}

class Mqtt extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator },
      values
    } = this.props;

    return (
      <div className={styles.container} style={{ minHeight: 490 }}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: '请输入不超过255的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>

          <FormItem label="所属业务系统" required>
            {getFieldDecorator('tagId', {
              initialValue: values.tagId,
              rules: [{ required: true, message: '业务系统不能为空' }]
            })(<SystemSelect />)}
          </FormItem>

          <FormItem
            label={
              <span>
                服务器地址
                <Tooltip
                  placement="top"
                  overlayStyle={{
                    maxWidth: 'unset'
                  }}
                  title="格式tcp://ip:port"
                >
                  <Icon type="circle-help" style={{ verticalAlign: '-3px' }} />
                </Tooltip>
              </span>
            }
          >
            {getFieldDecorator('url', {
              initialValue: values.url,
              rules: [
                ...needNoSpace('服务器地址'),
                {
                  pattern: /^tcp:\/\/([\w.]+\/?)(:\d{4,5})$/,
                  message: '以tcp开头，端口号结束的服务器地址'
                }
              ]
            })(<Input size="large" placeholder="tcp://ip:port" />)}
          </FormItem>
        </Form>
      </div>
    );
  }
}

export default Mqtt;
