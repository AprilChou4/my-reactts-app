import React, { Component } from 'react';
import { Form, Input, Select } from 'sup-ui';
import TimeZoneSelect from '@components/TimeZoneSelect';
import TimeZoneTips from '../../TimeZoneTips';
import { transJsonParse } from '@utils/common';
import { postgresServerVersionList } from '../../../consts/columns';
import { needNoSpace } from '../../../consts/pattern';
import SystemSelect from '../../../components/SystemSelect';
import ConnectType from '../components/connectType';
import styles from '../index.less';

const TextArea = Input.TextArea;
const FormItem = Form.Item;
const Option = Select.Option;

interface IProps {
  form: any;
  values?: any;
}

interface IState {}

class Postgres extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator },
      values
    } = this.props;

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源版本">
            {getFieldDecorator('version', {
              initialValue: _.get(values, 'spec.version', '1')
            })(
              <Select
                size="large"
                getPopupContainer={triggerNode =>
                  triggerNode.parentElement as HTMLElement
                }
              >
                {postgresServerVersionList.map((option: any) => (
                  <Option value={option.id} key={option.id}>
                    {option.showName}
                  </Option>
                ))}
              </Select>
            )}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 255, message: '请输入不超过255的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>

          <FormItem label="所属业务系统" required>
            {getFieldDecorator('tagId', {
              initialValue: values.tagId,
              rules: [{ required: true, message: '业务系统不能为空' }]
            })(<SystemSelect />)}
          </FormItem>
          <ConnectType
            getFieldDecorator={getFieldDecorator}
            initValue={values}
            type="postgres"
          />

          <TimeZoneSelect
            formKey="timezone"
            size="large"
            label={<TimeZoneTips />}
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default Postgres;
