import React, { Fragment } from 'react';
import {
  Form,
  Tabs,
  Radio,
  TimePicker,
  Input,
  Button,
  Icon,
  Divider,
  Table
} from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import DialogModal from '@components/Modal/Dialog';
// import { sepNumber, bytesToSize } from '@utils/common';
import moment from 'moment';
import styles from './index.less';
// import CustomPaging from '@components/CustomPaging';
import { TableCellText } from '@components/Table';
import CollectStatus from '@pages/Metadata/MetadataCollect/components/CollectStatus';
import { inject, observer } from 'mobx-react';
import {
  collectCycleList,
  collectStrategyList
} from '@pages/Metadata/consts/enum';
import CustomPaging from '@components/CustomPaging';

interface IProps extends FormComponentProps {
  collectStore?: any;
}

interface IState {}

const FormItem = Form.Item;
const { TabPane } = Tabs;
const RadioGroup = Radio.Group;
const { TextArea } = Input;

@inject('collectStore')
@observer
class DataSourceInfoCollect extends React.Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  private getExprInitValue = (expr: string) => {
    if (expr) {
      const [second, minute, hour] = expr.split(' ');
      return moment(`${hour}:${minute}:${second}`, 'H:m:s');
    }

    return moment('01:00', 'HH:mm');
  };

  public async componentDidMount() {
    const { scheduleId } = this.props.collectStore;

    //scheduleId不存在，未创建采集计划
    if (!scheduleId) {
      return;
    }

    await this.props.collectStore.getCollectInfo();
    await this.props.collectStore.getList();
  }

  public renderFileSize = (size: string): any => {
    const [n, unit] = _.split(size, /(?=([A-Z]{1,2})$)/g);

    return (
      <Fragment>
        {n} <i>{unit}</i>
      </Fragment>
    );
  };

  // public handleTabsChange = (key: string) => {};

  public handleSubmit = () => {
    const { form, collectStore } = this.props;
    const {
      info: { id, name }
    } = collectStore;
    form.validateFields((errors, values) => {
      if (errors) {
        return;
      }

      const { collectPeriod, expr, adaptType, comment } = values;

      const params = {
        id,
        name,
        collectPeriod,
        expr: expr.format('0 m H * * ?'),
        adaptType,
        comment: comment || ''
      };

      collectStore.updateInfo(params);
    });
  };
  public handleCancel = () => {
    this.props.collectStore.handleVisible();
  };
  /**
   * 采集历史记录点击分页
   * @param v
   */
  public handleTableChange = (pagination: any) => {
    this.props.collectStore.updateSearchParams({
      pageIndex: pagination.current,
      pageSize: pagination.pageSize
    });
  };
  public render() {
    const {
      form: { getFieldDecorator }
    } = this.props;

    const {
      scheduleId,
      modalLoading,
      tableLoading,
      invoking,
      info,
      list,
      count,
      searchParams,
      handleCollect,
      handleInvokeCollect
    } = this.props.collectStore;
    const columns = [
      {
        title: '采集时间',
        dataIndex: 'collectTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        render: (text: string) => (
          <TableCellText text={moment(text).format('YYYY-MM-DD HH:mm:ss')} />
        )
      },
      {
        title: '采集状态',
        dataIndex: 'collectStatus',
        width: 100,
        className: 'ellipsis-hide',
        render: (value: string) => <CollectStatus value={value} />
      },
      {
        title: '标识码',
        dataIndex: 'collectMsg',
        width: 180,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      }
    ];

    return (
      <DialogModal
        title={'数据源信息采集'}
        visible
        loading={modalLoading}
        onOk={this.handleSubmit}
        onCancel={this.handleCancel}
        width={900}
      >
        <div className={styles.container}>
          {/* <div className={styles.count}>
            <ul className={styles.overview}>
              <li>
                <span>物理表</span>
                <p>{sepNumber(1081)}</p>
              </li>
              <li>
                <span>视图</span>
                <p>{sepNumber(81)}</p>
              </li>
              <li>
                <span>记录数</span>
                <p>{sepNumber(57168)}</p>
              </li>
              <li>
                <span>存储量</span>
                <p>{this.renderFileSize(bytesToSize(8165123))}</p>
              </li>
            </ul>
          </div> */}
          <Tabs type="card">
            <TabPane tab="元数据采集" key="collect">
              <div className={styles.containerCollect}>
                <div className={styles.form}>
                  <Form colon={false} className={styles.formWrapper}>
                    <FormItem label="采集周期">
                      {getFieldDecorator('collectPeriod', {
                        initialValue: info.collectPeriod || 'day'
                      })(
                        <RadioGroup>
                          {collectCycleList.map((item: any) => (
                            <Radio key={item.key} value={item.key}>
                              {item.showName}
                            </Radio>
                          ))}
                        </RadioGroup>
                      )}
                    </FormItem>
                    <FormItem label="采集时间">
                      {getFieldDecorator('expr', {
                        initialValue: this.getExprInitValue(info.expr),
                        rules: [{ required: true, message: '请选择采集时间' }]
                      })(<TimePicker allowClear={false} format="HH:mm" />)}
                    </FormItem>
                    <FormItem label="采集策略">
                      {getFieldDecorator('adaptType', {
                        initialValue: info.adaptType || 'all'
                      })(
                        <RadioGroup>
                          {collectStrategyList.map((item: any) => (
                            <Radio key={item.key} value={item.key}>
                              {item.showName}
                            </Radio>
                          ))}
                        </RadioGroup>
                      )}
                    </FormItem>
                    <FormItem label="描述">
                      {getFieldDecorator('comment', {
                        initialValue: info.comment,
                        rules: [{ max: 255, message: '请输入不超过255的字符' }]
                      })(<TextArea autosize={{ minRows: 3, maxRows: 3 }} />)}
                    </FormItem>
                  </Form>
                  <div className={styles.footbutton}>
                    {info.sheduleStatus === '1' ? (
                      <Button
                        disabled={invoking ? true : false}
                        onClick={handleCollect}
                      >
                        <Icon type="pause-circle" theme="twoTone" />
                        停用
                      </Button>
                    ) : (
                      <Button onClick={handleCollect}>
                        <Icon type="play-circle" theme="twoTone" />
                        启用
                      </Button>
                    )}
                    <Button
                      onClick={handleInvokeCollect}
                      disabled={
                        !scheduleId || info.sheduleStatus === '0' || invoking
                      }
                    >
                      {invoking ? '采集中' : '立即采集'}
                    </Button>
                  </div>
                </div>
                <Divider type="vertical" />
                <div
                  className={`${styles.table} mp-table-gray-light mp-table-grow`}
                >
                  <Table
                    loading={tableLoading}
                    columns={columns}
                    dataSource={list}
                    onChange={this.handleTableChange}
                    rowKey={() => _.uniqueId('exec_')}
                    pagination={{
                      total: count,
                      showTotal: total => `共 ${total} 条`,
                      current: searchParams.pageIndex,
                      pageSize: searchParams.pageSize,
                      itemRender: CustomPaging
                    }}
                    scroll={{
                      y: 'calc(100% - 36px)'
                    }}
                  />
                </div>
              </div>
            </TabPane>
            {/* <TabPane tab="数据同步" key="sync" /> */}
          </Tabs>
        </div>
      </DialogModal>
    );
  }
}

export default Form.create<IProps>({
  name: 'collect'
})(DataSourceInfoCollect);
