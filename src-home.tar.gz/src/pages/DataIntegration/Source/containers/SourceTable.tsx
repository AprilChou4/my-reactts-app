import React, { Component, Fragment } from 'react';
import { inject, observer } from 'mobx-react';
import { Table, Divider } from 'sup-ui';
import memoizeOne from 'memoize-one';
import moment from 'moment';
import Icon from '@components/Icon';
import CustomPaging from '@components/CustomPaging';
import TipsDelete from '@components/Modal/TipsDelete';
import { TableCellText } from '@components/Table';
import TableFilter from '@components/TableFilter';
import { subCatalogSetMap, sourceNameMap } from '../consts/typeMap';
import styles from '../index.less';

interface IProps {
  store?: any;
}
interface IState {}

@inject('store')
@observer
class SourceTable extends Component<IProps, IState> {
  private readonly catalogMap: any;
  private readonly sourceNameMap: any;
  public constructor(props: IProps) {
    super(props);

    this.catalogMap = subCatalogSetMap();
    this.sourceNameMap = sourceNameMap();
  }

  public getSubCatalogEnum = (dataIndex: string): any => {
    const {
      selectedItem: { value, category }
    } = this.props.store;

    if (dataIndex === 'status') {
      return [
        { key: '1', showName: '已连通', disable: false },
        { key: '0', showName: '失败', disable: false }
      ];
    }

    if (dataIndex === 'subCatalog') {
      const key = category === 'all' ? 'all' : value;

      return _.map(this.catalogMap[key], item => ({
        key: item.key,
        showName: item.name,
        disable: item.disable
      }));
    }

    return [];
  };

  public getColumnSearchProps = (dataIndex: string, isEnum: boolean) => ({
    filterDropdown: ({ setSelectedKeys, confirm, selectedKeys }: any) => (
      <TableFilter
        isEnum={isEnum}
        enumData={this.getSubCatalogEnum(dataIndex)}
        confirm={confirm}
        selectedKeys={selectedKeys}
        setSelectedKeys={setSelectedKeys}
      />
    )
  });

  public handleTableChange = (pagination: any, filters: any, sorter: any) => {
    //页码
    const { current, pageSize } = pagination;
    const pageFilter = {
      pageNum: current,
      pageSize
    };

    //筛选filters
    const { name, subCatalog, status } = filters;
    let nameFilter = { opr: '', val: [] };
    let subFilter = { opr: '', val: [] };
    let statusFilter = { opr: '', val: [] };

    if (name && name.length) {
      nameFilter = {
        opr: 'like',
        val: name
      };
    }

    if (subCatalog && subCatalog.length) {
      subFilter = {
        opr: 'in',
        val: subCatalog
      };
    }

    if (status && status.length) {
      statusFilter = {
        opr: '=',
        val: status
      };
    }

    //排序sorter
    let orderBy = { name: ['update_time'], order: false };

    if (!_.isEmpty(sorter)) {
      orderBy = {
        name: ['update_time'],
        order: sorter.order
      };
    }

    this.props.store.updateSearchParams({
      pageFilter,
      name: nameFilter,
      subCatalog: subFilter,
      status: statusFilter,
      orderBy
    });
  };

  public handleSourceEdit = (record: any) => {
    const { updateCurrentSourceInfo, updateFromData } = this.props.store;
    const { subCatalog, catalog } = record;
    const info = {
      catalog,
      key: subCatalog,
      name: this.sourceNameMap[subCatalog]
    };

    updateFromData(record);
    updateCurrentSourceInfo(info);
  };

  public handleSourceDelete = (id: string, name: string) => {
    const { deleteSource } = this.props.store;
    const config = {
      title: '删除',
      content: `确定删除 ${name} 数据源？`,
      onOk: deleteSource.bind(this, [id])
    };
    TipsDelete(config);
  };

  public getColumns = () => {
    const {
      searchParams: { name, orderBy, subCatalog, status }
    } = this.props.store;

    return [
      {
        title: '数据源名称',
        dataIndex: 'name',
        width: 240,
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <a
            onClick={() => {
              this.handleSourceEdit(record);
            }}
          >
            <TableCellText text={text} />
          </a>
        ),
        filteredValue: name.val,
        ...this.getColumnSearchProps('name', false)
      },
      {
        title: '类型',
        dataIndex: 'subCatalog',
        width: 120,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />,
        filteredValue: subCatalog.val,
        ...this.getColumnSearchProps('subCatalog', true)
      },
      {
        title: '链接信息',
        dataIndex: 'url',
        width: 240,
        className: 'ellipsis-hide',
        render: (_value: any, record: any) => {
          const { url, spec } = record;
          const text = `${url}/${spec.dbName} 用户名：${spec.username}`;

          return <TableCellText text={text} />;
        }
      },
      {
        title: '描述',
        dataIndex: 'description',
        width: 240,
        className: 'ellipsis-hide',
        render: (text: string) => <TableCellText text={text} />
      },
      {
        title: '更新时间',
        dataIndex: 'updateTime',
        width: 180,
        className: 'ellipsis-hide dateTime',
        sorter: true,
        sortOrder: orderBy.order,
        render: (text: string) => (
          <TableCellText
            text={
              !_.isEmpty(text) ? moment(text).format('YYYY-MM-DD HH:mm:ss') : ''
            }
          />
        )
      },
      {
        title: '连通状态',
        dataIndex: 'status',
        width: 100,
        className: 'ellipsis-hide',
        render: (value: any) => {
          switch (value) {
            case '1':
              return (
                <div className={styles.status}>
                  <Icon type="success" width={11} />
                  <div className={styles.success}>已连通</div>
                </div>
              );
            case '0':
              return (
                <div className={styles.status}>
                  <Icon type="error" width={8} />
                  <div className={styles.error}>失败</div>
                </div>
              );
            default:
              return (
                <div className={styles.status}>
                  <Icon type="error" width={8} />
                  <div className={styles.notAdmitted}>未连通</div>
                </div>
              );
          }
        },
        filteredValue: status.val,
        ...this.getColumnSearchProps('status', true)
      },
      {
        title: '操作',
        dataIndex: 'operation',
        fixed: 'right',
        align: 'center',
        width: 260,
        render: (_value: any, record: any) => (
          <Fragment>
            <div className="more">
              <Icon type="ellipsis" />
            </div>
            <div className="operator">
              <a onClick={() => this.handleSourceEdit(record)}>编辑</a>
              <Divider type="vertical" />
              <a
                onClick={() => this.handleSourceDelete(record.id, record.name)}
              >
                删除
              </a>
            </div>
          </Fragment>
        )
      }
    ];
  };

  public getFilterColumns = memoizeOne(
    (columns: any[], checkedColumns: string[]): any => {
      const filterColumns = _.map(columns, column =>
        _.includes(checkedColumns, column.dataIndex) ? { ...column } : null
      ).filter(Boolean);

      //operation列
      filterColumns.push({ ..._.last(columns) });

      let totalWidthX = 50;

      _.forEach(
        filterColumns,
        column =>
          column.width &&
          _.isNumber(column.width) &&
          (totalWidthX += column.width)
      );

      if (filterColumns.length > 1) {
        //将倒数第二列的宽度置为auto
        filterColumns[filterColumns.length - 2]['width'] = 'auto' as any;
      }

      return { filterColumns, totalWidthX };
    }
  );

  public render() {
    const {
      selectedRowKeys,
      updateSelectedRowKeys,
      count,
      list,
      searchParams,
      loading,
      checkedColumns
    } = this.props.store;
    const rowSelection = {
      columnWidth: 50,
      selectedRowKeys,
      onChange: updateSelectedRowKeys,
      hideDefaultSelections: true
    };

    const columns = this.getColumns();
    const { filterColumns, totalWidthX } = this.getFilterColumns(
      columns,
      checkedColumns
    );

    return (
      <div className={`${styles.table} mp-table-white mp-table-grow`}>
        <Table
          loading={loading}
          rowSelection={rowSelection}
          columns={filterColumns}
          dataSource={list}
          onChange={this.handleTableChange}
          rowKey="id"
          pagination={{
            current: searchParams.pageFilter.pageNum,
            pageSize: searchParams.pageFilter.pageSize,
            showTotal: total => `共${total}条`,
            total: count,
            itemRender: CustomPaging,
            pageSizeOptions: ['20', '50', '100'],
            showSizeChanger: true,
            showQuickJumper: true
          }}
          scroll={{ x: totalWidthX, y: 'calc(100% - 52px)' }}
        />
      </div>
    );
  }
}

export default SourceTable;
