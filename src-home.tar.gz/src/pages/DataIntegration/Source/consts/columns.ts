export const dataSourceColumns: any = [
  {
    title: '数据源名称',
    dataIndex: 'name',
    check: true
  },
  {
    title: '类型',
    dataIndex: 'subCatalog',
    check: true
  },
  {
    title: '描述',
    dataIndex: 'description',
    check: true
  },
  {
    title: '链接信息',
    dataIndex: 'url',
    check: false
  },
  {
    title: '更新时间',
    dataIndex: 'updateTime',
    check: true
  },
  {
    title: '连通状态',
    dataIndex: 'status',
    check: true
  }
];

export const sqlServerVersionList = [
  { id: '0', showName: 'SQL Server 2000' },
  { id: '1', showName: 'SQL Server 2000以上' }
];
