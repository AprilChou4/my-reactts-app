import React, { Component } from 'react';
import { Form, Input } from 'sup-ui';

import TimeZoneSelect from '@components/TimeZoneSelect';
import TimeZoneTips from '../../TimeZoneTips';
import { transJsonParse } from '@utils/common';
import { needNoSpace, portValidator } from '../../../consts/pattern';
import styles from '../index.less';

const TextArea = Input.TextArea;
const FormItem = Form.Item;

interface IProps {
  form: any;
  values?: any;
}

interface IState {}

class MySql extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const {
      form: { getFieldDecorator },
      values
    } = this.props;
    const [ip, port] = _.split(_.get(values, 'url', ''), ':');

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 100, message: '请输入不超过100的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>
          <FormItem label="服务器地址">
            {getFieldDecorator('ip', {
              initialValue: ip,
              rules: [...needNoSpace('服务器地址')]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="服务器端口" required>
            {getFieldDecorator('port', {
              initialValue: port,
              rules: [portValidator]
            })(<Input placeholder="端口号范围：“1025～65534”" size="large" />)}
          </FormItem>
          <FormItem label="数据库名称">
            {getFieldDecorator('dbName', {
              initialValue: _.get(values, 'spec.dbName', ''),
              rules: [...needNoSpace('数据库名称')]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="用户名">
            {getFieldDecorator('username', {
              initialValue: _.get(values, 'spec.username', ''),
              rules: [...needNoSpace('用户名')]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="密码">
            {getFieldDecorator('password', {
              initialValue: _.get(values, 'spec.password', ''),
              rules: [...needNoSpace('密码')]
            })(
              <Input.Password
                visibilityToggle={false}
                autoComplete="new-password"
                size="large"
              />
            )}
          </FormItem>
          <TimeZoneSelect
            formKey="timezone"
            size="large"
            label={<TimeZoneTips />}
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default MySql;
