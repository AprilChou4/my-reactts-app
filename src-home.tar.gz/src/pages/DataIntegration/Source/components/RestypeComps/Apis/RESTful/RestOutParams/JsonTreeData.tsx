import React, { Component } from 'react';
import JSONTree from 'react-json-tree';
import { message } from 'sup-ui';
import uuid from '@utils/uuid';

interface IProps {
  dataSource: any;
  verificationParams: (v: any) => void;
}
interface IState {}

const getRelateKeys = (
  current: any,
  path: string,
  result: any[],
  isLast: boolean,
  lastName: string
) => {
  if (_.isArray(current)) {
    message.warning('父节点不能为数组');
    throw new Error('不支持');
  }

  if (isLast) {
    result.push({
      paramsName: lastName,
      value: current,
      paramsDataType: 'String',
      path,
      key: uuid(6)
    });
  }
};

class JsonTreeData extends Component<IProps, IState> {
  public result: any[] = [];
  public selectedItemType = 0;

  // 获取当前json的子节点
  public getCurrentData = (s: any, p: any) => {
    const lastName: any = _.last(p);

    let i = 0,
      current = s;

    while (i < p.length) {
      current = current[p[i]];
      i++;
    }

    return {
      current,
      lastName
    };
  };

  public getSelectedItemRelateKeys = (
    source: any, //当前json
    paths: any[], //当前用户选中的json的集合[]
    i = 0,
    result = []
  ) => {
    //root为默认根基点
    const isRoot = paths[i] === 'root';
    const { current, lastName } = isRoot
      ? source
      : this.getCurrentData(source, paths.slice(1, i + 1));

    //返回当前节点的json路径
    const path = isRoot ? 'root' : paths.slice(0, i).join('/');

    i++;

    //判断当前的i  是否已经循环到选中的json节点
    const isLast = i === paths.length;
    //如果时选中的节点
    if (isLast) {
      //判断选中项的类型
      this.selectedItemType = _.isArray(current)
        ? 1
        : _.isPlainObject(current)
        ? 2
        : 0;
    }

    //保存json路径上的字段
    getRelateKeys(current, path, result, isLast, lastName);

    //当i还小于paths话, 说明json还没有走到被选中项
    if (i < paths.length) {
      this.getSelectedItemRelateKeys(source, paths, i, result);
    }

    return { result, selectedItemType: this.selectedItemType };
  };

  public handleJson = (e: any, key: string[], childType: string) => {
    e.stopPropagation();
    const { dataSource, verificationParams } = this.props;

    if (childType === 'Array' || childType === 'Object') {
      message.warning('不能选择数组或对象, 选择的节点必须为单节点!');
      return;
    }

    try {
      const paths = key.reverse();
      const { result } = this.getSelectedItemRelateKeys(dataSource, paths);

      this.result = result;
    } catch (error) {
      console.error(error);
    }

    verificationParams(this.result);
    this.forceUpdate();
  };

  public handleItem = (e: any) => {
    e.stopPropagation();
  };

  public render() {
    const { dataSource } = this.props;

    return (
      <JSONTree
        data={dataSource}
        getItemString={(
          _type: any,
          _data: any,
          itemType: any,
          itemString: any
        ) => {
          return (
            <span style={{ cursor: 'text' }} onClick={this.handleItem}>
              {itemType} - {itemString}
            </span>
          );
        }}
        invertTheme={false}
        labelRenderer={(key: string[], childType: string) => (
          <span
            style={{ cursor: 'pointer' }}
            onClick={e => {
              this.handleJson(e, key, childType);
            }}
          >
            {key[0]}
          </span>
        )}
        shouldExpandNode={() => true}
      />
    );
  }
}

export default JsonTreeData;
