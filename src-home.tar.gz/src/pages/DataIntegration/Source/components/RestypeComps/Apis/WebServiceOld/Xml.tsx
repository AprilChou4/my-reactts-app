import React, { Component } from 'react';
import XmlEditor from '@components/ScriptEditor/XmlEditor';

interface IProps {
  value?: any;
  onChange?: any;
}

interface IState {}

class Xml extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
  }

  public render() {
    const { value, onChange } = this.props;
    return <XmlEditor height={280} xmlValue={value} onChange={onChange} />;
  }
}

export default Xml;
