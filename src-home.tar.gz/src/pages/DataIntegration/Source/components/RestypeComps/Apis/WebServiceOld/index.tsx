import React, { Component, createRef, Fragment } from 'react';
import { Form, Switch, Input, InputNumber, Radio } from 'sup-ui';
import { observer } from 'mobx-react';
import TimeZoneSelect from '@components/TimeZoneSelect';
import TimeZoneTips from '../../../TimeZoneTips';
import Params from './Params';
import Xml from './Xml';
import { filePathRegExp, needNoSpace } from '../../../../consts/pattern';
import styles from './index.less';
import { transJsonParse } from '@utils/common';

const FormItem = Form.Item;
const TextArea = Input.TextArea;

interface IProps {
  form: any;
  values: any;
}
interface IState {}

@observer
class WebServiceOld extends Component<IProps, IState> {
  public inParamsRef: any;
  public outParamsRef: any;
  public constructor(props: IProps) {
    super(props);

    this.inParamsRef = createRef();
    this.outParamsRef = createRef();
  }

  public getExtraParams = () => {
    let inParams = {};
    const outParams = this.outParamsRef.current.validateDatas();

    if (this.inParamsRef.current) {
      inParams = this.inParamsRef.current.validateDatas();

      if (!inParams) {
        return;
      }
    }

    if (!outParams) {
      return;
    }

    //inParamsType(0/1), inParams, outParamsType(0/1), outParams
    return {
      ...inParams,
      ...outParams
    };
  };

  public render() {
    const {
      form: { getFieldDecorator, getFieldsValue },
      values
    } = this.props;
    const {
      pathResolver,
      maxTransferNum,
      authType: initAuth = 0,
      inMode: initMode = 1,
      username,
      password,
      method,
      nameSpace,
      requestXml,
      propertyName,
      inParamsType,
      outParamsType,
      inParams = [],
      outParams = []
    } = transJsonParse(_.get(values, 'spec.union', '{}'));
    const { authType = initAuth, inMode = initMode } = getFieldsValue([
      'authType',
      'inMode'
    ]);

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 100, message: '请输入不超过100的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>
          <FormItem label="地址">
            {getFieldDecorator('url', {
              initialValue: values.url,
              rules: [
                {
                  required: true,
                  whitespace: true,
                  message: '请输入正确的地址'
                }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="解析路径">
            {getFieldDecorator('pathResolver', {
              initialValue: pathResolver,
              rules: [
                {
                  required: true,
                  pattern: filePathRegExp,
                  message: `请输入正确的解析路径!`
                }
              ]
            })(<Input placeholder="例: path/path/path" size="large" />)}
          </FormItem>
          <FormItem label="单次最大允许数据量">
            {getFieldDecorator('maxTransferNum', {
              initialValue: maxTransferNum || 2000
            })(<InputNumber min={0} size="large" />)}
          </FormItem>
          <FormItem label="http授权">
            {getFieldDecorator('authType', {
              valuePropName: 'checked',
              initialValue: !!initAuth
            })(<Switch />)}
          </FormItem>
          <div style={{ display: authType ? 'block' : 'none' }}>
            <FormItem label="用户名">
              {getFieldDecorator('username', {
                initialValue: username
              })(<Input size="large" />)}
            </FormItem>
            <FormItem label="密码">
              {getFieldDecorator('password', {
                initialValue: password
              })(
                <Input.Password
                  visibilityToggle={false}
                  autoComplete="new-password"
                  size="large"
                />
              )}
            </FormItem>
          </div>
          {inMode === 1 && (
            <Fragment>
              <FormItem label="方法" required>
                {getFieldDecorator('method', {
                  initialValue: method,
                  rules: [...needNoSpace('方法')]
                })(<Input size="large" />)}
              </FormItem>
              <FormItem label="命名空间" required>
                {getFieldDecorator('nameSpace', {
                  initialValue: nameSpace,
                  rules: [...needNoSpace('命名空间')]
                })(<Input size="large" />)}
              </FormItem>
            </Fragment>
          )}
          <FormItem label="入参模式">
            {getFieldDecorator('inMode', {
              initialValue: initMode
            })(
              <Radio.Group>
                <Radio value={1}>列表模式</Radio>
                <Radio value={2}>XML模式</Radio>
              </Radio.Group>
            )}
          </FormItem>
          {inMode === 1 && (
            <Fragment>
              <FormItem label="参数名称">
                {getFieldDecorator('propertyName', {
                  initialValue: propertyName
                })(<Input size="large" />)}
              </FormItem>
              <Params
                type="in"
                title="入参"
                dataSource={inParams}
                open={inParamsType}
                ref={this.inParamsRef}
              />
            </Fragment>
          )}
          {inMode === 2 && (
            <FormItem label="XML文本(注:变量以#{}标识)" required>
              {getFieldDecorator('requestXml', {
                initialValue: requestXml
              })(<Xml />)}
            </FormItem>
          )}
          <Params
            type="out"
            title="出参"
            dataSource={outParams}
            open={outParamsType}
            ref={this.outParamsRef}
          />
          <TimeZoneSelect
            formKey="timezone"
            size="large"
            label={<TimeZoneTips />}
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default WebServiceOld;
