export const modeTypes = [
  { key: 1, name: '列表模式' },
  { key: 2, name: 'XML模式' }
];

export const paramsTypes = [
  { key: 0, name: '无参数' },
  { key: 1, name: '解析' },
  { key: 2, name: '不解析' }
];
