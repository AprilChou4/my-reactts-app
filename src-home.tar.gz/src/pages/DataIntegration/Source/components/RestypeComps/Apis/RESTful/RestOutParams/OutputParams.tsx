import React, { Component } from 'react';
import Icon from '@components/Icon';
import { Table, Input, Form, Select, message, Tooltip } from 'sup-ui';
import uuid from '@utils/uuid';
import TipsDelete from '@components/Modal/TipsDelete';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
import { AddBtn, DelBtn } from '@components/Button';
import { webServiceType } from '@consts/dataTypes';
import styles from './index.less';

const EditableContext = React.createContext({});
const { Option } = Select;

interface IProps {
  record: any;
  title: string;
  dataSource: any;
  editable: boolean;
  dataIndex: string;
}
interface IState {}

class EditableCell extends Component<IProps, IState> {
  public form: any;

  public renderCell = (form: any) => {
    this.form = form;
    const { dataIndex, record } = this.props;
    const { getFieldDecorator } = this.form;

    if (dataIndex === 'paramsDataType') {
      return (
        <Form.Item>
          {this.form.getFieldDecorator(`${dataIndex}_${record.key}`, {
            rules: [
              {
                required: true
              }
            ],
            initialValue: record[dataIndex] || 'String'
          })(
            <Select dropdownMatchSelectWidth={false}>
              {_.map(webServiceType, (item: string) => (
                <Option key={item} value={item}>
                  {item}
                </Option>
              ))}
            </Select>
          )}
        </Form.Item>
      );
    }
    return (
      <Form.Item>
        {getFieldDecorator(`${dataIndex}_${record.key}`, {
          rules: [
            {
              required: true
            }
          ],
          initialValue: record[dataIndex],
          validateTrigger: ['onChange', 'onBlur']
        })(<Input disabled={!_.get(record, 'edit', true)} />)}
      </Form.Item>
    );
  };

  public render() {
    const { editable, children, ...restProps } = _.omit(this.props, [
      'dataIndex',
      'title',
      'record',
      'index',
      'dataSource'
    ]);

    return (
      <td {...restProps}>
        {editable ? (
          <EditableContext.Consumer>{this.renderCell}</EditableContext.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

interface IRequestProps extends FormComponentProps {
  dataSource: any[];
  addStatus?: boolean;
  deleteStatus?: boolean;
  updateVerificationParams: (value: any) => void;
}
interface IRequestState {
  dataSource: any[];
  selectRowKeys: string[] | number[];
}

class OutputParams extends Component<IRequestProps, IRequestState> {
  public columns: any;
  public constructor(props: IRequestProps) {
    super(props);
    this.columns = [
      {
        title: '参数名称',
        width: 'auto',
        dataIndex: 'paramsName',
        className: 'ellipsis-hide',
        render: (text: string, record: any) => (
          <Tooltip placement="top" title={`路径: ${record.path}`}>
            <span>{text}</span>
          </Tooltip>
        )
      },
      {
        title: '参数类型',
        width: 120,
        dataIndex: 'paramsDataType',
        editable: true
      },
      {
        title: '默认值',
        width: 120,
        dataIndex: 'value',
        editable: true
      },
      {
        title: '操作',
        width: 60,
        align: 'center',
        render: (_value: any, record: any) => (
          <div style={{ height: '30px', padding: '5px 0' }}>
            {_.get(record, 'edit', true) && (
              <Icon
                type="remove"
                width={22}
                onClick={() => this.handleRemove(record)}
              />
            )}
          </div>
        )
      }
    ];

    this.state = {
      dataSource: _.cloneDeep(props.dataSource),
      selectRowKeys: []
    };
  }

  public componentDidUpdate(prevProps: any) {
    const { dataSource } = this.props;
    const isDataSource = _.isEqual(dataSource, prevProps.dataSource);

    if (!isDataSource) {
      this.setState({
        dataSource
      });
    }
  }

  public handleAdd = () => {
    const { dataSource } = this.state;
    const { validateFieldsAndScroll } = this.props.form;
    validateFieldsAndScroll((error: any) => {
      if (error) {
        message.error('参数名称或者参数类型不能为空!');
        return;
      }

      const newData = {
        key: uuid(6),
        value: '',
        paramsName: ``,
        paramsDataType: `String`
      };
      this.setState({
        dataSource: [...dataSource, newData]
      });
    });
  };

  public handleRemove = (record: any) => {
    const config = {
      title: '删除该告警信息？',
      content: '请确认删除',
      onOk: () => {
        const { dataSource } = this.state;
        this.setState(
          {
            dataSource: _.filter(
              dataSource,
              (item: any) => item.key !== record.key
            ),
            selectRowKeys: []
          },
          () => {
            this.props.updateVerificationParams(this.state.dataSource);
          }
        );
      }
    };

    TipsDelete(config);
  };

  public handleSelectRowKeys = (selectRowKeys: string[] | number[]) => {
    this.setState({
      selectRowKeys
    });
  };

  public handleAllRemove = () => {
    const { dataSource, selectRowKeys } = this.state;
    this.setState(
      {
        dataSource: _.filter(
          dataSource,
          (item: any) => !_.includes(selectRowKeys, item.key)
        ),
        selectRowKeys: []
      },
      () => {
        this.props.updateVerificationParams(this.state.dataSource);
      }
    );
  };

  public getParams = () => {
    const { dataSource } = this.state;
    const { form } = this.props;
    let parameter: any;
    let formStatus = false;

    form.validateFields((error: any, values: any) => {
      if (error) {
        formStatus = true;
        return;
      }

      parameter = _.map(dataSource, (i: any) => {
        let item = { key: i.key, path: i.path, paramsName: i.paramsName };
        _.forIn(values, (v: any, k: string) => {
          const keyArr = k.split('_');
          if (i.key === keyArr[1]) {
            item = {
              ...item,
              [keyArr[0]]: v
            };
          }
        });
        return item;
      });
    });

    if (formStatus) {
      return false;
    }

    if (_.isEmpty(parameter)) {
      return parameter;
    }

    return parameter;
  };

  public render() {
    const { dataSource } = this.state;
    const { form, addStatus = true, deleteStatus = true } = this.props;
    const components = {
      body: {
        cell: EditableCell
      }
    };

    const columns = this.columns.map((col: any) => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: (record: any) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          dataSource
        })
      };
    });

    const rowSelection = {
      columnWidth: 40,
      onChange: (selectRowKeys: string[] | number[]) => {
        this.handleSelectRowKeys(selectRowKeys);
      },
      getCheckboxProps: (record: any) => ({
        disabled: !_.get(record, 'edit', true),
        name: record.paramsName
      })
    };

    return (
      <div className={styles.paramsNode}>
        <EditableContext.Provider value={form}>
          <div className={styles.editBtn}>
            {addStatus && <AddBtn onClick={this.handleAdd} />}
            {deleteStatus && <DelBtn onClick={this.handleAllRemove} />}
          </div>

          <Table
            size="small"
            className="mp-table-gray"
            rowSelection={rowSelection}
            components={components}
            rowClassName={() => 'editable-row'}
            dataSource={dataSource}
            columns={columns}
            pagination={false}
            scroll={{ y: 180 }}
            rowKey={(record: any) => record.key}
          />
        </EditableContext.Provider>
      </div>
    );
  }
}

export default Form.create<IRequestProps>()(OutputParams);
