import React, { Component, createRef, Fragment } from 'react';
import {
  Form,
  Switch,
  Row,
  Col,
  Input,
  Select,
  Tooltip,
  Radio,
  Button,
  message
} from 'sup-ui';
import { observer } from 'mobx-react';
import classnames from 'classnames';

import Icon from '@components/Icon';
import XmlEditor from '@components/ScriptEditor/XmlEditor';
import TimeZoneSelect from '@components/TimeZoneSelect';
import TimeZoneTips from '../../../TimeZoneTips';
import Params from './Params';
import NotParseParams from './NotParseParams';

import { popupContainer } from '@utils/propUtil';
import { transJsonParse } from '@utils/common';
import { filePathReg } from '@utils/regUtils';

import { needNoSpace } from '../../../../consts/pattern';
import { webServiceType } from '@consts/dataTypes';
import { paramsTypes, modeTypes } from './webservice.const';

import styles from './index.less';

const FormItem = Form.Item;
const { Option } = Select;
const TextArea = Input.TextArea;

// 解析参数接口
interface IParam {
  name: string;
  type: string;
  required?: number;
  children?: any[];
  childType?: any;
}

interface IProps {
  form: any;
  values: any;
  onParse: any;
  onMethodChange: any;
}
interface IState {
  disabled: boolean; //解析禁用
  parsing: boolean; //解析中
  methods: any[]; //方法列表
  inMode: number;
  inParamsType: number;
  outParamsType: number;
  inParams: any[];
  requestXml: string;
  outParams: any[];
}

@observer
class WebService extends Component<IProps, IState> {
  public inParamsRef: any;
  public outParamsRef: any;
  public constructor(props: IProps) {
    super(props);
    const {
      inParams = [],
      outParams = [],
      outParamsType = 0,
      inMode = 1,
      requestXml = '',
      inParamsType = 1
    } = transJsonParse(_.get(props.values, 'spec.union', '{}'));

    this.state = {
      disabled: !props.values.url,
      inMode,
      requestXml,
      methods: [],
      parsing: false,
      inParamsType,
      outParamsType,
      inParams,
      outParams
    };
    this.inParamsRef = createRef();
    this.outParamsRef = createRef();
  }

  public getExtraParams = () => {
    const { inMode, inParamsType, requestXml, outParamsType } = this.state;
    const inParams =
      inMode === 1 && inParamsType === 1
        ? this.inParamsRef.current.getParams()
        : [];
    const outParams =
      outParamsType === 0 ? [] : this.outParamsRef.current.getParams();

    if (!inParams || !outParams) {
      return;
    }
    return {
      inParams,
      outParams,
      requestXml: inMode === 2 ? requestXml : '',
      inParamsType: inMode === 1 ? inParamsType : 1
    };
  };

  private handleAddressChange = (e: any) => {
    this.setState({
      disabled: !e.target.value
    });
  };

  private handleUrlParse = () => {
    const { disabled } = this.state;
    const { onParse, form } = this.props;
    const url = form.getFieldValue('url');

    if (disabled) {
      return;
    }

    this.setState({
      parsing: true
    });

    onParse(
      url,
      (data: any) => {
        const { methods, nameSpace } = data;
        // 重新解析初始化已配置信息
        this.setState(
          {
            methods,
            parsing: false,
            inMode: 1,
            inParamsType: 1,
            outParamsType: 1,
            inParams: [],
            requestXml: '',
            outParams: []
          },
          () => {
            form.setFieldsValue({
              method: undefined,
              nameSpace,
              inMode: 1,
              inParamsType: true,
              outParamsType: 1,
              pathResolver: undefined
            });
          }
        );

        message.success('解析成功！');
      },
      () => {
        this.setState({
          parsing: false
        });
      }
    );
  };

  private handleMethodChange = (value: any) => {
    //调用测试连接的接口
    const {
      form: { getFieldsValue, setFieldsValue },
      onMethodChange
    } = this.props;
    const { name, description, url, authType, username, password } =
      getFieldsValue();

    const params = {
      name,
      description: description || '',
      catalog: 'api',
      subCatalog: 'webservice',
      namespace: 'default',
      replicate: 0,
      url,
      spec: {
        union: {
          method: value,
          authType: authType ? 1 : 0,
          ...(authType && { username, password }),
          oprType: 2, //区分获取参数调用和测试连接调用
          inParamsType: 0,
          outParamsType: 0
        }
      }
    };

    onMethodChange(params, (data: any) => {
      const { inParams, outParams, pathResolver } = data;

      //将出入参平铺
      const inp = this.flatParams(inParams);
      const outp = this.flatParams(outParams);

      this.setState(
        {
          inMode: 1,
          inParamsType: 1,
          inParams: inp,
          outParamsType: 1,
          outParams: outp
        },
        () => {
          setFieldsValue({
            pathResolver,
            inMode: 1,
            inParamsType: true,
            outParamsType: 1
          });
        }
      );
    });
  };

  private flatParams(params: IParam[], result: any[] = []) {
    _.forEach(params, (param: IParam) => {
      if (param.hasOwnProperty('childType')) {
        const cType =
          _.toLower(param.childType) === 'int' ? 'integer' : param.childType;
        const isBasicType = _.includes(webServiceType, _.upperFirst(cType));

        if (isBasicType) {
          result.push({
            paramsName: param.name,
            paramsDataType: _.upperFirst(cType),
            required: param.required || 1,
            defaultValue: undefined
          });

          return;
        }
      }

      if (
        param.name &&
        !param.hasOwnProperty('childType') &&
        !param.hasOwnProperty('children')
      ) {
        const dataType =
          _.toLower(param.type) === 'int' ? 'integer' : param.type;

        result.push({
          paramsName: param.name,
          paramsDataType: _.upperFirst(dataType),
          required: param.required || 1,
          defaultValue: undefined
        });
      }

      if (param.children && param.children.length) {
        this.flatParams(param.children, result);
      }
    });

    return result;
  }

  private handleInParamsType = (checked: boolean) => {
    this.setState({
      inParamsType: checked ? 1 : 0
    });
  };

  private handleInMode = (e: any) => {
    this.setState({
      inMode: e.target.value
    });
  };

  private handleXmlChange = (xml: any) => {
    this.setState({
      requestXml: xml
    });
  };

  private handleOutParamsType = (e: any) => {
    this.setState({
      outParamsType: e.target.value
    });
  };

  public componentDidMount() {
    //根据url获取方法列表
    const {
      values: { url },
      onParse
    } = this.props;

    if (url) {
      onParse(url, (data: any) => {
        this.setState({
          methods: data.methods || []
        });
      });
    }
  }

  public render() {
    const {
      form: { getFieldDecorator, getFieldsValue },
      values
    } = this.props;
    const {
      disabled,
      parsing,
      methods,
      inMode,
      inParamsType,
      inParams,
      requestXml,
      outParamsType,
      outParams
    } = this.state;
    const {
      authType: initAuth = 0,
      username,
      password,
      method,
      nameSpace,
      pathResolver
    } = transJsonParse(_.get(values, 'spec.union', '{}'));
    const { authType = initAuth } = getFieldsValue(['authType']);

    return (
      <div className={styles.container}>
        <Form>
          <FormItem label="数据源名称" required>
            {getFieldDecorator('name', {
              initialValue: values.name,
              rules: [
                ...needNoSpace('数据源名称'),
                { max: 20, message: '请输入长度不超过20的字符' }
              ]
            })(<Input size="large" />)}
          </FormItem>
          <FormItem label="数据源描述">
            {getFieldDecorator('description', {
              initialValue: values.description,
              rules: [{ max: 100, message: '请输入不超过100的字符' }]
            })(<TextArea autosize={{ minRows: 3, maxRows: 6 }} />)}
          </FormItem>
          <Row gutter={20}>
            <Col span={20}>
              <FormItem
                label={
                  <span className={styles.label}>
                    地址
                    <Tooltip
                      placement="right"
                      title="输入地址后，点击「解析」，可自动进行解析处理"
                      overlayStyle={{ maxWidth: '340px' }}
                    >
                      <Icon type="circle-help" />
                    </Tooltip>
                  </span>
                }
              >
                {getFieldDecorator('url', {
                  initialValue: values.url,
                  rules: [
                    {
                      required: true,
                      whitespace: true,
                      message: '请输入正确的地址'
                    }
                  ]
                })(<Input size="large" onChange={this.handleAddressChange} />)}
              </FormItem>
            </Col>
            <Col span={4}>
              <Button
                disabled={disabled}
                ghost
                size="large"
                className={styles.parse}
                onClick={this.handleUrlParse}
              >
                {parsing ? '解析中' : '解析'}
              </Button>
            </Col>
          </Row>
          <FormItem label="http授权">
            {getFieldDecorator('authType', {
              valuePropName: 'checked',
              initialValue: !!initAuth
            })(<Switch />)}
          </FormItem>
          <div style={{ display: authType ? 'block' : 'none' }}>
            <FormItem label="用户名">
              {getFieldDecorator('username', {
                initialValue: username
              })(<Input size="large" autoComplete="off" />)}
            </FormItem>
            <FormItem label="密码">
              {getFieldDecorator('password', {
                initialValue: password
              })(
                <Input.Password
                  visibilityToggle={false}
                  size="large"
                  autoComplete="new-password"
                />
              )}
            </FormItem>
          </div>
          <div className={styles.line} />
          {inMode === 1 && (
            <FormItem label="方法">
              {getFieldDecorator('method', {
                initialValue: method,
                rules: [
                  {
                    required: true,
                    message: '请选择方法'
                  }
                ]
              })(
                <Select
                  allowClear={true}
                  size="large"
                  placeholder="-请选择方法-"
                  onChange={this.handleMethodChange}
                  getPopupContainer={popupContainer}
                >
                  {_.map(methods, item => (
                    <Option key={item.methodName} value={item.methodName}>
                      {item.methodName}
                    </Option>
                  ))}
                </Select>
              )}
            </FormItem>
          )}

          <div style={{ display: 'none' }}>
            <FormItem label="命名空间">
              {getFieldDecorator('nameSpace', {
                initialValue: nameSpace
              })(<Input disabled size="large" />)}
            </FormItem>
          </div>
          <FormItem label="解析路径">
            {getFieldDecorator('pathResolver', {
              initialValue: pathResolver,
              rules: [
                {
                  required: true,
                  pattern: filePathReg,
                  whitespace: true,
                  message: `请输入正确的解析路径!`
                }
              ]
            })(<Input size="large" placeholder="例: path/path/path" />)}
          </FormItem>
          <FormItem label="入参模式" style={{ marginBottom: 0 }}>
            {getFieldDecorator('inMode', {
              initialValue: inMode,
              rules: [
                {
                  required: true
                }
              ]
            })(
              <Radio.Group onChange={this.handleInMode}>
                {_.map(modeTypes, (item: any) => (
                  <Radio value={item.key} key={item.key}>
                    {item.name}
                  </Radio>
                ))}
              </Radio.Group>
            )}
          </FormItem>
          {inMode === 1 && (
            <Fragment>
              <FormItem label="入参" style={{ marginBottom: 0 }}>
                {getFieldDecorator('inParamsType', {
                  initialValue: !!inParamsType,
                  valuePropName: 'checked',
                  rules: [
                    {
                      required: true
                    }
                  ]
                })(<Switch onChange={this.handleInParamsType} />)}
              </FormItem>
              {inParamsType === 1 && (
                <Params
                  type="in"
                  dataSource={inParams}
                  ref={this.inParamsRef}
                />
              )}
            </Fragment>
          )}
          {inMode === 2 && (
            <FormItem
              label="XML文本(注:变量以#{}标识)"
              colon={false}
              style={{ width: '100%' }}
              className={classnames(styles.formRequire, styles.xmlWrapper)}
            >
              <XmlEditor
                height={280}
                xmlValue={requestXml}
                onChange={this.handleXmlChange}
              />
            </FormItem>
          )}
          <FormItem label="出参模式" style={{ marginBottom: 0 }}>
            {getFieldDecorator('outParamsType', {
              initialValue: outParamsType,
              rules: [
                {
                  required: true
                }
              ]
            })(
              <Radio.Group onChange={this.handleOutParamsType}>
                {_.map(paramsTypes, (item: any) => (
                  <Radio value={item.key} key={item.key}>
                    {item.name}
                  </Radio>
                ))}
              </Radio.Group>
            )}
          </FormItem>
          {outParamsType === 1 && (
            <Params type="out" dataSource={outParams} ref={this.outParamsRef} />
          )}
          {outParamsType === 2 && <NotParseParams ref={this.outParamsRef} />}
          <TimeZoneSelect
            formKey="timezone"
            size="large"
            label={<TimeZoneTips />}
            initialValue={
              transJsonParse(_.get(values, 'spec.union', '')).timezone
            }
            required
            getFieldDecorator={getFieldDecorator}
          />
        </Form>
      </div>
    );
  }
}

export default WebService;
