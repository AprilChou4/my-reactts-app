import React, { FunctionComponent } from 'react';
import { Form, Radio } from 'sup-ui';

interface IProps {
  source: any;
  label?: string;
  colon?: boolean;
  style?: any;
  formKey: string;
  onChange?: (e: any) => void;
  initialValue?: string | number;
  getFieldDecorator: any;
}

const FormItem = Form.Item;

const DataRadio: FunctionComponent<IProps> = (props: IProps) => {
  const {
    label = '',
    source,
    formKey,
    onChange,
    colon = true,
    initialValue = '',
    getFieldDecorator,
    ...restProps
  } = props;

  return (
    <FormItem label={label} colon={colon} {...restProps}>
      {getFieldDecorator(formKey, {
        initialValue
      })(
        <Radio.Group onChange={onChange}>
          {_.map(source, (item: any) => (
            <Radio
              value={item.key}
              key={item.key}
              disabled={_.get(item, 'disabled', false)}
            >
              {item.name}
            </Radio>
          ))}
        </Radio.Group>
      )}
    </FormItem>
  );
};

export default DataRadio;
