import React, { Component } from 'react';
import { Form, Input, Divider, message } from 'sup-ui';
import { RouteComponentProps, withRouter } from 'react-router-dom';
import DialogModal from '@components/Modal/Dialog';
import { getUserInfo } from '@utils/common';
import { updatePassword } from './../user.service';

import styles from './../user.less';

interface IProps extends RouteComponentProps {
  form: any;
  userStore?: any;
}

interface IState {
  userInfo: any;
  changeLoading: boolean;
  isUpdatePassword: boolean;
}

const FormItem = Form.Item;

class UpdatePwdModel extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    const userInfo = getUserInfo();

    this.state = {
      userInfo,
      changeLoading: false,
      isUpdatePassword: !_.get(userInfo, 'isUpdatePassword', false)
    };
  }

  public handleSubmit = () => {
    const { validateFields } = this.props.form;

    validateFields((error: any, values: any) => {
      if (!error) {
        const { oldPassword, password, confirmPwd } = values;

        const { setFields } = this.props.form;
        if (password !== confirmPwd) {
          message.error('两次输入的密码不一致');
          setFields({
            confirmPwd: {
              value: confirmPwd,
              errors: [Error]
            }
          });

          return;
        }

        if (oldPassword === password) {
          message.error('新密码不能与旧密码一样');
          setFields({
            confirmPwd: {
              value: confirmPwd,
              errors: [Error]
            }
          });

          return;
        }

        const { userName } = this.state.userInfo;

        const params = {
          userName,
          password,
          oldPassword
        };

        this.updatePassword(params);
      }
    });
  };

  public async updatePassword(params: any) {
    this.setState({
      changeLoading: true
    });
    const res = await updatePassword(params);
    this.setState({
      changeLoading: false
    });

    if (res.code !== 200) {
      message.error(res.message);
      return;
    }

    message.success('密码修改成功');
    this.setState({
      isUpdatePassword: false
    });
    this.props.form.resetFields();
    this.props.history.push('/login');
  }

  public handleCancel = () => {
    this.setState({
      isUpdatePassword: false
    });

    this.props.history.push('/login');
  };

  public render() {
    const { isUpdatePassword } = this.state;
    const { getFieldDecorator } = this.props.form;

    return (
      <DialogModal
        title="修改密码"
        visible={isUpdatePassword}
        onOk={this.handleSubmit}
        onCancel={this.handleCancel}
      >
        <Form className={styles.changeInput}>
          <div className={styles.inputBox}>
            <FormItem label="旧密码">
              {getFieldDecorator('oldPassword', {
                rules: [
                  { required: true, message: '请输入旧密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请输入旧密码"
                  visibilityToggle={false}
                />
              )}
            </FormItem>

            <Divider />

            <FormItem label="新密码">
              {getFieldDecorator('password', {
                rules: [
                  { required: true, message: '请输入新密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请输入新密码"
                  visibilityToggle={false}
                />
              )}
            </FormItem>

            <FormItem label="确认新密码">
              {getFieldDecorator('confirmPwd', {
                rules: [
                  { required: true, message: '请再次新密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请再次新密码"
                  visibilityToggle={false}
                />
              )}
            </FormItem>
          </div>
        </Form>
      </DialogModal>
    );
  }
}

export default Form.create()(withRouter(UpdatePwdModel));
