import React, { Component } from 'react';
import { Form, Input, Button, Divider, message } from 'sup-ui';
import { RouteComponentProps, withRouter } from 'react-router-dom';
import { getUserInfo } from '@utils/common';
import { updatePassword } from './../user.service';
import styles from './../user.less';

interface IProps extends RouteComponentProps {
  form: any;
  userStore?: any;
}

const FormItem = Form.Item;

class UpdatePwd extends Component<IProps> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      changeLoading: false
    };
  }

  public handleReset = () => {
    this.props.form.resetFields();
  };

  public handleSubmit = () => {
    const { validateFields } = this.props.form;

    validateFields((error: any, values: any) => {
      if (!error) {
        const { oldPassword, password, confirmPwd } = values;
        const userInfo = getUserInfo();

        const { setFields } = this.props.form;
        if (password !== confirmPwd) {
          message.error('两次输入的密码不一致');
          setFields({
            confirmPwd: {
              value: confirmPwd,
              errors: [Error]
            }
          });

          return;
        }

        if (oldPassword === password) {
          message.error('新密码不能与旧密码一样');
          setFields({
            confirmPwd: {
              value: confirmPwd,
              errors: [Error]
            }
          });

          return;
        }

        const params = {
          userName: userInfo.userName,
          password,
          oldPassword
        };

        this.updatePassword(params);
      }
    });
  };

  public async updatePassword(params: any) {
    this.setState({
      changeLoading: true
    });
    const res = await updatePassword(params);
    this.setState({
      changeLoading: false
    });

    if (res.code !== 200) {
      message.error(res.message);
      return;
    }

    message.success('密码修改成功');
    this.props.form.resetFields();
    this.props.history.push('/login');
  }

  public render() {
    const { getFieldDecorator } = this.props.form;

    return (
      <div className={styles.changePassword}>
        <div className={styles.changeTitle}>修改密码</div>
        <Form className={styles.changeInput}>
          <div className={styles.inputBox}>
            <FormItem label="旧密码">
              {getFieldDecorator('oldPassword', {
                rules: [
                  { required: true, message: '请输入旧密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请输入旧密码"
                  visibilityToggle={false}
                />
              )}
            </FormItem>

            <Divider />

            <FormItem label="新密码">
              {getFieldDecorator('password', {
                rules: [
                  { required: true, message: '请输入新密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请输入新密码"
                  visibilityToggle={false}
                  maxLength={32}
                />
              )}
            </FormItem>

            <FormItem label="确认新密码">
              {getFieldDecorator('confirmPwd', {
                rules: [
                  { required: true, message: '请再次新密码' },
                  {
                    pattern: /^[A-Za-z0-9!@#$%^&*();'?.,]{8,32}$/,
                    message:
                      '密码长度为8-32位，密码规则为包括大小写、数字，特殊字符'
                  }
                ]
              })(
                <Input.Password
                  size="large"
                  placeholder="请再次新密码"
                  visibilityToggle={false}
                  maxLength={32}
                />
              )}
            </FormItem>
          </div>

          <div className={styles.footer}>
            <Button className={styles.submitBtn} onClick={this.handleSubmit}>
              提交
            </Button>
            <Button className={styles.resetBtn} onClick={this.handleReset}>
              重置
            </Button>
          </div>
        </Form>
      </div>
    );
  }
}

export default Form.create()(withRouter(UpdatePwd));
