import http from '@services/http';
import { SYSTEM_URL, TASK_URL } from '@config/env';

//用户登录
export const userLogin = (data: any): Promise<any> => {
  return http.post(`${SYSTEM_URL}/user/login`, data);
};

//用户登出
export const userLogout = (): Promise<any> => {
  return http.post(`${SYSTEM_URL}/user/loginOut`);
};

//修改密码
export const updatePassword = (data: any): Promise<any> => {
  return http.post(`${SYSTEM_URL}/user/updatePassword`, data);
};

//开发/已发布任务统计**  用于校验token是否过期
export function getTaskList(): Promise<any> {
  return http.get(`${TASK_URL}/panel/tasksByType`);
}

// 双跨平台临时处理
export const autoLogin = (): Promise<any> => {
  return http.post('/inter-api/auth/login', {
    clientId: 'ms-content-sample',
    password: 'Supos1304@',
    userName: 'admin'
  });
};
export const refreshToken = (): Promise<any> => {
  return http.put('/inter-api/auth/token/refresh');
};
