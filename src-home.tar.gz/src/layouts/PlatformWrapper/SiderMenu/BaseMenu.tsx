import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import classnames from 'classnames';
import { Menu } from 'sup-ui';

import Icon from '@components/Icon';
import { IMenuItem } from '../../../router/menu.config';
import styles from './index.less';

const { SubMenu } = Menu;

const getMenuShowName = (
  name: string,
  shortName: string,
  collapsed: boolean
): string => (collapsed && shortName ? shortName : name);

interface IBaseMenuProps {
  location: any;
  collapsed: boolean;
  flatMenus: string[];
  basicMenu: IMenuItem[];
  handleOpenChange: (openKeys: any[]) => void;
  openKeys: any[];
}
class BaseMenu extends Component<IBaseMenuProps> {
  private getSubMenuOrItem = (menu: IMenuItem[]) => {
    const { collapsed } = this.props;
    return _.map(menu, item => {
      const { children, icon, name, shortName = '', path } = item;
      const showName = getMenuShowName(name, shortName, collapsed);
      if (children && children.length) {
        return (
          <SubMenu
            title={
              icon ? (
                <span
                  className={classnames(
                    'menuName',
                    collapsed && styles.menuCollapsed
                  )}
                >
                  <Icon type={icon} className={styles.menuIcon} />
                  <span>{showName}</span>
                </span>
              ) : (
                showName
              )
            }
            key={path}
          >
            {this.getSubMenuOrItem(children)}
          </SubMenu>
        );
      } else {
        return (
          <Menu.Item key={path}>
            <Link to={path}>
              <span
                className={classnames(
                  'menuName',
                  collapsed && styles.menuCollapsed
                )}
              >
                {icon && <Icon type={icon} className={styles.menuIcon} />}
                <span>{showName}</span>
              </span>
            </Link>
          </Menu.Item>
        );
      }
    });
  };

  public render() {
    const {
      openKeys,
      handleOpenChange,
      basicMenu,
      flatMenus,
      location: { pathname }
    } = this.props;
    const selectedKeys = _.filter(flatMenus, item => pathname.startsWith(item));

    return (
      <Menu
        mode="inline"
        className={styles.menu}
        openKeys={openKeys}
        selectedKeys={selectedKeys}
        onOpenChange={handleOpenChange}
      >
        {this.getSubMenuOrItem(basicMenu)}
      </Menu>
    );
  }
}

export default BaseMenu;
