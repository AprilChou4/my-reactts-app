import React, { FunctionComponent } from 'react';

import Icon from '@components/Icon';

import styles from './index.less';

const EmptyPlaceholder: FunctionComponent = () => {
  return (
    <div className={styles.container}>
      <Icon type="point" width="36px" height="36px" />
      <span className={styles.text}>请选择左侧对象</span>
    </div>
  );
};

export default EmptyPlaceholder;
