import React, { FunctionComponent } from 'react';
import { Select, Form } from 'sup-ui';

import { popupContainer } from '@utils/propUtil';

const FormItem = Form.Item;
const { Option } = Select;
interface IProps {
  formKey: string;
  initialValue: any;
  getFieldDecorator: any;
  onChange: (value: number) => void;
  required?: boolean;
  size?: 'default' | 'small' | 'large' | undefined;
}

const BoolSelect: FunctionComponent<IProps> = (props: IProps) => {
  const {
    getFieldDecorator,
    formKey,
    initialValue,
    onChange,
    required,
    size = 'default'
  } = props;
  return (
    <FormItem>
      {getFieldDecorator(`bool_type_${formKey}`, {
        initialValue: _.isNumber(initialValue) ? initialValue : undefined,
        rules: [
          {
            required,
            message: '-请选择-'
          }
        ],
        validateTrigger: ['onChange', 'onBlur']
      })(
        <Select
          placeholder="-请选择-"
          size={size}
          allowClear
          style={{ width: '100%' }}
          dropdownMatchSelectWidth
          getPopupContainer={popupContainer}
          onChange={(value: number) => onChange(value)}
        >
          <Option key={1} value={1}>
            TRUE
          </Option>
          <Option key={0} value={0}>
            FALSE
          </Option>
        </Select>
      )}
    </FormItem>
  );
};

export default BoolSelect;
