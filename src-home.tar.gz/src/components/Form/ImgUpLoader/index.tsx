import React, { Component } from 'react';
import { message, Upload } from 'sup-ui';

import { getReqBaseHeader } from '@services/apiUtils';
import { transformFileName } from './helper';
import { AP_PREFIX } from '@config/env';
import { uploadImage } from '@api/common';
import Icon from '@components/Icon';

import styles from './index.less';

interface IProps {
  onChange?: (url: any) => void;
  value?: any;
  disabled?: boolean;
}
interface IState {
  value: string;
}

class ImgUpLoader extends Component<IProps, IState> {
  public constructor(props: Readonly<IProps>) {
    super(props);
    this.handleUploadFile = this.handleUploadFile.bind(this);
    this.state = {
      value: ''
    };
  }

  public componentDidMount() {
    const { value } = this.props;
    if (value) {
      this.setState({
        value
      });
    }
  }

  public componentDidUpdate(prevProps: IProps) {
    const { value } = this.props;
    if (value !== prevProps.value) {
      this.setState({
        value
      });
    }
  }

  public handleBeforeUpload = (file: File) => {
    const allowImgType = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/svg+xml'
    ];

    const isAllowImg = allowImgType.indexOf(file.type) > -1;
    if (!isAllowImg) {
      message.error('仅支持 JPG/PNG/GIF/SVG 格式图片!');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('图片大小必须小于2MB!');
    }
    return isAllowImg && isLt2M;
  };

  public async handleUploadFile(fileObj: any) {
    const { onChange } = this.props;
    // console.log(fileObj);
    if (!fileObj.file) return;
    const _formData = new FormData();

    _formData.append(
      'file',
      fileObj.file,
      transformFileName(fileObj.file.name)
    );
    const res = await uploadImage(_formData);

    if (!res.fileDownloadUrl) {
      message.error(`图片上传失败`);
      return;
    }

    if (onChange) onChange(res.fileDownloadUrl);
  }

  public removeValue = (e: any) => {
    const { onChange } = this.props;
    e.stopPropagation();

    this.setState({
      value: ''
    });
    if (onChange) onChange('');
  };

  public render() {
    const { disabled } = this.props;
    const { value } = this.state;
    return (
      <Upload
        accept="image/*"
        headers={getReqBaseHeader()}
        multiple={false}
        listType="picture-card"
        showUploadList={false}
        disabled={disabled}
        customRequest={this.handleUploadFile}
        beforeUpload={this.handleBeforeUpload}
        className={styles.upload}
      >
        <div className={`${styles.imgBox} ${!value && styles.none}`}>
          <img src={`${AP_PREFIX}${value}`} alt="图标" />
        </div>
        <div className={value && styles.none}>
          <Icon type="upload" />
          <p>上传</p>
        </div>
        <div
          className={`${styles.mask}`}
          onClick={(e: any) => {
            e.stopPropagation();
          }}
        >
          <Icon
            disabled={disabled}
            type="remove"
            width="25"
            height="25"
            onClick={(e: any) => {
              this.removeValue(e);
            }}
          />
          <span />
        </div>
      </Upload>
    );
  }
}

export default ImgUpLoader;
