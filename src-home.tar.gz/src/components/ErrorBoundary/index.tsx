import React, { PureComponent } from 'react';

import styles from './index.less';

interface IErrorProps {
  children?: any;
}

class ErrorBoundary extends PureComponent<IErrorProps> {
  public state = {
    hasError: false
  };

  public UNSAFE_componentWillReceiveProps() {
    this.setState({ hasError: false });
  }

  public componentDidCatch(error: any, info: any) {
    this.setState({
      hasError: true
    });
    console.error(error, info);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className={styles.fail}>
          <p className={styles.failText}>Content load failed</p>
        </div>
      );
    } else {
      return this.props.children;
    }
  }
}

export default ErrorBoundary;
