// 边框外的链接锚点
export default {
  // 算法节点边框
  cornerRadius: 3,
  // 算法节点内边距
  rectPadding: 0,
  // 连线的颜色
  edgeColor: '#4A68EA',
  // 连线的颜色(error连线)
  edgeErrorColor: '#ff4d4f',
  // 引脚边框色
  pointStrokeStyle: '#4A68EA',
  // 引脚边框色(error节点)
  pointErrorStrokeStyle: '#ff4d4f',
  // 引脚边框色（禁用状态）
  pointStrokeStyleDisabled: '#b0b0b0',
  // 引脚填充色
  pointFillStyle: '#ffffff',
  // 引脚半径
  pointRadius: 7,
  checkSize: window.ht.Default.isTouchable ? 15 : 3,
  // 引脚待连接时外光圈颜色
  sorptionColor: 'rgba(74, 104, 250, 0.6)',
  // 引脚待连接时外光圈半径
  sorptionSize: 5,
  // 引脚待连接时，可被连接的范围半径
  sorptionActiveSize: window.ht.Default.isTouchable ? 40 : 8
};
