export const isHtNode = (data: any) => {
  return data && data instanceof window.ht.Node;
};

export const isHtEdge = (data: any) => {
  return data && data instanceof window.ht.Edge;
};
