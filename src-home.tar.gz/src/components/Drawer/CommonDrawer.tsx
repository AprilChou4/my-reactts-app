import React, { Component } from 'react';
import { Drawer, Button } from 'sup-ui';
import { inject } from 'mobx-react';
import { DrawerProps } from 'sup-ui/es/drawer';
import classnames from 'classnames';
import styles from './CommonDrawer.less';

interface IProps extends DrawerProps {
  global?: any;
  onOk?: () => void;
  onCancel?: () => void;
  align?: string;
  loading?: boolean;
  destroyOnClose?: any;
  footer?: any;
  renderInner?: boolean;
  okText?: string;
  cancelText?: string;
  okButtonProps?: any; // ButtonProps
  cancelButtonProps?: any;
}

@inject('global')
class CommonDrawer extends Component<IProps> {
  public render() {
    const {
      align,
      width,
      children,
      onOk,
      onCancel,
      loading,
      visible,
      footer,
      title,
      wrapClassName,
      renderInner = true,
      maskClosable = false,
      okText,
      cancelText,
      okButtonProps,
      ...restProps
    } = this.props;
    const { inSupos } = this.props.global;

    const positionProps: any = renderInner
      ? {
          getContainer: false,
          style: { position: 'absolute' }
        }
      : {};

    return (
      <Drawer
        width={width}
        visible={visible}
        title={<span className="ellipsis-1">{title}</span>}
        {...positionProps}
        {...restProps}
        onClose={onCancel}
        className={classnames(
          styles.tagDrawer,
          inSupos && styles.suposTagDrawer,
          wrapClassName
        )}
        maskClosable={maskClosable}
      >
        <div className={`${styles.children} drawerChildren`}>
          {visible && children}
        </div>
        {footer !== null && (
          <div
            className={`${styles.footerBtn}  ${styles[align || 'left']}`}
            style={{ width: `${width}` }}
          >
            <Button
              loading={loading}
              type="primary"
              onClick={onOk}
              {...okButtonProps}
            >
              {okText || '确认'}
            </Button>
            <Button onClick={onCancel}>{cancelText || '取消'}</Button>
          </div>
        )}
      </Drawer>
    );
  }
}

export default CommonDrawer;
