import React, { FunctionComponent } from 'react';
import FormItem from 'sup-ui/lib/form/FormItem';
import { InputNumber } from 'sup-ui';

import styles from './index.less';

interface IProps {
  min?: number;
  max?: number;
  label: string;
  formKey: string;
  required?: boolean;
  defaultValue: string;
  getFieldDecorator: any;
}

const DataInputNum: FunctionComponent<IProps> = (props: IProps) => {
  const {
    getFieldDecorator,
    defaultValue,
    label,
    formKey,
    required = false,
    min = -Infinity,
    max = Infinity
  } = props;
  return (
    <FormItem label={label} className={styles.maxNum}>
      {getFieldDecorator(formKey, {
        initialValue: defaultValue,
        rules: [
          {
            required,
            message: '请输入!'
          }
        ]
      })(<InputNumber min={min} max={max} />)}
    </FormItem>
  );
};

export default DataInputNum;
