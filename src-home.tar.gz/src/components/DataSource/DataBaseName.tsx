import React, { FunctionComponent } from 'react';
import FormItem from 'sup-ui/lib/form/FormItem';
import { Input } from 'sup-ui';

interface IProps {
  label: string;
  defaultValue: string;
  getFieldDecorator: any;
}

const DataBaseName: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, defaultValue, label } = props;
  return (
    <FormItem label={label}>
      {getFieldDecorator('dbname', {
        initialValue: defaultValue,
        rules: [
          {
            required: true,
            message: '请输入数据库名称'
          },
          {
            whitespace: true,
            message: '请勿输入空格'
          }
        ]
      })(<Input />)}
    </FormItem>
  );
};

export default DataBaseName;
