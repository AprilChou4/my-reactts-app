import React, { FunctionComponent } from 'react';
import FormItem from 'sup-ui/lib/form/FormItem';

import { Input } from 'sup-ui';

interface IProps {
  defaultValue: string;
  getFieldDecorator: any;
}

const WindowsPath: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, defaultValue } = props;

  return (
    <FormItem label={'文件目录相对路径'}>
      {getFieldDecorator('url', {
        rules: [
          {
            required: true,
            whitespace: true,
            message: `请输入正确的解析路径!`
          }
        ],
        initialValue: !defaultValue ? `D:\\supfiles\\` : defaultValue
      })(<Input />)}
    </FormItem>
  );
};

export default WindowsPath;
