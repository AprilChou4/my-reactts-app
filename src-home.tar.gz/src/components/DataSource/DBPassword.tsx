import React, { FunctionComponent } from 'react';
import FormItem from 'sup-ui/lib/form/FormItem';
import { Input } from 'sup-ui';

interface IProps {
  required?: boolean;
  defaultValue: string;
  getFieldDecorator: any;
}

const DBPassword: FunctionComponent<IProps> = (props: IProps) => {
  const { required = true, getFieldDecorator, defaultValue } = props;
  return (
    <FormItem label="密码">
      {getFieldDecorator('password', {
        initialValue: defaultValue,
        rules: [
          {
            required,
            message: '请输入密码'
          },
          {
            whitespace: true,
            message: '请勿输入空格'
          }
        ]
      })(<Input.Password autoComplete="new-password" />)}
    </FormItem>
  );
};

export default DBPassword;
