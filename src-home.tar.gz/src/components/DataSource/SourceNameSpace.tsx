import React, { FunctionComponent } from 'react';
import { Input } from 'sup-ui';
import FormItem from 'sup-ui/lib/form/FormItem';

interface IProps {
  defaultValue: string;
  getFieldDecorator: any;
}

const SourceNameSpace: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, defaultValue } = props;

  return (
    <FormItem label="命名空间">
      {getFieldDecorator('nameSpace', {
        initialValue: defaultValue,
        rules: [
          {
            required: true,
            whitespace: true,
            message: `请输入正确的命名空间`
          }
        ]
      })(<Input />)}
    </FormItem>
  );
};

export default SourceNameSpace;
