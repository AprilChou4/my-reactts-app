import React, { FunctionComponent } from 'react';
import { Select, Form } from 'sup-ui';

const { Option } = Select;
interface IProps {
  record: any;
  options?: any;
  dataIndex: string;
  getFieldDecorator: any;
}

const IsRequired: FunctionComponent<IProps> = (props: IProps) => {
  const { dataIndex, options, record, getFieldDecorator } = props;

  return (
    <Form.Item>
      {getFieldDecorator(`${dataIndex}_${record.key}`, {
        rules: [
          {
            required: true
          }
        ],
        initialValue: record[dataIndex] || 0
      })(
        <Select dropdownMatchSelectWidth={false}>
          {_.map(options, (item: any) => (
            <Option key={item.key} value={item.key}>
              {item.value}
            </Option>
          ))}
        </Select>
      )}
    </Form.Item>
  );
};

export default IsRequired;
