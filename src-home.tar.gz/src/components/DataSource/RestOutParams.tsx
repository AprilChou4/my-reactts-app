import React, { Component, Fragment } from 'react';
import { Form, Switch, Input, Button, Table } from 'sup-ui';
import { toJS } from 'mobx';

import { AddBtn, DelBtn } from '@components/Button';
import TipsDelete from '@components/Modal/TipsDelete';
import {
  RequestParams,
  RestFulTreeData,
  JsonTreeData,
  OutputParams,
  DataRadio
} from '@components/DataSource';
import uuid from '@utils/uuid';
import NoData from '@components/NoData';
import styles from './index.less';

const EditableContext = React.createContext({});

interface IProps {
  union: any;
  connectRestfulData: any;
  getFieldDecorator: any;
}
interface IState {
  outSource: any[];
  verificationParams: any[];
  outMode: number;
  treeData: any;
  outputSetting: boolean;
  analyType: number;
  analyConfigList: any[];
  selectRowKeys: any[];
  analyPath: string;
}

const FormItem = Form.Item;

interface IEditProps {
  dataIndex: string;
  record: any;
  editable: boolean;
  getFieldDecorator: any;
  updateAnalyConfig: (record: any) => void;
}

class EditableCell extends Component<IEditProps> {
  public form: any;

  private handleAnalyChange = (
    key: 'analyColumn' | 'analyKey' | 'analyValue',
    e: any
  ) => {
    const { record } = this.props;
    record[key] = e.target.value;
    this.props.updateAnalyConfig(record);
  };

  public renderCell = () => {
    const { dataIndex, record, getFieldDecorator } = this.props;

    if (dataIndex === 'analyKey') {
      return (
        <FormItem>
          {getFieldDecorator(`analyKey_${record.key}`, {
            rules: [
              {
                required: true,
                whitespace: true,
                message: `请输入解析路径!`
              }
            ],
            initialValue: record.analyKey
          })(
            <Input
              placeholder="-请输入-"
              onChange={this.handleAnalyChange.bind(this, 'analyKey')}
            />
          )}
        </FormItem>
      );
    } else if (dataIndex === 'analyColumn') {
      return (
        <FormItem>
          {getFieldDecorator(`analyColumn_${record.key}`, {
            rules: [
              {
                required: true,
                whitespace: true,
                message: `请输入解析路径!`
              }
            ],
            initialValue: record.analyColumn
          })(
            <Input
              placeholder="-请输入-"
              onChange={this.handleAnalyChange.bind(this, 'analyColumn')}
            />
          )}
        </FormItem>
      );
    } else if (dataIndex === 'analyValue') {
      return (
        <FormItem>
          {getFieldDecorator(`analyValue_${record.key}`, {
            rules: [
              {
                required: true,
                whitespace: true,
                message: `请输入解析路径!`
              }
            ],
            initialValue: record.analyValue
          })(
            <Input
              placeholder="-请输入-"
              onChange={this.handleAnalyChange.bind(this, 'analyValue')}
            />
          )}
        </FormItem>
      );
    } else {
      return '';
    }
  };

  public render() {
    const { editable, children, ...restProps } = _.omit(this.props, [
      'dataIndex',
      'title',
      'record',
      'index',
      'getFieldDecorator',
      'updateAnalyConfig'
    ]);

    return (
      <td {...restProps}>
        {editable ? (
          <EditableContext.Consumer>{this.renderCell}</EditableContext.Consumer>
        ) : (
          children
        )}
      </td>
    );
  }
}

class RestOutParams extends Component<IProps, IState> {
  public outParamsRef: any;
  public outputRef: any;
  public columns: any;
  public components: any;

  public constructor(props: IProps) {
    super(props);
    this.state = {
      outSource: [],
      verificationParams: [],
      outMode: 1,
      outputSetting: false,
      treeData: _.cloneDeep(props.connectRestfulData),
      analyType: _.get(props, 'union.analyType', 1),
      analyConfigList: _.get(props, 'union.xmlAnalyParams.analyConfigList', []),
      selectRowKeys: [],
      analyPath: _.get(props, 'union.xmlAnalyParams.analyPath', '')
    };

    this.columns = [
      {
        title: '解析键名',
        dataIndex: 'analyKey',
        editable: true
      },
      {
        title: '解析值名',
        dataIndex: 'analyValue',
        editable: true
      },
      {
        title: '解析列',
        dataIndex: 'analyColumn',
        editable: true
      },
      {
        title: '操作',
        render: (_text: any, record: any) => {
          return (
            <Button
              ghost
              type="link"
              onClick={() => {
                this.handleRemove(record);
              }}
              disabled={!_.get(record, 'edit', true)}
            >
              删除
            </Button>
          );
        }
      }
    ];

    this.components = {
      body: {
        cell: EditableCell
      }
    };
  }

  public componentDidMount() {
    const { union } = this.props;

    this.setState({
      treeData: _.get(union, 'resultJson', {}),
      outSource: _.get(union, 'outParams', []),
      outputSetting: _.get(union, 'outputSetting', false),
      verificationParams: _.get(union, 'verificationParams', [])
    });
  }

  public static getDerivedStateFromProps(nextProps: any, state: any) {
    const { connectRestfulData } = nextProps;
    const { treeData } = state;

    const isTreeData = connectRestfulData === treeData;

    if (_.isEmpty(toJS(connectRestfulData))) {
      return null;
    }
    if (!isTreeData) {
      return {
        treeData: connectRestfulData
      };
    }

    return null;
  }

  //返回出参
  public getOutParams = () => {
    const { outMode, outputSetting, analyType, analyConfigList, analyPath } =
      this.state;
    const outParams = this.outParamsRef.getParams();
    let verificationParams = [];

    if (outputSetting) {
      verificationParams = this.outputRef.getParams();
    }

    const isOutParams = _.isEmpty(outParams);
    const outParamsType = isOutParams ? 0 : 1;
    const params: any = {
      verificationParams,
      outParamsType,
      outParams,
      outMode,
      analyType
    };
    if (analyType === 2) {
      params.xmlAnalyParams = {
        analyPath,
        analyConfigList
      };
    }
    return params;
  };

  public outDataSource = (value: any, type: string) => {
    const outMode = type === 'Array' ? 2 : 1;
    this.setState({
      outSource: value,
      outMode
    });
  };

  public verificationParams = (value: any) => {
    const { verificationParams } = this.state;

    const isRepeat = _.some(
      verificationParams,
      (item: any) =>
        item.path === value[0].path && item.paramsName === value[0].paramsName
    );

    const dataSource = _.isEmpty(verificationParams)
      ? value
      : isRepeat
      ? verificationParams
      : [...verificationParams, ...value];

    this.setState({
      verificationParams: dataSource
    });
  };

  public updateVerificationParams = (verificationParams: any) => {
    this.setState({
      verificationParams
    });
  };

  public handleChangeSetting = (checked: boolean) => {
    this.setState({
      outputSetting: checked
    });
  };

  private handleChangeRadio = (e: any) => {
    this.setState({
      analyType: e.target.value
    });
  };

  private handleAnalyPath = (e: any) => {
    this.setState({
      analyPath: e.target.value
    });
  };

  private handleSelectRowKeys = (selectRowKeys: string[] | number[]) => {
    this.setState({
      selectRowKeys
    });
  };
  private handleAdd = () => {
    const { analyConfigList } = this.state;

    const newData = {
      key: uuid(6),
      analyKey: undefined,
      analyColumn: undefined,
      analyValue: undefined
    };
    this.setState({
      analyConfigList: [...analyConfigList, newData]
    });
  };

  public handleRemove = (record: any) => {
    const config = {
      title: '删除该告警信息？',
      content: '请确认删除',
      onOk: () => {
        const { analyConfigList } = this.state;
        this.setState({
          analyConfigList: _.filter(
            analyConfigList,
            (item: any) => item.key !== record.key
          )
        });
      }
    };

    TipsDelete(config);
  };
  private handleAllRemove = () => {
    const { analyConfigList, selectRowKeys } = this.state;
    this.setState({
      analyConfigList: _.filter(
        analyConfigList,
        (item: any) => !_.includes(selectRowKeys, item.key)
      )
    });
  };

  private updateAnalyConfig = (index: number, record: any) => {
    const { analyConfigList } = this.state;
    analyConfigList[index] = record;
    this.setState({
      analyConfigList
    });
  };

  public render() {
    const { getFieldDecorator } = this.props;
    const {
      outSource,
      treeData,
      outputSetting,
      verificationParams,
      analyType,
      analyConfigList
    } = this.state;

    const columns = _.map(this.columns, (col: any) => {
      if (!col.editable) {
        return col;
      }
      return {
        ...col,
        onCell: (record: any, index: number) => ({
          record,
          editable: col.editable,
          dataIndex: col.dataIndex,
          title: col.title,
          getFieldDecorator,
          updateAnalyConfig: this.updateAnalyConfig.bind(this, index)
        })
      };
    });

    const rowSelection = {
      onChange: (selectRowKeys: string[] | number[]) => {
        this.handleSelectRowKeys(selectRowKeys);
      },
      getCheckboxProps: (record: any) => ({
        disabled: !_.get(record, 'edit', true),
        name: record.paramsName
      })
    };

    return (
      <Fragment>
        <FormItem label="输出参数配置">
          {getFieldDecorator('outputSetting', {
            valuePropName: 'checked',
            initialValue: outputSetting
          })(<Switch onChange={this.handleChangeSetting} />)}
        </FormItem>
        <DataRadio
          formKey="analyType"
          label="输出类型"
          source={[
            {
              key: 1,
              name: 'JSON'
            },
            {
              key: 2,
              name: 'XML'
            }
          ]}
          initialValue={analyType}
          onChange={this.handleChangeRadio}
          getFieldDecorator={getFieldDecorator}
        />
        {analyType === 2 && (
          <Fragment>
            <FormItem label="解析路径">
              {getFieldDecorator('analyPath', {
                rules: [
                  {
                    required: true,
                    whitespace: true,
                    message: `请输入解析路径!`
                  }
                ],
                initialValue: this.state.analyPath
              })(
                <Input placeholder="-请输入-" onChange={this.handleAnalyPath} />
              )}
            </FormItem>
            <div className={`${styles.paramsNode} customSource`}>
              <div className={styles.editBtn}>
                <AddBtn title="新增" onClick={this.handleAdd} />
                <DelBtn onClick={this.handleAllRemove} />
              </div>
              <Table
                rowSelection={rowSelection}
                components={this.components}
                rowClassName={() => 'editable-row'}
                dataSource={analyConfigList}
                columns={columns}
                pagination={false}
                scroll={{ y: '200px' }}
                rowKey={(record: any) => record.key}
              />
            </div>
          </Fragment>
        )}
        {outputSetting && (
          <Fragment>
            <div className={styles.jsonTree}>
              {!_.isEmpty(treeData) ? (
                <JsonTreeData
                  dataSource={treeData}
                  verificationParams={this.verificationParams}
                />
              ) : (
                <NoData />
              )}
            </div>
            <OutputParams
              addStatus={false}
              dataSource={verificationParams}
              updateVerificationParams={this.updateVerificationParams}
              wrappedComponentRef={(ref: any) => {
                this.outputRef = ref;
              }}
            />
          </Fragment>
        )}
        <div style={{ marginBottom: '15px' }}>响应结果</div>
        <div className={styles.jsonTree}>
          {!_.isEmpty(treeData) ? (
            <RestFulTreeData
              dataSource={treeData}
              outDataSource={this.outDataSource}
            />
          ) : (
            <NoData />
          )}
        </div>
        <div style={{ margin: '15px 0' }}>输出结果</div>
        <RequestParams
          addStatus={false}
          isRequired={true}
          dataSource={outSource}
          wrappedComponentRef={(ref: any) => {
            this.outParamsRef = ref;
          }}
        />
      </Fragment>
    );
  }
}

export default RestOutParams;
