import React, { FunctionComponent } from 'react';
import { Input } from 'sup-ui';
import FormItem from 'sup-ui/lib/form/FormItem';

// import { ipReg } from '@utils/regUtils';

interface IProps {
  label: string;
  type: string;
  defaultValue: string;
  getFieldDecorator: any;
}

const DataSourceIp: FunctionComponent<IProps> = (props: IProps) => {
  const { getFieldDecorator, defaultValue, label, type } = props;

  return (
    <FormItem label={label}>
      {getFieldDecorator(type, {
        initialValue: defaultValue,
        rules: [
          {
            required: true,
            // pattern: ipReg,
            whitespace: true,
            message: `请输入正确的${label}`
          }
        ]
      })(<Input />)}
    </FormItem>
  );
};

export default DataSourceIp;
