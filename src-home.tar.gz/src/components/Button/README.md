## 内部Button 封装
将项目中的新建/删除按钮公共封装，避免样式重写

## 公共参数说明
| 参数     | 说明     | 类型     | 默认值   | 是否必选 | 可选参数            |
| -------- | -------- | -------- | -------- | -------- | ------------------- |
| onClick  | 点击事件 | function | ()=>void | 无       | 无                  |
| disabled | 是否禁用 | boolean  | false    | 无       | true false          |
| size     | 样式大小 | string   | default  | false    | small default large |


## 新建按钮
| 参数  | 说明                          | 类型    | 默认值 | 是否必选 | 可选参数   |
| ----- | ----------------------------- | ------- | ------ | -------- | ---------- |
| title | 新增按钮文本                  | string  | '新增' | 否       | 无         |
| ghost | 幽灵模式，没有 primary 背景色 | boolean | false  | 否       | true false |

