import React from 'react';
import { Row, Col } from 'sup-ui';
import classNames from 'classnames';
import styles from './index.less';

//接口定义需要完善
interface ITitleProps {
  title: string;
  rightContent?: any;
  className?: any;
}

//TODO:通用头部标题组件
function SubTitle(props: ITitleProps) {
  const { title, rightContent, className } = props;
  return (
    <div className={classNames(styles.titleContainer, className)}>
      <Row>
        <Col span={8} className={styles.title}>
          {title}
        </Col>
        <Col
          span={16}
          className={classNames(styles.rightContent, 'rightContent')}
        >
          {rightContent}
        </Col>
      </Row>
    </div>
  );
}

export default SubTitle;
