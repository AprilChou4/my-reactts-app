import http from '@services/http';
import { OPEN_URL } from '@config/env';

//获取公司
export function getCompanies(params: any): Promise<any> {
  return http.get(`${OPEN_URL}/companies`, params);
}
//根据公司获取部门
export function getDepartmentByCompanyCode(
  code: string,
  params: any
): Promise<any> {
  return http.get(`${OPEN_URL}/companies/${code}/departments`, params);
}
//根据公司获取岗位
export function getPositionByCompanyCode(
  code: string,
  params: any
): Promise<any> {
  return http.get(`${OPEN_URL}/companies/${code}/positions`, params);
}

//根据公司获取人员
export function getPersonByCompanyCode(
  code: string,
  params: any
): Promise<any> {
  return http.get(`${OPEN_URL}/companies/${code}/persons`, params);
}

//根据部门获取人员
export function getPersonByDepartmentCode(
  code: string,
  params: any
): Promise<any> {
  return http.get(`${OPEN_URL}/departments/${code}/persons`, params);
}
//根据岗位获取人员
export function getPersonByPositionCode(
  code: string,
  params: any
): Promise<any> {
  return http.get(`${OPEN_URL}/positions/${code}/persons`, params);
}
