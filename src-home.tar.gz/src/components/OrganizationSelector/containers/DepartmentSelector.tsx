import React, { FC, useState, useEffect } from 'react';
import { useUpdateEffect } from 'ahooks';
import { getCompanies, getDepartmentByCompanyCode } from '../index.service';
import { CompanyDTO, DepartmentDTO } from '../enmu';
import { TreeSelect, Form } from 'sup-ui';
import { FormComponentProps } from 'sup-ui/lib/form/Form';
const FormItem = Form.Item;
interface IProps extends FormComponentProps {
  value: any;
  onChange: (params: any) => void;
}
const treeFind = (trees: any[], code: string): any => {
  for (const tree of trees) {
    if (tree.code === code) return tree;
    if (tree.children) {
      const res = treeFind(tree.children, code);
      if (res) return res;
    }
  }
  return undefined;
};
const DepartmentSelector: FC<IProps> = props => {
  const {
    value,
    onChange,
    form: { getFieldDecorator }
  } = props;
  const [companyList, setCompanyList] = useState<CompanyDTO[]>([]);
  const [departmentList, setDepartmentList] = useState<DepartmentDTO[]>([]);
  const [selectedCompany, setSelectedCompany] = useState<any>(null);
  const [selectedDepartment, setSelectedDepartment] = useState(
    value?.code ? { value: value?.code, label: value?.name } : null
  );

  //初始获取公司列表
  useEffect(() => {
    getCompanies({ current: 1, pageSize: 500 }).then((res: any) => {
      setCompanyList(res.list || []);
      setSelectedCompany(
        value?.company
          ? {
              value: value?.company?.code,
              lable: value?.company?.fullName
            }
          : {
              value: res.list[0]?.code,
              lable: res.list[0]?.fullName
            }
      ); //默认选中第一个
    });
  }, []);
  //公司改变 获取 部门列表
  useUpdateEffect(() => {
    const { setFieldsValue } = props.form;
    getDepartmentByCompanyCode(selectedCompany.value, {
      current: 1,
      pageSize: 500
    }).then((res: any) => {
      setFieldsValue({
        department: undefined
      });
      setDepartmentList(res.list || []);
    });
  }, [selectedCompany?.value]);
  //将数据结构转换为treeData
  const recurseTree = (type: 0 | 1, childs: any[]) => {
    const result: any[] = [];

    childs = _.sortBy(childs, ['sort']);

    childs.forEach(node => {
      const children = node.children || [];
      const tree: any = {
        value: node.code.toString(),
        title: type === 0 ? node.fullName : node.name,
        isLeaf: children.length === 0,
        selectable: true,
        children: []
      };

      if (children.length > 0) {
        tree.children = recurseTree(type, children);
      }

      result.push(tree);
    });

    return result;
  };
  const handleCompanyChange = (params: any) => {
    setSelectedCompany(params);
  };

  const handelDepartmentChange = (params: any) => {
    setSelectedDepartment(params);
    const detail = treeFind(departmentList, params.value);
    if (detail) {
      onChange && onChange(detail);
    }
  };
  return (
    <div>
      <FormItem label={'公司'}>
        {getFieldDecorator('company', { initialValue: selectedCompany })(
          <TreeSelect
            labelInValue
            style={{ width: '100%' }}
            dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
            getPopupContainer={triggerNode =>
              triggerNode.parentElement as HTMLElement
            }
            placeholder="-请选择-"
            onChange={handleCompanyChange}
            treeData={recurseTree(0, companyList)}
          />
        )}
      </FormItem>
      <FormItem label={'部门'}>
        {getFieldDecorator('department', {
          initialValue: selectedDepartment,
          rules: [{ required: true, message: '部门不能为空' }]
        })(
          <TreeSelect
            labelInValue
            style={{ width: '100%' }}
            dropdownStyle={{ maxHeight: 200, overflow: 'auto' }}
            getPopupContainer={triggerNode =>
              triggerNode.parentElement as HTMLElement
            }
            placeholder="-请选择-"
            onChange={handelDepartmentChange}
            treeData={recurseTree(1, departmentList)}
          />
        )}
      </FormItem>
    </div>
  );
};

export default Form.create<IProps>({ name: 'DepartmentSelector' })(
  DepartmentSelector
);
