import React, { FC, useState } from 'react';
import { Tree, Empty, Spin } from 'sup-ui';
import styles from './index.less';

const { TreeNode, DirectoryTree } = Tree;

interface IProps {
  loading: boolean;
  list: any[];
  onChange: any;
}
const OrganizeTree: FC<IProps> = props => {
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const treeTitle = (item: any) => (
    <div className={styles.customerTitle}>
      <div className={styles.edit}>
        <span title={item.name}>{item.name}</span>
      </div>
    </div>
  );
  //递归节点树结构
  const loopTreeNode = (data: any) => {
    return data.map((item: any) => {
      if (item.children) {
        return (
          <TreeNode
            key={item.code}
            dataRef={item}
            title={treeTitle(item)}
            selectable={item.selectable || true}
          >
            {loopTreeNode(item.children)}
          </TreeNode>
        );
      }

      return (
        <TreeNode
          key={item.code}
          isLeaf={item.isLeaf}
          selectable={item.selectable || true}
          title={treeTitle(item)}
          dataRef={item}
        />
      );
    });
  };

  const handleTreeNodeSelect = (keys: string[], { selected, node }: any) => {
    const { onChange } = props;

    if (keys[0] === selectedKeys[0]) {
      return;
    }

    const {
      props: { dataRef }
    } = node;
    setSelectedKeys(keys);

    if (selected) {
      onChange(dataRef);
    }
  };
  return (
    <div className={styles.treeContainer}>
      <div className={styles.directoryTree}>
        <Spin spinning={props.loading}>
          {props.list.length > 0 ? (
            <DirectoryTree
              expandAction={false}
              selectedKeys={selectedKeys}
              onSelect={handleTreeNodeSelect}
            >
              {loopTreeNode(props.list)}
            </DirectoryTree>
          ) : (
            <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
          )}
        </Spin>
      </div>
    </div>
  );
};

export default OrganizeTree;
