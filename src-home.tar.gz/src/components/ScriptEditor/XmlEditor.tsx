import React, { Component } from 'react';

import CodeMirror from 'codemirror';
import 'codemirror/lib/codemirror.css';
import 'codemirror/theme/monokai.css';
import 'codemirror/addon/hint/show-hint.css';
import 'codemirror/addon/hint/show-hint';
import 'codemirror/mode/xml/xml';
import 'codemirror/addon/hint/xml-hint';
import 'codemirror/addon/display/autorefresh';
// import beautify from '@utils/beautify';

interface IProps {
  xmlValue: string;
  onChange: (value: string) => void;
  theme?: string;
  width?: number;
  height?: number;
}
const dummy = {
  attrs: {
    color: ['red', 'green', 'blue', 'purple', 'white', 'black', 'yellow'],
    size: ['large', 'medium', 'small'],
    description: null
  },
  children: []
};

const tags = {
  '!top': ['top'],
  '!attrs': {
    id: null,
    class: ['A', 'B', 'C']
  },
  top: {
    attrs: {
      lang: ['en', 'de', 'fr', 'nl'],
      freeform: null
    },
    children: ['animal', 'plant']
  },
  animal: {
    attrs: {
      name: null,
      isduck: ['yes', 'no']
    },
    children: ['wings', 'feet', 'body', 'head', 'tail']
  },
  plant: {
    attrs: { name: null },
    children: ['leaves', 'stem', 'flowers']
  },
  wings: dummy,
  feet: dummy,
  body: dummy,
  head: dummy,
  tail: dummy,
  leaves: dummy,
  stem: dummy,
  flowers: dummy
};

class XmlEditor extends Component<IProps> {
  private xmlRef: any;
  private XmlEditor: any;
  public static defaultProps = {
    height: 300
  };
  public constructor(props: IProps) {
    super(props);
    this.xmlRef = null;
  }

  public componentDidMount() {
    this.initCodeEditor();
  }

  public completeAfter = (cm: any, pred: any) => {
    if (!pred || pred())
      setTimeout(function () {
        if (!cm.state.completionActive) cm.showHint({ completeSingle: false });
      }, 100);
    return CodeMirror.Pass;
  };

  public completeIfAfterLt = (cm: any) => {
    return this.completeAfter(cm, function () {
      const cur = cm.getCursor();
      return cm.getRange(CodeMirror.Pos(cur.line, cur.ch - 1), cur) === '<';
    });
  };

  public completeIfInTag = (cm: any) => {
    return this.completeAfter(cm, function () {
      const tok = cm.getTokenAt(cm.getCursor());
      const reg = /['"]/;
      if (
        tok.type === 'string' &&
        (!reg.test(tok.string.charAt(tok.string.length - 1)) ||
          tok.string.length === 1)
      )
        return false;
      const inner = CodeMirror.innerMode(cm.getMode(), tok.state).state;
      return inner.tagName;
    });
  };

  public initCodeEditor() {
    const { theme = 'monokai' } = this.props;
    this.XmlEditor = CodeMirror.fromTextArea(this.xmlRef, {
      mode: 'xml',
      gutters: ['CodeMirror-lint-markers'],
      lint: true,
      lineNumbers: true,
      lineWrapping: true, // 自动换行
      styleActiveLine: true, // 当前行背景高亮
      smartIndent: true,
      indentUnit: 4, // 缩进单位为4
      extraKeys: {
        "'<'": this.completeAfter,
        "'/'": this.completeIfAfterLt,
        "' '": this.completeIfInTag,
        "'='": this.completeIfInTag,
        'Ctrl-Space': 'autocomplete'
      },
      // scrollbarStyle: 'overlay',
      hintOptions: { schemaInfo: tags },
      theme
    });
    const { width = 'auto', height } = this.props;
    this.XmlEditor.setSize(`${width}`, `${height}px`);
    //事件触发后执行事件
    this.XmlEditor.on('change', _.debounce(this.onChange, 600));
    // this.setValue(beautify.xml(this.props.xmlValue));
    this.setValue(this.props.xmlValue);
  }

  public onChange = () => {
    const xml = this.getValue();
    this.props.onChange(xml);
    // this.XmlEditor.showHint();
  };

  public setValue = (value: string) => {
    if (value) {
      this.XmlEditor.setValue(value);
    }
  };

  public getValue = () => {
    const xml = this.XmlEditor.getValue();
    return xml;
    // return beautify.xmlmin(xml);
  };

  public render() {
    return (
      <textarea
        style={{ fontSize: '14px', lineHeight: '1.5' }}
        ref={ref => {
          if (!this.xmlRef) {
            this.xmlRef = ref;
          }
        }}
      />
    );
  }
}

export default XmlEditor;
