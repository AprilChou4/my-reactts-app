import React, { FunctionComponent, Fragment } from 'react';
import { Pagination } from 'sup-ui';

import CustomPaging from '@components/CustomPaging';

import styles from './index.less';

interface IProps {
  count: number;
  pageInfo: any;
  handleChange: any;
  handleSizeChange: any;
  defaultCurrent?: number;
  pageSizeOptions?: string[];
}

const Paging: FunctionComponent<IProps> = (props: IProps) => {
  const {
    count,
    pageInfo,
    handleChange,
    handleSizeChange,
    defaultCurrent = 5,
    pageSizeOptions = ['5']
  } = props;

  return (
    <Fragment>
      {count ? (
        <div className={styles.paging}>
          <Pagination
            defaultCurrent={defaultCurrent}
            current={pageInfo.pageNum}
            pageSize={pageInfo.pageSize}
            showTotal={total => `共${total}条`}
            itemRender={CustomPaging}
            total={count}
            pageSizeOptions={pageSizeOptions}
            onChange={handleChange}
            onShowSizeChange={handleSizeChange}
            showSizeChanger
            showQuickJumper
          />
        </div>
      ) : null}
    </Fragment>
  );
};

export default Paging;
