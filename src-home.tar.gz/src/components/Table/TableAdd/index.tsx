/*
 * 点击可以添加行的table
 */

import React, { Component } from 'react';
import classnames from 'classnames';
import { Button, Table } from 'sup-ui';
import { isFunction } from 'lodash';

import styles from './index.less';

interface TableAddProps {
  addRowBtnProps?: {
    // btn 扩展options
    [propName: string]: any;
  };
  className?: string; // 样式
  isAddNewRow?: boolean; // 是否新增行,true - footer展示新增按钮,false - footer无不展示
  onNewRowAdd?: () => void; // 新增按钮点击事件
  [propName: string]: any;
}

interface TableAddState {}

class TableAdd extends Component<TableAddProps, TableAddState> {
  public constructor(props: TableAddProps) {
    super(props);
    this.state = {};
  }

  private addNewTableRow = () => {
    const {
      isAddNewRow,
      addRowBtnProps: { ...otherProps }
    } = this.props;

    return (
      isAddNewRow && (
        <Button
          className={styles['table_row-add']}
          block
          type="dashed"
          onClick={() => this.handleNewTableRowAdd()}
          {...otherProps}
        >
          + 新增
        </Button>
      )
    );
  };

  private handleNewTableRowAdd() {
    const { onNewRowAdd } = this.props;
    if (isFunction(onNewRowAdd)) {
      onNewRowAdd();
    }
  }

  public render() {
    const { className, ...otherProps } = this.props;

    return (
      <>
        <Table
          className={classnames(styles.tableFormEdit, className)}
          {...otherProps}
        />
        {this.addNewTableRow()}
      </>
    );
  }
}

export default TableAdd;
