import React, { useState } from 'react';
import DialogModel from '@components/Modal/Dialog';
import Icon from '@components/Icon';
import EditTable from '../../index';
/* 具体的页面 */
import { Button } from 'sup-ui';
import uuid from '@utils/uuid';
import { DATATYPE_SETS } from '@utils/datatype';
import VarValue from './VarValue';
import styles from '../style.less';

const Demo8 = () => {
  const data = [
    {
      id: '0',
      name: '0',
      constValue: '1.11',
      dataType: 'Double',
      sex: 'male'
    },
    {
      id: '1',
      name: '1',
      constValue: '1',
      dataType: 'Integer',
      sex: 'female'
    }
  ];
  const [form, setForm] = useState<any>({});
  const [dateSetVisible, setDateSetVisible] = useState(false);
  const [currentRecord, setCurrentRecord] = useState({});

  const [dataSource, setDataSource] = useState(data);

  const { getFieldDecorator } = form;

  // 更新行
  const handleUpdateRecord = (record: any) => {
    setDataSource(
      _.map(dataSource, item =>
        record.id === item.id
          ? {
              ...item,
              ...record
            }
          : item
      )
    );
  };
  // 单行操作保存
  const onRowSave = (row: any) => {
    const newData = [...dataSource];
    const index = newData.findIndex(item => row.id === item.id);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row
    });
    setDataSource(newData);
  };

  const columns = [
    {
      title: '序号',
      dataIndex: 'id',
      key: 'id',
      width: 100,
      align: 'center',
      render: (text: any, _record: any) => text
    },
    {
      key: 'name',
      title: '变量名',
      dataIndex: 'name',
      width: 150,
      editable: true,
      type: 'input',
      fieldDecorator: {
        rules: [{ required: true, message: '变量名不能为空' }]
      },
      config: {
        autoFocus: true
      }
    },
    {
      key: 'dataType',
      title: '变量类型',
      dataIndex: 'dataType',
      width: 120,
      editable: true,
      type: 'select',
      config: {
        defaultOpen: true,
        selectOptions: DATATYPE_SETS,
        onChange: (newRecord: any) => {
          handleUpdateRecord({ ...newRecord, constValue: '2022' });
        }
      }
    },
    // {
    //   key: 'constValue',
    //   title: '变量值',
    //   dataIndex: 'constValue',
    //   width: 200,
    //   editable: true,
    //   config: {
    //     autoFocus: true,
    //     fieldDecorator: {
    //       rules: [{ required: true, message: '变量值不能为空' }]
    //     }
    //   },
    //   renderText: (text: any) => {
    //     return <div>{text}</div>;
    //   },
    //   // isToggleEdit: false,
    //   render: (text: any, record: any, index, handler: any) => {
    //     return record.dataType !== 'Datetime' ? (
    //       <Input
    //         autoFocus={!!text}
    //         autoComplete="off"
    //         onChange={e => {
    //           setDataSource(
    //             _.map(dataSource, item => {
    //               return item.id === record.id
    //                 ? { ...item, constValue: e.target.value }
    //                 : item;
    //             })
    //           );
    //         }}
    //         onBlur={() => handler.onToggleEdit()}
    //       />
    //     ) : (
    //       <div>{text}</div>
    //     );
    //   }
    // },
    {
      key: 'constValue',
      title: '变量值1',
      dataIndex: 'constValue',
      width: 200,
      render: (text: any, record: any, index) => {
        return (
          getFieldDecorator && (
            <VarValue
              getFieldDecorator={getFieldDecorator}
              record={record}
              onChange={row => {
                setDataSource(
                  _.map(dataSource, item => {
                    return item.id === row.id ? { ...item, ...row } : item;
                  })
                );
              }}
            />
          )
        );
      }
    },
    {
      key: 'timeSetting',
      title: '',
      dataIndex: 'timeSetting',
      textAlign: 'center',
      render: (_text: string, record: any) => {
        return (
          record.dataType === 'Datetime' && (
            <Icon
              type="setting"
              onClick={() => {
                setDateSetVisible(true);
                setCurrentRecord(record);
              }}
            />
          )
        );
      }
    }
  ];

  const onAddRow = () => {
    const newData = {
      id: uuid(6),
      name: '',
      constValue: '',
      sex: 'female',
      dataType: 'String'
    };
    setDataSource([...dataSource, newData]);
  };

  const handleOk = () => {
    form?.validateFields((err: any) => {
      if (err) {
        return;
      }
      console.log(dataSource, '-handleOk-dataSource---');
    });
  };

  return (
    <div style={{ marginTop: 20, background: '#fff' }}>
      <div className={styles.title}>
        demo_07 任务开发-变量-变量配置--支持自己写Form.Item
      </div>
      <div>
        <Button
          onClick={onAddRow}
          type="primary"
          style={{ marginBottom: 16, marginRight: 16 }}
        >
          新增
        </Button>
        <Button onClick={handleOk} type="primary" style={{ marginBottom: 16 }}>
          保存
        </Button>
      </div>
      <EditTable
        columns={columns}
        dataSource={dataSource}
        onRowSave={onRowSave}
        pagination={false}
        rowKey="id"
        isToggleEdit
        getForm={(f: any) => setForm(f)}
      />

      <DialogModel
        title="日期格式"
        width={460}
        visible={dateSetVisible}
        maskClosable={false}
        onOk={() => {
          handleUpdateRecord({ ...currentRecord, constValue: '2022-06-20' });
          setDateSetVisible(false);
        }}
        onCancel={() => {
          setDateSetVisible(false);
        }}
      >
        1111
      </DialogModel>
    </div>
  );
};
export default Demo8;
