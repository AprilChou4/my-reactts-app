import React from 'react';
import Demo1 from './demo_01';
import Demo3 from './demo_03';
import Demo4 from './demo_04';
import Demo5 from './demo_05';
import Demo7 from './demo7';
const DemoWrap = () => {
  return (
    <div>
      <Demo1 />
      <Demo1 theme="light" />
      <Demo3 />
      <Demo4 />
      <Demo5 />
      <Demo7 />
    </div>
  );
};
export default DemoWrap;
