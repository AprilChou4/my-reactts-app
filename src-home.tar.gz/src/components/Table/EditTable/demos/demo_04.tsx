import React, { useState } from 'react';
import EditTable from '../index';
/* 具体的页面 */
import '../index.less';
import styles from './style.less';
import { TreeSelect } from 'sup-ui';
const { TreeNode } = TreeSelect;
const Demo4 = () => {
  const data = [
    {
      key: '0',
      name: 'Edward King 0',
      sex: 'male',
      gift: '1',
      address: 'London, Park Lane no. 0',
      depart: 'parent 1-0'
    },
    {
      key: '1',
      name: 'Edward King 1',
      sex: 'female',
      gift: '2',
      address: 'London, Park Lane no. 1',
      depart: 'sss'
    }
  ];

  const [dataSource, setDataSource] = useState(data);

  // 单行操作保存
  const onRowSave = (row: any) => {
    const newData = [...dataSource];
    const index = newData.findIndex(item => row.key === item.key);
    const item = newData[index];
    newData.splice(index, 1, {
      ...item,
      ...row
    });
    setDataSource(newData);
  };

  const columns = [
    {
      title: 'name',
      dataIndex: 'name',
      width: 300,
      editable: true,
      type: 'input',
      trigger: 'onBlur'
    },
    {
      title: 'depart-自定义component',
      dataIndex: 'depart',
      editable: true,
      type: 'component',
      // isToggleEdit: true,
      component: (
        <TreeSelect
          // defaultOpen
          // showSearch
          style={{ width: '100%' }}
          dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
          placeholder="Please select"
          allowClear
          treeDefaultExpandAll
        >
          <TreeNode value="parent 1" title="parent 1" key="0-1">
            <TreeNode value="parent 1-0" title="parent 1-0" key="0-1-1">
              <TreeNode value="leaf1" title="my leaf" key="random" />
              <TreeNode value="leaf2" title="your leaf" key="random1" />
            </TreeNode>
            <TreeNode value="parent 1-1" title="parent 1-1" key="random2">
              <TreeNode
                value="sss"
                title={<b style={{ color: '#08c' }}>sss</b>}
                key="random3"
              />
            </TreeNode>
          </TreeNode>
        </TreeSelect>
      )
    },
    {
      title: 'sex',
      dataIndex: 'sex',
      editable: true,
      type: 'select',
      isToggleEdit: true,
      config: {
        selectOptions: [
          { name: '男', key: 'male' },
          { name: '女', key: 'female' }
        ],
        keyName: 'key',
        valueName: 'name',
        defaultOpen: true,
        onChange: (record: any, value: any) => {
          const newData = _.map(dataSource, (item: any) => {
            return item.key === record.key
              ? {
                  ...item,
                  ...record,
                  gift: value === 'female' ? '口红' : '篮球'
                }
              : item;
          });
          setDataSource(newData);
        }
      }
    },
    {
      title: 'gift',
      dataIndex: 'gift'
    }
  ];

  return (
    <div style={{ marginTop: 20 }}>
      <div className={styles.title}>=======demo_04 自定义component</div>
      <EditTable
        columns={columns}
        dataSource={dataSource}
        onRowSave={onRowSave}
        pagination={false}
        rowKey="key"
      />
    </div>
  );
};
export default Demo4;
