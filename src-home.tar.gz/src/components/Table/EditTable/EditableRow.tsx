import React, { FC } from 'react';
import { Form } from 'sup-ui';
import EditableContext from './EditableContext';
import { FormComponentProps } from 'sup-ui/lib/form/Form';

interface IProps extends FormComponentProps {}

const EditableRow: FC<IProps> = (props: IProps) => {
  const { form, ...rest } = _.omit(props, ['moveRow']);
  return (
    <EditableContext.Provider value={form}>
      <tr {...rest} />
    </EditableContext.Provider>
  );
};
const EditableFormRow = Form.create<IProps>()(EditableRow);
export default EditableFormRow;
