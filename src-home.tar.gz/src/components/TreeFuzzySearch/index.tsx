import React, { Component } from 'react';
import { observer } from 'mobx-react';
import { Empty } from 'sup-ui';
import Icon from '@components/Icon';
import styles from './index.less';

//onChange回调value: item, {}, ''
interface ITreeProps {
  onChange: (value: any) => void; //选择结果
  onSearch: (value: string) => void; //模糊搜索回调
  dataSource: any; //搜索结果列表
  placeholder?: string;
}
interface ITreeState {
  visible: boolean;
  inputValue: string;
}

@observer
class TreeFuzzySearch extends Component<ITreeProps, ITreeState> {
  private readonly inputRef: any;
  private readonly debounceFuc: any;
  public constructor(props: ITreeProps) {
    super(props);
    this.state = {
      visible: false,
      inputValue: ''
    };

    this.debounceFuc = _.debounce(props.onSearch, 500);
    this.inputRef = React.createRef();
  }

  //input-change事件
  public handleInputChange = (e: any) => {
    this.setState({
      inputValue: e.target.value,
      visible: true
    });

    this.debounceFuc(e.target.value);
  };

  //enter事件
  public handleInputEnter = () => {
    const { inputValue } = this.state;
    this.setState({ visible: false }, () => {
      this.inputRef.current.blur();
    });

    if (!inputValue) {
      this.props.onChange('');
      return;
    }

    const target =
      _.find(this.props.dataSource, ['displayName', inputValue]) || {};

    //enter时没有匹配到item, 回传{}
    this.props.onChange(target);
  };

  //clear事件
  public handleInputClear = () => {
    this.setState(
      {
        inputValue: '',
        visible: false
      },
      () => {
        this.inputRef.current.blur();
      }
    );

    this.props.onChange('');
  };

  //blur事件
  public handleInputBlur = () => {
    if (!this.state.visible) return;

    this.handleInputEnter();
  };

  //focus事件
  public handleInputFocus = () => {
    const { dataSource } = this.props;
    const { inputValue } = this.state;

    if (dataSource.length > 0 && inputValue) {
      this.setState({ visible: true });
    }
  };

  //选择模板
  public handleItemClick = (item: any) => {
    this.setState(
      {
        inputValue: item.displayName,
        visible: false
      },
      () => {
        this.inputRef.current.blur();
      }
    );

    this.props.onChange(item);
  };

  public render() {
    const { visible, inputValue } = this.state;

    const { placeholder = '-请输入-', dataSource } = this.props;
    return (
      <div className={styles.container}>
        <div className={styles.searchBox}>
          <input
            ref={this.inputRef}
            onKeyPress={(e: any) => {
              e.charCode === 13 && this.handleInputEnter();
            }}
            onBlur={this.handleInputBlur}
            onFocus={this.handleInputFocus}
            value={inputValue}
            onChange={this.handleInputChange}
            type="text"
            placeholder={placeholder}
          />
          {inputValue && (
            <div
              className={styles.close}
              onMouseDown={(e: any) => e.preventDefault()}
            >
              <Icon
                type="close"
                fill="#ffffff"
                onClick={this.handleInputClear}
                width={12}
                height={12}
              />
            </div>
          )}
        </div>
        {visible && (
          <ul className={styles.dropdown}>
            {dataSource.length > 0 ? (
              dataSource.map((item: any) => (
                <li
                  key={item.id}
                  onMouseDown={(e: any) => e.preventDefault()}
                  onClick={() => this.handleItemClick(item)}
                >
                  {item.displayName}
                </li>
              ))
            ) : (
              <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} />
            )}
          </ul>
        )}
      </div>
    );
  }
}

export default TreeFuzzySearch;
