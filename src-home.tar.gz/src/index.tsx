import 'multi-tab-framework-jssdk';
import React, { Component, Suspense, lazy } from 'react';
import ReactDOM from 'react-dom';
import intl from 'react-intl-universal';
import { configure } from 'mobx';
import moment from 'moment';
import 'moment-duration-format';
import 'moment/locale/zh-cn';

const Root = lazy(() => import('./route/Root'));

/* must use action() to mutate observables */
configure({
  enforceActions: 'always'
});

window.PROJECT_LANG = 'zh_CN';

//国际化资源
const locales = {
  en_US: require('./locales/en_US.json'),
  zh_CN: require('./locales/zh_CN.json')
};
const momentLocalesMap: any = {
  en_US: 'en',
  zh_CN: 'zh-cn'
};

interface IProps {}
interface IState {
  initDone: boolean;
}

class App extends Component<IProps, IState> {
  public constructor(props: IProps) {
    super(props);
    this.state = {
      initDone: false
    };
  }

  public componentDidMount(): void {
    const PROJECT_LANG = window.PROJECT_LANG;

    intl
      .init({
        currentLocale: PROJECT_LANG,
        locales
      })
      .then(() => {
        moment.locale(momentLocalesMap[PROJECT_LANG]);
        this.setState({ initDone: true });
      });
  }
  public render() {
    const { initDone } = this.state;
    return (
      initDone && (
        <Suspense fallback={''}>
          <Root />
        </Suspense>
      )
    );
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
