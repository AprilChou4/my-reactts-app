import moment from 'moment';
import { getUserInfo, getGMTimeZone } from '@utils/common';

const isWin = process.env.SYSTEM === 'WIN';

export const getReqBaseHeader = () => {
  const ticket = localStorage.getItem('ticket');
  const language = localStorage.getItem('language');
  const userInfo = getUserInfo();

  return {
    Authorization: `Bearer ${ticket}`,
    'Accept-Language': language || 'zh-cn',
    Sequence: `${moment().format('YYYYMMDDHHmmssms')}${_.random(100, 999)}`,
    timezone: getGMTimeZone(),
    ...(isWin && { 'X-Login-Token': _.get(userInfo, 'token', '') })
  };
};
