const isWin = process.env.SYSTEM === 'WIN';

export const databaseList = [
  {
    name: '关系型数据源',
    key: 'sql',
    restype: 'sql',
    children: [
      {
        key: 'MySQL',
        name: 'My SQL',
        isDisable: false,
        subCatalog: 'mysql'
      },
      {
        key: 'SQLServer',
        name: 'SQL Server',
        isDisable: false,
        subCatalog: 'sqlserver'
      },
      // {
      //   key: 'PostgreSQL',
      //   name: 'PostgreSQL',
      //   isDisable: true
      // },
      {
        key: 'Oracle',
        name: 'Oracle',
        isDisable: false,
        subCatalog: 'oracle'
      },
      {
        key: 'Hive',
        name: 'Hive',
        isDisable: false,
        subCatalog: 'hive'
      },
      isWin && {
        key: 'Access',
        name: 'Access',
        isDisable: false,
        subCatalog: 'access'
      },
      isWin && {
        key: 'Paradox',
        name: 'Paradox',
        isDisable: false,
        subCatalog: 'paradox'
      }
      // {
      //   key: 'DM',
      //   name: 'DM',
      //   isDisable: true
      // },
      // {
      //   key: 'DRDS',
      //   name: 'DRDS',
      //   isDisable: true
      // },
      // {
      //   key: 'POLARDB',
      //   name: 'POLARDB',
      //   isDisable: true
      // },
      // {
      //   key: 'HybirdDB',
      //   name: 'HybirdDB for MySQL',
      //   isDisable: true
      // },
      // {
      //   key: 'AnalyticDBPostgreSQL',
      //   name: 'AnalyticDB for PostgreSQL',
      //   isDisable: true
      // },
      // {
      //   key: 'AnalyticDBMySQL3',
      //   name: 'AnalyticDB for MySQL 3.0',
      //   isDisable: true
      // }
    ].filter(Boolean)
  },
  {
    name: '接口数据源',
    key: 'api',
    restype: 'api',
    children: [
      {
        key: 'webservice',
        name: 'WebService',
        isDisable: false,
        subCatalog: 'webservice'
      },
      {
        key: 'restful',
        name: 'RESTful',
        isDisable: false,
        subCatalog: 'restful'
      }
      // {
      //   key: 'MaxCompute',
      //   name: 'MaxCompute(ODPS)',
      //   isDisable: true
      // },
      // {
      //   key: 'DataHub',
      //   name: 'DataHub',
      //   isDisable: true
      // },
      // {
      //   key: 'AnalyticDBforMySQL2',
      //   name: 'AnalyticDB for MySQL 2.0',
      //   isDisable: true
      // },
      // {
      //   key: 'Lighting',
      //   name: 'Lighting',
      //   isDisable: true
      // },
      // {
      //   key: 'DataLakeAnalytics',
      //   name: 'Data Lake Analytics(DLA)',
      //   isDisable: true
      // }
    ]
  },
  {
    name: '对象模型数据源',
    key: 'supos',
    restype: 'supos',
    children: [
      {
        key: 'model',
        name: 'supOS数据源',
        isDisable: false,
        subCatalog: 'model'
      }
    ]
  },
  {
    name: '文件数据源',
    key: 'file',
    restype: 'file',
    children: [
      {
        key: 'localFile',
        name: '本地和服务文件目录',
        isDisable: false,
        subCatalog: 'localfile'
      },
      // {
      //   key: 'OSS',
      //   name: 'OSS',
      //   isDisable: true
      // },
      {
        key: 'HDFS',
        name: 'HDFS',
        isDisable: false,
        subCatalog: 'hdfs'
      }
      // {
      //   key: 'FTP',
      //   name: 'FTP',
      //   isDisable: true
      // }
    ]
  }
  // {
  //   name: '消息中间件',
  //   key: 'mom',
  //   restype: 'mom',

  //   children: [
  //     {
  //       key: 'kafka',
  //       name: 'kafka',
  //       isDisable: true
  //     },
  //     {
  //       key: 'MongoDB',
  //       name: 'MongoDB',
  //       isDisable: false,
  //       subCatalog: 'mongodb'
  //     },
  //     {
  //       key: 'Memcache',
  //       name: 'Memcache(OCS)',
  //       isDisable: false,
  //       subCatalog: 'memcache'
  //     },
  //     {
  //       key: 'Redis',
  //       name: 'Redis',
  //       isDisable: false,
  //       subCatalog: 'redis'
  //     },
  //     {
  //       key: 'TableStore',
  //       name: 'Table Store(OTS)',
  //       isDisable: false,
  //       subCatalog: 'tablestore'
  //     }
  //   ]
  // }
];

export const sourceKinds = [
  {
    key: 1,
    value: 'sql',
    isDisable: false,
    name: '关系型数据源'
  },
  {
    key: 3,
    value: 'supos',
    isDisable: false,
    name: 'supOS实例'
  },
  {
    key: 4,
    value: 'file',
    isDisable: false,
    name: '文件数据源'
  },
  // {
  //   key: 5,
  //   value: 'mq',
  //   isDisable: true,
  //   name: '消息中间件'
  // },
  {
    key: 6,
    value: 'api',
    isDisable: false,
    name: 'API数据源'
  }
  // {
  //   key: 7,
  //   value: 'timeDB',
  //   isDisable: true,
  //   name: '时序数据源'
  // },
  // {
  //   key: 8,
  //   value: 'search',
  //   isDisable: true,
  //   name: '搜索引擎'
  // }
];

export const outputSourceKinds = [
  {
    key: 1,
    value: 'sql',
    isDisable: false,
    name: '关系型数据源'
  },
  {
    key: 10,
    value: 'wm',
    isDisable: false,
    name: '数据仓库'
  },
  {
    key: 3,
    value: 'supos',
    isDisable: false,
    name: 'supOS实例'
  },
  {
    key: 4,
    value: 'file',
    isDisable: false,
    name: '文件数据源'
  },
  // {
  //   key: 5,
  //   value: 'mq',
  //   isDisable: true,
  //   name: '消息中间件'
  // },
  {
    key: 6,
    value: 'api',
    isDisable: false,
    name: 'API数据源'
  }
  // {
  //   key: 7,
  //   value: 'timeDB',
  //   isDisable: true,
  //   name: '时序数据源'
  // },
  // {
  //   key: 8,
  //   value: 'search',
  //   isDisable: true,
  //   name: '搜索引擎'
  // }
];

export const sourceTypes = [
  {
    key: '1',
    value: 'sql'
  },
  {
    key: '2',
    value: 'nosql'
  },
  {
    key: '3',
    value: 'file'
  },
  {
    key: '4',
    value: 'ts'
  }
];

export const pluginServerData = [
  {
    name: '标准数据服务',
    restype: 'sds'
  },
  {
    name: 'PI',
    restype: 'pi'
  }
];

export const outputFileType = [
  {
    name: 'Excel2003',
    key: 'EXCEL03'
  },
  {
    name: 'Excel2007',
    key: 'EXCEL07'
  },
  {
    name: 'CSV',
    key: 'CSV'
  }
];

//  大类中包含的小类
const extraLogs = isWin ? ['access', 'paradox'] : [];
export const sqlSubCatalog = ['mysql', 'sqlserver', 'oracle', 'hive'].concat(
  extraLogs
);
export const fileSubCatalog = ['localfile', 'hdfs'];
export const apiSubCatalog = ['webservice', 'restful'];

//supos数据源 包含本地SupOS和远程SupOS
export const supOSList = ['本地supOS', '远程supOS'];
