import moment from 'moment';
const dateTimeTypeOptions = [
  {
    key: 11,
    label: '年份'
  },
  {
    key: 12,
    label: '日期'
  },
  {
    key: 13,
    label: '日期时间'
  },
  {
    key: 14,
    label: '时间'
  },
  {
    key: 2,
    label: '当天'
  },
  {
    key: 3,
    label: '近三天'
  },
  {
    key: 4,
    label: '当周'
  },
  {
    key: 5,
    label: '当月'
  },
  {
    key: 6,
    label: '当季度'
  },
  {
    key: 7,
    label: '当年'
  }
];

const dataTimeValue = [11, 12, 13, 14];

/**
 * @description: 季度
 */
const quarter = ['第一季度', '第二季度', '第三季度', '第四季度'];

//moment
const YEAR = moment().format('YYYY'); //本年
const MONTH = moment().format('MM'); //本月
const DATE = moment().format('YYYY-MM-DD'); //当前 年-月-日
const TIME = moment().format('HH:mm:ss'); //当前 时:分:秒
const DATE_TIME = `${DATE} ${TIME}`; //当前 年-月-日 时:分:秒

const statisticalAttrData = [
  {
    value: 'name',
    name: '名称'
  },
  {
    value: 'alias',
    name: '别名'
  }
];

const statisticalMethodData = [
  {
    value: 'summation',
    name: '求和'
  },
  {
    value: 'average',
    name: '平均'
  },
  {
    value: 'statistics',
    name: '计数统计'
  }
];

const timeDimension = [
  {
    value: 'day',
    name: '日'
  },
  {
    value: 'week',
    name: '周'
  },
  {
    value: 'month',
    name: '月'
  },
  {
    value: 'quarter',
    name: '季度'
  },
  {
    value: 'year',
    name: '年'
  }
];

export default {
  dateTimeTypeOptions,
  statisticalMethodData,
  statisticalAttrData,
  timeDimension,
  quarter,
  dataTimeValue,
  YEAR,
  MONTH,
  DATE,
  TIME,
  DATE_TIME
};
