export const nameRule = {
  pattern: /^[A-Za-z][A-Za-z0-9_]{0,199}$/,
  message: '只允许输入以字母开头，字母数字和_的组合名称，最长200字符'
};
export const indicatorNameRule = {
  pattern: /^[A-Za-z][A-Za-z0-9_]{0,49}$/,
  message: '只允许输入以字母开头，字母数字和_的组合名称，最长50字符'
};
//中文名
export const cnNameReg = {
  pattern: /^[\u4e00-\u9fa5a-zA-Z0-9_]{1,50}$/,
  message: '只允许输入中文、字母、数字、“_”的组合名称，最长50字符'
};
//数据格式===数据标准-质量管理有用
export const dataFormat: any[] = [
  { key: '10', showName: '自定义[正则表达式]', reg: '.*' },
  {
    key: '1',
    showName: '身份证',
    reg: '^[1-9]\\d{5}(18|19|20)\\d{2}((0[1-9])|(1[0-2]))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$'
  },
  { key: '2', showName: '手机号码', reg: '^1\\d{10}$' },
  { key: '3', showName: '固定电话', reg: '^\\d{3}-\\d{8}|\\d{4}-\\d{7}$' },
  { key: '4', showName: '电子邮箱', reg: '^\\S+@\\S+$' },
  {
    key: '5',
    showName: 'IP地址',
    reg: '^((0{0,2}\\d|0?\\d{2}|1\\d{2}|2[0-4]\\d|25[0-5])\\.){3}(0{0,2}\\d|0?\\d{2}|1\\d{2}|2[0-4]\\d|25[0-5])$'
  },
  { key: '6', showName: '年份', sample: 'YYYY', reg: '^\\d{4}$' },
  {
    key: '7',
    showName: '月份',
    sample: 'YYYY-MM 或 YYYY/MM 或 YYYYMM',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])$'
  },
  {
    key: '8',
    showName: '日期',
    sample: 'YYYY-MM-DD 或 YYYY/MM/DD 或 YYYYMMDD',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])\\1(0[1-9]|[12][0-9]|3[01])$'
  },
  {
    key: '9',
    showName: '时间',
    sample: 'YYYY-MM-DD HH:mm:ss 或 YYYY/MM/DD HH:mm:ss 或 YYYYMMDD HH:mm:ss',
    reg: '^\\d{4}(-|\\/|)(0[1-9]|1[0-2])\\1(0[1-9]|[12][0-9]|3[01]) ([01][0-9]|[2][0-3])(:[0-5][0-9]){2}$'
  }
];
