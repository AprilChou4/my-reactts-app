//调度
const startMinOption: any[] = [];
const endMinOption: any[] = [];
const hourGap: any[] = [];
for (let i = 0; i < 24; i++) {
  startMinOption.push({
    key: i,
    name: `${i}:00`,
    disabled: false
  });
  endMinOption.push({
    key: i,
    name: `${i}:59`,
    disabled: false
  });
  hourGap.push({
    key: i,
    name: i
  });
}
const minGap: any[] = [];
for (let j = 0; j <= 30; j++) {
  if (60 % j === 0) {
    minGap.push({
      key: j,
      name: j
    });
  }
}

//小时
const hourTimeData: any = [];
for (let i = 0; i < 24; i++) {
  hourTimeData.push({ key: `${i}:00`, name: `${i}:00` });
}

//指定 日
const dayConfig: any[] = [];
for (let i = 0; i < 24; i++) {
  dayConfig.push({
    key: `${i}:00`,
    name: `${i}:00`
  });
}

//指定周
const configAssign = [
  {
    key: '2',
    name: '周一'
  },
  {
    key: '3',
    name: '周二'
  },
  {
    key: '4',
    name: '周三'
  },
  {
    key: '5',
    name: '周四'
  },
  {
    key: '6',
    name: '周五'
  },
  {
    key: '7',
    name: '周六'
  },
  {
    key: '1',
    name: '周日'
  }
];

//指定月
const monthAss: any[] = [];
for (let j = 1; j <= 31; j++) {
  monthAss.push({
    key: j,
    name: `${j}日`
  });
}

const cycle = [
  {
    value: 'minute',
    name: '分钟'
  },
  {
    value: 'hour',
    name: ' 小时'
  },
  {
    value: 'day',
    name: ' 日'
  },
  {
    value: 'week',
    name: ' 周'
  },
  {
    value: 'month',
    name: ' 月'
  },
  {
    value: 'customize',
    name: '自定义'
  }
];

export {
  startMinOption,
  endMinOption,
  hourGap,
  minGap,
  cycle,
  hourTimeData,
  dayConfig,
  configAssign,
  monthAss
};
